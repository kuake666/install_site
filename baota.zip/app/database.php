<?php
/*数据库配置*/
$dbconfig=array(
	'dbhost' => 'localhost', //数据库服务器
	'dbport' => 3306, //数据库端口
	'dbuser' => '', //数据库用户名
	'dbpwd' => '', //数据库密码
	'dbname' => '' //数据库名
);
?>