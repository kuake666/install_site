<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------


function curlGet($url)
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn; R815T Build/JOP40D) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/4.5 Mobile Safari/533.1');
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $content = curl_exec($ch);
    curl_close($ch);
    return ($content);
}

/**
 * @Description TODO 校验字符是否存在
 * @Author 79517721@qq.com
 * @param
 * @param null
 * @return
 * @Date 2020/2/8 3:37
 */
function strexists($string, $find)
{
    return !(strpos($string, $find) === FALSE);
}

/**
 * @Description TODO 过滤参数
 * @Author 79517721@qq.com
 * @param
 * @param null
 * @return
 * @Date 2020/2/8 3:37
 */
function daddslashes($string, $force = 0, $strip = FALSE)
{
    !defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());
    if (!MAGIC_QUOTES_GPC || $force) {
        if (is_array($string)) {
            foreach ($string as $key => $val) {
                $string[$key] = daddslashes($val, $force, $strip);
            }
        } else {
            $string = addslashes($strip ? stripslashes($string) : $string);
        }
    }
    return $string;
}

/**
 * @Description TODO 获取访问者IP
 * @Author 79517721@qq.com
 * @Date 2020/2/8 3:38
 */
function realIp()
{
    $ip = $_SERVER['REMOTE_ADDR'];
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {
        foreach ($matches[0] AS $xip) {
            if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {
                $ip = $xip;
                break;
            }
        }
    } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_REAL_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    }
    return $ip;
}

/**
 * @Description TODO 根据IP获取地址
 * @Author 79517721@qq.com
 * @param $cip
 * @Date 2020/2/8 3:38
 * @Date 2020/3/27 8:20 修复
 */
function getCityByIp($cip)
{
    $url = "http://whois.pconline.com.cn/ipJson.jsp?json=true&ip=" . $cip;
    $url = mb_convert_encoding(file_get_contents($url), "UTF-8", "gb2312");
    if ($ipinfo = json_decode($url, true)) {
        if ($ipinfo['city'] != null) {
            $city['city'] = $ipinfo['city'];
        } else if ($ipinfo['pro'] != null) {
            $city['city'] = $ipinfo['pro'];
        } else if ($ipinfo['addr'] != null) {
            $city['city'] = $ipinfo['addr'];
        } else {
            $city['city'] = '未知地点';
        }
        return $city;
    } else {
        $city['city'] = '未知地点';
        return $city;
    }
}

/**
 * author: 79517721@qq.com
 * time:2020/1/2 20:58
 * description:TODO 保存日志信息
 * @param $_pdo
 * @param $userId
 * @param $type
 */
function saveLog($userId, $type)
{
    global $DB;
    $ip = realIp();
    $city = getCityByIp($ip);
    $city = $city['city'];
    $date = date("Y-m-d H:i:s");
    $DB->exec("INSERT INTO `wcms_log` (`uid`,`type`,`date`,`city`,`data`) VALUES ('{$userId}','{$type}','{$date}','{$city}','{$ip}')");
}

/**
 * author: 79517721@qq.com
 * time:2020/2/12 22:18
 * description:TODO 邮件模板
 * @param $title
 * @param $type
 * @param $msg
 * @return string
 */
function emailWritting($title, $type, $msg)
{
    return '
    <meta charset="UTF-8">
<title>' . $title . '</title>
<!-- App css -->
<link href="https://kuake.coding.net/p/static/d/static/git/raw/master/baota/css/icons.css" type="text/css">
<link href="https://kuake.coding.net/p/static/d/static/git/raw/master/baota/css/metisMenu.min.css" type="text/css">
<link href="https://kuake.coding.net/p/static/d/static/git/raw/master/baota/css/style.css" type="text/css">
<!-- Page Content-->
<div class="page-content ">
    <div class="container-fluid">
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-lg-12">
                <table class="body-wrap"
                       style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; background-color: #eaf0f7; margin: 0;"
                       bgcolor="#eaf0f7">
                    <tbody>
                    <tr>
                        <td class="container"
                            style=" display: block !important; max-width: 600px !important; clear: both !important; "
                            width="600" valign="top">
                            <div class="content" style="padding: 20px;">
                                <table class="main" style="border: 1px solid #e9e9e9;" width="100%" cellspacing="0"
                                       cellpadding="0" bgcolor="#fff">
                                    <tbody>
                                    <tr>
                                        <td class="alert alert-dark border-0"
                                            style="color:#ffffff; background-color: #212f56; padding: 20px; border-radius: 0;"
                                            valign="top" align="center">
                                            <b>' . $title . '</b>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="content-wrap" style="padding: 20px;" valign="top">
                                            <table width="100%" cellspacing="0" cellpadding="0">
                                                <tbody>
                                                <tr>
                                                    <td class="content-block"
                                                        style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size: 14px; padding: 10px"
                                                        valign="top">
                                                        您正在进行[ ' . $type . ' ]操作,如果不是您本人操作,请忽略本邮件.
                                                    </td>
                                                </tr>
                                                <tr>
                                                   <!-- <td class="content-block"
                                                        style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size: 14px; padding: 10px 10px 20px;"
                                                        valign="top">
                                                        Add your credit card now to upgrade your account to a premium
                                                        plan to ensure you don\'t miss out on any reports.
                                                    </td>-->
                                                </tr>
                                                <tr>
                                                    <td class="content-block"
                                                        style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size: 14px; padding: 0 0 20px;"
                                                        valign="top"> 
                                                        <font size="4"><span style="color: rgb(0, 0, 255);"><span
                                                                    style="font-weight: bold;"><span
                                                                        style="font-size: 14px; text-decoration: none; line-height: 2em; text-align: center; cursor: pointer; display: block; border-radius: 5px; text-transform: capitalize; background-color: rgb(77, 121, 246); border-color: rgb(77, 121, 246); padding: 8px 0px;"
                                                                        class="btn-primary">' . $msg . '</span></span></span></font>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="content-block"
                                                        style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size: 14px; text-align: center;"
                                                        valign="top">
                                                         <b>' . $title . ' 版权所有</b>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </td>
                        <td style="font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;"
                            valign="top"><br></td>
                    </tr>
                    </tbody>
                </table><!--end table-->
            </div><!--end col-->
        </div><!--end row-->

    </div><!-- container -->

    <!--end footer-->
</div>
<!-- end page content -->

  
    ';
}


/**
 * author: 79517721@qq.com
 * time:2020/1/2 20:59
 * description:TODO 发送邮件
 * @param $to
 * @param $title
 * @param $html
 * @param $config
 * @return bool|string
 */
function sendEmail($to, $sub, $msg)
{
    global $conf;
    if ($conf['mail_cloud'] == 1) {
        $url = 'http://api.sendcloud.net/apiv2/mail/send';
        $data = array(
            'apiUser' => $conf['mail_apiuser'],
            'apiKey' => $conf['mail_apikey'],
            'from' => $conf['mail_name'],
            'fromName' => $conf['web_name'],
            'to' => $to,
            'subject' => $sub,
            'html' => $msg);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $json = curl_exec($ch);
        curl_close($ch);
        $arr = json_decode($json, true);
        if ($arr['statusCode'] == 200) {
            return true;
        } else {
            return implode("\n", $arr['message']);
        }
    } else {
        if (!function_exists("openssl_sign") && $conf['mail_port'] == 465) {
            $mail_api = 'http://1.mail.qqzzz.net/';
        }
        if ($mail_api) {
            $post[sendto] = $to;
            $post[title] = $sub;
            $post[content] = $msg;
            $post[user] = $conf['mail_name'];
            $post[pwd] = $conf['mail_pwd'];
            $post[nick] = $conf['web_name'];
            $post[host] = $conf['mail_smtp'];
            $post[port] = $conf['mail_port'];
            $post[ssl] = $conf['mail_port'] == 465 ? 1 : 0;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $mail_api);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $ret = curl_exec($ch);
            curl_close($ch);
            if ($ret == '1') return true;
            else return $ret;
        } else {
            include_once ROOT . 'app/smtp.class.php';
            $From = $conf['mail_name'];
            $Host = $conf['mail_smtp'];
            $Port = $conf['mail_port'];
            $SMTPAuth = 1;
            $Username = $conf['mail_name'];
            $Password = $conf['mail_pwd'];
            $Nickname = $conf['web_name'];
            $SSL = $conf['mail_port'] == 465 ? 1 : 0;
            $mail = new SMTP($Host, $Port, $SMTPAuth, $Username, $Password, $SSL);
            $mail->att = array();
            if ($mail->send($to, $From, $sub, $msg, $Nickname)) {
                return true;
            } else {
                return $mail->log;
            }
        }
    }
}

/**
 * author: 79517721@qq.com
 * time:2020/2/12 22:20
 * description:TODO 访问URL
 * @param $url
 * @param int $post
 * @param int $referer
 * @param int $cookie
 * @param int $header
 * @param int $ua
 * @param int $nobaody
 * @return bool|string
 */
function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $httpheader[] = "Accept: */*";
    $httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
    $httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
    $httpheader[] = "Connection: close";
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
    if ($header) {
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    if ($referer) {
        if ($referer == 1) {
            curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
        } else {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
    }
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);
    }
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}

//检测移动端
function checkmobile()
{
    $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
    $ualist = array('android', 'midp', 'nokia', 'mobile', 'iphone', 'ipod', 'blackberry', 'windows phone');
    if ((dstrpos($useragent, $ualist) || strexists($_SERVER['HTTP_ACCEPT'], "VND.WAP") || strexists($_SERVER['HTTP_VIA'], "wap")))
        return true;
    else
        return false;
}

function dstrpos($string, $arr)
{
    if (empty($string)) return false;
    foreach ((array)$arr as $v) {
        if (strpos($string, $v) !== false) {
            return true;
        }
    }
    return false;
}


function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0)
{
    $ckey_length = 4;
    $key = md5($key ? $key : ENCRYPT_KEY);
    $keya = md5(substr($key, 0, 16));
    $keyb = md5(substr($key, 16, 16));
    $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length) : substr(md5(microtime()), -$ckey_length)) : '';
    $cryptkey = $keya . md5($keya . $keyc);
    $key_length = strlen($cryptkey);
    $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string . $keyb), 0, 16) . $string;
    $string_length = strlen($string);
    $result = '';
    $box = range(0, 255);
    $rndkey = array();
    for ($i = 0; $i <= 255; $i++) {
        $rndkey[$i] = ord($cryptkey[$i % $key_length]);
    }
    for ($j = $i = 0; $i < 256; $i++) {
        $j = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }
    for ($a = $j = $i = 0; $i < $string_length; $i++) {
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
    }
    if ($operation == 'DECODE') {
        if ((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26) . $keyb), 0, 16)) {
            return substr($result, 26);
        } else {
            return '';
        }
    } else {
        return $keyc . str_replace('=', '', base64_encode($result));
    }
}

/**
 * author: 79517721@qq.com
 * time:2020/1/5 21:43
 * description:TODO 获取随机字符串
 * @param int $len
 * @param int $type
 * @return string
 */
function getRandStr($len = 5, $type = 0)
{
    $str = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $strlen = strlen($str);
    $randstr = '';
    for ($i = 0; $i < $len; $i++) {
        $randstr .= $str[mt_rand(0, $strlen - 1)];
    }
    if ($type == 1) {
        $randstr = strtoupper($randstr);
    } elseif ($type == 2) {
        $randstr = strtolower($randstr);
    }
    return $randstr;
}

/**
 * @Description TODO 生成随机字符
 * @Author 79517721@qq.com
 * @param  $length
 * @Date 2020/2/8 3:39
 */
function random($length, $numeric = 0)
{
    $seed = base_convert(md5(microtime() . $_SERVER['DOCUMENT_ROOT']), 16, $numeric ? 10 : 35);
    $seed = $numeric ? (str_replace('0', '', $seed) . '012340567890') : ($seed . 'zZ' . strtoupper($seed));
    $hash = '';
    $max = strlen($seed) - 1;
    for ($i = 0; $i < $length; $i++) {
        $hash .= $seed{mt_rand(0, $max)};
    }
    return $hash;
}


/**
 * author: 79517721@qq.com
 * time:2020/2/12 22:21
 * description:TODO 提示信息
 * @param string $msg
 * @param bool $die
 */
function sysmsg($msg = '未知的异常', $die = true)
{
    ?>
    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>站点提示信息</title>
        <style type="text/css">
            html {
                background: #eee
            }

            body {
                background: #fff;
                color: #333;
                font-family: "微软雅黑", "Microsoft YaHei", sans-serif;
                margin: 2em auto;
                padding: 1em 2em;
                max-width: 700px;
                -webkit-box-shadow: 10px 10px 10px rgba(0, 0, 0, .13);
                box-shadow: 10px 10px 10px rgba(0, 0, 0, .13);
                opacity: .8
            }

            h1 {
                border-bottom: 1px solid #dadada;
                clear: both;
                color: #666;
                font: 24px "微软雅黑", "Microsoft YaHei",, sans-serif;
                margin: 30px 0 0 0;
                padding: 0;
                padding-bottom: 7px
            }

            #error-page {
                margin-top: 50px
            }

            h3 {
                text-align: center
            }

            #error-page p {
                font-size: 9px;
                line-height: 1.5;
                margin: 25px 0 20px
            }

            #error-page code {
                font-family: Consolas, Monaco, monospace
            }

            ul li {
                margin-bottom: 10px;
                font-size: 9px
            }

            a {
                color: #21759B;
                text-decoration: none;
                margin-top: -10px
            }

            a:hover {
                color: #D54E21
            }

            .button {
                background: #f7f7f7;
                border: 1px solid #ccc;
                color: #555;
                display: inline-block;
                text-decoration: none;
                font-size: 9px;
                line-height: 26px;
                height: 28px;
                margin: 0;
                padding: 0 10px 1px;
                cursor: pointer;
                -webkit-border-radius: 3px;
                -webkit-appearance: none;
                border-radius: 3px;
                white-space: nowrap;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                -webkit-box-shadow: inset 0 1px 0 #fff, 0 1px 0 rgba(0, 0, 0, .08);
                box-shadow: inset 0 1px 0 #fff, 0 1px 0 rgba(0, 0, 0, .08);
                vertical-align: top
            }

            .button.button-large {
                height: 29px;
                line-height: 28px;
                padding: 0 12px
            }

            .button:focus, .button:hover {
                background: #fafafa;
                border-color: #999;
                color: #222
            }

            .button:focus {
                -webkit-box-shadow: 1px 1px 1px rgba(0, 0, 0, .2);
                box-shadow: 1px 1px 1px rgba(0, 0, 0, .2)
            }

            .button:active {
                background: #eee;
                border-color: #999;
                color: #333;
                -webkit-box-shadow: inset 0 2px 5px -3px rgba(0, 0, 0, .5);
                box-shadow: inset 0 2px 5px -3px rgba(0, 0, 0, .5)
            }

            table {
                table-layout: auto;
                border: 1px solid #333;
                empty-cells: show;
                border-collapse: collapse
            }

            th {
                padding: 4px;
                border: 1px solid #333;
                overflow: hidden;
                color: #333;
                background: #eee
            }

            td {
                padding: 4px;
                border: 1px solid #333;
                overflow: hidden;
                color: #333
            }
        </style>
    </head>
    <body id="error-page">
    <?php echo '<h3>站点提示信息</h3>';
    echo $msg; ?>
    </body>
    </html>
    <?php
    if ($die == true) {
        exit;
    }
}

?>