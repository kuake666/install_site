<?php
/**
 * author: 79517721@qq.com
 * time:2020/03/06 21:21
 * description:TODO 主机处理类自定义错误提示信息 [暂未启用]
 * Class: host
 */
$GLOBALS['error500'] ="ep面板3312产品配置错误或对接填写错误或域名填写错误或域名已存在";//500错误提示信息
$GLOBALS['errorOther'] ="连接kangle失败，请查看对接";//500错误提示信息
