<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
/**
 * @Description TODO API分站对接使用接口
 * @Author 79517721@qq.com
 * @Date 2020/2/8 4:00
 */

include('../app/common.php');


if(isset($_COOKIE['apiCookie'])) {
    $result = array("code" => -1, "msg" => "刷新太快了,服务器在赶来的路上...");
    echo json_encode($result);
    exit;
}
setcookie("apiCookie","value",time()+3);


$type = trim(strip_tags(daddslashes($_GET['type'])));
$api_key = trim(strip_tags(daddslashes($_GET['api_key'])));
$serverId = trim(strip_tags(daddslashes($_GET['serverid'])));
$pid = trim(strip_tags(daddslashes($_GET['pid'])));
$domain = trim(strip_tags(daddslashes($_GET['domain'])));

$result = api($type, $api_key, $serverId, $pid, $domain);

exit(json_encode($result));

