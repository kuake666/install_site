#插件安装sql
