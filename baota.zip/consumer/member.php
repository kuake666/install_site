<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

$list = $DB->query("SELECT * FROM `wcms_member` WHERE `mcode`!=10000 and `mcode`!=100 order by mcode asc")->fetchAll();
$numrows = $DB->query("SELECT * from `wcms_member` WHERE 1")->rowCount();
?>

<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">在线商城</a></li>
                            <li class="breadcrumb-item active">会员商城</li>
                        </ol>
                    </div>
                    <h4 class="page-title">会员商城</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="row">
                <?php
                foreach ($list as $res) {
                    if ($res['mcode'] <= $userrow['mcode']) {
                        $result = '<button class="btn btn-block  btn-success btn-square btn-skew  btn-outline-dashed mt-3 py-3 font-18" onclick="buyMember1()">
                                        <span>拥有</span>
                                     </button>';
                    } else {
                        $result = '<button class="btn btn-block  btn-secondary btn-square btn-skew btn-outline-dashed mt-3 py-3 font-18" onclick="buyMember(' . $res['mid'] . ')">
                                        <span>购买</span>
                                     </button>';
                    }
                    echo '  
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <span class="badge badge-pink a-animate-blink mt-0">新品上线</span>
                                <div class="pricingTable1 text-center">
                                    <h6 class="title1 py-3 m-0">' . $res['mname'] . '</h6>
        
                                    <div class="text-center py-1">
                                        <h3 class="amount">￥ ' . $res['mprice'] . '</h3>
                                    </div>
                                    <ul class="list-unstyled pricing-content-2 py-3 border-0">
                                    ' . $res['mdecription'] . '
                                       <!-- <li>会员介绍哒哒哒啊</li>
                                        <li>会员介绍呱呱呱呱呱呱哈哈哈哈</li>
                                        <li>会员介绍123123123哒哒哒啊啊</li>
                                        <li>会员介绍41123123123dd顶顶顶</li>-->
                                        
                                        
                                    </ul>
                                    ' . $result . '
                                </div><!--end pricingTable-->
                            </div><!--end card-body-->
                        </div> <!--end card-->
                    </div><!--end col-->
                ';
                } ?>
            </div><!--end row-->
        </div><!-- container -->

        <?php
        include('footer.php');
        ?>

        <script>
            function buyMember1() {
                layer.alert("您已经获得此身份,无需重复购买");
                return false;
            }

            function buyMember(mid) {
                var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
                $.ajax({
                    url: "ajax.php?act=buyMember",
                    type: 'POST',
                    dataType: 'json',
                    data: {mid: mid},
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = data.url;
                            });
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.close(ii);
                        layer.alert("网络连接错误");
                    }
                });
            }
        </script>
