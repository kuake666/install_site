<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include '../app/common.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title><?php echo $conf['web_name'] ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A premium admin dashboard template by kuake79517721" name="description"/>
    <meta content="kuake79517721" name="kuake79517721"/>
    <!-- App favicon -->
    <link rel="shortcut icon" href="../assets/images/favicon.ico">

    <!-- App css -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/metisMenu.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>

</head>

<body class="account-body accountbg">

<!-- Log In page -->
<div class="row vh-100 ">
    <div class="col-12 align-self-center">
        <div class="auth-page">
            <div class="card auth-card shadow-lg">
                <div class="card-body">
                    <div class="px-3">
                        <div class="auth-logo-box">
                            <a href="recoverPass.php" class="logo logo-admin"><img src="../assets/images/logo-sm.png"
                                                                                   height="55" alt="logo"
                                                                                   class="auth-logo"></a>
                        </div><!--end auth-logo-box-->

                        <div class="text-center auth-logo-text">
                            <h4 class="mt-0 mb-3 mt-5">邮箱找回密码</h4>
                            <p class="text-muted mb-0">系统将在3分钟发送验证码到您的邮箱</p>
                        </div> <!--end auth-logo-text-->


                        <form class="form-horizontal auth-form my-4" action="index.php">

                            <div class="form-group">
                                <label for="useremail">用户邮箱</label>
                                <div class="input-group mb-3">
                                            <span class="auth-form-icon">
                                                <i class="dripicons-mail"></i> 
                                            </span>
                                    <input type="email" class="form-control" id="useremail" placeholder="请输入账户绑定的邮箱">
                                </div>
                            </div><!--end form-group-->

                            <div class="input-group">
                                <input type="text" id="code" placeholder="请输入邮箱验证码" class="form-control no-border">&nbsp;&nbsp;
                                <button class="btn btn-primary font-2" id="sendCode" type="button">发送验证码</button>
                            </div>

                            <div class="form-group mb-0 row">
                                <div class="col-12 mt-2">
                                    <button class="btn btn-success btn-round btn-block waves-effect waves-light"
                                            type="button" id="recoverPass">立即找回 <i class="fas fa-sign-in-alt ml-1"></i>
                                    </button>
                                </div><!--end col-->
                            </div> <!--end form-group-->
                        </form><!--end form-->
                    </div><!--end /div-->

                    <div class="m-3 text-center text-muted">
                        <p class="">记得账号密码 ? <a href="login.php" class="text-primary ml-2">立即登录</a></p>
                    </div>
                </div><!--end card-body-->
            </div><!--end card-->
        </div><!--end auth-page-->
    </div><!--end col-->
</div><!--end row-->
<!-- End Log In page -->

<!-- jQuery  -->
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/metisMenu.min.js"></script>
<script src="../assets/js/waves.min.js"></script>
<script src="../assets/js/jquery.slimscroll.min.js"></script>

<!-- App js -->
<script src="../assets/js/app.js"></script>

<!--引入layer-->
<script src="../assets/js/layer/layer.js"></script>
<script>
    $("#sendCode").click(function () {
        var email = $("#useremail").val();
        if (email == '') {
            layer.alert('邮箱不能为空！');
            return false;
        }
        var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
        if (!reg.test(email)) {
            layer.alert('邮箱格式不正确！');
            return false;
        }
        layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
        $.ajax({
            url: './auth.php?act=sendCode',
            type: 'POST',
            dataType: 'json',
            data: {email: email},
            success: function (data) {
                if (data.code == 1) {
                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4});
                } else {
                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                }
            },
            error: function () {
                layer.alert("网络连接错误");
                return false;
            }
        });

    });

    $("#recoverPass").click(function () {
        var email = $("#useremail").val();
        var code =  $("#code").val();
        if (email == '') {
            layer.alert('邮箱不能为空！');
            return false;
        }
        var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
        if (!reg.test(email)) {
            layer.alert('邮箱格式不正确！');
            return false;
        }
        layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
        $.ajax({
            url: './auth.php?act=recoverPass',
            type: 'POST',
            dataType: 'json',
            data: {email: email, code: code},
            success: function (data) {
                if (data.code == 1) {
                    layer.msg(data.msg, {icon: 1, time: 5000, shade: 0.4},function () {
                        location.href='login.php';
                    });
                } else {
                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                }
            },
            error: function () {
                layer.alert("网络连接错误");
            }
        });

    })

</script>
</body>
