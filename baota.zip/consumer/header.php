<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include '../app/common.php';
if ($islogin2 == 1) {
} else exit("<script language='javascript'>window.location.href='./login.php';</script>");
if($userrow['status'] == 0){
    setcookie("user_token", "", time() - 604800);
    echo sysmsg("当前用户因违背本站使用协议,已被管理员暂停使用权限,有问题请联系管理员。");
    exit;
}

if(!isset($_SESSION['menuList'])){
    $menuList=$DB->query("SELECT * FROM  `wcms_menu`  where `status`= 1  and `parentid`=0 order by `id` asc")->fetchAll();
    $_SESSION["menuList"] = $menuList;
}else{
    $menuList = $_SESSION["menuList"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title><?php echo $conf['web_name'] ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A premium admin dashboard template by Mannatthemes" name="description"/>
    <meta content="Mannatthemes" name="author"/>

    <!-- App favicon -->
    <link rel="shortcut icon" href="../assets/img/favicon.ico?r=<?php echo rand(10000,99999)?>">
    <link href="../assets/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css"/>
    <!-- Responsive datatable examples -->
    <link href="../assets/plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css"/>

    <!-- App css -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/metisMenu.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>

</head>

<body>

<!-- Top Bar Start -->
<div class="topbar">

    <!-- LOGO -->
    <div class="topbar-left">
        <a href="index.php" class="logo">
            <span>
               <img src="../assets/images/logo-sm.png" alt="logo-small" class="logo-sm">
            </span>
            <span>
               <img src="../assets/images/logo-dark.png" alt="logo-large" class="logo-lg">
            </span>
        </a>
    </div>
    <!--end logo-->
    <!-- Navbar -->
    <nav class="navbar-custom">
        <ul class="list-unstyled topbar-nav float-right mb-0">
            <li class="hidden-sm">
                <div class="crypto-balance">
                    <i class="dripicons-wallet text-muted align-self-center"></i>
                    <div class="btc-balance">
                        <h5 class="m-0"><?php echo $userrow['money'] ?> <span>元</span></h5>
                        <span class="text-muted">账户余额</span>
                    </div>
                </div>
            </li>

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle arrow-none waves-light waves-effect" data-toggle="dropdown" href="#"
                   role="button"
                   aria-haspopup="false" aria-expanded="false">
                    <i class="dripicons-bell noti-icon"></i>
                    <span class="badge badge-danger badge-pill noti-icon-badge">2</span>
                </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-lg">
                    <!-- item-->
                    <h6 class="dropdown-item-text">
                        系统通知 (2)
                    </h6>
                    <div class="slimscroll notification-list">
                        <!-- item-->
                        <a href="message.php" class="dropdown-item notify-item">
                            <div class="notify-icon bg-warning"><i class="mdi mdi-message"></i></div>
                            <p class="notify-details">模板商城启用<small class="text-muted">模板商城上线启用</small></p>
                        </a>
                        <!-- item-->
                        <a href="message.php" class="dropdown-item notify-item">
                            <div class="notify-icon bg-success"><i class="mdi mdi-glass-cocktail"></i></div>
                            <p class="notify-details">系统上线<small class="text-muted">开始上线使用</small></p>
                        </a>
                    </div>
                    <!-- All-->
                    <a href="message.php" class="dropdown-item text-center text-primary">
                        查看所有 <i class="fi-arrow-right"></i>
                    </a>
                </div>
            </li>

            <li class="dropdown">
                <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#"
                   role="button"
                   aria-haspopup="false" aria-expanded="false">
                    <img src="../assets/images/users/user-img.svg" alt="profile-user" class="rounded-circle"/>
                    <span class="ml-1 nav-user-name hidden-sm"><?php echo $userrow['nickname'] ?> <i
                                class="mdi mdi-chevron-down"></i> </span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <?php if($userrow['mcode'] == 10000){?>
                        <a class="dropdown-item" href="../manage/index.php"><i class="fas fa-box  text-muted mr-2"></i> 后台管理</a>
                    <?php }?>
                    <a class="dropdown-item" href="info.php"><i class="dripicons-user text-muted mr-2"></i> 用户中心</a>
                    <a class="dropdown-item" href="program.php"><i class="dripicons-wallet text-muted mr-2"></i>
                        模板商城</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="javascript:logout()"><i class="dripicons-exit text-muted mr-2"></i>
                        注销登录</a>
                </div>
            </li>
        </ul><!--end topbar-nav-->

        <ul class="list-unstyled topbar-nav mb-0">
            <li>
                <button class="button-menu-mobile nav-link waves-effect waves-light">
                    <i class="dripicons-menu nav-icon"></i>
                </button>
            </li>
            <li class="hide-phone app-search">
                <form role="search" class="">
                    <input type="text" placeholder="search" class="form-control">
                    <a href="https://www.baidu.com/baidu?wd=<?php echo $conf['web_name']; ?>&tn=monline_3_dg&ie=utf-8"
                       target="_blank"><i class="fas fa-search"></i></a>
                </form>
            </li>
        </ul>
    </nav>
    <!-- end navbar-->
</div>
<!-- Top Bar End -->


<div class="page-wrapper">
    <!-- Left Sidenav -->
    <div class="left-sidenav">
        <div class="main-icon-menu">
            <nav class="nav">
                <?php foreach($menuList as $res){?>
                    <a href="#<?php echo $res['menupath']?>" class="nav-link " data-toggle="tooltip-custom" data-placement="top" title=""
                       data-original-title="<?php echo $res['menuname']?>">
                        <?php echo $res['menuicon']?>
                    </a>
                <?php }?>


            </nav><!--end nav-->
        </div><!--end main-icon-menu-->

        <div class="main-menu-inner">
            <div class="menu-body slimscroll">
                <?php foreach($menuList as $res){
                    echo ' <div id="'.$res['menupath'].'" class="main-icon-menu-pane">
		                    <div class="title-box">
		                        <h6 class="menu-title">'.$res['menuname'].'</h6>
		                    </div>
		                    <ul class="nav">';
                    $sunList=$DB->query("SELECT * FROM  `wcms_menu`  where `status`= 1  and parentid='{$res['id']}' order by id asc")->fetchAll();

                    /*	if(!isset($_SESSION['sunList'])){
                           $sunList=$DB->query("SELECT * FROM  `wcms_menu2`  where `status`= 1  and parentid='{$res['id']}' order by id asc")->fetchAll();
                           $_SESSION["sunList"] = $sunList;
                       }else{
                           $sunList = $_SESSION["sunList"];
                       } */
                    foreach($sunList as $row) {
                        echo '<li class="nav-item"><a class="nav-link" href="'.$row['menupath'].'"><i class="'.$row['menuicon'].'"></i>'.$row['menuname'].'</a>
                        </li>';
                    }
                    echo ' </ul>
                </div>';
                }
                ?>



            </div><!--end menu-body-->
        </div><!-- end main-menu-inner-->
    </div>
    <!-- end left-sidenav-->
    <script>
        function logout() {
            var ii = layer.msg('正在退出', {icon: 16, time: 0});
            $.ajax({
                type: "get",
                url: "auth.php?act=logout",
                dataType: 'json',
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            location.href = 'login.php';
                        });

                    }
                }
            });
        }
    </script>