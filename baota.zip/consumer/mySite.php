<?php
include('header.php');
$numrows = $DB->query("SELECT * from `wcms_site` WHERE `uid`={$userrow['uid']}")->rowCount();
$list = $DB->query("SELECT * FROM `wcms_site` WHERE `uid`={$userrow['uid']} order by `sid` asc ")->fetchAll();

?>

<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">用户中心</a></li>
                            <li class="breadcrumb-item active">我的模板</li>
                        </ol>
                    </div>
                    <h4 class="page-title">我的模板</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">模板列表</h4>
                        <p class="text-muted mb-4 font-13">
                            Available my sites.
                        </p>

                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>网站域名</th>
                                <th>项目名称</th>
                                <th>开通时间</th>
                                <th>到期时间</th>
                                <th>操作</th>
                            </tr>
                            </thead>


                            <tbody>
                            <?php foreach ($list as $res) {
                                $program = $DB->query("SELECT * FROM wcms_program WHERE code='{$res['code']}' limit 1")->fetch();
                                ?>
                                <tr>
                                    <td>
                                        <?php if($res['isinstall'] == 0){
                                            echo '<button type="button" class="btn m-b-xs btn-sm btn-success btn-addon" onclick="install('.$res['sid'].')"> 点我初始化网站 </button>';
                                        }else{
                                            echo '<b><a href="http://'.$res['domain'].'" target="_blank">'.$res['domain'].' </a></b>';
                                        }?>
                                    </td>
                                    <td><?php echo $program['name']?></td>
                                    <td><?php echo $res['addtime']?></td>
                                    <td><?php echo $res['endtime']?></td>
                                    <td>
                                        <?php if($res['isinstall'] == 0){
                                            echo '<button type="button" class="btn m-b-xs btn-sm btn-warning btn-addon" > 请先初始化网站 </button>';
                                        }else{
                                            echo '<button  class="btn m-b-xs btn-sm btn-info btn-addon" onclick="getMyOneSite('.$res['sid'].')">操作网站</button>';
                                        }?>

                                    </td>
                                </tr>

                            <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

        <!-- Modal -->
        <div class="modal fade" id="getMyOneSite" tabindex="-1" role="dialog" aria-labelledby="example-tooltip"
             aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="example-tooltip-title">操作网站 <span id="sid"></span></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <table class="table  table-hover">
                        <tbody>
                        <tr>
                            <td>网站域名:</td>
                            <td><span id="deDomain"></span></td>
                        </tr>
                        <tr>
                            <td>网站程序:</td>
                            <td><span id="proName"></span></td>
                        </tr>
                        <tr>
                            <td>到期时间:</td>
                            <td><span id="endTime"></span></td>
                        </tr>
                        <tr>
                            <td>续费周期:</td>
                            <td><span id="reMoney"></span>元/<span id="reTime"></span>个月(会员可享折扣)</td>
                        </tr>
                        <tr>
                            <td><a href="javascript:void(0)" role="button" class="btn btn-success popover-test"
                                   data-toggle="popover" onclick="rePay()">续费网站</a>
                            </td>
                            <td>
                                <a href="javascript:void(0)" role="button" class="btn btn-warning  popover-test"
                                   data-toggle="popover" onclick="reInstall()">重装网站</a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="javascript:void(0)" role="button" onclick="myDomain()"
                                   class="btn btn-info  popover-test" data-toggle="modal"
                                   data-target="#myModal">域名管理</a>
                            </td>

                            <td>
                                <a href="#" onclick="delSite()" class="btn btn-danger popover-test">删除网站</a>
                            </td>

                        </tr>
                        </tbody>
                    </table>


                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">关闭</button>
                    </div>
                </div>
            </div>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header"><h4>域名管理</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <!---业务代码 -->
                        <div class="form-group">
                            <div class="input-group mb-3">
                                <br/>

                                <input type="text" class="form-control" id="domain" name="domain"
                                       placeholder="请输入域名">
                                <button type="button" class="btn btn-primary" onclick="addDomain()" style="text-align:center"
                                        type="submit">绑定
                                </button>

                            </div>
                            <pre font="green"><span id="bdMethod"></span></pre>
                        </div><!--end form-group-->
                        <br/>
                        <table class="table table-striped table-bordered table-hover dataTables-example" id="tab">
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success" data-dismiss="modal">关闭</button>
                    </div>
                </div>
            </div>
        </div>


    </div><!-- container -->
    <?php
    include('footer.php');
    ?>
    <script>
        function install(sid){
            var ii = layer.msg('数据处理中···', { icon: 16, shade: 0.01, time: 35000 });
            $.ajax({
                url: "ajax.php?act=install",
                type: 'POST',
                dataType: 'json',
                data: {sid:sid},
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, { icon: 1, time: 2000, shade: 0.4 }, function () {
                            location.href = data.url;
                        });
                    } else {
                        layer.msg(data.msg, { icon: 2, time: 2000, shade: 0.4 });
                    }
                }
            })
        }


        function getMyOneSite(sid) {
            $.ajax({
                url: './ajax.php?act=getMyOneSite',
                type: 'POST',
                dataType: 'json',
                data: {sid: sid},
                success: function (data) {
                    if (data.code == 1) {
                        var mypro = data.site;
                        var pro = data.pro;
                        //console.log(mypro);
                        //console.log(pro);
                        $("#deDomain").html(mypro.domain);
                        $("#proName").html(pro.name);
                        $("#endTime").html(mypro.endtime);
                        $("#sid").html(mypro.sid);
                        $("#reTime").html(pro.usetime);
                        $("#reMoney").html(pro.reprice);
                        $('#getMyOneSite').modal('show');
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        return false;
                    }
                },
                error: function () {
                    layer.alert('服务器异常！');
                    return false;
                }
            })
        }

        function rePay() {
            layer.confirm('确认续费网站吗?', {
                btn: ['是', '否'], btn1: function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 35000});
                    var sid = document.getElementById("sid");
                    var sid = $(sid).html();//商品ID

                    $.ajax({
                        url: "ajax.php?act=rePay",
                        type: 'POST',
                        dataType: 'json',
                        data: {sid: sid},
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert('服务器异常！');
                        }
                    });
                }
            });
        }

        function reInstall() {
            layer.confirm('确认重装网站吗?', {
                btn: ['是', '否'], btn1: function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 35000});
                    var sid = document.getElementById("sid");
                    var sid = $(sid).html();//商品ID
                    $.ajax({
                        url: "ajax.php?act=reInstall",
                        type: 'POST',
                        dataType: 'json',
                        data: {sid: sid},
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert('服务器异常！');
                        }
                    });
                }
            });
        }

        function delSite() {
            layer.confirm('确认删除网站吗?', {
                btn: ['是', '否'], btn1: function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 35000});
                    var sid = document.getElementById("sid");
                    var sid = $(sid).html();//商品ID
                    $.ajax({
                        url: "ajax.php?act=delSite",
                        type: 'POST',
                        dataType: 'json',
                        data: {sid: sid},
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert('服务器异常！');
                        }
                    });
                }
            });
        }

        function myDomain() {
            var sid = document.getElementById("sid");
            var sid = $(sid).html();//商品ID
            $.ajax({
                url: "ajax.php?act=getMyDomain",
                type: 'POST',
                dataType: 'json',
                data: {sid: sid},
                success: function (data) {
                    if (data.code == 1) {
                        var str = "";
                        var td = "";
                        $.each(data.myDomain, function (i, j) {
                            str += "<tr id=\"" + sid + "\">";
                            str += "<td>" + j + "</td><td><a href=\"#\"  class=\"btn m-b-xs btn-sm btn-danger btn-addon\" onclick=\"delDoamin(" + "'" + j + "'," + sid + ")\"><i class=\"fa fa-trash-o fa-lg\"></i>删除</a></td>";
                            str += "</tr>";
                        });
                        var table = "<thead class=\"good\" id=\"" + sid + "\"><tr><th>自定义域名</th><th>操作</th></tr></thead><tbody >" + str + "</tbody>";
                        $("#tab").html(table);
                        $("#bdMethod").html("请将您的域名以CNAME方式绑定到"+data.domain);
                    } else {
                        layer.msg("稍后再试", {icon: 2, time: 2000, shade: 0.4});
                    }
                },
                error: function () {
                    layer.alert('网络连接错误！');
                }
            })
        }

        function delDoamin(domain, sid) {
            var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 5500});
            console.log(domain);
            $.ajax({
                url: "ajax.php?act=delDomain",
                type: 'POST',
                dataType: 'json',
                data: {domain: domain, sid: sid},
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            $('#myModal').modal('hide');
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                },
                error: function () {
                    layer.alert('网络连接错误！');
                }
            })
        }


        function addDomain() {
            var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 5500});
            $.ajax({
                url: "ajax.php?act=addDomain",
                type: 'POST',
                dataType: 'json',
                data: {domain: $("#domain").val(), sid: $(".good").attr("id")},
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            $('#myModal').modal('hide');
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                },
                error: function () {
                    layer.alert('网络连接错误！');
                }
            })
        }
    </script>
