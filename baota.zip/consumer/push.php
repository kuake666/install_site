<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">在线商城</a></li>
                                <li class="breadcrumb-item active">网站push</li>
                            </ol>
                        </div>
                        <h4 class="page-title">在线商城</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div><!--end-row-->
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title mt-0 mb-3">网站push</h4>
                            <div class="billing-nav">
                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade show active" id="pills-credit-card">
                                        <div class="demo-container">
                                            <div class="card-wrapper mb-4"></div>
                                            <div class="form-container">
                                                <form class="bill-form">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>对方账号</label>
                                                                <input placeholder="填写对方账号" class="form-control" type="tel" name="username">
                                                            </div>
                                                        </div><!--end col-->
                                                        <div class="col-md-6">
                                                            <div class="form-group" >
                                                                <label>选择网站</label>
                                                                <select class="custom-select" name="sid" >
                                                                    <option value="0000">请选择网站</option>
                                                                    <?php
                                                                        $list = $DB->query("SELECT * FROM `wcms_site` WHERE `uid`={$userrow['uid']} order by `addtime` asc ")->fetchAll();
                                                                        foreach ($list as $res){
                                                                         $program = $DB->query("SELECT * FROM `wcms_program` WHERE `code`='{$res['code']}' limit 1")->fetch();
                                                                         echo ' <option value="'.$res['sid'].'">'.$program['name'].'-'.$res['domain'].'</option>';
                                                                     }?>
                                                                </select>
                                                            </div>
                                                        </div><!--end col-->
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>push价格</label>
                                                                <input placeholder="push价格" class="form-control" value="<?php echo $conf['push_price']?> 元" type="tel" name="price" disabled>
                                                            </div>
                                                        </div><!--end col-->
                                                    </div><!--end row-->
                                                    <button  type="button" class="btn btn-primary px-3" onclick="pushIntroduction()">功能介绍</button> &nbsp;&nbsp;
                                                    <button  type="button" class="btn btn-success px-3" onclick="push()">立即push</button>
                                                </form><!--end form-->
                                            </div><!--end form-container-->
                                        </div><!--end demo-->
                                    </div><!--end tab-pane-->

                                </div><!--end tab-content-->
                            </div> <!--end billing-nav-->
                        </div><!--end card-body-->
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->

        </div><!-- container -->

<?php
include('footer.php');
?>

        <script>
            function push(){
                layer.confirm('确认push吗?push结果立即生效', {
                    btn: ['是', '否'], btn1: function () {
                        $.ajax({
                            url: 'ajax.php?act=push',
                            type: 'POST',
                            dataType: 'json',
                            data: {sid: $("select[name='sid']").val(),username: $("input[name='username']").val() },
                            success: function (data) {
                                if (data.code == 1) {
                                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                        location.href = data.url;
                                    });
                                } else {
                                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                }
                            },
                            error: function () {
                                layer.alert("网络连接错误");
                                return false;
                            }
                        });
                    }
                });
            }
            //push功能介绍
            function pushIntroduction(){
                layer.open({
                    type: 1
                    ,
                    title: false //不显示标题栏
                    ,
                    closeBtn: false
                    ,
                    area: '300px;'
                    ,
                    shade: 0.8
                    ,
                    id: 'LAY_layuipro' //设定一个id，防止重复弹出
                    ,
                    resize: false
                    ,
                    btn: ['关闭提示']
                    ,
                    btnAlign: 'c'
                    ,
                    moveType: 1 //拖拽模式，0或者1
                    ,
                    content: "<div style='padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;'> push功能介绍：<br/>push功能用于帐号间网站转让<br/>push完成后立即生效</div>"
                    ,
                    success: function (layero) {
                        var btn = layero.find('.layui-layer-btn');
                        btn.find('.layui-layer-btn0').attr({
                            //href: data.url
                        });
                    }
                });
            }
        </script>
