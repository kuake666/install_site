<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

$pid = daddslashes($_GET['pid']);
$rowMemberConf = $DB->query("SELECT * FROM `wcms_member` WHERE `mcode`='{$userrow['mcode']}' limit 1")->fetch();//判断服务器是否存在
if ($pid != null) {
    $row = $DB->query("SELECT * FROM `wcms_program` WHERE `status`=1 and `pid`='{$pid}' limit 1")->fetch();
    $serverList = $DB->query("SELECT * FROM `wcms_server` WHERE `active`=1 ")->fetchAll();
    $newPrice = $row['price'];
    $newReprice = $row['reprice']; //商品续费价格 = 原价 * 会员折扣
    if ($row['discount'] == 1) { //开启优惠
        $newPrice = $row['price'] * $rowMemberConf['mpercent']; //商品新价格 = 原价 * 会员折扣
        $newReprice = $row['reprice'] * $rowMemberConf['mpercent']; //商品续费价格 = 原价 * 会员折扣
    }
    $result = 2;
} else {
    $search = daddslashes($_GET['search']);
    if($search){
        $list = $DB->query("SELECT * FROM `wcms_program` WHERE `status`= 1 and `name` like '%{$search}%' order by `pid` asc")->fetchAll();
    }else{
        $list = $DB->query("SELECT * FROM `wcms_program` WHERE `status`=1 order by `pid` asc")->fetchAll();

    }
    $numrows = $DB->query("SELECT * from `wcms_program` WHERE `status`=1")->rowCount();
    $typeList = $DB->query("SELECT * FROM `wcms_protype` ")->fetchAll();
    $result = 1; //项目列表
}


?>
<?php if ($result == 1) { ?>
<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">在线商城</a></li>
                            <li class="breadcrumb-item active">模板商城</li>
                        </ol>
                    </div>
                    <h4 class="page-title">模板商城</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <ul class="col container-filter categories-filter mb-0" id="filter">
                                <?php foreach ($typeList as $type) { ?>
                                    <?php if ($type['id'] == 10000) {
                                        echo '<li><a class="categories  active" data-filter="*">默认分类</a></li>';
                                    } else {
                                        echo ' <li><a class="categories" data-filter=".' . $type['id'] . '">' . $type['name'] . '</a></li>';
                                    } ?>
                                <?php } ?>

                            </ul>
                        </div><!-- End portfolio  -->
                    </div><!--end card-body-->
                </div><!--end card-->

                <div class="col-lg-12 text-right">
                    <div class="text-right">
                        <ul class="list-inline">
                            <li class="list-inline-item">
                                <div class="input-group">
                                    <input type="text" id="example-input1-group2" name="searchPro" class="form-control" placeholder="查询模板">
                                    <span class="input-group-append">
                                         <button type="button" id="searchPro" class="btn btn-primary"><i class="fas fa-search"></i></button>
                                    </span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div><!--end col-->
                <div class="card-body">
                    <div class="row container-grid nf-col-3  projects-wrapper">
                        <?php
                        foreach ($list as $res) {
                            $newPrice = $res['price'];
                            if ($res['discount'] == 1) { //开启优惠
                                $newPrice = $res['price'] * $rowMemberConf['mpercent']; //商品新价格 = 原价 * 会员折扣
                            }
                            if ($userrow['mcode'] == 100) {
                                $result = '<small class="text-muted">会员优惠中</small>';
                            } else {
                                $result = '<small class="text-muted">享受优惠</small>';
                            }
                            $typeList = $DB->query("SELECT * FROM `wcms_protype` ")->fetchAll();

                            echo '
                                    <!--<div class="col-lg-4  photo spacing">-->
                                     <div class="col-lg-4 ' . $res['tid'] . '  spacing">
                                        <div class="card e-co-product">
                                            <a href="http://' . $res['demo'] . ' " target="_blank">
                                                <img src="' . $res['img'] . '" alt="" class="img-fluid"><!--../assets/images/products/img-7.png-->
                                            </a>
                                            <div class="ribbon ribbon-pink">
                                                <span>火爆销售中</span>
                                            </div>
                                            <div class="card-body product-info">
                                                <a href="#" class="product-title">' . $res['name'] . '  ' . $result . '</a>
                                                <div class="d-flex justify-content-between my-2">
                                                    <p class="product-price">￥ ' . $newPrice . '</p>
                                                    <ul class="list-inline mb-0 product-review align-self-center">
                                                        <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                                        <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                                        <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                                        <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                                        <!-- <li class="list-inline-item"><i class="mdi mdi-star-half text-warning"></i></li>-->
                                                    </ul>
                                                </div>

                                                <a href="http://' . $res['demo'] . ' " target="_blank" class="btn btn-cart btn-sm waves-effect waves-light "><i
                                                            class="mdi mdi-magnify"></i> 演示
                                                </a>
                                                <a href="program.php?pid=' . $res['pid'] . '" class="btn btn-cart btn-sm waves-effect waves-light"><i
                                                            class="mdi mdi-cart mr-1"></i> 购买
                                                </a>
                                            </div><!--end ard-body product-info-->
                                        </div><!--card e-co-product-->
                                    </div><!--end col-->
                                    ';
                        } ?>
                    </div><!--end card-body-->
                    <!--
                            <div class="card-body ">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination justify-content-center">
                                        <li class="page-item">
                                            <a class="page-link" href="#" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                        </li>
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item"><a class="page-link" href="#">4</a></li>
                                        <li class="page-item"><a class="page-link" href="#">5</a></li>
                                        <li class="page-item"><a class="page-link" href="#">6</a></li>
                                        <li class="page-item">
                                            <a class="page-link" href="#" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                                <span class="sr-only">Next</span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                   -->

                </div><!-- container -->
            </div><!-- container -->
        </div><!-- container -->
    </div><!-- container -->


    <?php } else { ?>

    <!-- Page Content-->
    <div class="page-content">

        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">在线商城</a></li>
                                <li class="breadcrumb-item active">模板商城</li>
                            </ol>
                        </div>
                        <h4 class="page-title">在线商城</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <img src="<?php echo $row['img']; ?>" alt="" class=" mx-auto  d-block"
                                         height="400" width="280"> <!-- -->
                                </div><!--end col-->
                                <div class="col-lg-6 align-self-center">
                                    <div class="single-pro-detail">
                                        <p class="mb-1">模板商城</p>
                                        <div class="custom-border mb-3"></div>
                                        <h3 class="pro-title"><?php echo $row['name'] ?></h3>
                                        <p class="text-muted mb-0">模板热销度</p>
                                        <ul class="list-inline mb-2 product-review">
                                            <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i>
                                            </li>
                                            <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i>
                                            </li>
                                            <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i>
                                            </li>
                                            <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i>
                                            </li>
                                            <li class="list-inline-item"><i
                                                        class="mdi mdi-star-half text-warning"></i>
                                            </li>
                                            <li class="list-inline-item">4.5 (<?php echo rand(300, 1000) ?>人 点赞)</li>
                                        </ul>
                                        <h2 class="pro-price"><?php echo $newPrice ?> 元 <span>
                                                    <?php if ($userrow['mcode'] != 100 && $row['discount'] == 1){ ?>
                                                    <del><?php echo $row['price'] ?> 元</del></span>
                                        <?php } ?>
                                            <small
                                                    class="text-danger font-weight-bold ml-2">促销中</small>
                                        </h2>
                                        <h6 class="text-muted font-13">使用时间 :<?php echo $row['usetime'] ?>
                                            个月,续费价格:<?php echo $newReprice ?> 元</h6>

                                        <h6 class="text-muted font-13">模板特点 :</h6>
                                        <ul class="list-unstyled pro-features border-0">
                                            <?php echo $row['decription'] ?>

                                        </ul>
                                        <h6 class="text-muted font-13 d-inline-block align-middle mr-2">服务器 :</h6>

                                        <!--                                    <div class="radio2 radio-danger2 form-check-inline">-->
                                        <!--                                        <input type="radio" id="inlineRadio3" value="option3" name="radioInline">-->
                                        <!--                                        <label for="inlineRadio3"></label>-->
                                        <!--                                    </div>-->
                                        <!--                                    <div class="radio2 radio-purple2 form-check-inline">-->
                                        <!--                                        <input type="radio" id="inlineRadio4" value="option4" name="radioInline">-->
                                        <!--                                        <label for="inlineRadio4"></label>-->
                                        <!--                                    </div>-->

                                        <div class="row">
                                            <div class="col-sm-6">
                                                <!--判断项目是否指定了服务器-->
                                                <?php if($row['specifys_server'] == 1){ //指定服务器
                                                    $server = $DB->query("SELECT * FROM `wcms_server` WHERE `active`=1 and `sid`= '{$row['sid']}' limit 1")->fetch();
                                                    if($server){
                                                        echo '
                                                        <div class="radio radio-success">
                                                            <input type="radio" name="radio" id="'.$server['sid'].'" value="'.$server['sid'].'" checked="">
                                                            <label for="'.$server['sid'].'">'.$server['sname'].'</label>
                                                        </div>
                                                        ';
                                                    }else{
                                                        foreach ($serverList as $server) {
                                                            echo '
                                                                <div class="radio radio-success">
                                                                    <input type="radio" name="radio" id="'.$server['sid'].'" value="'.$server['sid'].'" checked="">
                                                                    <label for="'.$server['sid'].'">'.$server['sname'].'</label>
                                                                </div>
                                                            ';
                                                        }
                                                    }
                                                }else {
                                                    foreach ($serverList as $server) {
                                                        echo '
                                                    <div class="radio radio-success">
                                                        <input type="radio" name="radio" id="' . $server['sid'] . '" value="' . $server['sid'] . '" checked="">
                                                        <label for="' . $server['sid'] . '">' . $server['sname'] . '</label>
                                                    </div>
                                                    ';
                                                    }
                                                }?>

                                            </div>
                                        </div>

                                        <div class="quantity mt-3 ">
                                            <button id="clickBtn" onclick="build(<?php echo $row['pid'] ?>)" class="btn btn-primary text-white px-4 d-inline-block"><i class="mdi mdi-cart mr-2"></i>购买
                                            </button>
                                        </div>
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div><!--end card-body-->
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="pro-order-box">
                                        <i class="mdi mdi-truck-fast text-success"></i>
                                        <h4 class="header-title">速度保证</h4>
                                        <p class="text-muted mb-0">
                                            购买后网站将在5分钟自动搭建完成,不需要配置其他内容,到手即可使用.
                                        </p>
                                    </div>
                                </div><!--end col-->
                                <div class="col-lg-3">
                                    <div class="pro-order-box">
                                        <i class="mdi mdi-refresh text-danger"></i>
                                        <h4 class="header-title">质量保证</h4>
                                        <p class="text-muted mb-0">
                                            系统开发团队成员均来自于互联网行业。
                                            轻松设置即可完成建站！更为人性化.
                                        </p>
                                    </div>
                                </div><!--end col-->
                                <div class="col-lg-3">
                                    <div class="pro-order-box">
                                        <i class="mdi mdi-headset text-warning"></i>
                                        <h4 class="header-title">服务保证</h4>
                                        <p class="text-muted mb-0">
                                            官方正版&永久更新.所有正版用户均可享受程序永久更新服务,后台一键更新！
                                        </p>
                                    </div>
                                </div><!--end col-->
                                <div class="col-lg-3">
                                    <div class="pro-order-box mb-0">
                                        <i class="mdi mdi-wallet text-purple"></i>
                                        <h4 class="header-title">售后保证</h4>
                                        <p class="text-muted mb-0">
                                            客服人员7x24小时在线处理您的问题，同时我们也准备了一些常见问题的处理文档供您查阅.
                                        </p>
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div><!--end card-body-->
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->


        </div><!-- container -->
        <?php } ?>
        <?php
        include('footer.php');
        ?>
        <script>
            function build(pid) {
                layer.confirm('你确定购买吗?', {
                    btn: ['是', '否'], btn1: function () {
                        var oneClick=document.getElementById("clickBtn");
                        var resultClick = oneClick.getAttribute("disabled");
                        if(null != resultClick && 'false'== resultClick){
                            return false;
                        }
                        oneClick.setAttribute("disabled","false");
                        var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 250000});
                        var serverid = $("input[type='radio']:checked").val();
                        $.ajax({
                            url: "ajax.php?act=build",
                            type: 'post',
                            dataType: 'json',
                            data: {serverid: serverid, pid: pid},
                            success: function (data) {
                                oneClick.removeAttribute("disabled");
                                layer.close(ii);
                                if (data.code == 1) {
                                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                        location.href = data.url;
                                    });
                                } else {
                                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                    return false;
                                }
                            },
                            error: function () {
                                oneClick.removeAttribute("disabled");
                                layer.alert("网络连接错误");
                                return false;
                            }
                        });
                    }
                });
            }

            $("#searchPro").click(function () {
                var searchPro = $("input[name='searchPro']").val();
                window.location.href='?search='+searchPro;
        });
        </script>
