<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
?>

    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">服务中心</a></li>
                                <li class="breadcrumb-item active">服务台</li>
                            </ol>
                        </div>
                        <h4 class="page-title">服务台</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <ol class="c-progress-steps">
                                <li class="c-progress-steps__step  done"><span>计划</span></li>
                                <li class="c-progress-steps__step  done"><span>设计</span></li>
                                <li class="c-progress-steps__step  done"><span>开发</span></li>
                                <li class="c-progress-steps__step current"><span>上线</span></li>
                            </ol>
                        </div> <!--end card-body-->
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="float-right eco-revene-history justify-content-end">
                                <ul class="nav">
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#">Today</a>
                                    </li>
                                </ul>
                            </div>
                            <h4 class="header-title mt-0">项目运行</h4>
                            <div class="apexchart-wrapper">
                                <div id="eco-dash1" class="chart-gutters"></div>
                            </div>
                        </div><!--end card-body-->
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->


        </div><!-- container -->

<?php
include('footer.php');
?>