<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
?>

<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">新闻中心</a></li>
                            <li class="breadcrumb-item active">指导说明</li>
                        </ol>
                    </div>
                    <h4 class="page-title">指导说明</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->

        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">有很多问题需要咨询了解?</h4>
                        <div class="accordion" id="accordionExample-faq">
                            <div class="card shadow-none border mb-1">
                                <div class="card-header" id="headingOne">
                                    <h5 class="my-0">
                                        <button class="btn btn-link ml-4" type="button" data-toggle="collapse"
                                                data-target="#collapseOne" aria-expanded="false"
                                                aria-controls="collapseOne">
                                            如何搭建一个网站?
                                        </button>
                                    </h5>
                                </div>

                                <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                                     data-parent="#accordionExample-faq">
                                    <div class="card-body">
                                        注册并登录系统后，选择您需要搭建的网站模板,一键即可完成搭建.
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow-none border mb-1">
                                <div class="card-header" id="headingTwo">
                                    <h5 class="my-0">
                                        <button class="btn btn-link collapsed ml-4 align-self-center" type="button"
                                                data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false"
                                                aria-controls="collapseTwo">
                                            会员级别?
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                     data-parent="#accordionExample-faq">
                                    <div class="card-body">
                                        不同级别的会员购买同款网站模板价格不同,会员级别越高,折扣越大.
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow-none border mb-1">
                                <div class="card-header" id="headingThree">
                                    <h5 class="my-0">
                                        <button class="btn btn-link collapsed ml-4" type="button" data-toggle="collapse"
                                                data-target="#collapseThree" aria-expanded="false"
                                                aria-controls="collapseThree">
                                            开通网站赠送域名?
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                     data-parent="#accordionExample-faq">
                                    <div class="card-body">
                                        使用我们的系统开通网站后即可自动赠送域名,可以使用赠送的域名访问您的网站.
                                    </div>
                                </div>
                            </div>

                            <div class="card shadow-none border mb-1">
                                <div class="card-header" id="headingThree1">
                                    <h5 class="my-0">
                                        <button class="btn btn-link collapsed ml-4" type="button" data-toggle="collapse"
                                                data-target="#collapseThree1" aria-expanded="false"
                                                aria-controls="collapseThree1">
                                            关于绑定自己的域名?
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseThree1" class="collapse" aria-labelledby="headingThree1"
                                     data-parent="#accordionExample-faq">
                                    <div class="card-body">
                                        使用我们的系统成功搭建网站后，您可以绑定您自己的域名,只需要将您自己的域名绑定到赠送的域名.
                                    </div>
                                </div>
                            </div>

                            <div class="card shadow-none border mb-1">
                                <div class="card-header" id="headingThree2">
                                    <h5 class="my-0">
                                        <button class="btn btn-link collapsed ml-4" type="button" data-toggle="collapse"
                                                data-target="#collapseThree2" aria-expanded="false"
                                                aria-controls="collapseThree2">
                                            充值未到账?
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseThree2" class="collapse" aria-labelledby="headingThree2"
                                     data-parent="#accordionExample-faq">
                                    <div class="card-body">
                                        如遇高峰期，导致充值未及时到账,请联系我们的客服人员.
                                    </div>
                                </div>
                            </div>
                        </div><!--end accordion-->
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
        </div><!--end row-->

    </div><!-- container -->
<?php
include 'footer.php';
?>