<?php
require 'common.php';

$trade_no=isset($_GET['trade_no'])?daddslashes($_GET['trade_no']):exit('No trade_no!');

@header('Content-Type: text/html; charset=UTF-8');

$row=$DB->query("SELECT * FROM `wcms_order` WHERE `order_no`='{$trade_no}' limit 1")->fetch();

$link = '../consumer/info.php';
if($row['status'] ==1){
	exit('{"code":1,"msg":"付款成功","backurl":"'.$link.'"}');
}else{
	exit('{"code":-1,"msg":"未付款"}');
}
?>