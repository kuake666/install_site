<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年1月1日
// +----------------------------------------------------------------------

error_reporting(0);
include '../plugin/common.php';
@header('Content-Type: text/html; charset=UTF-8');

$updateDB = $_GET['update'];

if ($updateDB == "updateDB") {
    if ($conf['version'] < DB_VERSION) {
        if ($conf['version'] < 1000) {
            $sqls = "install.sql";
            $version = 1000;
        }else if ($conf['version'] < 6500) {
            $sqls = "update1.sql";
            $version = 6500;
        }else if ($conf['version'] < 7000) {
            $sqls = "update2.sql";
            $version = 7000;
        } else if ($conf['version'] < 7200) {
            $sqls = "update3.sql";
            $version = 7200;
        } else if ($conf['version'] < 7300) {
            $sqls = "update4.sql";
            $version = 7300;
        } else if ($conf['version'] < 7500) {
            $sqls = "update5.sql";
            $version = 7500;
        } else if ($conf['version'] < 7600) {
            $sqls = "update6.sql";
            $version = 7600;
        } else if ($conf['version'] < 8000) {
            $sqls = "update7.sql";
            $version = 8000;
        } else {
            exit("<script language='javascript'>alert('你的网站已经升级到最新版本了！');window.location.href='../manage/index.php';</script>");
        }
        $ml = "./" . $sqls;
        $value = file_get_contents($ml);
        $value = str_replace("need_replacezuo", "<", $value);
        $value = str_replace("need_replaceyou", ">", $value);
        $value = str_replace("need_replace", ";", $value);
        if ($DB->query($value)) {
            $sql = $DB->query("UPDATE wcms_conf SET `v`='{$version}' WHERE `k`='version'")->fetch();
            exit("<script language='javascript'>alert('网站数据库升级完成！');window.location.href='../manage/index.php';</script>");
        } else {
            exit("<script language='javascript'>alert('导入数据失败,请手动导入sql文件！');window.location.href='../manage/index.php';</script>");
        }
    } else {
        exit("<script language='javascript'>alert('你的网站已经升级到最新版本了！');window.location.href='../manage/index.php';</script>");
    }


}



?>





