
-- 指定服务器功能  操作项目表
ALTER TABLE wcms_program ADD COLUMN specifys_server int(1) DEFAULT '0' COMMENT '是否指定服务器';
ALTER TABLE wcms_program ADD COLUMN sid int(11) DEFAULT '10000' COMMENT '服务器编号';
-- 小微支付
INSERT INTO `wcms_conf` VALUES ('micropay_api', '');
INSERT INTO `wcms_conf` VALUES ('micropay_pid', '');
INSERT INTO `wcms_conf` VALUES ('micropay_key', '');
INSERT INTO `wcms_conf` VALUES ('micropay_mchid', '');

-- API接口账号 密钥
INSERT INTO `wcms_conf` VALUES ('api_status', '0');
INSERT INTO `wcms_conf` VALUES ('api_user', '');
INSERT INTO `wcms_conf` VALUES ('api_key', '');