ALTER TABLE wcms_program ADD COLUMN site_path varchar(255) DEFAULT '/' COMMENT '项目运行目录';
ALTER TABLE wcms_program ADD COLUMN tip varchar(255) DEFAULT null COMMENT '项目提示信息';
ALTER TABLE wcms_server ADD COLUMN ok_domain int(1) DEFAULT '1' COMMENT '是否允许用户绑定默认域名 1:允许 0:不允许';
ALTER TABLE wcms_site ADD COLUMN open_ssl int(1) DEFAULT '0' COMMENT '是否开启SSL 1:开启 0:关闭';
-- conf 添加 teach_tip
INSERT INTO `wcms_conf` VALUES ('teach_tip', '0');
-- 注册时强制验证邮箱
 INSERT INTO `wcms_conf` VALUES ('need_email', '0');


-- 添加监控列表菜单
INSERT INTO `wcms_menu2` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('监控列表','cronList.php','dripicons-bell','10004','1');

-- 添加wcms_code表 用于发送注册验证码
CREATE TABLE IF NOT EXISTS `wcms_code` (
`cid` int(11) NOT NULL,
`email` varchar(255) DEFAULT NULL COMMENT '用户邮箱',
`code` varchar(255) DEFAULT NULL COMMENT '验证码',
`type` int(1) DEFAULT 1 COMMENT '验证码类型 1:注册账号 2:找回密码 3.修改密码',
`time` varchar(255) DEFAULT NULL,
`ip` varchar(64) DEFAULT NULL COMMENT '操作IP',
`status` int(11) DEFAULT 0
) DEFAULT CHARSET=utf8;
ALTER TABLE `wcms_code`
    ADD PRIMARY KEY (`cid`);
ALTER TABLE `wcms_code`
    MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10000;