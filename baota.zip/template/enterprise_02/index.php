<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="format-detection" content="telephone=yes">
<title><?php echo $conf['web_name'] ?>|<?php echo $conf['web_subtitle'] ?></title>
<meta name="description" content="<?php echo $conf['web_description'] ?>"/>
<meta name="keywords"  content="<?php echo $conf['keywords'] ?>"/>
<meta name="author" content="order by dede58.com" />
<meta name="renderer" content="webkit">
<!--ico-->
<link rel="stylesheet" type="text/css" href="./assets/enterprise_02/css/base.css" />
<link rel="stylesheet" type="text/css" href="./assets/enterprise_02/css/animate.min.css" />
<link rel="stylesheet" type="text/css" href="./assets/enterprise_02/css/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="./assets/enterprise_02/css/style.css" />
<link rel="stylesheet" type="text/css" href="./assets/enterprise_02/css/responsive.css" />
<script src="./assets/enterprise_02/js/jquery-1.11.0.min.js"></script>
<script src="./assets/enterprise_02/js/wow.min_1.js"></script>
<script src="./assets/enterprise_02/js/owl.carousel.min.js"></script>
<script src="./assets/enterprise_02/js/page.js"></script>
</head>
<body>
<div class="header">
  <div class="rowFluid">
    <div class="span2 col-md-12">
      <div class="logo"> <a href="/" title="返回首页"> <img src="./assets/img/logo/logo.png?r=<?php echo rand(10000,99999)?>" alt="响应式网络建设设计公司网站模板(自适应移动设备)" /> </a> </div>
    </div>
    <div class="span8">
      <div class="mobileMenuBtn"><span class="span1"></span><span class="span2"></span><span class="span3"></span></div>
      <div class="mobileMenuBtn_shad"></div>
      <div class="header_menu">
          <ul id="menu">
              <li><a href="/"  class='active'  title="首页">首页</a></li>

              <li><a href="./consumer/login.php" title="登录账号">登录账号</a></li>

              <li><a href="./consumer/register.php" title="免费注册">免费注册</a></li>


          </ul>
      </div>
    </div>
    <div class="span2"> </div>
  </div>
</div>
<!--<div class="aside">
  <ul>
    <li> <a href="/a/jianzhanfangan/" target="_blank" title="合作"><img src="./assets/enterprise_02/images/057.png" alt="合作" />合作</a> </li>
    <li class="consulting"><a href="#this" title="建站在线客服"><span></span><span></span><span></span><img src="./assets/enterprise_02/images/059.png" class="img1" alt="建站在线客服" /><img src="./assets/enterprise_02/images/061.png" class="img2" alt="建站在线客服" />咨询</a></li>
    <li> <a href="/a/jishuzhichi/"><img src="./assets/enterprise_02/images/060.png" alt="建站帮助中心" />帮助</a> </li>
  </ul>
</div>
<div class="consulting_box">
  <div class="title">
    <div class="title_t1">RELATEED CONSULTING</div>
    <div class="title_t2">相关咨询 </div>
  </div>
  <div class="consulting_type">
    <div class="consulting_type_title">选择下列产品马上在线沟通</div>
    <ul>
      <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=123456&site=qq&menu=yes" title="响应式建站咨询"> <img src="./assets/enterprise_02/images/062.png" class="img1" alt="网站建设" /><img src="./assets/enterprise_02/images/063.png" class="img2" alt="响应式网站咨询" />建站咨询 </a> </li>
      <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=123456&site=qq&menu=yes" title="建站平台加盟咨询"> <img src="./assets/enterprise_02/images/062.png" class="img1" alt="建站平台" /><img src="./assets/enterprise_02/images/063.png" class="img2" alt="建站平台代理咨询" />加盟咨询 </a> </li>
      <li> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=123456&site=qq&menu=yes" title="响应式网站定制"> <img src="./assets/enterprise_02/images/062.png" class="img1" alt="响应式网站定制" /><img src="./assets/enterprise_02/images/063.png" class="img2" alt="响应式网站定制" />定制咨询 </a> </li>
    </ul>
    <div class="time">服务时间：9:30-18:00</div>
  </div>
  <div class="problem">
    <div class="problem_title">你可能遇到了下面的问题</div>
    <ul>
      <li><span></span><a href="/a/jishuzhichi/fuwutiaokuan/34.html" title="开发App的5个基本步骤">开发App的5个基本步骤</a></li>
<li><span></span><a href="/a/jishuzhichi/fuwutiaokuan/33.html" title="手机App的发展前景展望">手机App的发展前景展望</a></li>
<li><span></span><a href="/a/jishuzhichi/shiyongshouce/32.html" title="网站制作从原型图架构到设计开发的具体步骤">网站制作从原型图架构到设计开发的具体步骤</a></li>
<li><span></span><a href="/a/jishuzhichi/shiyongshouce/31.html" title="站长必看网站建设系统选择知识">站长必看网站建设系统选择知识</a></li>
<li><span></span><a href="/a/jishuzhichi/shiyongshouce/30.html" title="高端网站建设必须要满足哪些要求">高端网站建设必须要满足哪些要求</a></li>

    </ul>
  </div>
  <div class="close"> <img src="./assets/enterprise_02/images/close.png" alt="关闭右侧工具栏" /> </div>
</div>
-->
<div class="page">
<div class="rowFluid">
<div class="span12">
<div class="main">
<script src="./assets/enterprise_02/js/login.js"></script>
<div class="banner">
  <div class="rowFluid">
    <div class="span12">
      <div class="owl-demo">
        <div class="item">
          <h3 class="banner_title">打破传统-免网站制作费</h3>
          <div class="banner_text">2020-找我们做网站我们只收取空间域名成本价，免取网站高额制作费用。</div>
          <div class="banner_button"> <a href="./consumer/index.php"  title="详细咨询">立即拥有</a> </div>
        </div>
        <div class="item">
          <h3 class="banner_title">主流响应式网站</h3>
          <div class="banner_text">一个网站就能自动适应PC端+平板端+手机端使用</div>
          <div class="banner_button"> <a href="./consumer/index.php" class="active" title="立即体验">立即体验</a> </div>
        </div>
        <div class="item">
          <h3 class="banner_title">为企业所想 满足企业需求</h3>
          <div class="banner_text">升级以您的需求为导向,提升以您的价值为目标</div>
          <div class="banner_button"> <a href="./consumer/index.php"  title="详细咨询">马上咨询</a> </div>
        </div>
      </div>
    </div>
  </div>
  <div id="container" class="mpage">
    <div id="anitOut" class="anitOut"></div>
  </div>
</div>
<div class="index_product">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="all_title1 wow fadeInDown">
          <h3 class="title">我们的产品</h3>
          <div class="text">OUR PRODUCT</div>
        </div>
        <div class="rowFluid">
          <div class="index_product_content">
            <div class="span4 col-md-6 col-xs-12 wow fadeInDown"> <a  class="index_product_list" title="响应式企业网站建设">
              <div class="list_backimg list_backimg1">
                <div class="list_img"> <img src="./assets/enterprise_02/images/045.png" alt="响应式企业网站建设" /> </div>
                <div class="list_txt">
                  <div class="list_title">企业官网</div>
                  <div class="list_text">CORPORATE WEBSITES</div>
                </div>
              </div>
              </a> </div>
            <div class="span4 col-md-6 col-xs-12 wow flipInX"> <a  class="index_product_list" title="响应式商城网站建设">
              <div class="list_backimg list_backimg2">
                <div class="list_img"> <img src="./assets/enterprise_02/images/046.png" alt="响应式商城网站建设" /> </div>
                <div class="list_txt">
                  <div class="list_title">购物商城</div>
                  <div class="list_text">SHOPPING MALL</div>
                </div>
              </div>
              </a> </div>
            <div class="span4 col-md-6 col-xs-12 wow fadeInRight"> <a  class="index_product_list" title="空间域名">
              <div class="list_backimg list_backimg3">
                <div class="list_img"> <img src="./assets/enterprise_02/images/047.png" alt="空间域名" /> </div>
                <div class="list_txt">
                  <div class="list_title">空间域名</div>
                  <div class="list_text">SPACE SERVICE</div>
                </div>
              </div>
              </a> </div>
            <div class="span4 col-md-6 col-xs-12 wow fadeInDown"> <a  class="index_product_list" title="生态级行业门户">
              <div class="list_backimg list_backimg4">
                <div class="list_img"> <img src="./assets/enterprise_02/images/048.png" alt="生态级行业门户" /> </div>
                <div class="list_txt">
                  <div class="list_title">行业门户</div>
                  <div class="list_text">INDUSTRY PORTAL</div>
                </div>
              </div>
              </a> </div>
            <div class="span4 col-md-6 col-xs-12 wow flipInX"> <a  class="index_product_list" title="H5三合一网站">
              <div class="list_backimg list_backimg5">
                <div class="list_img"> <img src="./assets/enterprise_02/images/049.png" alt="H5三合一网站" /> </div>
                <div class="list_txt">
                  <div class="list_title">三合一网站</div>
                  <div class="list_text">TRIAD WEBSITE</div>
                </div>
              </div>
              </a> </div>
            <div class="span4 col-md-6 col-xs-12 wow fadeInRight"> <a  class="index_product_list" title="生态级响应式全网营销平台">
              <div class="list_backimg list_backimg6">
                <div class="list_img"> <img src="./assets/enterprise_02/images/050.png" alt="生态级响应式全网营销平台" /> </div>
                <div class="list_txt">
                  <div class="list_title">全网营销</div>
                  <div class="list_text">NETWORK MARKETING</div>
                </div>
              </div>
              </a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="platform_advantage">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="all_title2 wow fadeInUp">
          <h3 class="title">我们的优势</h3>
          <div class="text">PLATFORM ADVANTAGE</div>
        </div>
        <div class="rowFluid">
          <div class="platform_advantage_content">
            <div class="span4 col-xm-6 col-xs-12 wow bounceInLeft">
              <div class="platform_advantage_list">
                <div class="platform_advantage_img"> <img src="./assets/enterprise_02/images/008.png" alt="响应式建站平台" /> </div>
                <div class="platform_advantage_brief">
                  <div class="brief_title">免网站制作费</div>
                  <div class="brief_text">只收空间域名取成本价</div>
                </div>
              </div>
            </div>
            <div class="span4 col-xm-6 col-xs-12 wow bounceIn">
              <div class="platform_advantage_list">
                <div class="platform_advantage_img"> <img src="./assets/enterprise_02/images/009.png" alt="响应式网站建设" /> </div>
                <div class="platform_advantage_brief">
                  <div class="brief_title">快速建站</div>
                  <div class="brief_text"> 打破传统网站制作工时<br />
                    网站制作最快只需1天 </div>
                </div>
              </div>
            </div>
            <div class="span4 col-xm-6 col-xs-12 wow bounceInRight">
              <div class="platform_advantage_list">
                <div class="platform_advantage_img"> <img src="./assets/enterprise_02/images/010.png" alt="响应式自助建站" /> </div>
                <div class="platform_advantage_brief">
                  <div class="brief_title">多合一终端使用</div>
                  <div class="brief_text"> 一个网站能够在CP+平板+手机<br />
                    完美响应展示。 </div>
                </div>
              </div>
            </div>
            <div class="span4 col-xm-6 col-xs-12 wow bounceInLeft">
              <div class="platform_advantage_list">
                <div class="platform_advantage_img"> <img src="./assets/enterprise_02/images/011.png" alt="响应式网站定制" /> </div>
                <div class="platform_advantage_brief">
                  <div class="brief_title">大数据</div>
                  <div class="brief_text"> 升级更新数据保留，企业数据沉淀<br />
                    实现数据分析。 </div>
                </div>
              </div>
            </div>
            <div class="span4 col-xm-6 col-xs-12 wow bounceIn">
              <div class="platform_advantage_list">
                <div class="platform_advantage_img"> <img src="./assets/enterprise_02/images/012.png" alt="html5建站平台" /> </div>
                <div class="platform_advantage_brief">
                  <div class="brief_title">高端设计</div>
                  <div class="brief_text"> 主流设计风格，极致交互体验，<br />
                    提升品牌价值 </div>
                </div>
              </div>
            </div>
            <div class="span4 col-xm-6 col-xs-12 wow bounceInRight">
              <div class="platform_advantage_list">
                <div class="platform_advantage_img"> <img src="./assets/enterprise_02/images/013.png" alt="H5响应式网站建设" /> </div>
                <div class="platform_advantage_brief">
                  <div class="brief_title">安全稳定</div>
                  <div class="brief_text"> 平台运行于阿里云计算中心<br />
                    多备份容灾保障，安全稳定 </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="rowFluid">
        <div class="waves_box">
          <canvas id="waves" class="waves"></canvas>
        </div>
      </div>
      <div class="container">
        <div class="rowFluid">
          <div class="response_shows">
            <div class="response_shows_box wow bounceIn">
              <div class="response_shows_width">
                <div class="pc"> <img src="./assets/enterprise_02/images/015.png" alt="建站神器" />
                  <div class="pic">
                    <div class="item"> <img src="./assets/enterprise_02/images/0511.jpg" alt="快速响应式网站制作" /> </div>
                    <div class="item"> <img src="./assets/enterprise_02/images/0512.jpg" alt="网站建设" /> </div>
                    <div class="item"> <img src="./assets/enterprise_02/images/0513.jpg" alt="响应式自助建站" /> </div>
                  </div>
                </div>
                <div class="pad"> <img src="./assets/enterprise_02/images/017.png" alt="H5响应式网站建设" />
                  <div class="pic">
                    <div class="item"> <img src="./assets/enterprise_02/images/0521.jpg" alt="建站" /> </div>
                    <div class="item"> <img src="./assets/enterprise_02/images/0522.jpg" alt="生态级响应式2.0建站平台" /> </div>
                    <div class="item"> <img src="./assets/enterprise_02/images/0523.jpg" alt="H5响应式网站建设" /> </div>
                  </div>
                </div>
                <div class="phone"> <img src="./assets/enterprise_02/images/016.png" alt="响应式网站模板" />
                  <div class="pic">
                    <div class="item"> <img src="./assets/enterprise_02/images/0531.jpg" alt="响应式网站设计案例" /> </div>
                    <div class="item"> <img src="./assets/enterprise_02/images/0532.jpg" alt="响应式网站案例" /> </div>
                    <div class="item"> <img src="./assets/enterprise_02/images/0533.jpg" alt="html5建站平台" /> </div>
                  </div>
                </div>
                <div class="thumb"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</div>
<div class="marketing_advantage">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="all_title2 wow fadeInUp">
          <h3 class="title">营销优势</h3>
          <div class="text">MARKETING ADVANTAGE</div>
        </div>
        <div class="rowFluid">
          <div class="marketing_advantage_content">
            <div class="span3 col-sm-6 wow flipInY">
              <div class="marketing_advantage_list"> <img src="./assets/enterprise_02/images/019.jpg" alt="响应式跨屏营销网站" /> </div>
            </div>
            <div class="span3 col-sm-6">
              <div class="span12 wow flipInY">
                <div class="marketing_advantage_list"> <img src="./assets/enterprise_02/images/054.jpg" />
                  <div class="marketing_advantage_brief">
                    <div class="brief_title">全网营销<span><img src="./assets/enterprise_02/images/020.png" alt="响应式网站营销" /></span></div>
                    <div class="brief_text">响应式全屏幕营销网站，无需重复投资无需重复维护，无需重复运营</div>
                  </div>
                </div>
              </div>
              <div class="span12 wow flipInY">
                <div class="marketing_advantage_list"> <img src="./assets/enterprise_02/images/054.jpg" />
                  <div class="marketing_advantage_brief">
                    <div class="brief_title">优化搜索<span><img src="./assets/enterprise_02/images/023.png" alt="响应式网站SEO" /></span></div>
                    <div class="brief_text">SEO轻松提高百度谷歌等搜索引擎的关键词自然排名。</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="span3 col-sm-6">
              <div class="span12 wow flipInY">
                <div class="marketing_advantage_list"> <img src="./assets/enterprise_02/images/054.jpg" />
                  <div class="marketing_advantage_brief">
                    <div class="brief_title">微信无缝对接<span><img src="./assets/enterprise_02/images/021.png" alt="平台微信营销" /></span></div>
                    <div class="brief_text">全面整合微信营销，数据对接微信互动与分享</div>
                  </div>
                </div>
              </div>
              <div class="span12 wow flipInY">
                <div class="marketing_advantage_list"> <img src="./assets/enterprise_02/images/054.jpg" />
                  <div class="marketing_advantage_brief">
                    <div class="brief_title">二维码<span><img src="./assets/enterprise_02/images/024.png" alt="二维码分享" /></span></div>
                    <div class="brief_text">生成页面二维码，任意分享</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="span3 col-sm-6">
              <div class="span12 wow flipInY">
                <div class="marketing_advantage_list"> <img src="./assets/enterprise_02/images/054.jpg" />
                  <div class="marketing_advantage_brief">
                    <div class="brief_title">社交分享<span><img src="./assets/enterprise_02/images/022.png" alt="跨屏网站社交分享" /></span></div>
                    <div class="brief_text">一键分享到微博、QQ空间朋友圈等社交网络</div>
                  </div>
                </div>
              </div>
              <div class="span12 wow flipInY">
                <div class="marketing_advantage_list"> <img src="./assets/enterprise_02/images/054.jpg" />
                  <div class="marketing_advantage_brief">
                    <div class="brief_title">分销体系<span><img src="./assets/enterprise_02/images/025.png" alt="响应式分销商城网站" /></span></div>
                    <div class="brief_text">系统化整合客户快速营销</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="partners">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="all_title1 wow fadeInUp">
          <h3 class="title">合作伙伴</h3>
          <div class="text">COOPERATIVE PARTNER</div>
        </div>
        <div class="rowFluid">
          <div class="partners_content"> <a href="#" class="partners_content_list wow fadeInUp" data-wow-delay="0.2s" target="_blank"> <img src="./assets/enterprise_02/images/026.png" alt="阿里云" /> </a> <a href="#" class="partners_content_list wow fadeInUp" data-wow-delay="0.4s" target="_blank"> <img src="./assets/enterprise_02/images/027.png" alt="驻云" /> </a> <a href="#" class="partners_content_list wow fadeInUp" data-wow-delay="0.6s" target="_blank"> <img src="./assets/enterprise_02/images/028_1.png" alt="麦田设计" /> </a> <a href="#" class="partners_content_list wow fadeInUp" data-wow-delay="0.8s" target="_blank"> <img src="./assets/enterprise_02/images/029.png" alt="博艺通展览" /> </a> <a href="#" class="partners_content_list wow fadeInUp" data-wow-delay="1s" target="_blank"> <img src="./assets/enterprise_02/images/030.png" alt="高斌钟表" /> </a> <a href="#this" class="partners_content_list wow fadeInUp" data-wow-delay="1.2s" target="_blank"> <img src="./assets/enterprise_02/images/0311.png" alt="仙作电商" /> </a> <a href="#this" class="partners_content_list wow fadeInUp" data-wow-delay="1.4s" target="_blank"> <img src="./assets/enterprise_02/images/0322.png" alt="纳威体育" /> </a> </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--<div class="join_in">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="join_in_title wow fadeInUp">选择我们，<span>让你的企业快速迈向互联网+时代</span></div>
        <div class="join_in_text wow fadeInLeft">选择对的服务商能让您更快更好的迈进互联网+时代</div>
        <a href="./consumer/index.php" class="all_button join_in_button wow fadeInUp"  >点击咨询</a> </div>
    </div>
  </div>
</div>-->
<!--<div class="news_center">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="all_title1 wow fadeInUp">
          <h3 class="title">新闻中心</h3>
          <div class="text">NEWS TRENDS</div>
        </div>
        <div class="rowFluid">
          <div class="news_center_content">
            <div class="span4 col-sm-12 wow fadeInDown" data-wow-delay="1.2s">
              <div class="news_center_list">
                <div class="news_center_list_img"> <img src="./assets/enterprise_02/images/034.jpg" alt="云平台动态" /> </div>
                <div class="news_center_list_title">平台动态</div>
                <ul>
                  <li class="span12"> <a href="/a/xinwenzixun/pingtaidongtai/5.html" class="span8" title="企业网站应该多长时间备份一次？"><i class="fa fa-angle-right"></i>企业网站应该多长时间备份一次？ </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/pingtaidongtai/4.html" class="span8" title="如何选择网站关键词?"><i class="fa fa-angle-right"></i>如何选择网站关键词? </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/pingtaidongtai/3.html" class="span8" title="企业建站选择主机和产品服务遇到的问题"><i class="fa fa-angle-right"></i>企业建站选择主机和产品服务遇到的问题 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/pingtaidongtai/2.html" class="span8" title="企业用网站进行网络宣传的优势"><i class="fa fa-angle-right"></i>企业用网站进行网络宣传的优势 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/pingtaidongtai/1.html" class="span8" title="什么是伪静态？伪静态有何作用?哪种好？"><i class="fa fa-angle-right"></i>什么是伪静态？伪静态有何作用?哪种好？ </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>

                </ul>
              </div>
            </div>
            <div class="span4 col-sm-12 wow fadeInUp" data-wow-delay="0.7s">
              <div class="news_center_list">
                <div class="news_center_list_img"> <img src="./assets/enterprise_02/images/035.jpg" /> </div>
                <div class="news_center_list_title">帮助中心</div>
                <ul>
                  <li class="span12"> <a href="/a/xinwenzixun/bangzhuzhongxin/21.html" class="span8" title="东莞家具出走湖北？家具业尝试高端规划集聚"><i class="fa fa-angle-right"></i>东莞家具出走湖北？家具业尝试高端规划集聚 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/bangzhuzhongxin/20.html" class="span8" title="改良与创新"><i class="fa fa-angle-right"></i>改良与创新 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/bangzhuzhongxin/19.html" class="span8" title="如何充分发挥SEO功能"><i class="fa fa-angle-right"></i>如何充分发挥SEO功能 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/bangzhuzhongxin/18.html" class="span8" title="SEO怎么加快文章的收录速度"><i class="fa fa-angle-right"></i>SEO怎么加快文章的收录速度 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/bangzhuzhongxin/17.html" class="span8" title="SEO快速排名算法"><i class="fa fa-angle-right"></i>SEO快速排名算法 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>

                </ul>
              </div>
            </div>
            <div class="span4 col-sm-12 wow fadeInDown" data-wow-delay="1.3s">
              <div class="news_center_list">
                <div class="news_center_list_img"> <img src="./assets/enterprise_02/images/036.jpg" /> </div>
                <div class="news_center_list_title">行业资讯</div>
                <ul>
                  <li class="span12"> <a href="/a/xinwenzixun/xingyexinwen/16.html" class="span8" title="SEO网站的基本术语"><i class="fa fa-angle-right"></i>SEO网站的基本术语 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/xingyexinwen/15.html" class="span8" title="企业建站系统有何优势？"><i class="fa fa-angle-right"></i>企业建站系统有何优势？ </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/xingyexinwen/14.html" class="span8" title="什么是伪静态？伪静态有何作用?"><i class="fa fa-angle-right"></i>什么是伪静态？伪静态有何作用? </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/xingyexinwen/13.html" class="span8" title="为什么企业要建多国语言网站？"><i class="fa fa-angle-right"></i>为什么企业要建多国语言网站？ </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>
<li class="span12"> <a href="/a/xinwenzixun/xingyexinwen/12.html" class="span8" title="企业用网站进行网络宣传的优势"><i class="fa fa-angle-right"></i>企业用网站进行网络宣传的优势 </a>
                    <div style="font-size: 12px; color: #ccc; float: right; margin-top: 3px;">10-01</div>
                  </li>

                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>-->
<script src="./assets/enterprise_02/js/effects.js"></script>
<div class="footer wow fadeInUp">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="footer_content">
          <div class="span4 col-xm-12">
            <div class="footer_list">
              <!--<div class="span6">
                <div class="bottom_logo"> <img src="./assets/enterprise_02/images/weixin.png" alt="微信服务号二维码" /> </div>
              </div>-->
              <div class="span6 col-xm-12">
                <div class="quick_navigation">
                  <div class="quick_navigation_title">快速导航</div>
                  <ul>
                    <li>
                        <?php echo $conf['quikly_pass'] ?>
                        <!--                     <a href="/" title="首页">首页</a> </li>
                                         <li> <a href="/a/jiejuefangan/" title="解决方案">解决方案</a> </li><li> <a href="/a/guanyuwomen/" title="关于我们">关于我们</a> </li><li> <a href="/a/kehuanli/" title="客户案例">客户案例</a> </li><li> <a href="/a/jianzhanfangan/" title="建站方案">建站方案</a> </li><li> <a href="/a/xinwenzixun/" title="新闻资讯">新闻资讯</a> </li><li> <a href="/a/jishuzhichi/" title="技术支持">技术支持</a> </li><li> <a href="/a/lianxiwomen/" title="联系我们">联系我们</a> </li>
                     -->
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="span4 col-xm-6 col-xs-12">
            <div class="footer_list">
              <div class="footer_link">
                <div class="footer_link_title">友情链接</div>
                <ul id="frientLinks">
                    <?php echo $conf['friend_link'] ?>
                  
                </ul>
              </div>
            </div>
          </div>
          <div class="span4 col-xm-6 col-xs-12">
            <div class="footer_list">
              <div class="footer_cotact">
                <div class="footer_cotact_title">联系方式</div>
                <ul>
                    <p><?php echo $conf['connect_us'] ?></p>
                  <!--
                  <li><span class="footer_cotact_type">地址：</span><span class="footer_cotact_content">广东省广州市番禺区玉沙路金城国际大厦</span></li>
                  <li><span class="footer_cotact_type">电话：</span><span class="footer_cotact_content"><a href="tel:66889888" class="call">66889888</a></span></li>
                  <li><span class="footer_cotact_type">网址：</span><span class="footer_cotact_content"><a href="#" title="官网">www.dede58.com</a></span></li>
                  <li><span class="footer_cotact_type">邮箱：</span><span class="footer_cotact_content">admin@dede58.com</span></li>
-->                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div class="copyright">Copyright &copy; 2020-2050 <?php echo $conf['web_name'] ?> 版权所有 <?php if($conf['web_icp']){echo " <br/> 网站备案号: <a href='http://beian.miit.gov.cn/' target='_blank'>".$conf['web_icp']."</a>";?> <?php } ?> </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>

</body>
<script src="#/templets/default/js/online.js" type="text/javascript"></script>
</html>
