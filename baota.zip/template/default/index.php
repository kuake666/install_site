<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';
?>
    <header id="fh5co-header" class="fh5co-cover" role="banner"
            style="background-image:url(https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/20200102213404jC.jpg);" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-7 text-left">
                    <div class="display-t">
                        <div class="display-tc animate-box" data-animate-effect="fadeInUp">
                            <h1 class="mb30"><?php echo $conf['web_name'] ?></h1>
                            <p>
                                <a href="./consumer/register.php" class="btn btn-primary">免费注册</a>
                                <a href="./consumer/login.php" class="btn btn-success">立即登录</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div id="fh5co-project">
        <div class="container">
            <div class="row row-pb-md">
                <div class="col-md-8 col-md-offset-2 text-left animate-box" data-animate-effect="fadeInUp">
                    <div class="fh5co-heading">
                        <span>We're expert</span>
                        <h3>系统功能介绍</h3>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia,
                            there live the blind texts.</p>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-md-4 col-sm-6 ">
                    <div class="feature-center animate-box" data-animate-effect="fadeInUp">
						<span class="icon">
							<i class="icon-eye"></i>
						</span>
                        <h3>安全可靠</h3>
                        <p>独立专项服务器，网站安全可靠</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 ">
                    <div class="feature-center animate-box" data-animate-effect="fadeInUp">
						<span class="icon">
							<i class="icon-command"></i>
						</span>
                        <h3>极速建站</h3>
                        <p>极速建站，只需一键就可拥有专属网站</p>
                    </div>
                </div>
                <div class="clearfix visible-sm-block"></div>
                <div class="col-md-4 col-sm-6 ">
                    <div class="feature-center animate-box" data-animate-effect="fadeInUp">
						<span class="icon">
							<i class="icon-power"></i>
						</span>
                        <h3>海量模板</h3>
                        <p>不同行业模板，随意挑选，随时更改</p>
                    </div>
                </div>

                <div class="clearfix visible-md-block"></div>

                <div class="col-md-4 col-sm-6 ">
                    <div class="feature-center animate-box" data-animate-effect="fadeInUp">
						<span class="icon">
							<i class="icon-eye"></i>
						</span>
                        <h3>维护便利</h3>
                        <p>维护网站便利，自己可随时修改网站</p>
                    </div>
                </div>
                <div class="clearfix visible-sm-block"></div>
                <div class="col-md-4 col-sm-6 ">
                    <div class="feature-center animate-box" data-animate-effect="fadeInUp">
						<span class="icon">
							<i class="icon-command"></i>
						</span>
                        <h3>网站三合一</h3>
                        <p>PC、手机、微信网站三合一</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 ">
                    <div class="feature-center animate-box" data-animate-effect="fadeInUp">
						<span class="icon">
							<i class="icon-power"></i>
						</span>
                        <h3>售后服务</h3>
                        <p>7*24小时，详细解答，随时响应</p>
                    </div>
                </div>

                <div class="clearfix visible-md-block"></div>

            </div>


        </div>

    </div>


    <div id="fh5co-testimonial" class="fh5co-bg-section">
        <div class="container">
            <div class="row animate-box row-pb-md">
                <div class="col-md-8 col-md-offset-2 text-left fh5co-heading">
                    <span>You deserved happiness</span>
                    <h3>用户评价</h3>
                    <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident.
                        Odit ab aliquam dolor eius.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 animate-box">
                    <div class="testimonial">
                        <blockquote>
                            <p>&ldquo;点评：安全稳定快速的服务器是网站经营的前提，<?php echo $conf['web_name']?>所具备的安全性完全可以作为建站行业标准，大大减少了中小站长的运维成本，值得推荐！&rdquo;</p>
                            <p class="author"><img src="./assets/default/images/person1.jpg"
                                                   alt="Free HTML5 Bootstrap Template by gettemplates.co"> <cite>
                                    小布 —— 资深服务器评测博主</cite></p>
                        </blockquote>
                    </div>

                    <div class="testimonial fh5co-selected">
                        <blockquote>
                            <p>&ldquo;点评：一直在做建站评测，<?php echo $conf['web_name']?>有着行业领先的安全性，在线率高、性能出众，在用户中的口碑极佳，是一款值得购买的建站产品，适合中小网站。&rdquo;</p>
                            <p class="author"><img src="./assets/default/images/person2.jpg"
                                                   alt="Free HTML5 Bootstrap Template by gettemplates.co"> <cite>&mdash;
                                    格优—— 企业用户</cite></p>
                        </blockquote>
                    </div>
                </div>

                <div class="col-md-6 animate-box">
                    <div class="testimonial fh5co-selected">
                        <blockquote>
                            <p>&ldquo;点评：<?php echo $conf['web_name']?>在中小网站主中的口碑很好，专业、有质量，售后有保障，在价格方面也是对中小企业和网站主非常的友好，性价比相对来说非常高。.&rdquo;</p>
                            <p class="author"><img src="./assets/default/images/person3.jpg"
                                                   alt="Free HTML5 Bootstrap Template by gettemplates.co"> <cite>&mdash;
                                    阿元 —— 知名站长</cite></p>
                        </blockquote>
                    </div>

                    <div class="testimonial">
                        <blockquote>
                            <p>&ldquo;点评：国内大多数服务商的建站毫无亮点，而<?php echo $conf['web_name']?>多年以来一直专心做好做强建站系统，得到广泛的个人站长人群认可。&rdquo;</p>
                            <p class="author"><img src="./assets/default/images/person1.jpg"
                                                   alt="Free HTML5 Bootstrap Template by gettemplates.co"> <cite>&mdash;
                                    玲哥 —— 知名站长</cite></p>
                        </blockquote>
                    </div>

                </div>


            </div>
        </div>
    </div>


 <?php
include 'footer.php';

?>