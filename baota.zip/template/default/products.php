<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';
$p = is_numeric($_GET['p']) ? $_GET['p'] : '1';
if($p < 1){
    $p =1;
}
$pp=$p+7;
$pagesize=6;
$start=($p-1)*$pagesize;

$list = $DB->query("SELECT * FROM `wcms_program` WHERE `status`=1 LIMIT $start,$pagesize")->fetchAll();
$pages=$DB->query("SELECT count(*) FROM `wcms_program`  WHERE `status`=1 ")->rowCount()/$pagesize;

if($pp>$pages){
    $s = 1;
    $pp=$pages;
    if($pages > 8){
        $s = $pages - $p;
        $s = 7 - $s;
        $s = $p - $s;
    }
}else{
    $s = $p;
}
if($p==1){
    $prev=1;
}else{
    $prev=$p-1;
}
if($p==$pages){
    $next=$p;
}else{
    $next=$p+1;
}
?>

	<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/20200102213404jC.jpg);" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-7 text-left">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeInUp">
							<h1 class="mb30">产品展示</h1>

						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	

	<div id="fh5co-project">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-8 col-md-offset-2 text-left fh5co-heading  animate-box">
					<span>我们的产品</span>
					<h2>我们的产品</h2>
					<p>无需购买主机无需技术，注册登陆后充值搭建即可使用，您可以随时在电脑/手机/平板登陆本网站进行功能设置.</p>
				</div>
			</div>

			<div class="row">
                <?php foreach ($list as $res){?>
                    <div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
                        <a href="http://<?php echo $res['demo']?>" target="_blank"><img src="<?php echo $res['img']?>" alt="<?php echo $res['name']?>" class="img-responsive">
                           
                        </a>
                        
                         <div class="fh5co-copy">
                                <p><?php echo $res['name']?>  <?php echo $res['price']?>元/<?php echo $res['usetime']?>个月</p>
                            </div>
                    </div>

                <?php }?>



				<div class="col-md-12 text-center">
					<nav aria-label="Page navigation">

    <ul class=" pagination" boundary-links="true" total-items="totalItems" ng-model="currentPage" previous-text="‹" next-text="›" first-text="«" last-text="»">
        <li ng-if="boundaryLinks" ng-class="{disabled: noPrevious()}" class="ng-scope"><a href="index.php?type=products&p=1" ng-click="selectPage(1)" class="ng-binding">«</a></li>
        <li ng-if="directionLinks" ng-class="{disabled: noPrevious()}" class="ng-scope"><a href="index.php?type=products&p=<?=$prev?>" ng-click="selectPage(page - 1)" class="ng-binding">‹</a></li>

        <?php for($i=$s;$i<=$pp;$i++){?>
            <li><a ng-if="boundaryLinks" ng-class="{disabled: noNext()}"  class="ng-scope <?php if($i==$p){echo'active';}?>" href="?p=<?=$i?>" ng-click="selectPage(page.number)" class="ng-binding"><?=$i?></a></li>
        <?php }?>
        <li ng-if="directionLinks" ng-class="{disabled: noNext()}" class="ng-scope"><a href="index.php?type=products&p=<?=$next?>" ng-click="selectPage(page + 1)" class="ng-binding">›</a></li>
        <li ng-if="boundaryLinks" ng-class="{disabled: noNext()}" class="ng-scope"><a href="index.php?type=products&p=<?=$pages?>" ng-click="selectPage(totalPages)" class="ng-binding">»</a></li>

    </ul>



					</nav>
				</div>

			</div>
		</div>
		
	</div>


<?php
include 'footer.php';

?>