<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include '../app/common.php';
?>

<div id="fh5co-started">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <span>Let's work together</span>
                <h2>PC端 移动端 自适应 </h2>
                <p>
                    <a href="../consumer/register.php" type="button" class="btn btn-primary">免费注册</a>
                </p>
            </div>
        </div>
    </div>
</div>

<footer id="fh5co-footer" role="contentinfo">
    <div class="container">
        <div class="row row-pb-md">
            <div class="col-md-4 fh5co-widget ">
                <h3>联系我们.</h3>
                <p><?php echo $conf['connect_us'] ?></p>
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1 ">
                <?php echo $conf['friend_link'] ?>
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1 ">
                <?php echo $conf['quikly_pass'] ?>
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1 ">
                <p>关于我们:<br/><?php echo $conf['about_us'] ?></p>
            </div>
        </div>

        <div class="row copyright">
            <div class="col-md-12 text-center">
                <p>
                    <small class="block">&copy; <span id="year"></span> &copy; Copyright
                        . <?php echo $conf['web_name'] ?> <?php if($conf['web_icp']){echo " <br/> 网站备案号: <a href='http://beian.miit.gov.cn/' target='_blank'>".$conf['web_icp']."</a>";?> <?php } ?></small>
                </p>
                <?php echo $conf['access_tongji'] ?>
            </div>
        </div>
    </div>
</footer>

</div>

<div class="gototop js-top">
    <a href="#" class="./assets/default/js-gotop"><i class="icon-arrow-up"></i></a>
</div>

<!-- jQuery -->
<script src="./assets/default/js/jquery.min.js"></script>
<!-- jQuery Easing -->
<script src="./assets/default/js/jquery.easing.1.3.js"></script>
<!-- Bootstrap -->
<script src="./assets/default/js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="./assets/default/js/jquery.waypoints.min.js"></script>
<!-- countTo -->
<script src="./assets/default/js/jquery.countTo.js"></script>
<!-- Magnific Popup -->
<script src="./assets/default/js/jquery.magnific-popup.min.js"></script>
<script src="./assets/default/js/magnific-popup-options.js"></script>
<!-- Stellar -->
<script src="./assets/default/js/jquery.stellar.min.js"></script>
<!-- Main -->
<script src="./assets/default/js/main.js"></script>
<script>
    var t = new Date();
    var year = t.getFullYear();
    $("#year").text(year);
</script>
</body>
</html>


