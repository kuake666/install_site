<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include '../app/common.php';
$type = daddslashes($_GET['type']);
if (!$type || $type == 'index') {
    $indexActive = 'class="active"';
} else if ($type == 'products') {
    $productsActive = 'class="active"';
} else if ($type == 'blog') {
    $blogActive = 'class="active"';
}

?>
<!DOCTYPE HTML>

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $conf['web_name'] ?>|<?php echo $conf['web_subtitle'] ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $conf['web_description'] ?>"/>
    <meta name="keywords"  content="<?php echo $conf['keywords'] ?>"/>


    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content=""/>
    <meta property="og:image" content=""/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta property="og:description" content=""/>
    <meta name="twitter:title" content=""/>
    <meta name="twitter:image" content=""/>
    <meta name="twitter:url" content=""/>
    <meta name="twitter:card" content=""/>

    <!--	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">-->
    <link rel="shortcut icon" href="./assets/img/favicon.ico?r=<?php echo rand(10000,99999)?>">
    <!-- Animate.css -->
    <link rel="stylesheet" href="./assets/default/css/animate.css">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="./assets/default/css/icomoon.css">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="./assets/default/css/bootstrap.css">

    <!-- Magnific Popup -->
    <link rel="stylesheet" href="./assets/default/css/magnific-popup.css">

    <!-- Theme style  -->
    <link rel="stylesheet" href="./assets/default/css/style.css">

    <!-- Modernizr JS -->
    <script src="./assets/default/js/modernizr-2.6.2.min.js"></script>
    <!-- FOR IE9 below -->
    <!--[if lt IE 9]>
    <script src="./assets/default/js/respond.min.js"></script>
    <![endif]-->

</head>
<body>

<div class="fh5co-loader"></div>

<div id="page">
    <nav class="fh5co-nav" role="navigation">
        <div class="container">
            <div class="row">
                <div class="col-xs-2 text-left">
                    <div id="fh5co-logo"><img src="./assets/img/logo/logo.png?r=<?php echo rand(10000,99999)?>" alt=""></div>
                </div>
                <div class="col-xs-10 text-right menu-1">
                    <ul>
                        <li <?php echo $indexActive?>><a href="index.php">首页</a></li>
                        <li <?php echo $productsActive?>><a href="?type=products">产品</a></li>
                        <li <?php echo $blogActive?>><a href="?type=blog">解决方案</a></li>
                    </ul>
                </div>
            </div>

        </div>
    </nav>
