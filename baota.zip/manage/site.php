<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
$numrows = $DB->query("SELECT * from `wcms_site` ")->rowCount();
$list = $DB->query("SELECT * FROM `wcms_site`")->fetchAll();

?>

<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">用户网站</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">用户网站</h4>
                        <p class="text-muted mb-4 font-13">
                            Available my sites.
                        </p>

                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>用户编号</th>
                                <th>网站域名</th>
                                <th>项目名称</th>
                                <th>开通时间</th>
                                <th>到期时间</th>
                                <th>操作</th>
                            </tr>
                            </thead>


                            <tbody>
                            <?php foreach ($list as $res) {
                                $program = $DB->query("SELECT * FROM wcms_program WHERE code='{$res['code']}' limit 1")->fetch();
                                echo '
                                <tr id="' . $res['sid'] . '">
                                    <td>' . $res['uid'] . '</td>
                                    <td><b><a href="http://' . $res['domain'] . '" target="_blank">' . $res['domain'] . ' </a></b></td>
                                    <td>' . $program['name'] . '</td>
                                    <td>' . $res['addtime'] . '</td>
                                    <td>' . $res['endtime'] . '</td>
                                    <td>
                                       <button  onclick="rePay(' . $res['sid'] . ')"  class="btn m-b-xs btn-sm btn-success btn-addon" >续费</button>
                                       <button  onclick="delSite(' . $res['sid'] . ',\''.$res['domain'].'\')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</button>
                                  <!--  <button  class="btn m-b-xs btn-sm btn-info btn-addon"   onclick="opeSite(' . $res['bid'] . ')">操作网站</button>-->
                                </tr>
                                ';
                            }
                            ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->
    <?php
    include('footer.php');
    ?>
    <script>
        function rePay(sid) {
            var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
            $.ajax({
                url: './ajax.php?act=rePay',
                type: 'post',
                dataType: 'json',
                data: { sid: sid },
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            location.href = data.url;
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                },
                error: function () {
                    layer.alert("网络连接错误");
                }
            });
        }

        function delSite(sid,domain) {
            layer.confirm('确认删除域名为 ' + domain + ' 的网站吗?', {
                btn: ['是', '否'], btn1: function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: './ajax.php?act=delSite',
                        type: 'post',
                        dataType: 'json',
                        data: {sid: sid},
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    var del="#"+sid;
                                    $(del).remove();
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert("网络连接错误");
                        }
                    });
                }
            });
        }
    </script>
