<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

$numrows = $DB->query("SELECT * FROM `wcms_order` ")->rowCount();
$list = $DB->query("SELECT * FROM `wcms_order` order by date desc")->fetchAll();

?>
<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">日志模块</a></li>
                            <li class="breadcrumb-item active">消费记录</li>
                        </ol>
                    </div>
                    <h4 class="page-title">日志模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">消费记录</h4>
                        <p class="text-muted mb-4 font-13">
                            Available my logs.
                        </p>

                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>订单编号</th>
                                <th>订单金额</th>
                                <th>订单日期</th>
                                <th>订单状态</th>
                            </tr>
                            </thead>


                            <tbody>
                            <?php
                            foreach ($list as $res) {
                                //1 表示充值成功  0表示充值失败  2表示消费成功
                                if ($res['status'] == 0) {
                                    $res['money'] = "+" . $res['money'];
                                    $res['status'] = "<span class='btn btn-ms'><font color=red>充值失败</font></span>";
                                } else if ($res['status'] == 1) {
                                    $res['money'] = "+" . $res['money'];
                                    $res['status'] = "<span class='btn btn-ms'><font color=green>充值成功</font></span>";
                                } else if ($res['status'] == 2) {
                                    $res['money'] = "-" . $res['money'];
                                    $res['status'] = "<span class='btn btn-ms'><font color=warning>消费成功</font></span>";
                                }
                                echo '
                                          <tr>
                                          <td>' . $res['order_no'] . '</td>
                                          <td>' . $res['money'] . '</td>
                                          <td> ' . $res['date'] . '</td>
                                          <td>' . $res['status'] . '</td>
                                          </tr>';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->
    <?php
    include('footer.php');
    ?>
