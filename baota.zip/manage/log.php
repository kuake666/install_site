<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
$numrows=$DB->query("SELECT * from `wcms_log` ")->rowCount();

$list=$DB->query("SELECT * FROM  `wcms_log`  order by date asc")->fetchAll();
?>

    <!-- Page Content-->
    <div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">日志模块</a></li>
                            <li class="breadcrumb-item active">操作记录</li>
                        </ol>
                    </div>
                    <h4 class="page-title">日志模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">操作记录</h4>
                        <p class="text-muted mb-4 font-13">
                            Available my logs.
                        </p>

                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>时间</th>
                                <th>详情</th>
                                <th>地点</th>
                                <th>用户编号</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            foreach($list as $res){
                                echo '
                                          <tr>
                                          <td>'.$res['date'].'</td>
                                          <td>'.$res['type'].'</td>
                                          <td>'.$res['city'].'</td>
                                          <td>'.$res['uid'].'</td>
                                          </tr>';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

<?php
include('footer.php');
?>