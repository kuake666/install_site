<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';
?>

<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">系统模块</a></li>
                            <li class="breadcrumb-item active">网站设置</li>
                        </ol>
                    </div>
                    <h4 class="page-title">系统模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">网站设置</h4>
                        <p class="text-muted mb-3">sysSet.
                        </p>
                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                               class="col-sm-2 col-form-label text-left">网站名称</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="web_name"
                                                   value="<?php echo $conf['web_name'] ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">网站副标题</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="web_subtitle"
                                                   value="<?php echo $conf['web_subtitle'] ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">网站备案号</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="web_icp"
                                                   value="<?php echo $conf['web_icp'] ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">QQ跳转浏览器</label>
                                        <div class="col-sm-10">
                                            <select class="form-control select2" data-toggle="select2" id="qqjump">
                                                <option value="1" <?php if($conf['qqjump']  == 1){?> selected = "selected" <?php }?>>开启跳转</option>
                                                <option value="0" <?php if($conf['qqjump']  == 0){?> selected = "selected" <?php }?>>关闭跳转</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">push是否付费</label>
                                        <div class="col-sm-10">
                                            <select class="form-control select2" data-toggle="select2" name="push_toll" id="change_666" >
                                                <option value="1" <?php if($conf['push_toll']  == 1){?> selected = "selected" <?php }?>>付费</option>
                                                <option value="0" <?php if($conf['push_toll']  == 0){?> selected = "selected" <?php }?>>免费</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row" id="open_666" <?php if($conf['push_toll']==0){ echo "style='display:none;'";} ?>>
                                        <label for="example-email-input" class="col-sm-2 col-form-label text-left">push付费价格</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="push_price" value="<?php echo $conf['push_price'] ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">首页模板</label>
                                        <div class="col-sm-10">
                                            <select class="form-control select2" data-toggle="select2" id="template">
		                                        <option value="<?php echo $conf['template'] ?>"><?php echo $conf['template'] ?></option>
		                                        <?php
		                                        $mblist = \app\Template::getList($conf['template']);
		                                        foreach ($mblist as $row) {
                                                    if($row){
                                                        echo '<option value="'.$row.'">'.$row.'</option>';
                                                    }
		                                            ?>
		                                        <?php } ?>
		                                    </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">网站关键字</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" rows="5"
                                                      name="keywords"><?php echo $conf['keywords'] ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">网站描述</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" rows="5"
                                                      name="web_description"><?php echo $conf['web_description'] ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">关于我们</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" rows="5"
                                                      name="about_us"><?php echo $conf['about_us'] ?></textarea>
                                            <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">联系我们</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" rows="5"
                                                      name="connect_us"><?php echo $conf['connect_us'] ?></textarea>
                                            <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">友情链接</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" rows="5"
                                                      name="friend_link"><?php echo $conf['friend_link'] ?></textarea>
                                            <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">快捷通道</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" rows="5"
                                                      name="quikly_pass"><?php echo $conf['quikly_pass'] ?></textarea>
                                            <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">访问统计代码</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" rows="5" name="access_tongji"><?php echo $conf['access_tongji'] ?></textarea>
                                            <code>统计网站访问人数等信息 <a href="https://www.umeng.com/" target="_blank">cnzz免费网站流量统计</a></code>
                                        </div>
                                    </div>
                                </div>
                            </div><!--end card-body-->
                            <div class="row">
                                <div class="col-sm-10 ml-auto">
                                    <button type="button" class="btn btn-primary" onclick="siteSet()">保存数据</button>
                                </div>
                            </div>
                        </form>
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->


        </div><!--end row-->

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">LOGO设置</h4>
                        <p class="text-muted mb-3">logoSet.
                        </p>
                        <form method="post" action="#" enctype="multipart/form-data" id="formTag1">
                            <input type="hidden" name="do" value="upload">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                               class="col-sm-2 col-form-label text-left">网站LOGO</label>
                                        <div class="col-sm-10">
                                            <div class="col-sm-10"><img src="../assets/img/logo/logo.png?r=<?php echo rand(10000, 99999) ?>" style="max-width:100%"/></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                               class="col-sm-2 col-form-label text-left">更换LOGO</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="file" name="file" >
                                        </div>
                                    </div>
                                </div>
                            </div><!--end card-body-->
                            <div class="row">
                                <div class="col-sm-10 ml-auto">
                                    <button type="button" class="btn btn-primary" onclick="logoSet()">保存数据</button>
                                </div>
                            </div>
                        </form>
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end row-->

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mt-0 header-title">ICO图标设置</h4>
                            <p class="text-muted mb-3">icoSet.
                            </p>
                            <form method="post" action="#" enctype="multipart/form-data" id="formTag2">
                                <input type="hidden" name="do" value="upload">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">ICO图标</label>
                                            <div class="col-sm-10">
                                                <div class="col-sm-10"><img src="../assets/img/favicon.ico?r=<?php echo rand(10000, 99999) ?>" style="max-width:100%"/></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">更换ICO图标</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="file" name="file" >
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end card-body-->
                                <div class="row">
                                    <div class="col-sm-10 ml-auto">
                                        <button type="button" class="btn btn-primary" onclick="icoSet()">保存数据</button>
                                    </div>
                                </div>
                            </form>
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end row-->

        </div><!-- container -->

        <?php
        require_once 'footer.php';
        ?>
        <script>
            $("select[id^='change_']").change(function(){
                var id = $(this).attr('id').split('_')[1];
                var c  = $(this).val();
                if( parseInt(c) == 1 ){
                    $('#open_'+id).show();
                }else{
                    $('#open_'+id).hide();
                }
            });

            function siteSet() {
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                $.ajax({
                    url: "ajax.php?act=siteSet",
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        web_name: $("input[name='web_name']").val(),
                        web_subtitle: $("input[name='web_subtitle']").val(),
                        web_description: $("textarea[name='web_description']").val(),
                        push_price: $("input[name='push_price']").val(),
                        push_toll: $("select[name='push_toll']").val(),
                        template: $("#template").val(),
                        qqjump: $("#qqjump").val(),
                        keywords: $("textarea[name='keywords']").val(),
                        web_icp: $("input[name='web_icp']").val(),
                        about_us: $("textarea[name='about_us']").val(),
                        connect_us: $("textarea[name='connect_us']").val(),
                        friend_link: $("textarea[name='friend_link']").val(),
                        access_tongji: $("textarea[name='access_tongji']").val(),
                        quikly_pass: $("textarea[name='quikly_pass']").val()
                    },
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4});

                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误!");
                    }
                })
            }

            function logoSet() {
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                console.log($("#formTag1")[0]);
                $.ajax({
                    url: "ajax.php?act=logoSet",
                    type: 'POST',
                    dataType: 'json',
                    data: new FormData($("#formTag1")[0]),
                    processData: false,  //必须false才会避开jQuery对 formdata 的默认处理
                    contentType: false,
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4});
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误!");
                    }
                })

            }

            function icoSet() {
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                console.log($("#formTag2")[0]);
                $.ajax({
                    url: "ajax.php?act=icoSet",
                    type: 'POST',
                    dataType: 'json',
                    data: new FormData($("#formTag2")[0]),
                    processData: false,  //必须false才会避开jQuery对 formdata 的默认处理
                    contentType: false,
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4});
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误!");
                    }
                })

            }
        </script>
