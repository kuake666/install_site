<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

$numrows = $DB->query("SELECT * from `wcms_protype` ")->rowCount();
$list = $DB->query("SELECT * FROM `wcms_protype` ")->fetchAll();
$id = intval(daddslashes($_GET['id']));
$type = daddslashes($_GET['type']);

if ($type == 'edit' && $id) {
    $row = $DB->query("SELECT * from `wcms_protype` WHERE `id`={$id} limit 1")->fetch();
    $title = '修改分类';
    $result = 1;
} else if ($type == 'add') {
    $title = '添加分类';
    $result = 2;
} else {
    $result = 3;
}
?>

<?php if ($result == 3){ ?>
<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">项目分类</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">项目分类</h4>
                        <div class="float-right">
                            <a href="?type=add" class="btn m-b-xs btn-sm btn-success btn-addon">
                                <i class="typcn typcn-th-large-outline "></i> 添加分类
                            </a>
                        </div>
                        <p class="text-muted mb-4 font-13">
                            系统共有 <code><?php echo $numrows?></code> 个项目分类
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>分类编号</th>
                                <th>分类名称</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $res) {
                                echo '
                                    <tr id="' . $res['id'] . '">
                                        <td>' . $res['id'] . '</td>
                                        <td>' . $res['name'] . '</td>
                                        <td>
                                          <a href="?type=edit&id=' . $res['id'] . '" class="btn m-b-xs btn-sm btn-primary btn-addon" >修改</a>
                                          <a href="javascript:void(0);" onclick="delProType(' . $res['id'] . ')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</a>
                                        </td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php } else if ($result == 2){ ?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                <li class="breadcrumb-item active"><?php echo $title ?></li>
                            </ol>
                        </div>
                        <h4 class="page-title">管理模块</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                            <p class="text-muted mb-3">addProType.
                            </p>
                            <form action="#" method="post">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">分类名称</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="name">
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end card-body-->
                                <div class="row">
                                    <div class="col-sm-10 ml-auto">
                                        <button type="button" class="btn btn-primary" id="addProType">保存数据</button>
                                    </div>
                                </div>
                            </form>
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end row-->
        </div><!-- container -->
        <?php } else if ($result == 1){ ?>
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="float-right">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                    <li class="breadcrumb-item active"><?php echo $title ?></li>
                                </ol>
                            </div>
                            <h4 class="page-title">管理模块</h4>
                        </div><!--end page-title-box-->
                    </div><!--end col-->
                </div>
                <!-- end page title end breadcrumb -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                                <p class="text-muted mb-3">editProType.
                                </p>
                                <form action="#" method="post">
                                    <input class="form-control" type="hidden" name="id"
                                           value="<?php echo $row['id'] ?>">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">分类名称</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="name"
                                                           value="<?php echo $row['name'] ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div><!--end card-body-->
                                    <div class="row">
                                        <div class="col-sm-10 ml-auto">
                                            <button type="button" class="btn btn-primary" id="editProType">保存数据</button>
                                        </div>
                                    </div>
                                </form>
                            </div><!--end card-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end row-->
            </div><!-- container -->
            <?php } ?>

            <?php
            include('footer.php');
            ?>
            <script>
                function delProType(id) {
                    layer.confirm('确认删除 ' + id + ' 吗?', {
                        btn: ['是', '否'], btn1: function () {
                            var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
                            $.ajax({
                                url: 'ajax.php?act=delProType',
                                type: 'POST',
                                dataType: 'json',
                                data: {id: id},
                                success: function (data) {
                                    layer.close(ii);
                                    if (data.code == 1) {
                                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                            var del="#"+id;
                                            $(del).remove();
                                        });
                                    } else {
                                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                    }
                                },
                                error: function () {
                                    layer.close(ii);
                                    layer.alert("网络连接错误");
                                }
                            });
                        }
                    });
                }

                $("#editProType").click(function () {
                    var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
                    $.ajax({
                        url: 'ajax.php?act=editProType',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            id: $("input[name='id']").val(),
                            name: $("input[name='name']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.close(ii);
                            layer.alert("网络连接错误");
                        }
                    })
                })


                $("#addProType").click(function () {
                    var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
                    $.ajax({
                        url: 'ajax.php?act=addProType',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            name: $("input[name='name']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.close(ii);
                            layer.alert("网络连接错误");
                        }
                    })
                })
            </script>
