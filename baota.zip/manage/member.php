<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

//用户会员分类
$numrows = $DB->query("SELECT * from `wcms_member` ")->rowCount();
$list = $DB->query("SELECT * FROM `wcms_member` ")->fetchAll();
//添加、修改会员分类
$mid = intval(daddslashes($_GET['mid']));
$type = daddslashes($_GET['type']);

if ($type == 'edit' && $mid) {
    $row = $DB->query("SELECT * from `wcms_member` WHERE mid={$mid} limit 1")->fetch();
    $title = '修改会员分类';
    $result = 1; //修改会员分类
} else if ($type == 'add') {
    $title = '添加会员分类';
    $result = 2; //添加会员分类
} else {
    $result = 3; //会员分类列表
}
?>

<?php if ($result == 3){ ?>
<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">会员分类</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">会员分类</h4>
                        <p class="text-muted mb-4 font-13">
                            Available my sites.
                            <a href="member.php?type=add" class="btn m-b-xs btn-sm btn-primary btn-addon">
                                <i class="fa fa-edit"></i>添加分类
                            </a>
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>会员名称</th>
                                <th>会员价格</th>
                                <th>唯一编码</th>
                                <th>会员折扣</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $res) {
                                echo '
                                    <tr id="' . $res['mcode'] . '">
                                        <td>' . $res['mname'] . '</td>
                                        <td>' . $res['mprice'] . '</td>
                                        <td>' . $res['mcode'] . '</td>
                                        <td>' . $res['mpercent'] . '</td>
                                        <td>
                                          <a href="member.php?type=edit&mid=' . $res['mid'] . '" class="btn m-b-xs btn-sm btn-primary btn-addon" >修改</a>
                                          <a href="#" onclick="delMember(' . $res['mcode'] . ')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</a>
                                        </td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php } else if ($result == 2){ ?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                <li class="breadcrumb-item active"><?php echo $title ?></li>
                            </ol>
                        </div>
                        <h4 class="page-title">会员分类添加</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                            <p class="text-muted mb-3">addMember.
                            </p>
                            <form action="#" method="post">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">会员名称</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="mname">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">会员描述</label>
                                            <div class="col-sm-10">
                                                <textarea class="form-control" rows="5" name="mdecription"></textarea>
                                                <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">会员价格</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="mprice">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">会员折扣</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="mpercent" >
                                                <small class="text-navy">商品价格=商品原价*会员折扣</small>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">唯一编码</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="mcode">
                                                <small class="text-navy">注意:唯一编码只能是数字,高等级的编码一定要比低等级的编码大</small>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end card-body-->
                                <div class="row">
                                    <div class="col-sm-10 ml-auto">
                                        <button type="button" class="btn btn-primary" id="addMember">保存数据</button>
                                    </div>
                                </div>
                            </form>
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end row-->
        </div><!-- container -->
        <?php } else if ($result == 1){ ?>
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="float-right">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0);">用户模块</a></li>
                                    <li class="breadcrumb-item active"><?php echo $title ?></li>
                                </ol>
                            </div>
                            <h4 class="page-title">用户模块</h4>
                        </div><!--end page-title-box-->
                    </div><!--end col-->
                </div>
                <!-- end page title end breadcrumb -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                                <p class="text-muted mb-3">memberEdit.
                                </p>
                                <form action="#" method="post">
                                    <div class="row">
                                        <input class="form-control" type="hidden" name="mid"
                                               value="<?php echo $row['mid'] ?>">
                                        <div class="col-lg-12">
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">会员名称</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="mname" value="<?php echo $row['mname']?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">会员描述</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" name="mdecription"><?php echo $row['mdecription']?></textarea>
                                                    <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">会员价格</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="mprice" value="<?php echo $row['mprice']?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">会员折扣</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="mpercent" value="<?php echo $row['mpercent']?>">
                                                    <small class="text-navy">商品价格=商品原价*会员折扣</small>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">唯一编码</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="mcode" value="<?php echo $row['mcode']?>" disabled>
                                                    <small class="text-navy">注意:唯一编码只能是数字,高等级的编码一定要比低等级的编码大</small>
                                                </div>
                                            </div>

                                        </div>
                                    </div><!--end card-body-->
                                    <div class="row">
                                        <div class="col-sm-10 ml-auto">
                                            <button type="button" class="btn btn-primary" id="editMember">保存数据</button>
                                        </div>
                                    </div>
                                </form>
                            </div><!--end card-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end row-->
            </div><!-- container -->
            <?php } ?>

            <?php
            include('footer.php');
            ?>
            <script>
                function delMember(mcode) {
                    layer.confirm('确认删除 ' + mcode + ' 吗?', {
                        btn: ['是', '否'], btn1: function () {
                            var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                            $.ajax({
                                url: 'ajax.php?act=delMember',
                                type: 'POST',
                                dataType: 'json',
                                data: { mcode: mcode },
                                success: function (data) {
                                    layer.close(ii);
                                    if (data.code == 1) {
                                        layer.msg(data.msg, { icon: 1, time: 2000, shade: 0.4 }, function () {
                                            var del="#"+mcode;
                                            $(del).remove();
                                        });
                                    } else {
                                        layer.msg(data.msg, { icon: 2, time: 2000, shade: 0.4 });
                                    }
                                },
                                error:function () {
                                    layer.alert("网络连接错误");
                                }
                            });
                        }
                    });
                }

                $("#editMember").click(function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: 'ajax.php?act=editMember',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            mcode: $("input[name='mcode']").val(),
                            mname: $("input[name='mname']").val(),
                            mprice: $("input[name='mprice']").val(),
                            mpercent: $("input[name='mpercent']").val(),
                            mdecription: $("textarea[name='mdecription']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = 'member.php';
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error:function () {
                            layer.alert("网络连接错误");
                        }
                    })
                })


                $("#addMember").click(function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: 'ajax.php?act=addMember',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            mcode: $("input[name='mcode']").val(),
                            mname: $("input[name='mname']").val(),
                            mprice: $("input[name='mprice']").val(),
                            mpercent: $("input[name='mpercent']").val(),
                            mdecription: $("textarea[name='mdecription']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = 'member.php';
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error:function () {
                            layer.alert("网络连接错误");
                        }
                    })
                })
            </script>
