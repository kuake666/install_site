<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

$numrows = $DB->query("SELECT * from `wcms_card` WHERE `type`=0")->rowCount();
$list = $DB->query("SELECT * FROM `wcms_card` ")->fetchAll();
$type = daddslashes($_GET['type']);
if ($type == 'add') {
    $title = '添加卡密';
    $result = 2;
} else {
    $result = 1;
}
?>

<?php if ($result == 1){ ?>
<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">卡密列表</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">卡密列表</h4>
                        <p class="text-muted mb-4 font-13">
                            card.
                            <a href="?type=add" class="btn m-b-xs btn-sm btn-primary btn-addon">
                                <i class="fa fa-edit"></i> 添加
                            </a>
                            <a href="#" onclick="delUseCard()" class="btn m-b-xs btn-sm btn-warning btn-addon">
                                <i class="fa fa-adjust"></i> 清空已使用
                            </a>
                            <a href="#" onclick="delAllCard()" class="btn m-b-xs btn-sm btn-danger btn-addon">
                                <i class="fa fa-database"></i> 清空所有
                            </a>
                            <a href="#" onclick="exportCard()" class="btn m-b-xs btn-sm btn-success btn-addon">
                                <i class="fa fa-file-export"></i> 导出未使用
                            </a>
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>卡密</th>
                                <th>金额</th>
                                <th>状态</th>
                                <th>添加时间</th>
                                <th>使用时间</th>
                                <th>使用者编号</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $res) {
                                if($res['active'] == 0){
                                    $res['active'] = "<span style='color:green;'>未使用</span>";
                                }else{
                                    $res['active'] = "<span style='color:red;'>已使用</span>";
                                }
                                if(!$res['endtime']){$res['endtime'] = '无';}
                                if(!$res['uid']){$res['uid'] = '无';}
                                echo '
                                    <tr id="' . $res['id'] . '">
                                        <td>' . $res['card'] . '</td>
                                        <td>' . $res['money'] . '</td>
                                        <td>' . $res['active'] . '</td>
                                        <td>' . $res['addtime'] . '</td>
                                        <td>' . $res['endtime'] . '</td>
                                        <td>' . $res['uid'] . '</td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php } else if ($result == 2){ ?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                <li class="breadcrumb-item active"><?php echo $title ?></li>
                            </ol>
                        </div>
                        <h4 class="page-title">管理模块</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                            <p class="text-muted mb-3">addCard.
                            </p>
                            <form action="#" method="post">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">卡密金额</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="money" onkeyup="this.value=this.value.replace(/\D/g,'')" placeholder="请输入整数!">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">生成个数</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="num" onkeyup="this.value=this.value.replace(/\D/g,'')" placeholder="请输入整数!">
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end card-body-->
                                <div class="row">
                                    <div class="col-sm-10 ml-auto">
                                        <button type="button" class="btn btn-primary" id="addCard">确认生成</button>
                                    </div>
                                </div>
                            </form>
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end row-->
        </div><!-- container -->
        <?php } else if ($result == 1){ ?>
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="float-right">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                    <li class="breadcrumb-item active"><?php echo $title ?></li>
                                </ol>
                            </div>
                            <h4 class="page-title">管理模块</h4>
                        </div><!--end page-title-box-->
                    </div><!--end col-->
                </div>
                <!-- end page title end breadcrumb -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                                <p class="text-muted mb-3">articleEdit.
                                </p>
                                <form action="#" method="post">
                                    <input class="form-control" type="hidden" name="id"
                                           value="<?php echo $row['id'] ?>">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">文章标题</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="title"
                                                           value="<?php echo $row['title'] ?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">文章内容</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5"
                                                              name="content"><?php echo $row['content'] ?></textarea>
                                                    <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">文章分类</label>
                                                <div class="col-sm-10">
                                                    <select name="type" class="custom-select">
                                                        <?php if ($row['type'] == 0) { ?>
                                                            <option value="0">通知</option>
                                                            <option value="1">新闻</option>
                                                        <?php } else { ?>
                                                            <option value="1">新闻</option>
                                                            <option value="0">通知</option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!--end card-body-->
                                    <div class="row">
                                        <div class="col-sm-10 ml-auto">
                                            <button type="button" class="btn btn-primary" id="editArticle">保存数据</button>
                                        </div>
                                    </div>
                                </form>
                            </div><!--end card-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end row-->
            </div><!-- container -->
            <?php } ?>

            <?php
            include('footer.php');
            ?>
            <script>
                function delUseCard() {
                    layer.confirm('确认删除已使用卡密吗?', {
                        btn: ['是', '否'], btn1: function () {
                            var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                            $.ajax({
                                url: 'ajax.php?act=delUseCard',
                                type: 'POST',
                                dataType: 'json',
                                data: {},
                                success: function (data) {
                                    layer.close(ii);
                                    if (data.code == 1) {
                                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                            location.href = data.url;
                                        });
                                    } else {
                                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                    }
                                },
                                error: function () {
                                    layer.alert("网络连接错误");
                                }
                            });
                        }
                    });
                }

                function delAllCard() {
                    layer.confirm('确认删除所有卡密吗?', {
                        btn: ['是', '否'], btn1: function () {
                            var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                            $.ajax({
                                url: 'ajax.php?act=delAllCard',
                                type: 'POST',
                                dataType: 'json',
                                data: {},
                                success: function (data) {
                                    layer.close(ii);
                                    if (data.code == 1) {
                                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                            location.href = data.url;
                                        });
                                    } else {
                                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                    }
                                },
                                error: function () {
                                    layer.alert("网络连接错误");
                                }
                            });
                        }
                    });
                }
                //导出未使用卡密
                function exportCard() {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: 'ajax.php?act=exportCard',
                        type: 'POST',
                        dataType: 'json',
                        data: {},
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 800, shade: 0.4}, function () {
                                    layer.open({
                                        type: 1
                                        ,
                                        title: false //不显示标题栏
                                        ,
                                        closeBtn: false
                                        ,
                                        area: '300px;'
                                        ,
                                        shade: 0.8
                                        ,
                                        id: 'LAY_layuipro' //设定一个id，防止重复弹出
                                        ,
                                        resize: false
                                        ,
                                        btn: ['关闭提示']
                                        ,
                                        btnAlign: 'c'
                                        ,
                                        moveType: 1 //拖拽模式，0或者1
                                        ,
                                        content: "<div style='padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;'>" + data.data + "</div>"
                                        ,
                                        success: function (layero) {
                                            var btn = layero.find('.layui-layer-btn');
                                            btn.find('.layui-layer-btn0').attr({
                                                //href: data.url
                                            });
                                        }
                                    });

                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert("网络连接错误");
                        }
                    })
                }

                //生成卡密
                $("#addCard").click(function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: 'ajax.php?act=addCard',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            num: $("input[name='num']").val(),
                            money: $("input[name='money']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert("网络连接错误");
                        }
                    })
                })
            </script>
