<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

$lognumrows = $DB->query("SELECT * from wcms_log WHERE 1")->rowCount();
$ordernumrows = $DB->query("SELECT * from wcms_order WHERE 1")->rowCount();
?>

<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">系统模块</a></li>
                            <li class="breadcrumb-item active">系统优化</li>
                        </ol>
                    </div>
                    <h4 class="page-title">系统模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">系统优化</h4>
                        <p class="text-muted mb-4 font-13">
                            Available my logs.
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>数据表</th>
                                <th>数据</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>日志表</td>
                                <td><?php echo $lognumrows ?> 条</td>
                                <td><a href="#" class="btn m-b-xs btn-sm btn-primary btn-addon" onclick="delLog(7)">清空7天前</a>
                                    <a href="#" class="btn m-b-xs btn-sm btn-info btn-addon" onclick="delLog(15)">清空15天前</a>
                                    <a href="#" class="btn m-b-xs btn-sm btn-danger btn-addon" onclick="delLog(0)">清空全部</a></td>
                            </tr>
                            <tr>
                                <td>消费表</td>
                                <td><?php echo $ordernumrows ?> 条</td>
                                <td><a href="#" class="btn m-b-xs btn-sm btn-primary btn-addon" onclick="delOrder(777)">清空失败</a>
                                    <a href="#" class="btn m-b-xs btn-sm btn-info btn-addon" onclick="delOrder(15)">清空15天前</a>
                                    <a href="#" class="btn m-b-xs btn-sm btn-danger btn-addon" onclick="delOrder(0)">清空全部</a></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php
    include('footer.php');
    ?>

    <script>
        function delLog(pid) {
            var day = "15天前";
            if (pid == 0) {
                day = "全部";
            } else if (pid == 7) {
                day = "7天前";
            } else if (pid == 15) {
                day = "15天前";
            }

            layer.confirm('确认清空' + day + '日志记录吗?', {
                btn: ['是', '否'], btn1: function () {
                    $.ajax({
                        url: './ajax.php?act=delLog',
                        type: 'POST',
                        data: {day: day},
                        dataType: 'json',
                        success: function (data) {
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = 'sysInit.php';
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        }
                    });
                }
            });
        }

        function delOrder(pid) {
            var day = "15天前";
            if (pid == 0) {
                day = "全部";
            } else if (pid == 777) {
                day = "所有支付失败";
            } else if (pid == 15) {
                day = "15天前";
            }

            layer.confirm('确认清空' + day + '消费记录吗?', {
                btn: ['是', '否'], btn1: function () {
                    $.ajax({
                        url: './ajax.php?act=delOrder',
                        type: 'POST',
                        data: {day: day},
                        dataType: 'json',
                        success: function (data) {
                            if (data.code == '1') {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = 'sysInit.php';
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        }
                    });
                }
            });
        }


    </script>
