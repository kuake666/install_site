<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

//用户列表
$numrows = $DB->query("SELECT * from `wcms_user` WHERE 1")->rowCount();
$list = $DB->query("SELECT * FROM `wcms_user` WHERE 1 order by `uid` asc ")->fetchAll();
//添加、修改用户
$uid = intval(daddslashes($_GET['uid']));
$type = daddslashes($_GET['type']);

if ($type == 'edit' && $uid) {
    $row = $DB->query("SELECT * from wcms_user WHERE uid={$uid} limit 1")->fetch();
    $title = '修改用户';
    $result = 1; //修改用户
} else if ($type == 'add') {

    $title = '添加用户';
    $result = 2; //添加用户
} else {
    $result = 3; //用户列表
}
?>

<?php if ($result == 3){ ?>
<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">用户列表</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">用户列表</h4>
                        <p class="text-muted mb-4 font-13">
                            Available my sites.
                            <a href="user.php?type=add" class="btn m-b-xs btn-sm btn-primary btn-addon">
                                <i class="fa fa-edit"></i>添加用户
                            </a>
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>用户编号</th>
                                <th>用户名</th>
                                <th>邮箱</th>
                                <th>手机号</th>
                                <th>余额</th>
                                <th>注册时间</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $res) {
                                $program = $DB->query("SELECT * FROM wcms_program WHERE code='{$res['code']}' limit 1")->fetch();
                                echo '
                                    <tr id="' . $res['uid'] . '">
                                        <td>' . $res['uid'] . '</td>
                                        <td>' . $res['username'] . '</td>
                                        <td>' . $res['email'] . '</td>
                                        <td>' . $res['phone'] . '</td>
                                        <td>￥ <b>' . $res['money'] . '</b></td>
                                        <td>' . $res['regtime'] . '</td>
                                        <td>
                                          <a href="user.php?type=edit&uid=' . $res['uid'] . '" class="btn m-b-xs btn-sm btn-primary btn-addon" >修改</a>
                                          <a href="#" onclick="delUser(' . $res['uid'] . ')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</a>
                                        </td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php } else if ($result == 2){ ?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                <li class="breadcrumb-item active"><?php echo $title ?></li>
                            </ol>
                        </div>
                        <h4 class="page-title">添加用户</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                            <p class="text-muted mb-3">userAdd.
                            </p>
                            <form action="#" method="post">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">用户账号</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="username">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">用户密码</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="pass">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">用户昵称</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="nickname">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">用户邮箱</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="email">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">用户手机号</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="phone">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">用户余额</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="number" name="money">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">用户等级</label>
                                            <div class="col-sm-10">
                                                <select class="custom-select" name="mcode">
                                                    <?php
                                                    $rowMembers = $DB->query("SELECT * from `wcms_member` WHERE  1")->fetchAll();
                                                    foreach ($rowMembers as $rowMember) { ?>
                                                        <option value="<?php echo $rowMember['mcode'] ?>"><?php echo $rowMember['mname'] ?>  </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">是否启用</label>
                                            <div class="col-sm-10">
                                                <select class="custom-select" name="status">
                                                    <option value="1">启用</option>
                                                    <option value="0">禁用</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end card-body-->
                                <div class="row">
                                    <div class="col-sm-10 ml-auto">
                                        <button type="button" class="btn btn-primary" id="addUser">保存数据</button>
                                    </div>
                                </div>
                            </form>
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end row-->
        </div><!-- container -->
        <?php } else if ($result == 1){ ?>
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="float-right">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                    <li class="breadcrumb-item active"><?php echo $title ?></li>
                                </ol>
                            </div>
                            <h4 class="page-title">管理模块</h4>
                        </div><!--end page-title-box-->
                    </div><!--end col-->
                </div>
                <!-- end page title end breadcrumb -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                                <p class="text-muted mb-3">userEdit.
                                </p>
                                <form action="#" method="post">
                                    <div class="row">
                                        <input class="form-control" type="hidden" name="uid"
                                               value="<?php echo $row['uid'] ?>">
                                        <div class="col-lg-12">
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">用户账号</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="username"
                                                           value="<?php echo $row['username'] ?>" disabled>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">用户密码</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="pass"
                                                           placeholder="不修改请留空">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">用户昵称</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="nickname"
                                                           value="<?php echo $row['nickname'] ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">用户邮箱</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="email"
                                                           value="<?php echo $row['email'] ?>">
                                                </div>
                                            </div>


                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">用户手机号</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="phone"
                                                           value="<?php echo $row['phone'] ?>">
                                                </div>
                                            </div>


                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">用户余额</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="number" name="money"
                                                           value="<?php echo $row['money'] ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label text-left">用户等级</label>
                                                <div class="col-sm-10">
                                                    <select class="custom-select" name="mcode">
                                                        <?php
                                                        $rowMember = $DB->query("SELECT * from `wcms_member` WHERE  `mcode`= '{$row['mcode']}' limit 1")->fetch();
                                                        ?>
                                                        <option value="<?php echo $rowMember['mcode'] ?>"><?php echo $rowMember['mname'] ?>  </option>
                                                        <?php
                                                        $rowMembers = $DB->query("SELECT * from `wcms_member` WHERE  mcode !='{$row['mcode']}' ")->fetchAll();
                                                        foreach ($rowMembers as $rowMember) { ?>
                                                            <option value="<?php echo $rowMember['mcode'] ?>"><?php echo $rowMember['mname'] ?>  </option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label text-left">是否启用</label>
                                                <div class="col-sm-10">
                                                    <select class="custom-select" name="status">
                                                        <?php if ($row['status'] == 0) { ?>
                                                            <option value="0">停用</option>
                                                            <option value="1">启用</option>
                                                        <?php } else { ?>
                                                            <option value="1">启用</option>
                                                            <option value="0">停用</option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!--end card-body-->
                                    <div class="row">
                                        <div class="col-sm-10 ml-auto">
                                            <button type="button" class="btn btn-primary" id="editUser">保存数据</button>
                                        </div>
                                    </div>
                                </form>
                            </div><!--end card-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end row-->
            </div><!-- container -->
            <?php } ?>

            <?php
            include('footer.php');
            ?>
            <script>
                function delUser(uid) {
                    layer.confirm('确认删除 ' + uid + ' 吗?', {
                        btn: ['是', '否'], btn1: function () {
                            $.ajax({
                                url: './ajax.php?act=delUser',
                                type: 'POST',
                                dataType: 'json',
                                data: {uid: uid},
                                success: function (data) {
                                    if (data.code == 1) {
                                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                            var del="#"+uid;
                                            $(del).remove();
                                        });
                                    } else {
                                        layer.msg(data.msg, {icon: 7, time: 2000, shade: 0.4});
                                    }
                                },
                                error: function () {
                                    layer.alert("网络连接错误");
                                }
                            });
                        }
                    });
                }

                $("#editUser").click(function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: 'ajax.php?act=editUser',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            uid: $("input[name='uid']").val(),
                            user: $("input[name='user']").val(),
                            pass: $("input[name='pass']").val(),
                            email: $("input[name='email']").val(),
                            phone: $("input[name='phone']").val(),
                            mcode: $("select[name='mcode']").val(),
                            status: $("select[name='status']").val(),
                            nickname: $("input[name='nickname']").val(),
                            money: $("input[name='money']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = 'user.php';
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert("网络异常");
                        }
                    })
                })


                $("#addUser").click(function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: 'ajax.php?act=addUser',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            user: $("input[name='username']").val(),
                            pass: $("input[name='pass']").val(),
                            email: $("input[name='email']").val(),
                            phone: $("input[name='phone']").val(),
                            nickname: $("input[name='nickname']").val(),
                            mcode: $("select[name='mcode']").val(),
                            status: $("select[name='status']").val(),
                            money: $("input[name='money']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == '1') {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = 'user.php';
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert("网络连接错误");
                        }
                    })
                })
            </script>
