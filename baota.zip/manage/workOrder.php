<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

//工单列表
$numrows = $DB->query("SELECT * from `wcms_workorder` ")->rowCount();

$list = $DB->query("set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';")->fetch();
$list = $DB->query("SELECT * FROM `wcms_workorder` WHERE `num` !='' GROUP BY `code` ORDER BY `num` DESC ")->fetchAll();

//添加、修改项目
$code = daddslashes($_GET['code']);
$type = daddslashes($_GET['type']);

if ($type == 'edit' && $code) {
    $rows = $DB->query("SELECT * from `wcms_workorder` WHERE `code`='{$code}' order by `date` asc")->fetchAll();
    $row =  $DB->query("SELECT * FROM `wcms_workorder` WHERE `code` =  '{$code}' limit 1")->fetch();
    $title = '沟通记录';
    $result = 1; //修改项目
} else {
    $result = 3; //工单列表
}

?>

<?php if ($result == 3){ ?>
<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">日志记录</a></li>
                            <li class="breadcrumb-item active">工单列表</li>
                        </ol>
                    </div>
                    <h4 class="page-title">日志记录</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">工单列表</h4>
                        <p class="text-muted mb-4 font-13">
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <a class="btn btn-primary waves-effect waves-light btn-sm m-b-5" id="d-button" href="#" onclick="delOkWorkOrder()">删除所有已解决工单</a> &nbsp;
                            <a class="btn btn-danger waves-effect waves-light btn-sm m-b-5" id="d-button"  href="#" onclick="delAllWorkOrder()">删除所有工单</a>
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>工单编号</th>
                                <th>状态</th>
                                <th>工单标题</th>
                                <th>提交时间</th>
                                <th>用户回复时间</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $res) {
                                $res['title'] = mb_substr($res['title'], 0, 5, 'utf-8');
                                $res['title'] = $res['title'] . "...";
                                if($res['state']==1){
                                    $res['state']="<span style='color:green;'>已解决</span>";
                                }else{
                                    $res['state']="<span style='color:red;'>处理中</span>";
                                }
                                echo '
                                    <tr id="' . $res['id'] . '">
                                        <td>' . $res['id'] . '</td>
                                        <td>' . $res['state'] . '</td> 
                                        <td>' . $res['title'] . '</td>
                                        <td>' . $res['date'] . '</td>
                                        <td>' .$res['userreply'] . '</td>
                                        <td>
                                          <a href="?type=edit&code='.$res['code'].'" class="btn m-b-xs btn-sm btn-success btn-addon" >查看</a>
                                          <a href="#" onclick="changeWorkOrder(' . $res['id'] . ')" class="btn m-b-xs btn-sm btn-primary btn-addon" >更改状态</a>
                                          <a href="#" onclick="delOneWorkOrder('.$res['id'].')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</a>
                                        </td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->
        <?php } else if ($result == 1){ ?>
            <style>
                .gdan_gout{width:100%;height:auto;background-color:#fff;padding-bottom:1em}
                .gdan_txt{height:3em;line-height:3em;text-indent:1em;font-family:"微软雅黑";font-weight:800;}
                .gdan_txt>span{position:absolute;right:3em;}
                .gdan_zhugan{width:96%;height:auto;padding-top:1em;margin-left:2%;padding-left:.5em;padding-right:1em;margin-bottom:2em;border-top:dashed 1px #a9a9a9;margin-top: 2em;padding-top: 2em;}
                .gdan_kjia1{width:auto;margin-left:4em;margin-top:-3em}
                .gdan_xiaozhi{width:100%;height:1em;color:#a9a9a9;margin-bottom:1em}
                .gdan_xiaozhi>span{position:absolute;right:3em;}
                .gdan_huifu{width:100%;height:auto;margin-top:1em;border-top:solid #ccc 1px}
                .gdan_srk{width:98%;height:8em;margin-left:1%;margin-top:1em;border-color:#6495ed}
                .gdan_huifu1{width:6em;height:2.5em;border:none;background-color:#29b6f6;color:#fff;margin:.5em 0 .5em 1%}
                .gdan_jied{width:100%;height:3em;line-height:3em;text-align:center;color:#129DDE}
            </style>
            <!-- Page Content-->
            <div class="page-content">
                <div class="container-fluid">
                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title-box">
                                <div class="float-right">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                        <li class="breadcrumb-item active"><?php echo $title ?></li>
                                    </ol>
                                </div>
                                <h4 class="page-title">工单记录</h4>
                            </div><!--end page-title-box-->
                        </div><!--end col-->
                    </div>
                    <!-- end page title end breadcrumb -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="gdan_gout">
                                        <div class="gdan_txt">沟通记录<span>状态：<?php if($row['state'] == 1){ echo '<font color="green">已完结</font>';}else{ echo '<font color="red">待补充</font>';}?></span></div>
                                        <!------------------开始沟通------------------------>
                                        <?php foreach ($rows as  $key =>$value ) {?>

                                            <div class="gdan_zhugan" style="border: none;">
                                                <img src="<?php if($value['uid']==10000){ echo '../assets/avatar/user2.png';}else{ echo '../assets/avatar/user1.png';}?>" class="img-circle" width="40">
                                                <div class="gdan_kjia1">
                                                    <div class="gdan_xiaozhi"><?php if($value['uid']==10000){ echo '官方客服';}else{ echo $value['user'].'<br>问题描述：'.$value['title'];}?></div>
                                                    <p><span style='color:#a9a9a9;'><?php if($value['uid']==10000){ echo '问题回复：';} else{ echo '<br>问题详情：';}?></span><?php echo $value['content'];?><br><span><?php echo $value['date'];?></span></p>
                                                </div>
                                            </div>
                                        <?php } ?>
                                        <div class="gdan_huifu">
                                                <textarea class="gdan_srk" id="content" placeholder="可输入需要补充的内容，回复后用户将会收到你的消息！" required=""></textarea>
                                                <input type="button" value="提交回复" class="gdan_huifu1" onclick="replyWorkOrder()">
                                                <input type="hidden" id="code" value="<?php echo $value['code']?>" >
                                                <input type="button"  value="完结工单" class="gdan_huifu1" style="background-color: mediumseagreen;" onclick="changeWorkOrder(<?php echo $value['id']?>)">
                                        </div>
                                    </div>
                            </div><!--end card-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end row-->
            </div><!-- container -->
        <?php } ?>

        <?php
        include('footer.php');
        ?>
        <script>
            function delOneWorkOrder(id) {
                layer.confirm('确认删除 ' + id + ' 吗?', {
                    btn: ['是', '否'], btn1: function () {
                        $.ajax({
                            url: 'ajax.php?act=delOneWorkOrder',
                            type: 'POST',
                            dataType: 'json',
                            data: {id: id},
                            success: function (data) {
                                if (data.code == 1) {
                                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                        var del="#"+id;
                                        $(del).remove();
                                    });
                                } else {
                                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                }
                            },
                            error: function () {
                                layer.alert("网络连接错误");
                                return false;
                            }
                        });
                    }
                });
            }

            function delAllWorkOrder() {
                layer.confirm('确认删除所有工单?', {
                    btn: ['是', '否'], btn1: function () {
                        $.ajax({
                            url: 'ajax.php?act=delAllWorkOrder',
                            type: 'POST',
                            dataType: 'json',
                            data: {},
                            success: function (data) {
                                if (data.code == 1) {
                                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {

                                    });
                                } else {
                                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                }
                            },
                            error: function () {
                                layer.alert("网络连接错误");
                                return false;
                            }
                        });
                    }
                });
            }

            function delOkWorkOrder() {
                layer.confirm('确认删除所有已解决工单?', {
                    btn: ['是', '否'], btn1: function () {
                        $.ajax({
                            url: 'ajax.php?act=delOkWorkOrder',
                            type: 'POST',
                            dataType: 'json',
                            data: {},
                            success: function (data) {
                                if (data.code == 1) {
                                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                        location.href = data.url;
                                    });
                                } else {
                                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                }
                            },
                            error: function () {
                                layer.alert("网络连接错误");
                                return false;
                            }
                        });
                    }
                });
            }

            function replyWorkOrder(){
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                $.ajax({
                    url: 'ajax.php?act=replyWorkOrder',
                    type: 'POST',
                    dataType: 'json',
                    data: {code:$("#code").val(),content:$("#content").val() },
                    success: function (data) {
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = data.url;
                            });
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误");
                        return false;
                    }
                });
            }

            function changeWorkOrder(id) {
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                $.ajax({
                    url: 'ajax.php?act=changeWorkOrder',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        id:id
                    },
                    success: function (data) {
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = data.url;
                            });
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误");
                        return false;
                    }
                });
            }

        </script>
