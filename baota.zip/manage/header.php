<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include '../app/common.php';
if ($islogin == 1) {} else exit("<script language='javascript'>window.location.href='./login.php';</script>");

if(!isset($_SESSION['menuListManage'])){
    $menuListManage=$DB->query("SELECT * FROM  `wcms_menu2`  where `status`= 1  and `parentid`=0 order by `id` asc")->fetchAll();
    $_SESSION["menuListManage"] = $menuListManage;
}else{
    $menuListManage = $_SESSION["menuListManage"];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title>管理后台|<?php echo $conf['web_name'] ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A premium admin dashboard template by Mannatthemes" name="description"/>
    <meta content="Mannatthemes" name="author"/>

    <!-- App favicon -->
    <link rel="shortcut icon" href="../assets/img/favicon.ico?r=<?php echo rand(10000,99999)?>">   <!-- DataTables -->
    <link href="../assets/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css"/>
    <!-- Responsive datatable examples -->
    <link href="../assets/plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css"/>

    <!-- App css -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/metisMenu.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>

</head>

<body>

<!-- Top Bar Start -->
<div class="topbar">

    <!-- LOGO -->
    <div class="topbar-left">
        <a href="index.php" class="logo">
            <span>
               <img src="../assets/images/logo-sm.png" alt="<?php echo $conf['web_name']?>" class="logo-sm">
            </span>
            <span>
               <img src="../assets/images/logo-dark.png" alt="<?php echo $conf['web_name']?>" class="logo-lg">
            </span>
        </a>
    </div>
    <!--end logo-->
    <!-- Navbar -->
    <nav class="navbar-custom">
        <ul class="list-unstyled topbar-nav float-right mb-0">
            <li class="hidden-sm">
                <div class="crypto-balance">
                    <i class="dripicons-wallet text-muted align-self-center"></i>
                    <div class="btc-balance">
                        <h5 class="m-0"><?php echo $userrow['money'] ?> <span>元</span></h5>
                        <span class="text-muted">账户余额</span>
                    </div>
                </div>
            </li>

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle arrow-none waves-light waves-effect" data-toggle="dropdown" href="#"
                   role="button"
                   aria-haspopup="false" aria-expanded="false">
                    <i class="dripicons-bell noti-icon"></i>
                    <span class="badge badge-danger badge-pill noti-icon-badge">+1</span>
                </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-lg">
                    <!-- item-->
                    <h6 class="dropdown-item-text">
                        系统通知
                    </h6>
                    <div class="slimscroll notification-list">
                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item active">
                            <div class="notify-icon bg-success"><i class="mdi mdi-cart-outline"></i></div>
                            <p class="notify-details">通知标题<small class="text-muted">下个版本完善.</small></p>
                        </a>

                    </div>
                    <!-- All-->
                    <a href="javascript:void(0);" class="dropdown-item text-center text-primary">
                        查看所有 <i class="fi-arrow-right"></i>
                    </a>
                </div>
            </li>

            <li class="dropdown">
                <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#"
                   role="button"
                   aria-haspopup="false" aria-expanded="false">
                    <img src="../assets/images/users/user-img.svg" alt="profile-user" class="rounded-circle"/>
                    <span class="ml-1 nav-user-name hidden-sm"><?php echo $userrow['nickname'] ?> <i
                                class="mdi mdi-chevron-down"></i> </span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="log.php"><i class="dripicons-user text-muted mr-2"></i> 操作记录</a>
                    <a class="dropdown-item" href="update.php"><i class="dripicons-wallet text-muted mr-2"></i> 系统更新</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="../consumer/index.php"><i class="dripicons-exit text-muted mr-2"></i>
                        返回前台</a>
                </div>
            </li>
        </ul><!--end topbar-nav-->

        <ul class="list-unstyled topbar-nav mb-0">
            <li>
                <button class="button-menu-mobile nav-link waves-effect waves-light">
                    <i class="dripicons-menu nav-icon"></i>
                </button>
            </li>
            <li class="hide-phone app-search">
                <form role="search" class="">
                    <input type="text" placeholder="search" class="form-control">
                    <a href="https://www.baidu.com/baidu?wd=<?php echo $conf['web_name']; ?>&tn=monline_3_dg&ie=utf-8"
                       target="_blank"><i class="fas fa-search"></i></a>
                </form>
            </li>
        </ul>
    </nav>
    <!-- end navbar-->
</div>
<!-- Top Bar End -->


<div class="page-wrapper">
    <!-- Left Sidenav -->
    <div class="left-sidenav">
        <div class="main-icon-menu">
            <nav class="nav">
                <?php foreach($menuListManage as $res){?>
                    <a href="#<?php echo $res['menupath']?>" class="nav-link " data-toggle="tooltip-custom" data-placement="top" title=""
                       data-original-title="<?php echo $res['menuname']?>">
                        <?php echo $res['menuicon']?>
                    </a>
                <?php }?>


            </nav>
        </div>
        <div class="main-menu-inner">
            <div class="menu-body slimscroll">

                <?php foreach($menuListManage as $res){
                    echo ' <div id="'.$res['menupath'].'" class="main-icon-menu-pane">
		                    <div class="title-box">
		                        <h6 class="menu-title">'.$res['menuname'].'</h6>
		                    </div>
		                    <ul class="nav">';
                    $sunList=$DB->query("SELECT * FROM  `wcms_menu2`  where `status`= 1  and parentid='{$res['id']}' order by id asc")->fetchAll();

                    /*	if(!isset($_SESSION['sunList'])){
                           $sunList=$DB->query("SELECT * FROM  `wcms_menu2`  where `status`= 1  and parentid='{$res['id']}' order by id asc")->fetchAll();
                           $_SESSION["sunList"] = $sunList;
                       }else{
                           $sunList = $_SESSION["sunList"];
                       } */
                    foreach($sunList as $row) {
                        echo '<li class="nav-item"><a class="nav-link" href="'.$row['menupath'].'"><i class="'.$row['menuicon'].'"></i>'.$row['menuname'].'</a>
                        </li>';
                    }
                    echo ' </ul>
                </div>';
                }
                ?>






            </div><!--end menu-body-->
        </div><!-- end main-menu-inner-->
    </div>
    <!-- end left-sidenav-->
