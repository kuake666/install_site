<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';
?>

<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">系统模块</a></li>
                            <li class="breadcrumb-item active">系统设置</li>
                        </ol>
                    </div>
                    <h4 class="page-title">系统模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">系统设置</h4>
                        <p class="text-muted mb-3">sysSet.
                        </p>
                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                               class="col-sm-2 col-form-label text-left">网站驱动密钥</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" value="<?php echo $conf['site_key']?>" readonly>
                                            <pre><font color="green">系统自动生成,无需更改。项目安装驱动验证使用,请勿泄露.如要对接多台服务器,宝塔配置文件中的autosite.php的$myKey都要是这个网站驱动密钥！！！</font></pre>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">插件模板密钥</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="system_key" value="<?php echo $conf['system_key']?>"
                                                   id="example-email-input" >
                                            <p class="text-muted mb-3">
                                                <code class="highlighter-rouge">插件模板密钥请在<a href="http://w-cms.cn"
                                                                                           target="_blank">w-cms.cn</a>申请</code>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">注册时是否验证邮箱</label>
                                        <div class="col-sm-10">
                                            <select class="form-control select2" data-toggle="select2" id="need_email" >
                                                <option value="1" <?php if($conf['need_email']  == 1){?> selected = "selected" <?php }?>>验证</option>
                                                <option value="0" <?php if($conf['need_email']  == 0){?> selected = "selected" <?php }?>>不验证</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">是否开启API接口</label>
                                        <div class="col-sm-10">
                                            <select class="form-control select2" data-toggle="select2" name="api_status" id="change_666" >
                                                <option value="1" <?php if($conf['api_status']  == 1){?> selected = "selected" <?php }?>>开启</option>
                                                <option value="0" <?php if($conf['api_status']  == 0){?> selected = "selected" <?php }?>>关闭</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div id="open_666" <?php if($conf['api_status']==0){ echo "style='display:none;'";} ?>>
                                        <div class="form-group row" >
                                            <label for="example-email-input" class="col-sm-2 col-form-label text-left">API账号</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="api_user" value="<?php echo $conf['api_user'] ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row" >
                                            <label for="example-email-input" class="col-sm-2 col-form-label text-left">API密钥</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="api_key" value="<?php echo $conf['api_key'] ?>">
                                                <p class="text-muted mb-3">
                                                    <code class="highlighter-rouge">API接口可用于您开发APP、机器人或小程序等,API账号、API密钥由您自己填写。<a href="https://support.qq.com/products/129921/" target="_blank">查看开发手册</a></code>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div><!--end card-body-->
                            <div class="row">
                                <div class="col-sm-10 ml-auto">
                                    <button type="button" class="btn btn-primary" id="sysSet">保存数据</button>
                                </div>
                            </div>
                        </form>
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end row-->
    </div><!-- container -->

    <?php
    require_once 'footer.php';
    ?>
    <script>
        $("select[id^='change_']").change(function(){
            var id = $(this).attr('id').split('_')[1];
            var c  = $(this).val();
            if( parseInt(c) == 1 ){
                $('#open_'+id).show();
            }else{
                $('#open_'+id).hide();
            }
        });

        $("#sysSet").click(function () {
            var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
            $.ajax({
                url: "ajax.php?act=sysSet",
                type: 'POST',
                dataType: 'json',
                data: {
                    system_key: $("input[name='system_key']").val(),
                    need_email: $("#need_email").val(),
                    api_status: $("select[name='api_status']").val(),
                    api_user: $("input[name='api_user']").val(),
                    api_key: $("input[name='api_key']").val()
                },
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, { icon: 1, time: 2000, shade: 0.4 });
                    } else {
                        layer.msg(data.msg, { icon: 7, time: 2000, shade: 0.4 });
                    }
                },
                error:function () {
                    layer.close(ii);
                    layer.alert("网络连接错误!");
                }
            })
        });
    </script>
