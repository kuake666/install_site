<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
$list = \app\Admin::getStore('www.w-cms.cn');

?>

<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">服务商城</a></li>
                            <li class="breadcrumb-item active">模板商城</li>
                        </ol>
                    </div>
                    <h4 class="page-title">服务商城</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="row">
                <?php
                foreach ($list as $res) {
                    echo '  
                    <div class="col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <span class="badge badge-pink a-animate-blink mt-0">新品上线</span>
                                <div class="pricingTable1 text-center">
                                    <h6 class="title1 py-3 m-0">' . $res['pname'] . '</h6>
        
                                    <div class="text-center py-1">
                                        <h3 class="amount">￥ ' . $res['price'] . '</h3>
                                    </div>
                                    <ul class="list-unstyled pricing-content-2 py-3 border-0 ">
                                    ' . $res['decription'] . '
                                    </ul>
                                    <button class="btn btn-block  btn-secondary btn-square btn-skew btn-outline-dashed mt-3 py-3 font-18" onclick="installTem(' . $res['pid'] . ')">
                                        <span>安装</span>
                                     </button>
                                </div><!--end pricingTable-->
                            </div><!--end card-body-->
                        </div> <!--end card-->
                    </div><!--end col-->
                ';
                } ?>


            </div><!--end row-->


        </div><!-- container -->

        <?php
        include('footer.php');
        ?>

        <script>
            function installTem(pid) {
                var ii = layer.load(0, {shade: false}); //0代表加载的风格，支持0-2
                $.ajax({
                    type: "post",
                    url: "ajax.php?act=installTem",
                    dataType: "json",
                    data: {
                        pid: pid
                    },
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = 'store.php';
                            });
                        } else if(data.msg == 10000){
                            layer.confirm('<font color="red"><b>系统提醒:</b></font></br></br><b>您还未填写插件模板密钥</b></br><font color="green"><b>申请密钥后可安装系统插件</b></font></b>', {
                                btn: ['现在申请','稍后再说'] //按钮
                            }, function(){
                                layer.msg('跳转中', {icon: 1});//
                                location="https://www.w-cms.cn/auth/user";
                                return false;
                            }, function(){

                            });

                        }else{
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            return false;
                        }
                    }
                });
            }
        </script>
