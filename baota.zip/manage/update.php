<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';

?>
<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">系统更新</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">系统更新</h4>
                        <span id="updateResult">服务器正在赶来的路上...</span>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">版本日志</h4>
                        <span id="oldLogResult">服务器正在赶来的路上...</span>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php
    include 'footer.php';
    ?>
    <script>
        $.ajax
        ({
            cache: false,
            async: false,
            dataType: 'json', type: 'post',
            url: "ajax.php?act=getUpdate",
            success: function (data){
                $("#updateResult").html(data.data);
                $("#oldLogResult").html(data.oldLog);
            }
        });

        function update() {
            var ii = layer.msg('正在更新···', {icon: 16, shade: 0.01, time: 95000});
            $.ajax({
                url: "ajax.php?act=update",
                type: 'POST',
                dataType: 'json',
                data: {},
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            location.href = data.url;
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                }
            });
        }
    </script>
