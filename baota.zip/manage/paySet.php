<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';
?>
<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">系统模块</a></li>
                            <li class="breadcrumb-item active">支付设置</li>
                        </ol>
                    </div>
                    <h4 class="page-title">系统模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">支付设置</h4>
                        <p class="text-muted mb-3">paylSet.
                        </p>
                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label text-left">支付宝支付接口</label>
                                        <div class="col-sm-10">
                                            <select name="alipay_api" class="custom-select" id="change_1">
                                                <option value="0"<?php if ($conf['alipay_api'] == 0) { ?> selected<?php } ?>>
                                                    关闭
                                                </option>
                                                <option value="1"<?php if ($conf['alipay_api'] == 1) { ?> selected<?php } ?>>
                                                    支付宝官方即时到账
                                                </option>
                                                <option value="3"<?php if ($conf['alipay_api'] == 3) { ?> selected<?php } ?>>
                                                    支付宝当面付扫码付
                                                </option>
                                                <option value="2"<?php if ($conf['alipay_api'] == 2) { ?> selected<?php } ?>>
                                                    易支付免签约接口
                                                </option>
                                                <option value="5"<?php if ($conf['alipay_api'] == 5) { ?> selected<?php } ?>>
                                                    码支付免签约接口
                                                </option>
                                            </select>
                                            <?php if($conf['alipay_api'] == 3){
                                                echo '<code id="alipay_api03"><a href="https://b.alipay.com/signing/productSetV2.htm" rel="noreferrer" target="_blank">申请地址</a> 支付宝当面付接口配置请修改pay/f2fpay/config.php</code>';
                                            }else{
                                                echo '<code id="alipay_api03"  style="display:none;"><a href="https://b.alipay.com/signing/productSetV2.htm" rel="noreferrer" target="_blank">申请地址</a> 支付宝当面付接口配置请修改pay/f2fpay/config.php</code>';
                                            }?>
                                        </div>

                                    </div>
                                    <div class="alipay">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">合作者身份(PID)</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="alipay_pid"
                                                       value="<?php echo $conf['alipay_pid'] ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">安全校验码(KEY)</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="alipay_key"
                                                       value="<?php echo $conf['alipay_key'] ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">支付宝手机网站支付</label>
                                            <div class="col-sm-10">
                                                <select name="alipay2_api" class="custom-select" id="change_2">
                                                    <option value="1"<?php if ($conf['alipay2_api'] == 1) { ?> selected<?php } ?>>
                                                        支付宝手机网站支付接口
                                                    </option>
                                                    <option value="0"<?php if ($conf['alipay2_api'] == 0) { ?> selected<?php } ?>>
                                                        关闭
                                                    </option>
                                                </select>
                                                <pre class="wap-alipay">相关信息与以上支付宝即时到账接口一致，开启前请确保已开通支付宝手机支付，否则会导致手机用户无法支付！</pre>
                                            </div>
                                        </div>
                                    </div>
                                    <!--  QQ钱包支付接口-->
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label text-left">QQ钱包支付接口</label>
                                        <div class="col-sm-10">
                                            <select name="qqpay_api" class="custom-select" id="change_3">
                                                <option value="0"<?php if ($conf['qqpay_api'] == 0) { ?> selected<?php } ?>>
                                                    关闭
                                                </option>
                                                <option value="2"<?php if ($conf['qqpay_api'] == 2) { ?> selected<?php } ?>>
                                                    易支付免签约接口
                                                </option>
                                                <option value="5"<?php if ($conf['qqpay_api'] == 5) { ?> selected<?php } ?>>
                                                    码支付免签约接口
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <!--  微信支付接口-->
                                    <div class="hr-line-dashed"></div>
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label text-left">微信支付接口</label>
                                        <div class="col-sm-10">
                                            <select name="wxpay_api" class="custom-select" id="change_4">
                                                <option value="0"<?php if ($conf['wxpay_api'] == 0) { ?> selected<?php } ?>>
                                                    关闭
                                                </option>
                                                <option value="1"<?php if ($conf['wxpay_api'] == 1) { ?> selected<?php } ?>>
                                                    微信官方扫码+H5支付接口
                                                </option>
                                                <option value="2"<?php if ($conf['wxpay_api'] == 2) { ?> selected<?php } ?>>
                                                    易支付免签约接口
                                                </option>
                                                <option value="5"<?php if ($conf['wxpay_api'] == 5) { ?> selected<?php } ?>>
                                                    码支付免签约接口
                                                </option>
                                                <option value="6"<?php if ($conf['wxpay_api'] == 6) { ?> selected<?php } ?>>
                                                    小微支付接口
                                                </option>
                                            </select>
                                            <pre class="wxpay"><font color="green">*微信支付接口配置请修改pay/wxpay/WxPay.Config.php</font></pre>
                                        </div>
                                    </div>

                                    <!--  码支付支付接口-->
                                    <div class="codepay">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">码支付商户ID</label>
                                            <div class="col-md-10">
                                                <input type="text" name="ma_id" value="<?php echo $conf['ma_id']; ?>"
                                                       class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">码支付商户秘钥</label>
                                            <div class="col-md-10">
                                                <input type="text" name="ma_key" value="<?php echo $conf['ma_key']; ?>"
                                                       class="form-control">
                                            <font color="green"><a href="https://codepay.fateqq.com/" rel="noreferrer" target="_blank">码支付申请地址</a> （需要挂电脑软件，用户支付需要手动输入金额）</font>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="micropay">
                                        <!--  微信小微支付地址-->
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">微信小微支付地址</label>
                                            <div class="col-md-10">
                                                <input type="text" name="micropay_api" value="<?php echo $conf['micropay_api']; ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">微信小微支付APPID</label>
                                            <div class="col-md-10">
                                                <input type="text" name="micropay_pid" value="<?php echo $conf['micropay_pid']; ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">微信小微支付密钥</label>
                                            <div class="col-md-10">
                                                <input type="text" name="micropay_key" value="<?php echo $conf['micropay_key']; ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">微信小微支付MCHID</label>
                                            <div class="col-md-10">
                                                <input type="text" name="micropay_mchid" value="<?php echo $conf['micropay_mchid']; ?>" class="form-control">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="epay">
                                        <!--  易支付支付接口-->
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">易支付接口地址</label>
                                            <div class="col-md-10">
                                                <input type="text" name="epay_api"
                                                       value="<?php echo $conf['epay_api']; ?>"
                                                       class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">易支付商户ID</label>
                                            <div class="col-md-10">
                                                <input type="text" name="epay_id"
                                                       value="<?php echo $conf['epay_id']; ?>"
                                                       class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">易支付商户密钥</label>
                                            <div class="col-md-10">
                                                <input type="text" name="epay_key"
                                                       value="<?php echo $conf['epay_key']; ?>"
                                                       class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><!--end card-body-->
                            <div class="row">
                                <div class="col-sm-10 ml-auto">
                                    <button type="button" class="btn btn-primary" onclick="paySet()">保存数据</button>
                                </div>
                            </div>
                        </form>
                    </div><!--end card-->
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end row-->
</div><!-- container -->

<?php
require_once 'footer.php';
?>
<script>
    $("select[name='alipay_api']").change(function(){
        if($(this).val() == 1){
            $("#alipay_api03").css("display","none");
        }else if($(this).val() == 3){
            $("#alipay_api03").css("display","inherit");
        }else{
            $("#alipay_api03").css("display","none");
        }
    });
    init();
    $('#change_1').change(function () {
        init();
    });
    $('#change_2').change(function () {
        init();
    });
    $('#change_3').change(function () {
        init();
    });
    $('#change_4').change(function () {
        init();
    });

    function init() {
        $(".alipay").hide();
        $(".codepay").hide();
        $(".epay").hide();
        $(".wxpay").hide();
        $(".wap-alipay").hide();
        $(".micropay").hide();
        var alipay = $('#change_1 option:selected').text();
        if (alipay.indexOf("支付宝官方") >= 0) {
            $(".alipay").show();
        }
        if (alipay.indexOf("码支付") >= 0) {
            $(".codepay").show();
        }
        if (alipay.indexOf("易支付") >= 0) {
            $(".epay").show();
        }
        var wap_alipay = $('#change_2 option:selected').text();
        if (wap_alipay.indexOf("支付宝手机") >= 0) {
            //$(".alipay").show();
            $(".wap-alipay").show();
        }
        var qqpay = $('#change_3 option:selected').text();
        if (qqpay.indexOf("码支付") >= 0) {
            $(".codepay").show();
        }
        if (qqpay.indexOf("易支付") >= 0) {
            $(".epay").show();
        }
        var wxpay = $('#change_4 option:selected').text();
        if (wxpay.indexOf("微信官方") >= 0) {
            $(".wxpay").show();
        }
        if (wxpay.indexOf("码支付") >= 0) {
            $(".codepay").show();
        }
        if (wxpay.indexOf("易支付") >= 0) {
            $(".epay").show();
        }
        if (wxpay.indexOf("小微") >= 0) {
            $(".micropay").show();
        }
    }

    function paySet() {
        var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 95000});
        $.ajax({
            url: './ajax.php?act=paySet',
            type: 'POST',
            dataType: 'json',
            data: {
                alipay_api: $("select[name='alipay_api']").val(),
                alipay_pid: $("input[name='alipay_pid']").val(),
                alipay_key: $("input[name='alipay_key']").val(),
                alipay2_api: $("select[name='alipay2_api']").val(),
                qqpay_api: $("select[name='qqpay_api']").val(),
                wxpay_api: $("select[name='wxpay_api']").val(),
                ma_id: $("input[name='ma_id']").val(),
                ma_key: $("input[name='ma_key']").val(),
                epay_api: $("input[name='epay_api']").val(),
                epay_id: $("input[name='epay_id']").val(),
                epay_key: $("input[name='epay_key']").val(),
                micropay_api: $("input[name='micropay_api']").val(),
                micropay_pid: $("input[name='micropay_pid']").val(),
                micropay_key: $("input[name='micropay_key']").val(),
                micropay_mchid: $("input[name='micropay_mchid']").val()
            },
            success: function (data) {
                layer.close(ii);
                if (data.code == 1) {
                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4});
                } else {
                    layer.msg(data.msg, {icon: 2, time: 5000, shade: 0.4});
                }
            },
            error: function () {
                layer.alert("网络连接错误");
            }
        })
    }
</script>
