<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

//菜单列表
$ManageMenuList = $DB->query("SELECT * FROM `wcms_menu2` order by `id` asc")->fetchAll();
$ConsumerMenuList = $DB->query("SELECT * FROM `wcms_menu` order by `id` asc")->fetchAll();
//添加、修改项目
$id = intval(daddslashes($_GET['id']));
$type = daddslashes($_GET['type']);
$c = daddslashes($_GET['c']); //菜单分类 用户/后台
if ($type == 'edit' && $id && $c == 'manage') {
    $row = $DB->query("SELECT * from `wcms_menu2` WHERE `id`={$id} limit 1")->fetch();
    $title = '修改后台菜单';
    $result = 1; //修改后台菜单
} else if ($type == 'edit' && $id && $c == 'consumer') {
    $row = $DB->query("SELECT * from `wcms_menu` WHERE `id`={$id} limit 1")->fetch();
    $title = '修改用户菜单';
    $result = 1; //修改用户菜单
}else if ($type == 'add' && $c == 'manage') {
    $title = '添加后台菜单';
    $result = 2; //添加后台菜单
} else if ($type == 'add' && $c == 'consumer') {
    $title = '添加用户菜单';
    $result = 2; //添加用户菜单
}else {
    $result = 3; //菜单列表
}

?>

<?php if ($result == 3){ ?>
<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">菜单列表</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">后台菜单</h4>
                        <p class="text-muted mb-4 font-13">
                            programList.
                            <a href="?c=manage&type=add" class="btn m-b-xs btn-sm btn-primary btn-addon">
                                <i class="fa fa-edit"></i>添加后台菜单
                            </a>
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>菜单编号</th>
                                <th>菜单名称</th>
                                <th>上级菜单</th>
                                <th>菜单状态</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($ManageMenuList as $res) {
                                $parent = $DB->query("SELECT * FROM `wcms_menu2` WHERE `id` ='{$res['parentid']}' limit 1")->fetch();
                                if($parent){
                                    $res['parentid'] = $parent['menuname'];
                                }else{
                                    $res['parentid'] = "无";
                                }
                                if($res['status'] == 1){
                                    $res['status'] = "<span style='color:green;'>显示</span>";
                                }else{
                                    $res['status'] = "<span style='color:red;'>隐藏</span>";
                                }
                                echo '
                                    <tr id="' . $res['id'] . '">
                                        <td>' . $res['id'] . '</td>
                                        <td>' . $res['menuname'] . '</td>
                                        <td>' . $res['parentid'] . '</td>
                                        <td>' . $res['status'] . '</td>
                                        <td>
                                          <a href="?c=manage&type=edit&id=' . $res['id'] . '" class="btn m-b-xs btn-sm btn-primary btn-addon" >修改</a>
                                          <a href="#" onclick="delManageMenu(' . $res['id'] . ')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</a>
                                        </td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->


        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">用户菜单</h4>
                        <p class="text-muted mb-4 font-13">
                            consumerMenuList.
                            <a href="?c=consumer&type=add" class="btn m-b-xs btn-sm btn-primary btn-addon">
                                <i class="fa fa-edit"></i>添加用户菜单
                            </a>
                        </p>
                        <table id="datatable2" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>菜单编号</th>
                                <th>菜单名称</th>
                                <th>上级菜单</th>
                                <th>菜单状态</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($ConsumerMenuList as $res) {
                                $parent = $DB->query("SELECT * FROM `wcms_menu` WHERE `id` ='{$res['parentid']}' limit 1")->fetch();
                                if($parent){
                                    $res['parentid'] = $parent['menuname'];
                                }else{
                                    $res['parentid'] = "无";
                                }
                                if($res['status'] == 1){
                                    $res['status'] = "<span style='color:green;'>显示</span>";
                                }else{
                                    $res['status'] = "<span style='color:red;'>隐藏</span>";
                                }
                                echo '
                                    <tr id="' . $res['id'] . '">
                                        <td>' . $res['id'] . '</td>
                                        <td>' . $res['menuname'] . '</td>
                                        <td>' . $res['parentid'] . '</td>
                                        <td>' . $res['status'] . '</td>
                                        <td>
                                          <a href="?c=consumer&type=edit&id=' . $res['id'] . '" class="btn m-b-xs btn-sm btn-primary btn-addon" >修改</a>
                                          <a href="#" onclick="delConsumerMenu(' . $res['id'] . ')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</a>
                                        </td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php } else if ($result == 2){ ?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                <li class="breadcrumb-item active"><?php echo $title ?></li>
                            </ol>
                        </div>
                        <h4 class="page-title">管理模块</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                            <p class="text-muted mb-3">addMenu.
                            </p>
                            <form action="#" method="post">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input" class="col-sm-2 col-form-label text-left">菜单名称</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="menuname">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input" class="col-sm-2 col-form-label text-left">菜单图标</label>
                                            <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" name="menuicon"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input" class="col-sm-2 col-form-label text-left">菜单路径</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="menupath">
                                            </div>
                                        </div>
                                        <div class="form-group row" >
                                            <label class="col-sm-2 col-form-label text-left">是否有父级</label>
                                            <div class="col-sm-10">
                                                <select class="custom-select" name="hava_parent" id="change_111">
                                                        <option value="0">无父级</option>
                                                        <option value="1">有父级</option>
                                                </select>
                                            </div>
                                        </div>

                                     <div class="form-group row"  id="open_111" style="display:none;">
                                        <label for="example-text-input"  class="col-sm-2 col-form-label text-left">选择父级菜单</label>
                                        <div class="col-sm-10">
                                            <select class="custom-select" name="parentid" >
                                                <?php  if ($c == 'manage') {
                                                    $parentList = $DB->query("SELECT * FROM `wcms_menu2` WHERE `parentid`=0 and `id`!='{$row['id']}'  ORDER BY `id` asc")->fetchAll();
                                                    foreach ($parentList as $parent){?>
                                                        <option value="<?php echo $parent['id']?>"><?php echo $parent['menuname']?></option>
                                                    <?php } ?>
                                                <?php }else{
                                                    $parentList = $DB->query("SELECT * FROM `wcms_menu` WHERE `parentid`=0 and `id`!='{$row['id']}'  ORDER BY `id` asc")->fetchAll();
                                                    foreach ($parentList as $parent){?>
                                                        <option value="<?php echo $parent['id']?>"><?php echo $parent['menuname']?></option>
                                                    <?php }?>
                                                <?php }?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label text-left">菜单状态</label>
                                        <div class="col-sm-10">
                                            <select class="custom-select" name="status">
                                                <option value="1">显示</option>
                                                <option value="0">隐藏</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                        </div><!--end card-body-->
                        <div class="row">
                            <div class="col-sm-10 ml-auto">
                                <?php if($c == 'manage'){?>
                                    <button type="button" class="btn btn-primary" id="addManageMenu">保存数据</button>
                                <?php }else{?>
                                    <button type="button" class="btn btn-primary" id="addConsumerMenu">保存数据</button>
                                <?php }?>
                            </div>
                        </div>
                        </form>
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end row-->
        </div><!-- container -->
        <?php } else if ($result == 1){ ?>
            <!-- Page Content-->
            <div class="page-content">
                <div class="container-fluid">
                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title-box">
                                <div class="float-right">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                        <li class="breadcrumb-item active"><?php echo $title ?></li>
                                    </ol>
                                </div>
                                <h4 class="page-title">管理模块</h4>
                            </div><!--end page-title-box-->
                        </div><!--end col-->
                    </div>
                    <!-- end page title end breadcrumb -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                                    <p class="text-muted mb-3">editMenu.
                                    </p>
                                    <form action="#" method="post">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-group row">
                                                    <input class="form-control" type="hidden" name="id"
                                                           value="<?php echo $row['id'] ?>">
                                                    <label for="example-text-input"
                                                           class="col-sm-2 col-form-label text-left">菜单名称</label>
                                                    <div class="col-sm-10">
                                                        <input class="form-control" type="text" name="menuname"
                                                               value="<?php echo $row['menuname'] ?>">
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label for="example-text-input"
                                                           class="col-sm-2 col-form-label text-left">菜单图标</label>
                                                    <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5" name="menuicon"><?php echo $row['menuicon'] ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label for="example-text-input"
                                                           class="col-sm-2 col-form-label text-left">菜单路径</label>
                                                    <div class="col-sm-10">
                                                        <input class="form-control" type="text" name="menupath" value="<?php echo $row['menupath'] ?>">
                                                    </div>
                                                </div>
                                                <div class="form-group row" >
                                                    <label class="col-sm-2 col-form-label text-left">是否有父级</label>
                                                    <div class="col-sm-10">
                                                        <select class="custom-select" name="hava_parent" id="change_222" >
                                                            <?php if ($row['parentid'] == 0) { ?>
                                                                <option value="0">无父级</option>
                                                                <option value="1">有父级</option>
                                                            <?php } else { ?>
                                                                <option value="1">有父级</option>
                                                                <option value="0">无父级</option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <?php if($row['parentid'] == 0){
                                                    echo '<div class="form-group row"  id="open_222" style="display:none;">';
                                                }else{
                                                    echo '<div class="form-group row"  id="open_222" >';
                                                }?>
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">选择父级菜单</label>
                                                <div class="col-sm-10">
                                                    <select class="custom-select" name="parentid" >
                                                        <?php if ($c == 'manage') {
                                                            $parentList = $DB->query("SELECT * FROM `wcms_menu2` WHERE `parentid`=0 and `id`!='{$row['id']}'  ORDER BY `id` asc")->fetchAll();
                                                        }else{
                                                            $parentList = $DB->query("SELECT * FROM `wcms_menu` WHERE `parentid`=0 and `id`!='{$row['id']}'  ORDER BY `id` asc")->fetchAll();
                                                        }
                                                         foreach ($parentList as $parent){?>
                                                        <option value="<?php echo $parent['id']?>" <?php if($parent['id']  == $row['parentid']){?> selected = "selected" <?php }?> ><?php echo $parent['menuname']?></option>
                                                        <?php }?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label text-left">菜单状态</label>
                                                <div class="col-sm-10">
                                                    <select class="custom-select" name="status">
                                                        <?php if ($row['status'] == 0) { ?>
                                                            <option value="0">隐藏</option>
                                                            <option value="1">显示</option>
                                                        <?php } else { ?>
                                                            <option value="1">显示</option>
                                                            <option value="0">隐藏</option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                </div><!--end card-body-->
                                <div class="row">
                                    <div class="col-sm-10 ml-auto">
                                        <?php if($c == 'manage'){?>
                                            <button type="button" class="btn btn-primary" id="editManageMenu">保存数据</button>
                                        <?php }else{?>
                                            <button type="button" class="btn btn-primary" id="editConsumerMenu">保存数据</button>
                                        <?php }?>
                                    </div>
                                </div>
                                </form>
                            </div><!--end card-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end row-->
            </div><!-- container -->
        <?php } ?>

        <?php
        include('footer.php');
        ?>
        <script>
            $("select[id^='change_']").change(function(){
                var id = $(this).attr('id').split('_')[1];
                var c  = $(this).val();
                if( parseInt(c) == 1 ){
                    $('#open_'+id).show();
                }else{
                    $('#open_'+id).hide();
                }
            });
            //删除后台菜单
            function delManageMenu(id) {
                layer.confirm('确认删除后台菜单 ' + id + ' 吗?', {
                    btn: ['是', '否'], btn1: function () {
                        $.ajax({
                            url: 'ajax.php?act=delManageMenu',
                            type: 'POST',
                            dataType: 'json',
                            data: {id: id},
                            success: function (data) {
                                if (data.code == 1) {
                                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                        var del="#"+id;
                                        $(del).remove();
                                    });
                                } else {
                                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                }
                            },
                            error: function () {
                                layer.alert("网络连接错误");
                                return false;
                            }
                        });
                    }
                });
            }

            //删除用户菜单
            function delConsumerMenu(id) {
                layer.confirm('确认删除用户菜单 ' + id + ' 吗?', {
                    btn: ['是', '否'], btn1: function () {
                        $.ajax({
                            url: 'ajax.php?act=delConsumerMenu',
                            type: 'POST',
                            dataType: 'json',
                            data: {id: id},
                            success: function (data) {
                                if (data.code == 1) {
                                    layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                        var del="#"+id;
                                        $(del).remove();
                                    });
                                } else {
                                    layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                }
                            },
                            error: function () {
                                layer.alert("网络连接错误");
                                return false;
                            }
                        });
                    }
                });
            }

            //添加后台菜单
            $("#addManageMenu").click(function () {
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                $.ajax({
                    url: 'ajax.php?act=addManageMenu',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        menuname: $("input[name='menuname']").val(),
                        menupath: $("input[name='menupath']").val(),
                        menuicon: $("textarea[name='menuicon']").val(),
                        parentid: $("select[name='parentid']").val(),
                        hava_parent: $("select[name='hava_parent']").val(),
                        status : $("select[name='status']").val()
                    },
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = 'menu.php';
                            });
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误");
                    }
                })
            })

            //修改后台菜单
            $("#editManageMenu").click(function () {
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                $.ajax({
                    url: 'ajax.php?act=editManageMenu',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        id: $("input[name='id']").val(),
                        menuname: $("input[name='menuname']").val(),
                        menupath: $("input[name='menupath']").val(),
                        menuicon: $("textarea[name='menuicon']").val(),
                        parentid: $("select[name='parentid']").val(),
                        hava_parent: $("select[name='hava_parent']").val(),
                        status : $("select[name='status']").val()
                    },
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = 'menu.php';
                            });
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误");
                    }
                })
            })

            //添加用户菜单
            $("#addConsumerMenu").click(function () {
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                $.ajax({
                    url: 'ajax.php?act=addConsumerMenu',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        menuname: $("input[name='menuname']").val(),
                        menupath: $("input[name='menupath']").val(),
                        menuicon: $("textarea[name='menuicon']").val(),
                        parentid: $("select[name='parentid']").val(),
                        hava_parent: $("select[name='hava_parent']").val(),
                        status : $("select[name='status']").val()
                    },
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = 'menu.php';
                            });
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误");
                    }
                })
            })

            //修改用户菜单
            $("#editConsumerMenu").click(function () {
                var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                $.ajax({
                    url: 'ajax.php?act=editConsumerMenu',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        id: $("input[name='id']").val(),
                        menuname: $("input[name='menuname']").val(),
                        menupath: $("input[name='menupath']").val(),
                        menuicon: $("textarea[name='menuicon']").val(),
                        parentid: $("select[name='parentid']").val(),
                        hava_parent: $("select[name='hava_parent']").val(),
                        status : $("select[name='status']").val()
                    },
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = 'menu.php';
                            });
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error: function () {
                        layer.alert("网络连接错误");
                    }
                })
            })

        </script>
