<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

$numrows=$DB->query("SELECT * from `wcms_news` WHERE 1")->rowCount();
$list=$DB->query("SELECT * FROM  `wcms_news` WHERE 1 order by date desc")->fetchAll();
?>

    <!-- Page Content-->
    <div class="page-content">

        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">服务中心</a></li>
                                <li class="breadcrumb-item active">系统通知</li>
                            </ol>
                        </div>
                        系统通知
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <?php
                foreach($list as $res){
                    echo '
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="blog-card">
                                        <img src="../assets/images/small/img-1.jpg" alt="" class="img-fluid"/>
                                        <div class="meta-box">
                                            <ul class="p-0 mt-4 list-inline">
                                                <li class="list-inline-item">'.$res['date'].'</li>
                                                <li class="list-inline-item">管理员 发布</li>
                                            </ul>
                                        </div><!--end meta-box-->
                                        <h4 class="mt-2 mb-3">
                                            <a href="">'.$res['title'].'</a>
                                        </h4>
                                        <p class="text-muted">文章内容</p>
                                        <a href="#" class="text-primary">阅读通知 <i class="fas fa-long-arrow-alt-right"></i></a>
                                    </div><!--end blog-card-->
                                </div><!--end card-body-->
                            </div><!--end card-->
                        </div> <!--end col-->
                    ';
                }
                ?>
            </div><!--end row-->
        </div><!-- container -->

<?php
include('footer.php');
?>