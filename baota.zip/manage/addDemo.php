<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
$list = $DB->query("SELECT * FROM `wcms_demo` ")->fetchAll();

?>

<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">更多功能</a></li>
                            <li class="breadcrumb-item active">一键建站</li>
                        </ol>
                    </div>
                    <h4 class="page-title">更多功能</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">一键建站</h4>
                        <p class="text-muted mb-4 font-13">
                            本功能仅用于管理员一键搭建所有演示站
                        </p><p class="text-muted mb-4 font-13">
                            使用本功能需要进行监控操作,监控地址<?php $siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].'/'; echo $siteurl."api/cron.php?type=addDemo&key=".$conf['site_key'];?>
                        </p>
                        <table class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <tbody>
                            <tr>
                                <td>
                                    <button href="#" class="btn btn-sm btn-success" onclick="demoInfo()">使用说明
                                    </button>
                                    <button href="#" class="btn m-b-xs btn-sm btn-primary btn-addon"
                                            onclick="addDemo()">创建任务
                                    </button>
                                    <button href="#" class="btn m-b-xs btn-sm btn-danger btn-addon"
                                            onclick="clearDemo()">清空任务
                                    </button>
                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">建站情况</h4>
                        <p class="text-muted mb-4 font-13">
                            一键建站进度
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>网站域名</th>
                                <th>项目名称</th>
                                <th>创建时间</th>
                                <th>状态</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $res){
                                $program = $DB->query("SELECT * FROM `wcms_program` where `code`='{$res['code']}' limit 1 ")->fetch();
                                if($res['status'] == 0){
                                    $res['status'] = '<span class="badge badge-soft-danger">搭建异常</span>';
                                }else if($res['status'] == 1){
                                    $res['status'] = '<span class="badge badge-soft-dark">已创建任务</span>';
                                }else if($res['status'] == 2){
                                    $res['status'] = '<span class="badge badge-soft-primary">已开通主机</span>';
                                }else if($res['status'] == 3){
                                    $res['status'] = '<span class="badge badge-soft-success">已初始化</span>';
                                }else if($res['status'] == 4){
                                    $res['status'] = '<span class="badge badge-soft-success">搭建完成</span>';
                                }
                                ?>
                                <tr>
                                    <td><?php echo $res['domain']?></td>
                                    <td><?php echo $program['name']?>
                                    <td><?php echo $res['date']?></td>
                                    <td><?php echo $res['status']?></td>
                                </tr>
                            <?php }?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->


    </div><!-- container -->
    <?php
    include('footer.php');
    ?>
    <script>
        function clearDemo() {
            layer.confirm('是否删除所有任务?', {
                btn: ['是', '否'], btn1: function () {
                    $.ajax({
                        url: 'ajax.php?act=clearDemo',
                        type: 'POST',
                        dataType: 'json',
                        data: {},
                        success: function (data) {
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert("网络连接错误");
                            return false;
                        }
                    });
                }
            });
        }

        function addDemo() {
            layer.confirm('是否开启一键建站任务?', {
                btn: ['是', '否'], btn1: function () {
                    $.ajax({
                        url: 'ajax.php?act=addDemo',
                        type: 'POST',
                        dataType: 'json',
                        data: {},
                        success: function (data) {
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert("网络连接错误");
                            return false;
                        }
                    });
                }
            });
        }

        function demoInfo() {
            layer.open({
                type: 1
                ,
                title: false //不显示标题栏
                ,
                closeBtn: false
                ,
                area: '300px;'
                ,
                shade: 0.8
                ,
                id: 'LAY_layuipro' //设定一个id，防止重复弹出
                ,
                resize: false
                ,
                btn: ['关闭提示']
                ,
                btnAlign: 'c'
                ,
                moveType: 1 //拖拽模式，0或者1
                ,
                content: "<div style='padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;'> 温馨提示：<br/>1.本功能仅用于管理员一键搭建所有演示站<br/>2.使用本功能前请先配置好服务器信息<br/>" +
                    "3.手动在用户端页面搭建网站并初始化<br/>4.如手动搭建正常,则可以使用本功能<br/>5.如手动不正常,排查问题,之后再使用本功能</div>"
                ,
                success: function (layero) {
                    var btn = layero.find('.layui-layer-btn');
                    btn.find('.layui-layer-btn0').attr({
                        //href: data.url
                    });
                }
            });
        }
    </script>
