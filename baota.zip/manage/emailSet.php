<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';
?>
<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">系统模块</a></li>
                            <li class="breadcrumb-item active">邮箱设置</li>
                        </ol>
                    </div>
                    <h4 class="page-title">系统模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">邮箱设置</h4>
                        <p class="text-muted mb-3">emailSet.
                        </p>
                        <form>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label text-left">发信模式</label>
                                        <div class="col-sm-10">
                                            <select name="mail_cloud" class="custom-select">
                                                <option value="0"<?php if ($conf['mail_cloud'] == 8) { ?> selected<?php } ?>>
                                                    普通
                                                </option>
                                                <option value="1"<?php if ($conf['mail_cloud'] == 1) { ?> selected<?php } ?>>
                                                    搜狐Sendcould
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                               class="col-sm-2 col-form-label text-left">STMP服务器</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="mail_smtp"
                                                   value="<?php echo $conf['mail_smtp'] ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">STMP端口</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="mail_port"
                                                   value="<?php echo $conf['mail_port'] ?>">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">邮箱账号</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="mail_name"
                                                   value="<?php echo $conf['mail_name'] ?>">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="example-email-input"
                                               class="col-sm-2 col-form-label text-left">邮箱授权码</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="text" name="mail_pwd"
                                                   value="<?php echo $conf['mail_pwd'] ?>">
                                        </div>
                                    </div>
                                </div>
                            </div><!--end card-body-->
                            <div class="row">
                                <div class="col-sm-10 ml-auto">
                                    <button type="button" class="btn btn-primary" onclick="emailSet()">保存数据</button>
                                </div>
                            </div>
                        </form>
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->


        </div><!--end row-->

    </div><!-- container -->

    <?php
    require_once 'footer.php';
    ?>
    <script>
        function emailSet() {
            var ii = layer.msg('数据处理中···', { icon: 16, shade: 0.01, time: 15000 });
            $.ajax({
                url: './ajax.php?act=emailSet',
                type: 'POST',
                dataType: 'json',
                data: {
                    mail_cloud: $("select[name='mail_cloud']").val(),
                    mail_smtp: $("input[name='mail_smtp']").val(),
                    mail_port: $("input[name='mail_port']").val(),
                    mail_name: $("input[name='mail_name']").val(),
                    mail_pwd: $("input[name='mail_pwd']").val()
                },
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, { icon: 1, time: 2000, shade: 0.4 }, function () {
                            //
                        });
                    } else {
                        layer.msg(data.msg, { icon: 2, time: 2000, shade: 0.4 });
                    }
                },
                error:function () {
                    layer.alert("网络连接错误");
                }
            })

        }
    </script>
