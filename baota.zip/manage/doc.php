<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';

?>
<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">服务商城</a></li>
                            <li class="breadcrumb-item active">指导手册</li>
                        </ol>
                    </div>
                    <h4 class="page-title">服务商城</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">指导手册</h4>
                         <div class='ibox-content'>
                             <div class='alert alert-green'>官方指导手册固定地址:</br>  https://support.qq.com/products/129921/ </div> &nbsp;&nbsp;&nbsp;<a href="https://support.qq.com/products/129921/" target="_blank" class='btn btn-success'>点我进入</a></div>

                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php
    include 'footer.php';
    ?>
