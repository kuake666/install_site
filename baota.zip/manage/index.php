<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');


?>

<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">服务中心</a></li>
                            <li class="breadcrumb-item active">服务台</li>
                        </ol>
                    </div>
                    <h4 class="page-title">服务台</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->


        <div class="row">
            <div class="col-lg-4">
                <div class="card card-eco">
                    <div class="card-body">
                        <h4 class="title-text mt-0">今日注册用户</h4>
                        <div class="d-flex justify-content-between">
                            <h3 class="font-weight-bold"><span id="todayUser"></span> 人</h3>
                            <i class="dripicons-user-group card-eco-icon text-pink align-self-center"></i>
                        </div>
                        <p class="mb-0 text-muted text-truncate"><span class="text-success"><i
                                        class="mdi mdi-trending-up"></i>8.5%</span>Up From Yesterday</p>
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
            <div class="col-lg-4">
                <div class="card card-eco">
                    <div class="card-body">
                        <h4 class="title-text mt-0">今日搭建网站</h4>
                        <div class="d-flex justify-content-between">
                            <h3 class="font-weight-bold"><span id="todaySite"></span> 个</h3>
                            <i class="dripicons-cart card-eco-icon text-secondary  align-self-center"></i>
                        </div>
                        <p class="mb-0 text-muted text-truncate"><span class="text-success"><i
                                        class="mdi mdi-trending-up"></i>1.5%</span> Up From Last Week</p>
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
            <div class="col-lg-4">
                <div class="card card-eco">
                    <div class="card-body">
                        <h4 class="title-text mt-0">今日充值金额</h4>
                        <div class="d-flex justify-content-between">
                            <h3 class="font-weight-bold"><span id="todayMoney"></span> 元</h3>
                            <i class="dripicons-wallet card-eco-icon text-success  align-self-center"></i>
                        </div>
                        <p class="mb-0 text-muted text-truncate"><span class="text-success"><i
                                        class="mdi mdi-trending-up"></i>10.5%</span> Up From Yesterday</p>
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->

        </div><!--end row-->

        <div class="row">
            <div class="col-lg-4">
                <div class="card card-eco">
                    <div class="card-body">
                        <h4 class="title-text mt-0">总计注册用户</h4>
                        <div class="d-flex justify-content-between">
                            <h3 class="font-weight-bold"><span id="allUser"></span> 人</h3>
                            <i class="dripicons-user-group card-eco-icon text-pink align-self-center"></i>
                        </div>
                        <p class="mb-0 text-muted text-truncate"><span class="text-success"><i
                                        class="mdi mdi-trending-up"></i>8.5%</span>Up From Yesterday</p>
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
            <div class="col-lg-4">
                <div class="card card-eco">
                    <div class="card-body">
                        <h4 class="title-text mt-0">总计搭建网站</h4>
                        <div class="d-flex justify-content-between">
                            <h3 class="font-weight-bold"><span id="allSite"></span> 个</h3>
                            <i class="dripicons-cart card-eco-icon text-secondary  align-self-center"></i>
                        </div>
                        <p class="mb-0 text-muted text-truncate"><span class="text-success"><i
                                        class="mdi mdi-trending-up"></i>1.5%</span> Up From Last Week</p>
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
            <div class="col-lg-4">
                <div class="card card-eco">
                    <div class="card-body">
                        <h4 class="title-text mt-0">总计充值金额</h4>
                        <div class="d-flex justify-content-between">
                            <h3 class="font-weight-bold"><span id="allMoney"></span> 元</h3>
                            <i class="dripicons-wallet card-eco-icon text-success  align-self-center"></i>
                        </div>
                        <p class="mb-0 text-muted text-truncate"><span class="text-success"><i
                                        class="mdi mdi-trending-up"></i>10.5%</span> Up From Yesterday</p>
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->

        </div><!--end row-->


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="wallet-bal-usd">
                                    <h4 class="wallet-title m-0">快捷操作</h4>

                                </div>
                            </div>
                        </div>
                    </div><!--end card-body-->
                    <div class="card-body pt-0">
                        <ul class="list-group wallet-bal-crypto">
                            <li class="list-group-item align-items-center d-flex justify-content-between">
                                <div class="media">
                                    <img src="../assets/images/coins/dash.png" class="mr-3 thumb-sm align-self-center rounded-circle" alt="...">
                                    <div class="media-body align-self-center">
                                        <div class="coin-bal">
                                            <h3 class="m-0">指导手册</h3>
                                        </div>
                                    </div><!--end media body-->
                                </div>
                                <a href="https://support.qq.com/products/129921/" target="_blank" class="btn btn-success btn-sm px-3" >立即查看</a>
                            </li>
                        </ul>
                    </div><!--end card-body-->
                    <div class="card-body pt-0">
                        <ul class="list-group wallet-bal-crypto">
                            <li class="list-group-item align-items-center d-flex justify-content-between">
                                <div class="media">
                                    <img src="../assets/images/coins/mon.png" class="mr-3 thumb-sm align-self-center rounded-circle" alt="...">
                                    <div class="media-body align-self-center">
                                        <div class="coin-bal">
                                            <h3 class="m-0">清除缓存</h3>
                                        </div>
                                    </div><!--end media body-->
                                </div>
                                <button class="btn btn-success btn-sm px-3" onclick="clearCache()">立即清除</button>
                            </li>
                        </ul>
                    </div><!--end card-body-->
                    <div class="card-body pt-0">
                        <ul class="list-group wallet-bal-crypto">
                            <li class="list-group-item align-items-center d-flex justify-content-between">
                                <div class="media">
                                    <img src="../assets/images/coins/eth.png" class="mr-3 thumb-sm align-self-center rounded-circle" alt="...">
                                    <div class="media-body align-self-center">
                                        <div class="coin-bal">
                                            <h3 class="m-0">推广链接</h3>
                                        </div>
                                    </div><!--end media body-->
                                </div>
                                <button class="btn btn-success btn-sm px-3" onclick="getShortLink()">点我生成</button>
                            </li>
                        </ul>
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
        </div><!--end row-->


    </div><!-- container -->

    <?php
    include('footer.php');
    ?>
    <script>
        $.ajax
        ({
            cache: false,
            async: false,
            dataType: 'json', type: 'post',
            url: "ajax.php?act=teachTip",
            success: function (data){
                if (data.code != 1) {
                    var log = data.data;
                    //示范一个公告层
                    layer.open({
                        type: 1
                        ,
                        title: false //不显示标题栏
                        ,
                        closeBtn: false
                        ,
                        area: '300px;'
                        ,
                        shade: 0.8
                        ,
                        id: 'LAY_layuipro' //设定一个id，防止重复弹出
                        ,
                        resize: false
                        ,
                        btn: ['不再提示', '保持提示']
                        ,
                        btnAlign: 'c'
                        ,
                        moveType: 1 //拖拽模式，0或者1
                        ,
                        content: "<div style='padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;'>" + log + "</div>"
                        ,
                        success: function (layero) {
                            var btn = layero.find('.layui-layer-btn');
                            btn.find('.layui-layer-btn0').attr({
                                onclick:'closeTeachTip()'
                            });

                        }
                    });
                }
            }
        });

        $.ajax
        ({
            cache: false,
            async: false,
            dataType: 'json', type: 'post',
            url: "ajax.php?act=getData",
            success: function (data){
                $("#allSite").html(data.allSite);
                $("#todaySite").html(data.todaySite);
                $("#allUser").html(data.allUser);
                $("#todayUser").html(data.todayUser);
                $("#todayMoney").html(data.todayMoney);
                $("#allMoney").html(data.allMoney);
            }
        });

        $.ajax
        ({
            cache: false,
            async: false,
            dataType: 'json', type: 'post',
            url: "ajax.php?act=isUpdate",
            success: function (data) {
                if (data.code != 1) {
                    var log = data.data;
                    //示范一个公告层
                    layer.open({
                        type: 1
                        ,
                        title: false //不显示标题栏
                        ,
                        closeBtn: false
                        ,
                        area: '300px;'
                        ,
                        shade: 0.8
                        ,
                        id: 'LAY_layuipro' //设定一个id，防止重复弹出
                        ,
                        resize: false
                        ,
                        btn: ['立即更新', '稍后提示']
                        ,
                        btnAlign: 'c'
                        ,
                        moveType: 1 //拖拽模式，0或者1
                        ,
                        content: "<div style='padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;'>" + log + "</div>"
                        ,
                        success: function (layero) {
                            var btn = layero.find('.layui-layer-btn');
                            btn.find('.layui-layer-btn0').attr({
                                href: 'update.php'
                            });
                        }
                    });
                }
            }
        });

        //关闭教程提示
        function closeTeachTip(){
            $.ajax
            ({
                cache: false,
                async: false,
                dataType: 'json', type: 'post',
                url: "ajax.php?act=closeTeachTip",
                success: function (data){
                    layer.msg(data.msg, { icon: 1, time: 2000, shade: 0.4 });
                }
            });
        }


        function clearCache(){
            var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
            $.ajax({
                url: 'ajax.php?act=clearCache',
                type: 'POST',
                dataType: 'json',
                data: {},
                success: function (data) {
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            location.href = data.url;
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                },
                error: function () {
                    layer.alert("网络连接错误");
                    return false;
                }
            });
        }

        function getShortLink(){
            var index = layer.msg('数据加载中', {time: 9999999});
            $.ajax({
                type: "post",
                url: "ajax.php?act=getShortLink",
                dataType: "json",
                data: {},
                success: function (data) {
                    layer.close(index);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 800, shade: 0.4}, function () {
                            layer.open({
                                    type: 1
                                    ,
                                    title: false //不显示标题栏
                                    ,
                                    closeBtn: false
                                    ,
                                    area: '300px;'
                                    ,
                                    shade: 0.8
                                    ,
                                    id: 'LAY_layuipro' //设定一个id，防止重复弹出
                                    ,
                                    resize: false
                                    ,
                                    btn: ['前往生成', '关闭提示']
                                    ,
                                    btnAlign: 'c'
                                    ,
                                    moveType: 1 //拖拽模式，0或者1
                                    ,
                                    content: "<div style='padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;'>" + data.data + "</div>"
                                    ,
                                success: function (layero) {
                                    var btn = layero.find('.layui-layer-btn');
                                    btn.find('.layui-layer-btn0').attr({
                                        href: data.url
                                    });
                                }
                            });
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                }
            });
        }
    </script>
