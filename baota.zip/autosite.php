<?php

/*
 * author: 79517721@qq.com
 * time:2020/1/4 0:04
 * 网站驱动文件
 * 将此文件放于宝塔面板目录
 * linux系统:/www/server/panel/data/
 * win系统: 盘符:/BtSoft/panel/data/
 */

header('Content-Type:application/json; charset=utf-8'); 

//$programName  项目程序包安装标识
//$path 		项目存放路径
//$key			网站驱动密钥
//$mykey		用户设定的密钥

$myKey = htmlspecialchars("site_key");
$key = htmlspecialchars($_GET['key']);
$programName = htmlspecialchars($_GET['program']); //项目
$path = htmlspecialchars($_GET['path']);

//以下三个参数可扩展使用
$username = htmlspecialchars($_GET['username']);//网站用户名 默认传输为admin
$password = htmlspecialchars($_GET['password']);//网站密码 默认传输为123456
$domain =  htmlspecialchars($_GET['domain']); //网站域名 传输的值为网站默认域名

$install = "$path/$programName.zip"; //网站程序路径

if($key == $myKey){
    ini_set('user_agent', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; GreenBrowser)');
    if($file = file_get_contents($install)){ //压缩文件所在网站
        if(file_put_contents('autosite.zip', $file)){
            $zip=new ZipArchive();
            if($zip->open('./autosite.zip') && $zip->extractTo('./')){
                unlink('autosite.zip');//删除已下载的文件
                $zip->close();
                $result=array('code'=>1,'msg'=>"程序下载解压成功");
            }else{
                $result=array('code'=>-1,'msg'=>"程序解压失败");
            }
        }else{
            $result=array('code'=>-1,'msg'=>"程序保存失败");
        }
    }else{
        $result=array('code'=>-1,'msg'=>"程序下载失败");
    }
}else{
	$result=array('code'=>-1,'msg'=>"网站驱动密钥错误");
	}

echo json_encode($result);


?>
