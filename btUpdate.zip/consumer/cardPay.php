<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">充值中心</a></li>
                                <li class="breadcrumb-item active">卡密充值</li>
                            </ol>
                        </div>
                        <h4 class="page-title">卡密充值</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div><!--end-row-->
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title mt-0 mb-3">cardPay</h4>
                            <div class="billing-nav">
                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade show active" id="pills-credit-card">
                                        <div class="demo-container">
                                            <div class="card-wrapper mb-4"></div>
                                            <div class="form-container">
                                                <form class="bill-form">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>账号余额</label>
                                                                <input placeholder="用户账号" class="form-control" type="tel" value="<?php echo $userrow['money']?> 元" readonly>
                                                            </div>
                                                        </div><!--end col-->
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>充值卡密</label>
                                                                <input placeholder="充值卡密" class="form-control"
                                                                       type="text" name="card"  onkeyup="this.value=this.value.replace(/\W/g,'')" placeholder="请填写已购买的卡密!" >
                                                            </div>
                                                        </div><!--end col-->
                                                    </div><!--end row-->
                                                    <button class="btn btn-success px-3" type="button" onclick="cardPay()">充值余额</button>
                                                </form><!--end form-->
                                            </div><!--end form-container-->
                                        </div><!--end demo-->
                                    </div><!--end tab-pane-->

                                </div><!--end tab-content-->
                            </div> <!--end billing-nav-->
                        </div><!--end card-body-->
                    </div><!--end card-->
                </div><!--end col-->
            </div><!--end row-->

        </div><!-- container -->

<?php
include('footer.php');
?>
        <script>
            function cardPay(){
                var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
                $.ajax({
                    url: 'ajax.php?act=cardPay',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        card: $("input[name='card']").val()
                    },
                    success: function (data) {
                        layer.close(ii);
                        if (data.code == 1) {
                            layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                location.href = 'info.php';
                            });
                        } else {
                            layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                        }
                    },
                    error:function () {
                        layer.close(ii);
                        layer.alert("网络连接错误");
                    }
                })
            }
        </script>
