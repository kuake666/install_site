<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
?>

<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">用户中心</a></li>
                            <li class="breadcrumb-item active">控制中心</li>
                        </ol>
                    </div>
                    <h4 class="page-title">控制中心</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body  met-pro-bg">
                        <div class="met-profile">
                            <div class="row">
                                <div class="col-lg-4 align-self-center">
                                    <div class="met-profile-main">
                                        <div class="met-profile-main-pic">
                                            <img src="../assets/images/users/user-img.svg" alt=""
                                                 class="rounded-circle">

                                        </div>
                                        <div class="met-profile_user-detail">
                                            <h5 class="met-user-name"><?php echo $userrow['nickname'] ?></h5>
                                            <p class="mb-0 met-user-name-post"><i class="dripicons-user mr-2 text-info font-18"></i>账号：<?php echo $userrow['username'] ?></p>
                                            <p class="mb-0 met-user-name-post"><i class=" dripicons-user-id  mr-2 text-info font-18"></i>身份：<?php echo $userStatus ?></p>
                                        </div>

                                    </div>
                                </div><!--end col-->
                                <div class="col-lg-4 ml-auto">
                                    <ul class="list-unstyled personal-detail">

                                        <li class="mt-2"><i class="dripicons-phone mr-2 text-info font-18"></i> <b>
                                                手机 </b> : <?php echo $userrow['phone'] ?>
                                        </li>
                                        <li class="mt-2"><i class="dripicons-mail text-info font-18 mt-2 mr-2"></i>
                                            <b> 邮箱 </b> : <?php echo $userrow['email'] ?>
                                        </li>
                                        <li class="mt-2"><i class="dripicons-wallet mr-2 text-info font-18"></i> <b>
                                                余额 </b> : <?php echo $userrow['money'] ?>
                                        </li>

                                    </ul>
                                    <!--
                                    <div class="button-list btn-social-icon">
                                        <button type="button" class="btn btn-blue btn-round">
                                            <i class="fab fa-facebook-f"></i>
                                        </button>

                                        <button type="button" class="btn btn-secondary btn-round ml-2">
                                            <i class="fab fa-twitter"></i>
                                        </button>

                                        <button type="button" class="btn btn-pink btn-round  ml-2">
                                            <i class="fab fa-dribbble"></i>
                                        </button>
                                    </div> -->
                                </div><!--end col-->
                            </div><!--end row-->
                        </div><!--end f_profile-->
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
        </div><!--end row-->

        <div class="row">
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <form action="#" method="post">
                            <div class="form-group">
                                <label for="setFullName">昵称</label>
                                <input type="text" class="form-control" id="setNickName" placeholder="请输入昵称"
                                       value="<?php echo $userrow['nickname'] ?>">
                            </div><!--end form-group-->
                            <div class="form-group">
                                <label for="setEmail">邮箱</label>
                                <input type="email" class="form-control" id="setEmail" placeholder="请输入邮箱"
                                       value="<?php echo $userrow['email'] ?>">
                            </div><!--end form-group-->
                            <div class="form-group">
                                <label for="setEmail">手机</label>
                                <input type="phone" class="form-control" id="setPhone"
                                       placeholder="请输入手机号" value="<?php echo $userrow['phone'] ?>">
                            </div><!--end form-group-->
                            <button type="button" class="btn btn-secondary btn-sm" id="saveMyInfo">保存数据</button>
                        </form> <!--end form-->
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <form action="#" method="post">
                            <div class="form-group">
                                <label for="setFullName">账号[不可修改]</label>
                                <input type="text" class="form-control" placeholder="登陆账号"
                                       value="<?php echo $userrow['username'] ?>" disabled>
                            </div><!--end form-group-->
                            <div class="form-group">
                                <label for="setChangePassword">旧密码</label>
                                <input type="password" class="form-control" id="setChangePassword"
                                       placeholder="输入旧密码" name="password">
                            </div> <!--end form-group-->
                            <div class="form-group">
                                <label for="setChangePassword">新密码</label>
                                <input type="password" class="form-control" id="setChangePassword1"
                                       placeholder="输入新密码" name="newpassword">
                            </div> <!--end form-group-->
                            <button type="button" class="btn btn-secondary btn-sm" onclick="passSet()">保存数据</button>
                        </form> <!--end form-->
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 mb-3 header-title">邮件提示</h4>
                        <div class="text-center">
                            <img src="../assets/images/widgets/notify.svg" alt="" class="mb-3" height="115">
                        </div>
                        <form><br/><br/><br/>
                            <div class="custom-control custom-switch switch-success mb-2">
                                <input type="checkbox" class="custom-control-input" id="ICOnotify" checked>
                                <label class="custom-control-label" for="ICOnotify">账号登录提示</label>
                            </div>
                            <div class="custom-control custom-switch switch-success mb-2">
                                <input type="checkbox" class="custom-control-input" id="notyfySound">
                                <label class="custom-control-label" for="notyfySound">重要操作提示</label>
                            </div>
                        </form> <!--end form-->
                    </div><!--end card-body-->
                </div><!--end card-->
            </div><!--end col-->
        </div><!--end row-->

    </div><!-- container -->

    <?php
    include('footer.php');
    ?>
    <script>
        $("#saveMyInfo").click(function () {
            var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
            $.ajax({
                type: "post",
                url: "ajax.php?act=saveMyInfo",
                dataType: "json",
                data: {nickname: $("#setNickName").val(), email: $("#setEmail").val(), phone: $("#setPhone").val()},
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            //location.href = 'index.php';
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                },
                error: function () {
                    layer.alert('网络连接错误！');
                }
            });
        });


        function passSet() {
            var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
            $.ajax({
                url: './ajax.php?act=passSet',
                type: 'POST',
                dataType: 'json',
                data: {newpassword: $("input[name='newpassword']").val(), password: $("input[name='password']").val()},
                success: function (data) {
                    layer.close(ii);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            location.href = 'index.php';
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                },
                error: function () {
                    layer.close(ii);
                    layer.alert('网络连接错误！');
                }
            })
        }
    </script>
