<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------


include("../app/common.php");
$act = isset($_GET['act']) ? daddslashes($_GET['act']) : null;

@header('Content-Type: application/json; charset=UTF-8');

switch ($act) {
    case 'register':
        $username = trim(strip_tags(daddslashes($_POST['user'])));
        $password = trim(strip_tags(daddslashes($_POST['pass'])));
        $password2 = trim(strip_tags(daddslashes($_POST['pass2'])));
        $code = trim(strip_tags(daddslashes($_POST['code'])));
        $verifycode = 1;//验证码开关
        if (!function_exists("imagecreate") || !file_exists('./code.php')) $verifycode = 0;
        if ($verifycode == 1 && (!$code || strtolower($code) != $_SESSION['vc_code'])) {
            unset($_SESSION['vc_code']);
            $result = array("code" => -1, "msg" => "验证码错误,请重新输入");
            exit(json_encode($result));
        }
        if ($password == null || $username == null || $password2 == null) {
            $result = array("code" => -1, "msg" => "数据填写不完整");
            exit(json_encode($result));
        }
        if (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
            $result = array("code" => -1, "msg" => "用户名只能为英文或数字！");
            exit(json_encode($result));
        } elseif (strlen($password) < 6) {
            $result = array("code" => -1, "msg" => "密码不能低于6位！");
            exit(json_encode($result));
        }
        if ($password != $password2) {
            $result = array("code" => -1, "msg" => "两次输入密码不一致！");
            exit(json_encode($result));
        }
        $existUser = $DB->query("SELECT * FROM wcms_user WHERE username='{$username}' limit 1")->fetch();
        if ($existUser) {
            $result = array("code" => -1, "msg" => "账户存在,请更换用户名！");
            exit(json_encode($result));
        }
        $nickname = "网友";
        $city = getCityByIp($clientIp);
        $city = $city['city'];
        $password = md5($password);
        $sql = $DB->exec("INSERT INTO `wcms_user` (`username`, `password`,  `email`, `sid`,`phone`,`nickname`,`regtime`, `regip`, `regcity`, `mcode`,`money`,`status`)VALUES ('{$username}', '{$password}','','', '17800000000','{$nickname}',  '{$date}', '{$clientIp}','{$city}', '100','0.00', '1')");
        unset($_SESSION['vc_code']); //销毁验证码
        if ($sql) {
            $result = array("code" => 1, "msg" => "用户注册成功");
            exit(json_encode($result));
        } else {
            $result = array("code" => -1, "msg" => "用户注册失败,请稍后再试");
            exit(json_encode($result));
        }

        break;

    case 'login':
        $username = trim(strip_tags(daddslashes($_POST['user'])));
        $password = trim(strip_tags(daddslashes($_POST['pass'])));
        $isNologin = trim(strip_tags(daddslashes($_POST['isNologin'])));
        if ($password == null || $username == null) {
            $result = array("code" => -1, "msg" => "请填写账号密码后再登陆");
            exit(json_encode($result));
        }

        $userrow = $DB->query("SELECT * FROM `wcms_user` WHERE `username`='{$username}'  limit 1")->fetch();
        $password = md5($password);
        if ($username == $userrow['username'] && $password == $userrow['password']) {
            saveLog($userrow['uid'], "登录用户中心");
            /*
            $city = getCityByIp($clientIp);
            $city = $city['city'];
            $userLog = $DB->query("SELECT `uid` FROM `wcms_log` WHERE `uid`='{$userrow['uid']}' and `city`='{$city}' and `type`='登录用户中心' ")->rowCount();//判断异地
            $userLogAll = $DB->query("SELECT `uid` FROM `wcms_log` WHERE `uid`='{$userrow['uid']}' and `type`='登录用户中心'")->rowCount(); //总共登陆次数
            if ($userLogAll > 10 && $userLog < 5) { //在用户登陆第十次之后， 如果发生异地登陆开始执行
                //符合特定条件 发送邮件功能
                //如果当前登陆账户在此地登陆次数少于5次 则发送邮件
                $mail_name = $userrow['email'] ? $userrow['email'] : $conf["mail_name"];
                send_mail($mail_name, $conf["web_name"] . "-异地登陆提醒", '尊敬客户您好：');
            }

            */
            if (!$isNologin || $isNologin = 0) { //未开启30天免登录
                $expiretime = time() + 604800;
            } else {
                $expiretime = time() + 2592000;
            }
            $session = md5($username . $password . $password_hash);

            $token = authcode("{$username}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
            setcookie("user_token", $token, $expiretime);
            exit('{"code":1,"msg":"尊敬的 ' . $userrow['nickname'] . ' ,登录成功!"}');
        } else {
            $result = array("code" => -1, "msg" => "用户名或密码不正确");
            exit(json_encode($result));
        }

        break;

    case 'logout':
        setcookie("user_token", "", time() - 604800);
        setcookie("admin_token", "", time() - 604800);
        $result = array("code" => 1, "msg" => "退出成功");
        exit(json_encode($result));
        break;

    case 'recoverPass':
        $code = trim(strip_tags(daddslashes($_POST['code'])));
        $email = trim(strip_tags(daddslashes($_POST['email'])));
        if ($code == null || $email == null) {
            $result = array("code" => -1, "msg" => "邮箱和验证码不能为空");
            exit(json_encode($result));
        }
        $userrow = $DB->query("SELECT `uid`,`username` FROM `wcms_user` WHERE `email`='{$email}' and `sid`='{$code}' limit 1")->fetch();
        if ($userrow) {
            $DB->exec("UPDATE `wcms_user` SET `password` ='e10adc3949ba59abbe56e057f20f883e',`sid`='' WHERE `uid`='{$userrow['uid']}'");
            $result = array("code" => 1, "msg" => "您的账号为:" . $userrow['username'] . " ,密码已重置为123456");
            exit(json_encode($result));
        } else {
            $result = array("code" => -1, "msg" => "验证码失效");
            exit(json_encode($result));
        }
        break;


    case 'sendCode':
        $email = trim(daddslashes($_POST['email']));
        if (isset($_SESSION['find_mail']) && $_SESSION['find_mail'] > time() - 600) {
            $result = array("code" => -1, "msg" => "请勿频繁发送邮件，如果未收到请尝试在垃圾邮件箱寻找");
            exit(json_encode($result));
        }
        $row = $DB->query("SELECT uid FROM `wcms_user` WHERE `email`='$email' limit 1")->fetch();
        if (!$row) {
            $result = array("code" => -1, "msg" => "未查到有效用户，如需找回请联系客服");
            exit(json_encode($result));
        }
        $scriptpath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
        $sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));
        $siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $sitepath . '/';
        $sub = $conf['web_name'] . ' - 用户密码找回';
        $sid = substr(md5(uniqid() . rand(1, 5)), 16);
        $DB->exec("UPDATE `wcms_user` SET `sid` ='{$sid}' WHERE `email`='{$email}'");
        $msg = emailWritting($conf['web_name'], "找回密码", " 本次操作验证码 :$sid");
        $result = sendEmail($email, $sub, $msg);
        if ($result === true) {
            $_SESSION['find_mail'] = time();
            $result = array("code" => 1, "msg" => "发送成功，请注意查收");
            exit(json_encode($result));
        } else {
            file_put_contents('mail.log', $result);
            $result = array("code" => -1, "msg" => "邮件发送失败");
            exit(json_encode($result));
        }
        break;


    default:
        $result = array("code" => -1, "msg" => "服务器异常");
        exit(json_encode($result));
        break;


}



/**
 * @Description 手机验证码 =>暂未开发
 * @Author 夸克 79517721@qq.com
 * @param $phone 手机号
 * @param $code 验证码
 * @param $moban 模板编号
 * @return
 * @Date 2020/3/3 17:44

function send_sms($phone, $code, $moban){
    $host = "http://ding1xin.market.alicloudapi.com";
    $path = "/dx/sendSms";
    $method = "POST";
    $appcode = "c03844bf2e929b8d";
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "mobile=$phone&param=code%3A$code&tpl_id=$moban";
    $bodys = "";
    $url = $host . $path . "?" . $querys;
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, true);
    if (1 == strpos("$".$host, "https://"))
    {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }
    $response = curl_exec($curl);
    if (curl_getinfo($curl, CURLINFO_HTTP_CODE) == '200') {
        $headerSize = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $header = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);
        return $body;
    }else{
        $result = array("return_code"=>'-1',"msg"=>"请求错误！未找到网址！");
        return $result;
    }

}
 */


?>