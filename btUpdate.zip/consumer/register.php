<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include '../app/common.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title><?php echo $conf['web_name'] ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A premium admin dashboard template by Mannatthemes" name="description"/>
    <meta content="Mannatthemes" name="author"/>

    <!-- App favicon -->
    <link rel="shortcut icon" href="../assets/images/favicon.ico">

    <!-- App css -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/icons.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/metisMenu.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>

</head>

<body class="account-body accountbg" onkeydown="keyLogin();">

<!-- Log In page -->
<div class="row vh-100 ">
    <div class="col-12 align-self-center">
        <div class="auth-page">
            <div class="card auth-card shadow-lg">
                <div class="card-body">
                    <div class="px-3">
                        <div class="auth-logo-box">
                            <a href="./register.php" class="logo logo-admin"><img src="../assets/images/logo-sm.png"
                                                                                  height="55" alt="logo"
                                                                                  class="auth-logo"></a>
                        </div><!--end auth-logo-box-->
                        <div class="text-center auth-logo-text">
                            <h4 class="mt-0 mb-3 mt-5">注册账号</h4>
                        </div> <!--end auth-logo-text-->
                        <form class="form-horizontal auth-form my-4" action="#" method="post">
                            <div class="form-group">
                                <label for="username">用户名</label>
                                <div class="input-group mb-3">
                                            <span class="auth-form-icon">
                                                <i class="dripicons-user"></i> 
                                            </span>
                                    <input type="text" class="form-control" id="user" name="user" placeholder="请输入用户名">
                                </div>
                            </div><!--end form-group-->
                            <div class="form-group">
                                <label for="userpassword">密码</label>
                                <div class="input-group mb-3">
                                            <span class="auth-form-icon">
                                                <i class="dripicons-lock"></i> 
                                            </span>
                                    <input type="password" class="form-control" id="pass" name="pass"
                                           placeholder="请输入密码">
                                </div>
                            </div><!--end form-group-->
                            <div class="form-group">
                                <label for="useremail">确认密码</label>
                                <div class="input-group mb-3">
                                            <span class="auth-form-icon">
                                                <i class="dripicons-lock"></i>
                                            </span>
                                    <input type="password" class="form-control" id="pass2" name="pass2"
                                           placeholder="请再次输入密码">
                                </div>
                            </div><!--end form-group-->

                            <label for="useremail">验证码</label>
                            <div class="input-group">
                                <input type="text" name="code" placeholder="请输入验证码" class="form-control no-border">&nbsp;&nbsp;

                                <span style="padding: 0">
                                    <img src="code.php" height="43" onclick="this.src='./code.php?r='+Math.random();"
                                         title="点击更换验证码">
                                </span>
                            </div>
                            <!--  开发邮箱 手机验证码时使用
                            <label for="useremail">邮箱验证码</label>
                            <div class="input-group">
                                <input type="text" id="code" placeholder="请输入邮箱验证码" class="form-control no-border">&nbsp;&nbsp;
                                <button class="btn btn-primary font-2" id="sendCode" type="button">发送验证码</button>
                            </div>
                            -->

                            <div class="form-group">
                                <div class="form-group row mt-4">
                                    <div class="col-sm-12">
                                        <div class="custom-control custom-switch switch-success">
                                            <input type="checkbox" class="custom-control-input"
                                                   id="customSwitchSuccess" name="check">
                                            <label class="custom-control-label text-muted"
                                                   for="customSwitchSuccess">同意我们的 <a href="#"
                                                                                      class="text-primary"
                                                                                      data-toggle="modal"
                                                                                      data-target="#myModal">使用协议</a></label>
                                        </div>
                                    </div><!--end col-->
                                </div><!--end form-group-->

                                <div class="form-group mb-0 row">
                                    <div class="col-12 mt-2">
                                        <button class="btn btn-primary btn-round btn-block waves-effect waves-light"
                                                type="button" id="userRegister">免费注册 <i
                                                    class="fas fa-sign-in-alt ml-1"></i></button>
                                    </div><!--end col-->
                                </div> <!--end form-group-->
                        </form><!--end form-->
                    </div><!--end /div-->

                    <div class="m-3 text-center text-muted">
                        <p class="">已经有账号 ? <a href="./login.php" class="text-primary ml-2">立即登录</a></p>
                    </div>
                </div><!--end card-body-->
            </div><!--end card-->
        </div><!--end auth-card-->
    </div><!--end col-->


    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="example-tooltip"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="example-tooltip-title"><b>使用协议</b></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class='ibox-content'>
                    <div class='alert'>
                        使用本系统需遵守以下协议: <br> <br>
                        <a class='alert-link' href='#'>具体请咨询系统管理员! </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">关闭</button>
                </div>
            </div>
        </div>
    </div>


</div><!--end row-->
<!-- End Log In page -->

<!-- jQuery  -->
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/metisMenu.min.js"></script>
<script src="../assets/js/waves.min.js"></script>
<script src="../assets/js/jquery.slimscroll.min.js"></script>

<!-- App js -->
<script src="../assets/js/app.js"></script>
<!--引入layer-->
<script src="../assets/js/layer/layer.js"></script>
<script>
    $("#userRegister").click(function () {
        if ($('#customSwitchSuccess').is(':checked')) {
            var ii = layer.load(0, {shade: false}); //0代表加载的风格，支持0-2
            $.ajax({
                url: './auth.php?act=register',
                type: 'POST',
                dataType: 'json',
                data: {
                    code: $("input[name='code']").val(),
                    user: $("input[name='user']").val(),
                    pass2: $("input[name='pass2']").val(),
                    pass: $("input[name='pass']").val()
                },
                success: function (data) {
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            location.href = 'index.php';
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                }
            });
        } else {
            layer.msg("您还没有同意我们的使用协议", {icon: 2, time: 2000, shade: 0.4});

        }
    });

    function keyLogin(){
        if (event.keyCode==13)  //回车键的键值为13
            $("#userRegister").click();
    }
</script>
</body>
</html>