-- wcms_conf QQ跳转/push 状态及 价格
INSERT INTO `wcms_conf` VALUES ('qqjump', '0');
INSERT INTO `wcms_conf` VALUES ('push_toll', '1');
INSERT INTO `wcms_conf` VALUES ('push_price', 20);
-- 卡密表
CREATE TABLE `wcms_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card` varchar(255) NOT NULL COMMENT '卡密',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `addtime` datetime DEFAULT NULL COMMENT '生成时间',
  `endtime` datetime DEFAULT NULL COMMENT '使用时间',
  `uid` int(10) DEFAULT NULL COMMENT '使用者编号',
  `active` int(11) DEFAULT '0' COMMENT '状态 0:未使用 1:已使用',
  `type` int(11) DEFAULT '0' COMMENT '卡密类型 0: 充值卡密',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- demo表
CREATE TABLE `wcms_demo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) NOT NULL COMMENT '域名',
  `code` varchar(255) NOT NULL COMMENT '项目编码',
  `date` datetime NOT NULL COMMENT '任务创建时间',
  `status` int(11) DEFAULT '0' COMMENT '状态',
  `type` varchar(255) NOT NULL COMMENT '详情',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- 工单表
CREATE TABLE `wcms_workorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL COMMENT '工单编码',
  `num` varchar(255) NOT NULL COMMENT '时间戳',
  `uid` int(11) NOT NULL COMMENT '用户编号',
  `user` varchar(255) NOT NULL COMMENT '用户名',
  `title` varchar(255) NOT NULL COMMENT '工单标题',
  `content` varchar(255) NOT NULL COMMENT '工单内容',
  `date` datetime NOT NULL COMMENT '发起时间',
  `userreply` datetime NOT NULL COMMENT '用户回复时间',
  `adminreply` datetime NOT NULL DEFAULT '0001-01-01 00:00:00' COMMENT '管理员回复时间',
  `state` int(2) NOT NULL DEFAULT '0' COMMENT '工单状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- 新增菜单 前后台工单 前后台卡密 网站push 后台菜单设置 网站图标
INSERT INTO `wcms_menu2` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('菜单设置','menu.php','fab fa-envira','10001','1'),
('工单记录','workOrder.php','fas fa-comment','10002','1'),
('卡密列表','cardPay.php','fab fa-cc-visa','10004','1'),
(' 网站图标','icons.php','fab fa-accusoft','10004','1');

INSERT INTO `wcms_menu` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('在线工单','workOrder.php','fas fa-comment','10000','1'),
('网站push','push.php','fab fa-slideshare','10002','1'),
('卡密支付','cardPay.php','fab fa-cc-visa','10003','1');