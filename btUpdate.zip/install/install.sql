-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2020-01-03 22:41:52
-- 服务器版本： 5.6.44-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


-- --------------------------------------------------------

--
-- 表的结构 `wcms_conf`
--

CREATE TABLE IF NOT EXISTS `wcms_conf` (
  `k` varchar(255) NOT NULL,
  `v` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `wcms_conf`
--

INSERT INTO `wcms_conf` (`k`, `v`) VALUES
('web_name', '宝塔建站系统'),
('web_subtitle', '全自动建站神器'),
('keywords', '全自动建站神器,一键搭建企业官网,个人博客,个人官网,宝塔面板建站系统,一键搭建网站'),
('web_description', ' 本网站是一款企业级的建站系统,高效快速,可一键搭建企业官网,企业博客,企业宣传网站,个人官网,个人博客等网站'),
('web_icp', '辽88888888'),
('mail_cloud', '0'),
('mail_smtp', 'smtp.qq.com'),
('mail_port', '465'),
('mail_name', '79517721@qq.com'),
('mail_pwd', ''),
('mail_apiuser', NULL),
('mail_apikey', NULL),
('sms_appkey', NULL),
('epay_api', 'http://www.w-cms.cn/'),
('epay_id', ''),
('epay_key', ''),
('ma_id', ''),
('ma_key', ''),
('qqpay_api', '0'),
('wxpay_api', '0'),
('alipay_key', ''),
('alipay_pid', ''),
('alipay_api', '0'),
('alipay2_api', '1'),
('system_key', ''),
('template', 'default'),
('about_us', ' <p>\n 本网站是一款企业级的建站系统,高效快速\n</p>'),
('connect_us', '<p>\n电话:  123456 <br>\nQ  Q: 123456<br>\n微信: 123456\n</p>'),
('friend_link', '<ul class="list-unstyled">\n<li><a href="#" class="btn btn-underline">阿里云</a></li>\n<li><a href="#" class="btn btn-underline">腾讯云</a></li>\n<li><a href="#" class="btn btn-underline">华为云</a></li>\n</ul>'),
('quikly_pass', '<ul class="list-unstyled">\n<li><a href="index.php?type=products" class="btn btn-underline">产品</a></li>\n<li><a href="index.php?type=blog" class="btn btn-underline">解决方案</a></li>\n\n</ul>'),
('version', '7500');

-- --------------------------------------------------------

--
-- 表的结构 `wcms_log`
--

CREATE TABLE IF NOT EXISTS `wcms_log` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `type` varchar(64) DEFAULT NULL COMMENT '操作详情',
  `date` datetime NOT NULL,
  `city` varchar(64) DEFAULT NULL COMMENT '地区',
  `data` text COMMENT '操作IP'
) DEFAULT CHARSET=utf8;



-- --------------------------------------------------------

--
-- 表的结构 `wcms_member`
--

CREATE TABLE IF NOT EXISTS `wcms_member` (
  `mid` int(11) NOT NULL,
  `mname` varchar(64) NOT NULL COMMENT '会员名称',
  `mprice` decimal(32,0) NOT NULL COMMENT '会员价格',
  `mpercent` float NOT NULL COMMENT '会员折扣',
  `mdecription` text NOT NULL COMMENT '会员介绍',
  `mcode` int(11) NOT NULL COMMENT '唯一编码'
)DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `wcms_member`
--
   
INSERT INTO `wcms_member` (`mid`, `mname`, `mprice`, `mpercent`, `mdecription`, `mcode`) VALUES
(10001, '普通用户', '0', 1, '<li>普通用户建站不享受优惠</li>', 100),
(10002, '初级会员', '50', 0.8, '<li>初级会员建站可享受8折优惠</li>', 200),
(10003, '中级会员', '100', 0.5, '<li>中级会员建站可享受5折优惠</li>', 300),
(10004, '高级会员', '150', 0.3, '<li>高级会员建站可享受3折优惠</li>', 400),
(10005, '系统管理员', '10000', 0, '<li>系统管理员,不可删除,用户不可购买,系统管理员具有最高权限</li>', 10000);

-- --------------------------------------------------------

--
-- 表的结构 `wcms_menu`
--

CREATE TABLE IF NOT EXISTS `wcms_menu` (
  `id` int(11) NOT NULL,
  `menuname` varchar(255) NOT NULL COMMENT '菜单名字',
  `menupath` varchar(255) DEFAULT NULL COMMENT '菜单路径',
  `menuicon` text DEFAULT NULL COMMENT '父菜单图标',
  `parentid` int(11) NOT NULL DEFAULT '0' COMMENT '是否有父级',
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `wcms_menu`
--

INSERT INTO `wcms_menu` (`id`, `menuname`, `menupath`, `menuicon`, `parentid`, `status`) VALUES
(10003, '支付中心', 'PayModel', 'need_replacezuosvg class="nav-svg" version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg"\n                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\n                         viewBox="0 0 512 512" style="enable-background:new 0 0 512 512need_replace" xml:space="preserve"need_replaceyou\n                                need_replacezuogneed_replaceyou\n                                    need_replacezuogneed_replaceyou\n                                        need_replacezuopath d="M276,68.1v219c0,3.7-2.5,6.8-6,7.7L81.1,343.4c-2.3,0.6-3.6,3.1-2.7,5.4C109.1,426,184.9,480.6,273.2,480\n                                            C387.8,479.3,480,386.5,480,272c0-112.1-88.6-203.5-199.8-207.8C277.9,64.1,276,65.9,276,68.1z"/need_replaceyou\n                                    need_replacezuo/gneed_replaceyou\n                                    need_replacezuopath class="svg-primary" d="M32,239.3c0,0,0.2,48.8,15.2,81.1c0.8,1.8,2.8,2.7,4.6,2.2l193.8-49.7c3.5-0.9,6.4-4.6,6.4-8.2V36c0-2.2-1.8-4-4-4\n                                        C91,33.9,32,149,32,239.3z"/need_replaceyou\n                                need_replacezuo/gneed_replaceyou\n                            need_replacezuo/svgneed_replaceyou', 0, 1),
(10002, '在线商城', 'ShopModel', ' need_replacezuosvg class="nav-svg" version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg"\n                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\n                         viewBox="0 0 512 512" style="enable-background:new 0 0 512 512need_replace" xml:space="preserve"need_replaceyou\n                                need_replacezuogneed_replaceyou\n                                    need_replacezuoellipse class="svg-primary"\n                                             transform="matrix(0.9998 -1.842767e-02 1.842767e-02 0.9998 -7.7858 3.0205)"\n                                             cx="160" cy="424" rx="24" ry="24"/need_replaceyou\n                                    need_replacezuoellipse class="svg-primary"\n                                             transform="matrix(2.381651e-02 -0.9997 0.9997 2.381651e-02 -48.5107 798.282)"\n                                             cx="384.5" cy="424" rx="24" ry="24"/need_replaceyou\n                                    need_replacezuopath d="M463.8,132.2c-0.7-2.4-2.8-4-5.2-4.2L132.9,96.5c-2.8-0.3-6.2-2.1-7.5-4.7c-3.8-7.1-6.2-11.1-12.2-18.6\n                                        c-7.7-9.4-22.2-9.1-48.8-9.3c-9-0.1-16.3,5.2-16.3,14.1c0,8.7,6.9,14.1,15.6,14.1c8.7,0,21.3,0.5,26,1.9c4.7,1.4,8.5,9.1,9.9,15.8\n                                        c0,0.1,0,0.2,0.1,0.3c0.2,1.2,2,10.2,2,10.3l40,211.6c2.4,14.5,7.3,26.5,14.5,35.7c8.4,10.8,19.5,16.2,32.9,16.2h236.6\n                                        c7.6,0,14.1-5.8,14.4-13.4c0.4-8-6-14.6-14-14.6H189h-0.1c-2,0-4.9,0-8.3-2.8c-3.5-3-8.3-9.9-11.5-26l-4.3-23.7\n                                        c0-0.3,0.1-0.5,0.4-0.6l277.7-47c2.6-0.4,4.6-2.5,4.9-5.2l16-115.8C464,134,464,133.1,463.8,132.2z"/need_replaceyou\n                                need_replacezuo/gneed_replaceyou\n                            need_replacezuo/svgneed_replaceyou', 0, 1),
(10001, '用户中心', 'UserModel', 'need_replacezuosvg class="nav-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"need_replaceyou\n                        need_replacezuopath class="svg-primary"\n                              d="M239.208 343.937c-17.78 10.103-38.342 15.876-60.255 15.876-21.909 0-42.467-5.771-60.246-15.87C71.544 358.331 42.643 406 32 448h293.912c-10.639-42-39.537-89.683-86.704-104.063zM178.953 120.035c-58.479 0-105.886 47.394-105.886 105.858 0 58.464 47.407 105.857 105.886 105.857s105.886-47.394 105.886-105.857c0-58.464-47.408-105.858-105.886-105.858zm0 186.488c-33.671 0-62.445-22.513-73.997-50.523H252.95c-11.554 28.011-40.326 50.523-73.997 50.523z"/need_replaceyou\n                        need_replacezuogneed_replaceyou\n                            need_replacezuopath d="M322.602 384H480c-10.638-42-39.537-81.691-86.703-96.072-17.781 10.104-38.343 15.873-60.256 15.873-14.823 0-29.024-2.654-42.168-7.49-7.445 12.47-16.927 25.592-27.974 34.906C289.245 341.354 309.146 364 322.602 384zM306.545 200h100.493c-11.554 28-40.327 50.293-73.997 50.293-8.875 0-17.404-1.692-25.375-4.51a128.411 128.411 0 0 1-6.52 25.118c10.066 3.174 20.779 4.862 31.895 4.862 58.479 0 105.886-47.41 105.886-105.872 0-58.465-47.407-105.866-105.886-105.866-37.49 0-70.427 19.703-89.243 49.09C275.607 131.383 298.961 163 306.545 200z"/need_replaceyou\n                        need_replacezuo/gneed_replaceyou\n                    need_replacezuo/svgneed_replaceyou', 0, 1),
(10000, '服务中心', 'ServiceModel', 'need_replacezuosvg class="nav-svg" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"\n                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\n                         viewBox="0 0 512 512" style="enable-background:new 0 0 512 512need_replace" xml:space="preserve"need_replaceyou\n                                need_replacezuogneed_replaceyou\n                                    need_replacezuopath d="M184,448h48c4.4,0,8-3.6,8-8V72c0-4.4-3.6-8-8-8h-48c-4.4,0-8,3.6-8,8v368C176,444.4,179.6,448,184,448z"/need_replaceyou\n                                    need_replacezuopath class="svg-primary"\n                                          d="M88,448H136c4.4,0,8-3.6,8-8V296c0-4.4-3.6-8-8-8H88c-4.4,0-8,3.6-8,8V440C80,444.4,83.6,448,88,448z"/need_replaceyou\n                                    need_replacezuopath class="svg-primary" d="M280.1,448h47.8c4.5,0,8.1-3.6,8.1-8.1V232.1c0-4.5-3.6-8.1-8.1-8.1h-47.8c-4.5,0-8.1,3.6-8.1,8.1v207.8\n                                        C272,444.4,275.6,448,280.1,448z"/need_replaceyou\n                                    need_replacezuopath d="M368,136.1v303.8c0,4.5,3.6,8.1,8.1,8.1h47.8c4.5,0,8.1-3.6,8.1-8.1V136.1c0-4.5-3.6-8.1-8.1-8.1h-47.8\n                                        C371.6,128,368,131.6,368,136.1z"/need_replaceyou\n                                need_replacezuo/gneed_replaceyou\n                            need_replacezuo/svgneed_replaceyou', 0, 1),
(10004, '新闻中心', 'ArticleModel', ' need_replacezuosvg class="nav-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"need_replaceyou\n                        need_replacezuopath d="M70.7 164.5l169.2 81.7c4.4 2.1 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c8.9-4.3 8.9-11.3 0-15.6L272.1 67.2c-4.4-2.1-10.3-3.2-16.1-3.2s-11.7 1.1-16.1 3.2L70.7 148.9c-8.9 4.3-8.9 11.3 0 15.6z"/need_replaceyou\n                        need_replacezuopath class="svg-primary"\n                              d="M441.3 248.2s-30.9-14.9-35-16.9-5.2-1.9-9.5.1S272 291.6 272 291.6c-4.5 2.1-10.3 3.2-16.1 3.2s-11.7-1.1-16.1-3.2c0 0-117.3-56.6-122.8-59.3-6-2.9-7.7-2.9-13.1-.3l-33.4 16.1c-8.9 4.3-8.9 11.3 0 15.6l169.2 81.7c4.4 2.1 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c9.1-4.2 9.1-11.2.2-15.5z"/need_replaceyou\n                        need_replacezuopath d="M441.3 347.5s-30.9-14.9-35-16.9-5.2-1.9-9.5.1S272.1 391 272.1 391c-4.5 2.1-10.3 3.2-16.1 3.2s-11.7-1.1-16.1-3.2c0 0-117.3-56.6-122.8-59.3-6-2.9-7.7-2.9-13.1-.3l-33.4 16.1c-8.9 4.3-8.9 11.3 0 15.6l169.2 81.7c4.4 2.2 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c9-4.3 9-11.3.1-15.6z"/need_replaceyou\n                    need_replacezuo/svgneed_replaceyou', 0, 1),
(10006, '服务台', 'index.php', 'dripicons-meter', 10000, 1),
(10007, '系统通知', 'message.php', 'dripicons-volume-medium', 10000, 1),
(10008, '控制中心', 'info.php', 'dripicons-card', 10001, 1),
(10009, '已购模板', 'mySite.php', 'dripicons-stack', 10001, 1),
(10010, '操作记录', 'log.php', 'dripicons-calendar', 10001, 1),
(10011, '消费记录', 'charge.php', 'dripicons-clipboard', 10001, 1),
(10012, '模板商城', 'program.php', 'dripicons-cart', 10002, 1),
(10013, '会员商城', 'member.php', 'dripicons-thumbs-up', 10002, 1),
(10014, '在线支付', 'onlinePay.php', 'dripicons-card', 10003, 1),
(10015, '文章列表', 'article.php', 'dripicons-blog', 10004, 1),
(10016, '手册说明', 'doc.php', 'dripicons-direction', 10004, 1);


-- --------------------------------------------------------

--
-- 表的结构 `wcms_menu2`
--

CREATE TABLE IF NOT EXISTS `wcms_menu2` (
  `id` int(11) NOT NULL,
  `menuname` varchar(255) NOT NULL COMMENT '菜单名字',
  `menupath` varchar(255) NOT NULL COMMENT '菜单路径',
  `menuicon` text DEFAULT NULL COMMENT '父菜单图标',
  `parentid` int(11) NOT NULL DEFAULT '0' COMMENT '是否有父级',
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `wcms_menu2`
--

INSERT INTO `wcms_menu2` (`id`, `menuname`, `menupath`, `menuicon`, `parentid`, `status`) VALUES
(10006, '控制中心', 'index.php', 'dripicons-view-thumb', 10000, 1),
(10007, '项目列表', 'program.php', 'dripicons-stack', 10000, 1),
(10008, '服务器列表', 'server.php', 'dripicons-cloud', 10000, 1),
(10009, '会员分类', 'member.php', 'dripicons-user-id', 10000, 1),
(10010, '用户列表', 'user.php', 'dripicons-user-group', 10000, 1),
(10011, '用户网站', 'site.php', 'dripicons-web', 10000, 1),
(10012, '新闻通知', 'article.php', 'dripicons-blog', 10000, 1),
(10013, '系统设置', 'sysSet.php', 'dripicons-gear', 10001, 1),
(10004, '更多功能', 'MoreFunction', ' need_replacezuosvg class="nav-svg" version="1.1" id="Layer_4" xmlns="http://www.w3.org/2000/svg"\r\n                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\r\n                         viewBox="0 0 512 512" style="enable-background:new 0 0 512 512need_replace" xml:space="preserve"need_replaceyou\r\n                                need_replacezuogneed_replaceyou\r\n                                    need_replacezuopath d="M462.5,352.3c-1.9-5.5-5.6-11.5-11.4-18.3c-10.2-12-30.8-29.3-54.8-47.2c-2.6-2-6.4-0.8-7.5,2.3l-4.7,13.4\r\n                                        c-0.7,2,0,4.3,1.7,5.5c15.9,11.6,35.9,27.9,41.8,35.9c2,2.8-0.5,6.6-3.9,5.8c-10-2.3-29-7.3-44.2-12.8c-8.6-3.1-17.7-6.7-27.2-10.6\r\n                                        c16-20.8,24.7-46.3,24.7-72.6c0-32.8-13.2-63.6-37.1-86.4c-22.9-21.9-53.8-34.1-85.7-33.7c-25.7,0.3-50.1,8.4-70.7,23.5\r\n                                        c-18.3,13.4-32.2,31.3-40.6,52c-8.3-6-16.1-11.9-23.2-17.6c-13.7-10.9-28.4-22-38.7-34.7c-2.2-2.8,0.9-6.7,4.4-5.9\r\n                                        c11.3,2.6,35.4,10.9,56.4,18.9c1.5,0.6,3.2,0.3,4.5-0.8l11.1-10.1c2.4-2.1,1.7-6-1.3-7.2C121,137.4,89.2,128,73.2,128\r\n                                        c-11.5,0-19.3,3.5-23.3,10.4c-7.6,13.3,7.1,35.2,45.1,66.8c34.1,28.5,82.6,61.8,136.5,92c87.5,49.1,171.1,81,208,81\r\n                                        c11.2,0,18.7-3.1,22.1-9.1C464.4,364.4,464.7,358.7,462.5,352.3z"/need_replaceyou\r\n                                    need_replacezuopath class="svg-primary" d="M312,354c-29.1-12.8-59.3-26-92.6-44.8c-30.1-16.9-59.4-36.5-84.4-53.6c-1-0.7-2.2-1.1-3.4-1.1c-0.9,0-1.9,0.2-2.8,0.7\r\n                                        c-2,1-3.3,3-3.3,5.2c0,1.2-0.1,2.4-0.1,3.5c0,32.1,12.6,62.3,35.5,84.9c22.9,22.7,53.4,35.2,85.8,35.2c23.6,0,46.5-6.7,66.2-19.5\r\n                                        c1.9-1.2,2.9-3.3,2.7-5.5C315.5,356.8,314.1,354.9,312,354z"/need_replaceyou\r\n                                need_replacezuo/gneed_replaceyou\r\n                           need_replacezuo/svgneed_replaceyou', 0, 1),
(10003, '服务商城', 'StoreModel', ' need_replacezuosvg class="nav-svg" version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg"\r\n                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\r\n                         viewBox="0 0 512 512" style="enable-background:new 0 0 512 512need_replace" xml:space="preserve"need_replaceyou\r\n                                need_replacezuogneed_replaceyou\r\n                                    need_replacezuoellipse class="svg-primary"\r\n                                             transform="matrix(0.9998 -1.842767e-02 1.842767e-02 0.9998 -7.7858 3.0205)"\r\n                                             cx="160" cy="424" rx="24" ry="24"/need_replaceyou\r\n                                    need_replacezuoellipse class="svg-primary"\r\n                                             transform="matrix(2.381651e-02 -0.9997 0.9997 2.381651e-02 -48.5107 798.282)"\r\n                                             cx="384.5" cy="424" rx="24" ry="24"/need_replaceyou\r\n                                    need_replacezuopath d="M463.8,132.2c-0.7-2.4-2.8-4-5.2-4.2L132.9,96.5c-2.8-0.3-6.2-2.1-7.5-4.7c-3.8-7.1-6.2-11.1-12.2-18.6\r\n                                        c-7.7-9.4-22.2-9.1-48.8-9.3c-9-0.1-16.3,5.2-16.3,14.1c0,8.7,6.9,14.1,15.6,14.1c8.7,0,21.3,0.5,26,1.9c4.7,1.4,8.5,9.1,9.9,15.8\r\n                                        c0,0.1,0,0.2,0.1,0.3c0.2,1.2,2,10.2,2,10.3l40,211.6c2.4,14.5,7.3,26.5,14.5,35.7c8.4,10.8,19.5,16.2,32.9,16.2h236.6\r\n                                        c7.6,0,14.1-5.8,14.4-13.4c0.4-8-6-14.6-14-14.6H189h-0.1c-2,0-4.9,0-8.3-2.8c-3.5-3-8.3-9.9-11.5-26l-4.3-23.7\r\n                                        c0-0.3,0.1-0.5,0.4-0.6l277.7-47c2.6-0.4,4.6-2.5,4.9-5.2l16-115.8C464,134,464,133.1,463.8,132.2z"/need_replaceyou\r\n                                need_replacezuo/gneed_replaceyou\r\n                            need_replacezuo/svgneed_replaceyou', 0, 1),
(10001, '系统模块', 'SystemModel', ' need_replacezuosvg class="nav-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"need_replaceyou\r\n                        need_replacezuopath d="M70.7 164.5l169.2 81.7c4.4 2.1 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c8.9-4.3 8.9-11.3 0-15.6L272.1 67.2c-4.4-2.1-10.3-3.2-16.1-3.2s-11.7 1.1-16.1 3.2L70.7 148.9c-8.9 4.3-8.9 11.3 0 15.6z"/need_replaceyou\r\n                        need_replacezuopath class="svg-primary"\r\n                              d="M441.3 248.2s-30.9-14.9-35-16.9-5.2-1.9-9.5.1S272 291.6 272 291.6c-4.5 2.1-10.3 3.2-16.1 3.2s-11.7-1.1-16.1-3.2c0 0-117.3-56.6-122.8-59.3-6-2.9-7.7-2.9-13.1-.3l-33.4 16.1c-8.9 4.3-8.9 11.3 0 15.6l169.2 81.7c4.4 2.1 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c9.1-4.2 9.1-11.2.2-15.5z"/need_replaceyou\r\n                        need_replacezuopath d="M441.3 347.5s-30.9-14.9-35-16.9-5.2-1.9-9.5.1S272.1 391 272.1 391c-4.5 2.1-10.3 3.2-16.1 3.2s-11.7-1.1-16.1-3.2c0 0-117.3-56.6-122.8-59.3-6-2.9-7.7-2.9-13.1-.3l-33.4 16.1c-8.9 4.3-8.9 11.3 0 15.6l169.2 81.7c4.4 2.2 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c9-4.3 9-11.3.1-15.6z"/need_replaceyou\r\n                    need_replacezuo/svgneed_replaceyou', 0, 1),
(10002, '日志模块', 'LogModel', ' need_replacezuosvg class="nav-svg" version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg"\r\n                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\r\n                         viewBox="0 0 512 512" style="enable-background:new 0 0 512 512need_replace" xml:space="preserve"need_replaceyou\r\n                                need_replacezuogneed_replaceyou\r\n                                    need_replacezuogneed_replaceyou\r\n                                        need_replacezuopath d="M276,68.1v219c0,3.7-2.5,6.8-6,7.7L81.1,343.4c-2.3,0.6-3.6,3.1-2.7,5.4C109.1,426,184.9,480.6,273.2,480\r\n                                            C387.8,479.3,480,386.5,480,272c0-112.1-88.6-203.5-199.8-207.8C277.9,64.1,276,65.9,276,68.1z"/need_replaceyou\r\n                                    need_replacezuo/gneed_replaceyou\r\n                                    need_replacezuopath class="svg-primary" d="M32,239.3c0,0,0.2,48.8,15.2,81.1c0.8,1.8,2.8,2.7,4.6,2.2l193.8-49.7c3.5-0.9,6.4-4.6,6.4-8.2V36c0-2.2-1.8-4-4-4\r\n                                        C91,33.9,32,149,32,239.3z"/need_replaceyou\r\n                                need_replacezuo/gneed_replaceyou\r\n                            need_replacezuo/svgneed_replaceyou', 0, 1),
(10000, '管理模块', 'ManageModel', ' need_replacezuosvg class="nav-svg" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"\n                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\n                         viewBox="0 0 512 512" style="enable-background:new 0 0 512 512need_replace" xml:space="preserve"need_replaceyou\n                                   need_replacezuogneed_replaceyou\n                                       need_replacezuopath d="M184,448h48c4.4,0,8-3.6,8-8V72c0-4.4-3.6-8-8-8h-48c-4.4,0-8,3.6-8,8v368C176,444.4,179.6,448,184,448z"/need_replaceyou\n                                       need_replacezuopath class="svg-primary"\n                                             d="M88,448H136c4.4,0,8-3.6,8-8V296c0-4.4-3.6-8-8-8H88c-4.4,0-8,3.6-8,8V440C80,444.4,83.6,448,88,448z"/need_replaceyou\n                                       need_replacezuopath class="svg-primary" d="M280.1,448h47.8c4.5,0,8.1-3.6,8.1-8.1V232.1c0-4.5-3.6-8.1-8.1-8.1h-47.8c-4.5,0-8.1,3.6-8.1,8.1v207.8\n                                           C272,444.4,275.6,448,280.1,448z"/need_replaceyou\n                                       need_replacezuopath d="M368,136.1v303.8c0,4.5,3.6,8.1,8.1,8.1h47.8c4.5,0,8.1-3.6,8.1-8.1V136.1c0-4.5-3.6-8.1-8.1-8.1h-47.8\n                                           C371.6,128,368,131.6,368,136.1z"/need_replaceyou\n                                   need_replacezuo/gneed_replaceyou\n                               need_replacezuo/svgneed_replaceyou', 0, 1),
(10014, '网站设置', 'siteSet.php', 'dripicons-graph-pie', 10001, 1),
(10015, '邮箱设置', 'emailSet.php', 'dripicons-mail', 10001, 1),
(10016, '支付设置', 'paySet.php', 'dripicons-battery-full', 10001, 1),
(10017, '系统优化', 'sysInit.php', 'dripicons-rocket', 10001, 1),
(10018, '操作记录', 'log.php', 'dripicons-duplicate', 10002, 1),
(10019, '消费记录', 'charge.php', 'dripicons-folder-open', 10002, 1),
(10020, '模板商城', 'store.php', 'dripicons-cart', 10003, 1),
(10021, '系统更新', 'update.php', 'dripicons-cloud-download', 10003, 1),
(10022, '一键建站', 'addDemo.php', 'dripicons-direction', 10004, 1);

-- --------------------------------------------------------

--
-- 表的结构 `wcms_news`
--

CREATE TABLE IF NOT EXISTS `wcms_news` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL COMMENT '发布人id',
  `type` int(11) DEFAULT '0' COMMENT '文章类型',
  `date` datetime NOT NULL COMMENT '发布时间',
  `title` text DEFAULT NULL COMMENT '新闻标题',
  `content` text DEFAULT NULL COMMENT '新闻内容'
) DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `wcms_news`
--

INSERT INTO `wcms_news` (`id`, `uid`, `date`, `title`, `content`) VALUES
(10000, 10000, '2020-1-1 23:25:00', '宝塔建站系统上线啦', '宝塔建站系统上线啦,网站正式运营中');

-- --------------------------------------------------------

--
-- 表的结构 `wcms_order`
--

CREATE TABLE IF NOT EXISTS `wcms_order` (
  `oid` int(11) NOT NULL,
  `order_no` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `uid` int(11) NOT NULL,
  `money` varchar(32) NOT NULL,
  `date` datetime NOT NULL,
  `type` varchar(20) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `wcms_plugin`
--

CREATE TABLE IF NOT EXISTS `wcms_plugin` (
  `pid` int(11) NOT NULL,
  `pcode` varchar(64) NOT NULL COMMENT '模板唯一编码'
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `wcms_program`
--

CREATE TABLE IF NOT EXISTS `wcms_program` (
  `pid` int(11) NOT NULL,
  `name` varchar(64) NOT NULL COMMENT '程序名称',
  `price` decimal(10,2) NOT NULL DEFAULT '500.00' COMMENT '程序价格',
  `reprice` decimal(10,2) NOT NULL DEFAULT '300.00' COMMENT '续费价格',
  `path` varchar(255) NOT NULL COMMENT '项目源地址',
  `img` varchar(255) DEFAULT NULL COMMENT '项目缩略图',
  `install` varchar(64) NOT NULL COMMENT '安装标识',
  `usetime` int(11) NOT NULL DEFAULT '12' COMMENT '使用时间',
  `decription` text DEFAULT NULL COMMENT '程序描述',
  `demo` varchar(64) DEFAULT NULL COMMENT '程序演示地址',
  `code` varchar(32) NOT NULL COMMENT '程序唯一编码',
  `phpversion` varchar(180) DEFAULT '56',
  `discount` int(1) NOT NULL DEFAULT '1',
  `isrewrite` int(2) NOT NULL DEFAULT '0' COMMENT '是否开启伪静态',
  `rewrite` text NOT NULL COMMENT '伪静态内容',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1:出售中，0:下架'
) DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `wcms_program`
--
INSERT INTO `wcms_program` (`pid`, `name`, `price`, `reprice`, `path`, `img`, `install`, `usetime`, `decription`, `demo`, `code`, `phpversion`, `discount`, `isrewrite`, `rewrite`, `status`) VALUES
(10001, '发卡网[修复版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'fakawang', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'O01NC03t9Tec0lEE', '56', 1, 0, '', 1),
(10002, '彩虹ds[免授权]', '100.00', '10.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'daishua', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'P0eDAVdp3tGztL4E', '56', 1, 0, '', 1),
(10003, '博客网[最新版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'emlog', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'fEAYEZG7AsfO0Tfa', '56', 1, 0, '', 1),
(10004, '易支付[修复版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'epay', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'ESZriieN1sP1XKmM', '56', 1, 0, '', 1),
(10005, '个人导航网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'gerendaohang', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'L8EY8VALtE9ZTQOO', '56', 1, 0, '', 1),
(10006, '代理查询', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'dailichaxun', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'PFP1P5qBrZQZzszO', '56', 1, 0, '', 1),
(10007, '导航网[流行版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'daohang', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '5VsLhx7PZXlVgGZg', '56', 1, 0, '', 1),
(10008, '加密系统[修复版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'jiami', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'nHVX3XvOrai3CS3I', '56', 1, 0, '', 1),
(10009, '授权系统', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'shouquan', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'BXmuCkw87m3bpHdB', '56', 1, 0, '', 1),
(10010, '留言网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'liuyan', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'QFLPKLToofUfamTF', '56', 1, 0, '', 1),
(10011, '匿言网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'niyan', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '8fXF00308o2YuyuK', '56', 1, 0, '', 1),
(10012, '抽奖网[稳定版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'choujiang', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'BM7lpodpMd7anBNr', '56', 1, 0, '', 1),
(10013, 'laysns[火热版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'laysns', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '7sCqEmNsGaSl9LEs', '56', 1, 0, '', 1),
(10014, '修罗论坛', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'xiunobbs', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'W2y9Gg1r1ph3Ws77', '56', 1, 0, '', 1),
(10015, '要饭网[最新版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'yaofan', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'Gg2qreESqQuegqnU', '56', 1, 0, '', 1),
(10016, '源码站', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'yuanmazhan', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'HT5oOuHxxOMoO56X', '56', 1, 0, '', 1),
(10017, 'zblog博客', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'zblog', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '0DIj0jJjVJTfh076', '56', 1, 0, '', 1),
(10018, '织梦CMS', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'zmcms', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'FHIfkiT5IuIKcpX6', '56', 1, 0, '', 1),
(10019, '个人官网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'gerenguanwang', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '9kM8t6D9bs8TmSWY', '56', 1, 0, '', 1),
(10020, '教程网[流行版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'jiaochengwang', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'lriIsRLoZPcLSin2', '56', 1, 0, '', 1),
(10021, '流量卡官网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'liuliangka', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'rlOeqe08Q7q47HDn', '56', 1, 0, '', 1),
(10022, '企业官网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'qiyedou', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '0IXzsV4iXhIBx400', '56', 1, 0, '', 1),
(10023, '图床网[最新版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'tuchuang', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '9kJjwl99nJO1ZWvl', '56', 1, 0, '', 1),
(10024, 'typecho[清爽版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'typecho', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'tGzrmSw9fqFyiqYf', '56', 1, 0, '', 1),
(10025, '淘宝客', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'taoke', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'qbNgSYb7n55Bn7qN', '56', 1, 0, '', 1),
(10026, '表白墙[流行版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'bb', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'qha00OjMj0m9aOLq', '56', 1, 0, '', 1),
(10027, '表情包网', '100.00', '120.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'biaoqing', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'sSyNV8y2Ys80nrzi', '56', 1, 0, '', 1),
(10028, '黑名单网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'blacklist', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '88619J8j9R669d66', '56', 1, 0, '', 1),
(10029, 'dz论坛', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'dzluntan', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'l1NdWN2WH7wE01HE', '56', 1, 0, '', 1),
(10030, '二级域名分发平台', '200.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'fenfa', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'Hg8m2YZMwTqe6kvk', '72', 0, 1, 'location / {\n	if (!-e $request_filename){\n		rewrite  ^(.*)$  /index.php?s=$1  last need_replace   break need_replace \n	}\n}', 1),
(10031, 'idc网站', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'idc', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', '6kXxMx33XXxkxxk6', '56', 1, 0, '', 1),
(10032, '搜索网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'sousuo', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'Qq1b2NNZhnz72NvA', '56', 1, 0, '', 1),
(10033, '同学录[修复版]', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'ssnhtxl', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'KK24IZ680fl4i66W', '56', 1, 0, '', 1),
(10034, '选号网', '100.00', '100.00', 'https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram', 'https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg', 'xuanhao', 12, '<li>简单.</li><li>高效.</li><li>安全.</li>', 'www.w-cms.cn', 'pnZaNBlHhhHIhP8B', '56', 1, 0, '', 1);

-- --------------------------------------------------------


-- --------------------------------------------------------

--
-- 表的结构 `wcms_server`
--

CREATE TABLE IF NOT EXISTS `wcms_server` (
  `sid` int(11) NOT NULL,
  `sname` varchar(64) NOT NULL COMMENT '服务器名称',
  `api` varchar(255) NOT NULL COMMENT '宝塔面板管理地址',
  `pass` varchar(255) NOT NULL COMMENT '宝塔api密钥',
  `domain` varchar(64) NOT NULL COMMENT '默认泛绑定域名',
  `active` int(2) NOT NULL DEFAULT '1' COMMENT '服务器状态，0:关闭1:开启',
  `sitepath` varchar(64) DEFAULT '/www/wwwroot/'
) DEFAULT CHARSET=utf8;



-- --------------------------------------------------------

--
-- 表的结构 `wcms_site`
--

CREATE TABLE IF NOT EXISTS `wcms_site` (
  `sid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `serverid` int(11) NOT NULL,
  `domain` varchar(64) NOT NULL COMMENT '网站域名',
  `userdomain` varchar(255) DEFAULT NULL COMMENT '客户自定义域名',
  `sqlname` varchar(32) DEFAULT NULL,
  `sqlpass` varchar(32) DEFAULT NULL,
  `code` varchar(32) NOT NULL COMMENT '程序唯一编码',
  `addtime` datetime NOT NULL COMMENT '搭建时间',
  `endtime` datetime NOT NULL COMMENT '到期时间',
  `isinstall` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '站点状态'
) DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- 表的结构 `wcms_user`
--

CREATE TABLE IF NOT EXISTS `wcms_user` (
  `uid` int(11) NOT NULL,
  `username` varchar(64) NOT NULL COMMENT '用户名',
  `password` varchar(64) NOT NULL COMMENT '密码',
  `email` varchar(32) DEFAULT NULL,
  `sid` varchar(64) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `nickname` varchar(255) NOT NULL DEFAULT '网友' COMMENT '用户昵称',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `regtime` datetime NOT NULL COMMENT '注册时间',
  `regip` text COMMENT '注册ip',
  `regcity` text COMMENT '注册城市',
  `mcode` int(11) NOT NULL DEFAULT '100' COMMENT '身份标识',
  `status` varchar(32) NOT NULL DEFAULT '1' COMMENT '用户状态'
)DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `wcms_user`
--

INSERT INTO `wcms_user` (`uid`, `username`, `password`, `email`, `sid`, `phone`, `nickname`, `money`, `regtime`, `regip`, `regcity`, `mcode`, `status`) VALUES
(10000, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '79517721@qq.com', '', '17888888888', '夸克', '10000.00', '2020-01-01 20:58:12', '127.0.0', '北京', 10000, '1');


--
-- Indexes for dumped tables
--

--
-- Indexes for table `wcms_conf`
--
ALTER TABLE `wcms_conf`
  ADD PRIMARY KEY (`k`);

--
-- Indexes for table `wcms_log`
--
ALTER TABLE `wcms_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wcms_member`
--
ALTER TABLE `wcms_member`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `wcms_menu`
--
ALTER TABLE `wcms_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wcms_menu2`
--
ALTER TABLE `wcms_menu2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wcms_news`
--
ALTER TABLE `wcms_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wcms_order`
--
ALTER TABLE `wcms_order`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `wcms_plugin`
--
ALTER TABLE `wcms_plugin`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `wcms_program`
--
ALTER TABLE `wcms_program`
  ADD PRIMARY KEY (`pid`);


--
-- Indexes for table `wcms_server`
--
ALTER TABLE `wcms_server`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `wcms_site`
--
ALTER TABLE `wcms_site`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `wcms_user`
--
ALTER TABLE `wcms_user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wcms_log`
--
ALTER TABLE `wcms_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10000;
--
-- AUTO_INCREMENT for table `wcms_member`
--
ALTER TABLE `wcms_member`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10010;
--
-- AUTO_INCREMENT for table `wcms_news`
--
ALTER TABLE `wcms_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10001;
--
-- AUTO_INCREMENT for table `wcms_order`
--
ALTER TABLE `wcms_order`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10000;
--
-- AUTO_INCREMENT for table `wcms_plugin`
--
ALTER TABLE `wcms_plugin`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10000;
--
-- AUTO_INCREMENT for table `wcms_program`
--
ALTER TABLE `wcms_program`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10026;

--
-- AUTO_INCREMENT for table `wcms_server`
--
ALTER TABLE `wcms_server`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10000;
--
-- AUTO_INCREMENT for table `wcms_site`
--
ALTER TABLE `wcms_site`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10000;
--
-- AUTO_INCREMENT for table `wcms_user`
--
ALTER TABLE `wcms_user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10001;


--
-- AUTO_INCREMENT for table `wcms_menu`
--
ALTER TABLE `wcms_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10018;
--
-- AUTO_INCREMENT for table `wcms_menu2`
--
ALTER TABLE `wcms_menu2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10024;
  
-- wcms_conf QQ跳转/push 状态及 价格
INSERT INTO `wcms_conf` VALUES ('qqjump', '0');
INSERT INTO `wcms_conf` VALUES ('push_toll', '1');
INSERT INTO `wcms_conf` VALUES ('push_price', 20);
-- 卡密表
CREATE TABLE `wcms_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card` varchar(255) NOT NULL COMMENT '卡密',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `addtime` datetime DEFAULT NULL COMMENT '生成时间',
  `endtime` datetime DEFAULT NULL COMMENT '使用时间',
  `uid` int(10) DEFAULT NULL COMMENT '使用者编号',
  `active` int(11) DEFAULT '0' COMMENT '状态 0:未使用 1:已使用',
  `type` int(11) DEFAULT '0' COMMENT '卡密类型 0: 充值卡密',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- demo表
CREATE TABLE `wcms_demo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) NOT NULL COMMENT '域名',
  `code` varchar(255) NOT NULL COMMENT '项目编码',
  `date` datetime NOT NULL COMMENT '任务创建时间',
  `status` int(11) DEFAULT '0' COMMENT '状态',
  `type` varchar(255) NOT NULL COMMENT '详情',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- 工单表
CREATE TABLE `wcms_workorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL COMMENT '工单编码',
  `num` varchar(255) NOT NULL COMMENT '时间戳',
  `uid` int(11) NOT NULL COMMENT '用户编号',
  `user` varchar(255) NOT NULL COMMENT '用户名',
  `title` varchar(255) NOT NULL COMMENT '工单标题',
  `content` varchar(255) NOT NULL COMMENT '工单内容',
  `date` datetime NOT NULL COMMENT '发起时间',
  `userreply` datetime NOT NULL COMMENT '用户回复时间',
  `adminreply` datetime NOT NULL DEFAULT '0001-01-01 00:00:00' COMMENT '管理员回复时间',
  `state` int(2) NOT NULL DEFAULT '0' COMMENT '工单状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

-- 新增菜单 前后台工单 前后台卡密 网站push 后台菜单设置 网站图标
INSERT INTO `wcms_menu2` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('菜单设置','menu.php','fab fa-envira','10001','1'),
('工单记录','workOrder.php','fas fa-comment','10002','1'),
('卡密列表','cardPay.php','fab fa-cc-visa','10004','1'),
(' 网站图标','icons.php','fab fa-accusoft','10004','1');

INSERT INTO `wcms_menu` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('在线工单','workOrder.php','fas fa-comment','10000','1'),
('网站push','push.php','fab fa-slideshare','10002','1'),
('卡密支付','cardPay.php','fab fa-cc-visa','10003','1');

-- wcms_conf 网站流量访问统计
INSERT INTO `wcms_conf` VALUES ('access_tongji', '');

-- 新增菜单 后台菜单
INSERT INTO `wcms_menu2` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('指导手册','doc.php','fab fa-hire-a-helper','10003','1');
INSERT INTO `wcms_menu2` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('项目分类','programType.php','typcn typcn-sort-alphabetically','10000','1');
-- 创建wcms_protype表 id name

CREATE TABLE `wcms_protype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;
INSERT INTO `wcms_protype` (`id`, `name`)VALUES('10000','默认分类');
-- wcms_program 添加 tid字段 默认为 10000
ALTER TABLE wcms_program ADD COLUMN tid int(11) DEFAULT '10000' COMMENT '项目分类';

-- 指定服务器功能  操作项目表
ALTER TABLE wcms_program ADD COLUMN specifys_server int(1) DEFAULT '0' COMMENT '是否指定服务器';
ALTER TABLE wcms_program ADD COLUMN sid int(11) DEFAULT '10000' COMMENT '服务器编号';
-- 小微支付
INSERT INTO `wcms_conf` VALUES ('micropay_api', '');
INSERT INTO `wcms_conf` VALUES ('micropay_pid', '');
INSERT INTO `wcms_conf` VALUES ('micropay_key', '');
INSERT INTO `wcms_conf` VALUES ('micropay_mchid', '');

-- API接口账号 密钥
INSERT INTO `wcms_conf` VALUES ('api_status', '0');
INSERT INTO `wcms_conf` VALUES ('api_user', '');
INSERT INTO `wcms_conf` VALUES ('api_key', '');
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
