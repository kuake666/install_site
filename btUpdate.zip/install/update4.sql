-- wcms_conf 网站流量访问统计
INSERT INTO `wcms_conf` VALUES ('access_tongji', '');

-- 新增菜单 后台菜单
INSERT INTO `wcms_menu2` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('指导手册','doc.php','fab fa-hire-a-helper','10003','1');
INSERT INTO `wcms_menu2` (`menuname`, `menupath`, `menuicon`, `parentid`, `status`)
VALUES('项目分类','programType.php','typcn typcn-sort-alphabetically','10000','1');
-- 创建wcms_protype表 id name

CREATE TABLE `wcms_protype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;
INSERT INTO `wcms_protype` (`id`, `name`)VALUES('10000','默认分类');
-- wcms_program 添加 tid字段 默认为 10000
ALTER TABLE wcms_program ADD COLUMN tid int(11) DEFAULT '10000' COMMENT '项目分类';