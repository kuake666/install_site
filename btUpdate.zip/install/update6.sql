-- 替换项目源地址 项目自带图片
UPDATE `wcms_program` SET `path`='https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram' WHERE `path`='http://file.w-cms.cn/down/24622176/baotaProgram/oldProgram';
UPDATE `wcms_program` SET `path`='https://kuake.coding.net/p/baota_programs/d/baota_programs/git/raw/master/oldProgram' WHERE `path`='https://code.aliyun.com/kuake/baota_programs/raw/master/oldProgram';
UPDATE `wcms_program` SET `img`='https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/wcms.jpg' WHERE `img`='https://dev.tencent.com/u/kuakeyun/p/wcms/git/raw/master/oldProgram/wcms.jpg';
