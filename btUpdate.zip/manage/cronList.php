<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
$cronList = array(
    '网站到期提醒'=>'/api/cron.php?type=endSiteEmail&key=',
    '到期7天自动删除网站'=>'/api/cron.php?type=delEndSite&key=',
    '一键搭建网站'=>'/api/cron.php?type=addDemo&key='
);

?>

<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">更多功能</a></li>
                            <li class="breadcrumb-item active">监控列表</li>
                        </ol>
                    </div>
                    <h4 class="page-title">更多功能</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">监控列表</h4>
                        <div class="float-right">
                            <button href="javascript:void(0);" class="btn btn-sm btn-success" onclick="cronInfo()">使用说明
                            </button>
                        </div>
                        <p class="text-muted mb-4 font-13">
                            网站监控任务
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>监控名称</th>
                                <th nowrap>监控地址</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://').$_SERVER['HTTP_HOST'];
                            foreach($cronList as $key => $value){
                                ?>
                                <tr>
                                    <td><?php echo $key;?></td>
                                    <td><?php echo $siteurl.$value.$conf['site_key'];?></td>
                                    <td nowrap>
                                        <a href="javascript:void(0);" id="<?php echo $key;?>" data-clipboard-text="<?php echo $siteurl.$value.$conf['site_key'];?>" onclick="copyUrl(<?php echo "'".$key."'";?>)" class="btn m-b-xs btn-sm btn-primary btn-addon app-download-btn" >复制地址</a>
                                    </td>
                                </tr>
                            <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->


    </div><!-- container -->
    <?php
    include('footer.php');
    ?>
    <script src="../assets/js/clipboard.min.js"></script>
    <script>

        function copyUrl(key){
            new ClipboardJS("#"+key);
            layer.msg("复制成功",{time:800,icon:6});
        }

        function cronInfo() {
            layer.open({
                type: 1
                ,
                title: false //不显示标题栏
                ,
                closeBtn: false
                ,
                area: '300px;'
                ,
                shade: 0.8
                ,
                id: 'LAY_layuipro' //设定一个id，防止重复弹出
                ,
                resize: false
                ,
                btn: ['关闭提示']
                ,
                btnAlign: 'c'
                ,
                moveType: 1 //拖拽模式，0或者1
                ,
                content: "<div style='padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;'> 温馨提示：<br/>1、本功能将系统中所有监控任务统计在一起，方便使用。<br/>" +
                    "2、一键搭建网站:注意事项请看一键站菜单页面<br/>3、到期7天自动删除网站:请在系统模块->邮箱设置中配置好邮箱信息,网站删除时会进行邮件提示,建议设置监控时间为24小时<br/>4、网站到期提醒:请在系统模块->邮箱设置中配置好邮箱信息,网站离到期还有7天时每天会进行邮箱提示,建议设置监控时间为24小时<br/><br/>复制监控地址到宝塔面板计划任务中,任务类型选择url,或者使用阿里云监控、百度云监控等也是可以的</div>"
                ,
                success: function (layero) {
                    var btn = layero.find('.layui-layer-btn');
                    btn.find('.layui-layer-btn0').attr({
                        //href: data.url
                    });
                }
            });
        }
    </script>
