<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

//文章列表
$numrows = $DB->query("SELECT * from `wcms_news` ")->rowCount();
$list = $DB->query("SELECT * FROM `wcms_news` ")->fetchAll();
//添加、修改文章列表
$id = intval(daddslashes($_GET['id']));
$type = daddslashes($_GET['type']);

if ($type == 'edit' && $id) {
    $row = $DB->query("SELECT * from `wcms_news` WHERE `id`={$id} limit 1")->fetch();
    $title = '修改文章';
    $result = 1; //修改文章
} else if ($type == 'add') {
    $title = '添加文章';
    $result = 2; //添加文章
} else {
    $result = 3; //文章列表
}
?>

<?php if ($result == 3){ ?>
<!-- Page Content-->
<div class="page-content">

    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">文章列表</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">文章列表</h4>
                        <div class="float-right">
                            <a href="?type=add" class="btn m-b-xs btn-sm btn-success btn-addon">
                                <i class="typcn typcn-th-large-outline "></i> 添加文章
                            </a>
                        </div>
                        <p class="text-muted mb-4 font-13">
                            系统共有 <code><?php echo $numrows?></code> 篇文章
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>文章编号</th>
                                <th>文章标题</th>
                                <th>文章内容</th>
                                <th>文章类型</th>
                                <th>发布时间</th>
                                <th>发布人</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $res) {
                                $title = mb_substr($res['title'], 0, 6, 'utf-8');
                                $newTitle = $title . "...";
                                $content = mb_substr($res['content'], 0, 5, 'utf-8');
                                $newContent = $content . "...";
                                if ($res['type'] == 0) {
                                    $res['type'] = '通知';
                                } else {
                                    $res['type'] = '新闻';
                                }
                                echo '
                                    <tr id="' . $res['id'] . '">
                                        <td>' . $res['id'] . '</td>
                                        <td>' . $newTitle . '</td>
                                        <td>' . $newContent . '</td>
                                        <td>' . $res['type'] . '</td>
                                        <td>' . $res['date'] . '</td>
                                        <td>' . $res['uid'] . '</td>
                                        <td>
                                          <a href="article.php?type=edit&id=' . $res['id'] . '" class="btn m-b-xs btn-sm btn-primary btn-addon" >修改</a>
                                          <a href="javascript:void(0);" onclick="delArticle(' . $res['id'] . ')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</a>
                                        </td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php } else if ($result == 2){ ?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                <li class="breadcrumb-item active"><?php echo $title ?></li>
                            </ol>
                        </div>
                        <h4 class="page-title">文章添加</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                            <p class="text-muted mb-3">addArticle.
                            </p>
                            <form action="#" method="post">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">文章标题</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="title">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">文章内容</label>
                                            <div class="col-sm-10">
                                                <textarea class="form-control" rows="5" name="content"></textarea>
                                                <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">文章分类</label>
                                            <div class="col-sm-10">
                                                <select name="type" class="custom-select">
                                                    <option value="0">通知</option>
                                                    <option value="1">新闻</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end card-body-->
                                <div class="row">
                                    <div class="col-sm-10 ml-auto">
                                        <button type="button" class="btn btn-primary" id="addArticle">保存数据</button>
                                    </div>
                                </div>
                            </form>
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end row-->
        </div><!-- container -->
        <?php } else if ($result == 1){ ?>
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="float-right">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                    <li class="breadcrumb-item active"><?php echo $title ?></li>
                                </ol>
                            </div>
                            <h4 class="page-title">管理模块</h4>
                        </div><!--end page-title-box-->
                    </div><!--end col-->
                </div>
                <!-- end page title end breadcrumb -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                                <p class="text-muted mb-3">articleEdit.
                                </p>
                                <form action="#" method="post">
                                    <input class="form-control" type="hidden" name="id"
                                           value="<?php echo $row['id'] ?>">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">文章标题</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="title"
                                                           value="<?php echo $row['title'] ?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">文章内容</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" rows="5"
                                                              name="content"><?php echo $row['content'] ?></textarea>
                                                    <code>支持html代码,可使用 <a href="http://ueditor.baidu.com/website/onlinedemo.html" target="_blank">百度在线编辑器</a></code>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">文章分类</label>
                                                <div class="col-sm-10">
                                                    <select name="type" class="custom-select">
                                                        <?php if ($row['type'] == 0) { ?>
                                                            <option value="0">通知</option>
                                                            <option value="1">新闻</option>
                                                        <?php } else { ?>
                                                            <option value="1">新闻</option>
                                                            <option value="0">通知</option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!--end card-body-->
                                    <div class="row">
                                        <div class="col-sm-10 ml-auto">
                                            <button type="button" class="btn btn-primary" id="editArticle">保存数据</button>
                                        </div>
                                    </div>
                                </form>
                            </div><!--end card-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end row-->
            </div><!-- container -->
            <?php } ?>

            <?php
            include('footer.php');
            ?>
            <script>
                function delArticle(id) {
                    layer.confirm('确认删除 ' + id + ' 吗?', {
                        btn: ['是', '否'], btn1: function () {
                            var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
                            $.ajax({
                                url: 'ajax.php?act=delArticle',
                                type: 'POST',
                                dataType: 'json',
                                data: {id: id},
                                success: function (data) {
                                    layer.close(ii);
                                    if (data.code == 1) {
                                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                            var del="#"+id;
                                            $(del).remove();
                                        });
                                    } else {
                                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                                    }
                                },
                                error: function () {
                                    layer.close(ii);
                                    layer.alert("网络连接错误");
                                }
                            });
                        }
                    });
                }

                $("#editArticle").click(function () {
                    var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
                    $.ajax({
                        url: 'ajax.php?act=editArticle',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            id: $("input[name='id']").val(),
                            title: $("input[name='title']").val(),
                            content: $("textarea[name='content']").val(),
                            type: $("select[name='type']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.close(ii);
                            layer.alert("网络连接错误");
                        }
                    })
                })


                $("#addArticle").click(function () {
                    var ii = layer.load(0, {shade: false,time: 35000}); //0代表加载的风格，支持0-2
                    $.ajax({
                        url: 'ajax.php?act=addArticle',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            title: $("input[name='title']").val(),
                            content: $("textarea[name='content']").val(),
                            type: $("select[name='type']").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.href = data.url;
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.close(ii);
                            layer.alert("网络连接错误");
                        }
                    })
                })
            </script>
