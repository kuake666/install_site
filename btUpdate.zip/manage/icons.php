<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');
?>

            <!-- Page Content-->
            <div class="page-content">

                <div class="container-fluid">
                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title-box">
                                <div class="float-right">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">更多功能</a></li>
                                        <li class="breadcrumb-item active">网站图标</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">更多功能</h4>
                            </div><!--end page-title-box-->
                        </div><!--end col-->
                    </div>
                    <!-- end page title end breadcrumb -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">

                                    <h4 class="mt-0 header-title">网站图标</h4>
                                    <p class="text-muted mb-4">Use <code>&lt;i class="fa fa-font-awesome"&gt;&lt;/i&gt;</code>.
                                    </p>

                                    <section>
                                        <div class="icon-demo-content row">
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-500px"></i> fab fa-500px
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-accessible-icon"></i> fab fa-accessible-icon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-accusoft"></i> fab fa-accusoft
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-address-book"></i> fas fa-address-book
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-address-book"></i> far fa-address-book
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-adjust"></i> fas fa-adjust
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-adn"></i> fab fa-adn
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-adversal"></i> fab fa-adversal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-affiliatetheme"></i> fab fa-affiliatetheme
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-algolia"></i> fab fa-algolia
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-align-center"></i> fas fa-align-center
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-align-justify"></i> fas fa-align-justify
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-align-left"></i> fas fa-align-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-align-right"></i> fas fa-align-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-allergies"></i> fas fa-allergies
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-amazon"></i> fab fa-amazon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-amazon-pay"></i> fab fa-amazon-pay
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ambulance"></i> fas fa-ambulance
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-american-sign-language-interpreting"></i> fas fa-american-sign-language-interpreting
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-amilia"></i> fab fa-amilia
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-anchor"></i> fas fa-anchor
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-android"></i> fab fa-android
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-angellist"></i> fab fa-angellist
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-angle-double-down"></i> fas fa-angle-double-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-angle-double-left"></i> fas fa-angle-double-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-angle-double-right"></i> fas fa-angle-double-righ
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-angle-double-up"></i> fas fa-angle-double-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-angle-down"></i> fas fa-angle-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-angle-left"></i> fas fa-angle-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-angle-right"></i> fas fa-angle-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-angle-up"></i> fas fa-angle-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-angrycreative"></i> fab fa-angrycreative
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-angular"></i> fab fa-angular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-app-store"></i> fab fa-app-store
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-app-store-ios"></i> fab fa-app-store-ios
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-apper"></i> fab fa-apper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-apple"></i> fab fa-apple
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-apple-pay"></i> fab fa-apple-pay
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-archive"></i> fas fa-archive
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-alt-circle-down"></i> fas fa-arrow-alt-circle-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-arrow-alt-circle-down"></i> far fa-arrow-alt-circle-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-alt-circle-left"></i> fas fa-arrow-alt-circle-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-arrow-alt-circle-left"></i> far fa-arrow-alt-circle-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-alt-circle-right"></i> fas fa-arrow-alt-circle-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-arrow-alt-circle-right"></i> far fa-arrow-alt-circle-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-alt-circle-up"></i> fas fa-arrow-alt-circle-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-arrow-alt-circle-up"></i> far fa-arrow-alt-circle-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-circle-down"></i> fas fa-arrow-circle-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-circle-left"></i> fas fa-arrow-circle-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-circle-right"></i> fas fa-arrow-circle-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-circle-up"></i> fas fa-arrow-circle-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-down"></i> fas fa-arrow-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-left"></i> fas fa-arrow-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-right"></i> fas fa-arrow-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrow-up"></i> fas fa-arrow-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrows-alt"></i> fas fa-arrows-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrows-alt-h"></i> fas fa-arrows-alt-h
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-arrows-alt-v"></i> fas fa-arrows-alt-v
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-assistive-listening-systems"></i> fas fa-assistive-listening-systems
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-asterisk"></i> fas fa-asterisk
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-asymmetrik"></i> fab fa-asymmetrik
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-at"></i> fas fa-at
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-audible"></i> fab fa-audible
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-audio-description"></i> fas fa-audio-description
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-autoprefixer"></i> fab fa-autoprefixer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-avianex"></i> fab fa-avianex
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-aviato"></i> fab fa-aviato
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-aws"></i> fab fa-aws
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-backward"></i> fas fa-backward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-balance-scale"></i> fas fa-balance-scale
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ban"></i> fas fa-ban
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-band-aid"></i> fas fa-band-aid
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-bandcamp"></i> fab fa-bandcamp
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-barcode"></i> fas fa-barcode
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bars"></i> fas fa-bars
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-baseball-ball"></i> fas fa-baseball-ball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-basketball-ball"></i> fas fa-basketball-ball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bath"></i> fas fa-bath
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-battery-empty"></i> fas fa-battery-empty
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-battery-full"></i> fas fa-battery-full
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-battery-half"></i> fas fa-battery-half
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-battery-quarter"></i> fas fa-battery-quarter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-battery-three-quarters"></i> fas fa-battery-three-quarters
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bed"></i> fas fa-bed
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-beer"></i> fas fa-beer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-behance"></i> fab fa-behance
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-behance-square"></i> fab fa-behance-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bell"></i> fas fa-bell
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-bell"></i> far fa-bell
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bell-slash"></i> fas fa-bell-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-bell-slash"></i> far fa-bell-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bicycle"></i> fas fa-bicycle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-bimobject"></i> fab fa-bimobject
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-binoculars"></i> fas fa-binoculars
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-birthday-cake"></i> fas fa-birthday-cake
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-bitbucket"></i> fab fa-bitbucket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-bitcoin"></i> fab fa-bitcoin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-bity"></i> fab fa-bity
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-black-tie"></i> fab fa-black-tie
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-blackberry"></i> fab fa-blackberry
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-blender"></i> fas fa-blender
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-blind"></i> fas fa-blind
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-blogger"></i> fab fa-blogger
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-blogger-b"></i> fab fa-blogger-b
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-bluetooth"></i> fab fa-bluetooth
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-bluetooth-b"></i> fab fa-bluetooth-b
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bold"></i> fas fa-bold
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bolt"></i> fas fa-bolt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bomb"></i> fas fa-bomb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-book"></i> fas fa-book
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-book-open"></i> fas fa-book-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bookmark"></i> fas fa-bookmark
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-bookmark"></i> far fa-bookmark
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bowling-ball"></i> fas fa-bowling-ball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-box"></i> fas fa-box
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-box-open"></i> fas fa-box-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-boxes"></i> fas fa-boxes
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-braille"></i> fas fa-braille
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-briefcase"></i> fas fa-briefcase
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-briefcase-medical"></i> fas fa-briefcase-medical
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-broadcast-tower"></i> fas fa-broadcast-tower
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-broom"></i> fas fa-broom
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-btc"></i> fab fa-btc
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bug"></i> fas fa-bug
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-building"></i> fas fa-building
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-building"></i> far fa-building
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bullhorn"></i> fas fa-bullhorn
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bullseye"></i> fas fa-bullseye
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-burn"></i> fas fa-burn
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-buromobelexperte"></i> fab fa-buromobelexperte
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-bus"></i> fas fa-bus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-buysellads"></i> fab fa-buysellads
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-calculator"></i> fas fa-calculator
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-calendar"></i> fas fa-calendar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-calendar"></i> far fa-calendar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-calendar-alt"></i> fas fa-calendar-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-calendar-alt"></i> far fa-calendar-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-calendar-check"></i> fas fa-calendar-check
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-calendar-check"></i> far fa-calendar-check
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-calendar-minus"></i> fas fa-calendar-minus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-calendar-minus"></i> far fa-calendar-minus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-calendar-plus"></i> fas fa-calendar-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-calendar-plus"></i> far fa-calendar-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-calendar-times"></i> fas fa-calendar-times
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-calendar-times"></i> far fa-calendar-times
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-camera"></i> fas fa-camera
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-camera-retro"></i> fas fa-camera-retro
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-capsules"></i> fas fa-capsules
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-car"></i> fas fa-car
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-caret-down"></i> fas fa-caret-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-caret-left"></i> fas fa-caret-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-caret-right"></i> fas fa-caret-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-caret-square-down"></i> fas fa-caret-square-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-caret-square-down"></i> far fa-caret-square-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-caret-square-left"></i> fas fa-caret-square-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-caret-square-left"></i> far fa-caret-square-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-caret-square-right"></i> fas fa-caret-square-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-caret-square-right"></i> far fa-caret-square-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-caret-square-up"></i> fas fa-caret-square-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-caret-square-up"></i> far fa-caret-square-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-caret-up"></i> fas fa-caret-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cart-arrow-down"></i> fas fa-cart-arrow-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cart-plus"></i> fas fa-cart-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-amazon-pay"></i> fab fa-cc-amazon-pay
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-amex"></i> fab fa-cc-amex
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-apple-pay"></i> fab fa-cc-apple-pay
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-diners-club"></i> fab fa-cc-diners-club
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-discover"></i> fab fa-cc-discover
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-jcb"></i> fab fa-cc-jcb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-mastercard"></i> fab fa-cc-mastercard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-paypal"></i> fab fa-cc-paypal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-stripe"></i> fab fa-cc-stripe
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cc-visa"></i> fab fa-cc-visa
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-centercode"></i> fab fa-centercode
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-certificate"></i> fas fa-certificate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chalkboard"></i> fas fa-chalkboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chalkboard-teacher"></i> fas fa-chalkboard-teacher
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chart-area"></i> fas fa-chart-area
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chart-bar"></i> fas fa-chart-bar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-chart-bar"></i> far fa-chart-bar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chart-line"></i> fas fa-chart-line
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chart-pie"></i> fas fa-chart-pie
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-check"></i> fas fa-check
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-check-circle"></i> fas fa-check-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-check-circle"></i> far fa-check-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-check-square"></i> fas fa-check-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-check-square"></i> far fa-check-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chess"></i> fas fa-chess
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chess-bishop"></i> fas fa-chess-bishop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chess-board"></i> fas fa-chess-board
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chess-king"></i> fas fa-chess-king
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chess-knight"></i> fas fa-chess-knight
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chess-pawn"></i> fas fa-chess-pawn
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chess-queen"></i> fas fa-chess-queen
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chess-rook"></i> fas fa-chess-rook
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chevron-circle-down"></i> fas fa-chevron-circle-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chevron-circle-left"></i> fas fa-chevron-circle-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chevron-circle-right"></i> fas fa-chevron-circle-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chevron-circle-up"></i> fas fa-chevron-circle-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chevron-down"></i> fas fa-chevron-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chevron-left"></i> fas fa-chevron-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chevron-right"></i> fas fa-chevron-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-chevron-up"></i> fas fa-chevron-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-child"></i> fas fa-child
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-chrome"></i> fab fa-chrome
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-church"></i> fas fa-church
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-circle"></i> fas fa-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-circle"></i> far fa-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-circle-notch"></i> fas fa-circle-notch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-clipboard"></i> fas fa-clipboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-clipboard"></i> far fa-clipboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-clipboard-check"></i> fas fa-clipboard-check
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-clipboard-list"></i> fas fa-clipboard-list
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-clock"></i> fas fa-clock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-clone"></i> fas fa-clone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-clone"></i> far fa-clone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-closed-captioning"></i> fas fa-closed-captioning
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-closed-captioning"></i> far fa-closed-captioning
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cloud"></i> fas fa-cloud
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cloud-download-alt"></i> fas fa-cloud-download-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cloud-upload-alt"></i> fas fa-cloud-upload-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cloudscale"></i> fab fa-cloudscale
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cloudsmith"></i> fab fa-cloudsmith
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cloudversify"></i> fab fa-cloudversify
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-code"></i> fas fa-code
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-code-branch"></i> fas fa-code-branch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-codepen"></i> fab fa-codepen
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-codiepie"></i> fab fa-codiepie
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-coffee"></i> fas fa-coffee
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cog"></i> fas fa-cog
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cogs"></i> fas fa-cogs
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-coins"></i> fas fa-coins
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-columns"></i> fas fa-columns
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-comment"></i> fas fa-comment
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-comment"></i> far fa-comment
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-comment-alt"></i> fas fa-comment-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-comment-alt"></i> far fa-comment-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-comment-dots"></i> fas fa-comment-dots
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-comment-dots"></i> far fa-comment-dots
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-comment-slash"></i> fas fa-comment-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-comments"></i> fas fa-comments
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-comments"></i> far fa-comments
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-compact-disc"></i> fas fa-compact-disc
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-compass"></i> fas fa-compass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-compass"></i> far fa-compass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-compress"></i> fas fa-compress
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-connectdevelop"></i> fab fa-connectdevelop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-contao"></i> fab fa-contao
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-copy"></i> fas fa-copy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-copy"></i> far fa-copy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-copyright"></i> fas fa-copyright
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-copyright"></i> far fa-copyright
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-couch"></i> fas fa-couch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cpanel"></i> fab fa-cpanel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons"></i> fab fa-creative-commons
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-by"></i> fab fa-creative-commons-by
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-nc"></i> fab fa-creative-commons-nc
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-nc-eu"></i> fab fa-creative-commons-nc-eu
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-nc-jp"></i> fab fa-creative-commons-nc-jp
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-nd"></i> fab fa-creative-commons-nd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-pd"></i> fab fa-creative-commons-pd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-pd-alt"></i> fab fa-creative-commons-pd-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-remix"></i> fab fa-creative-commons-remix
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-sa"></i> fab fa-creative-commons-sa
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-sampling"></i> fab fa-creative-commons-sampling 
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-sampling-plus"></i> fab fa-creative-commons-sampling-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-creative-commons-share"></i> fab fa-creative-commons-share
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-credit-card"></i> fas fa-credit-card
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-credit-card"></i> far fa-credit-card
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-crop"></i> fas fa-crop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-crosshairs"></i> fas fa-crosshairs
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-crow"></i> fas fa-crow
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-crown"></i> fas fa-crown
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-css3"></i> fab fa-css3
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-css3-alt"></i> fab fa-css3-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cube"></i> fas fa-cube
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cubes"></i> fas fa-cubes
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-cut"></i> fas fa-cut
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-cuttlefish"></i> fab fa-cuttlefish
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-d-and-d"></i> fab fa-d-and-d
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-dashcube"></i> fab fa-dashcube
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-database"></i> fas fa-database
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-deaf"></i> fas fa-deaf
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-delicious"></i> fab fa-delicious
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-deploydog"></i> fab fa-deploydog
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-deskpro"></i> fab fa-deskpro
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-desktop"></i> fas fa-desktop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-deviantart"></i> fab fa-deviantart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-diagnoses"></i> fas fa-diagnoses
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dice"></i> fas fa-dice
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dice-five"></i> fas fa-dice-five
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dice-four"></i> fas fa-dice-four
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dice-one"></i> fas fa-dice-one
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dice-six"></i> fas fa-dice-six
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dice-three"></i> fas fa-dice-three
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dice-two"></i> fas fa-dice-two
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-digg"></i> fab fa-digg
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-digital-ocean"></i> fab fa-digital-ocean
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-discord"></i> fab fa-discord
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-discourse"></i> fab fa-discourse
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-divide"></i>fas fa-divide 
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dna"></i> fas fa-dna
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-dochub"></i> fab fa-dochub
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-docker"></i> fab fa-docker
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dollar-sign"></i> fas fa-dollar-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dolly"></i> fas fa-dolly
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dolly-flatbed"></i> fas fa-dolly-flatbed
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-donate"></i> fas fa-donate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-door-closed"></i> fas fa-door-closed 
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-door-open"></i> fas fa-door-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dot-circle"></i> fas fa-dot-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-dot-circle"></i> far fa-dot-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dove"></i> fas fa-dove
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-download"></i> fas fa-download
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-draft2digital"></i> fab fa-draft2digital
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-dribbble"></i> fab fa-dribbble
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-dribbble-square"></i> fab fa-dribbble-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-dropbox"></i> fab fa-dropbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-drupal"></i> fab fa-drupal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-dumbbell"></i> fas fa-dumbbell
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-dyalog"></i> fab fa-dyalog
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-earlybirds"></i> fab fa-earlybirds
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-ebay"></i> fab fa-ebay
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-edge"></i> fab fa-edge
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-edit"></i> fas fa-edit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-edit"></i> far fa-edit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-eject"></i> fas fa-eject
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-elementor"></i> fab fa-elementor
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ellipsis-h"></i> fas fa-ellipsis-h
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ellipsis-v"></i> fas fa-ellipsis-v
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-ember"></i> fab fa-ember
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-empire"></i> fab fa-empire
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-envelope"></i> fas fa-envelope
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-envelope"></i> far fa-envelope
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-envelope-open"></i> fas fa-envelope-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-envelope-open"></i> far fa-envelope-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-envelope-square"></i> fas fa-envelope-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-envira"></i> fab fa-envira
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-equals"></i> fas fa-equals
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-eraser"></i> fas fa-eraser
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-erlang"></i> fab fa-erlang
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-ethereum"></i> fab fa-ethereum
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-etsy"></i> fab fa-etsy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-euro-sign"></i> fas fa-euro-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-exchange-alt"></i> fas fa-exchange-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-exclamation"></i> fas fa-exclamation
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-exclamation-circle"></i> fas fa-exclamation-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-exclamation-triangle"></i> fas fa-exclamation-triangle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-expand"></i> fas fa-expand
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-expand-arrows-alt"></i> fas fa-expand-arrows-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-expeditedssl"></i> fab fa-expeditedssl
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-external-link-alt"></i> fas fa-external-link-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-external-link-square-alt"></i> fas fa-external-link-square-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-eye"></i> fas fa-eye
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-eye"></i> far fa-eye
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-eye-dropper"></i> fas fa-eye-dropper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-eye-slash"></i> fas fa-eye-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-eye-slash"></i> far fa-eye-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-facebook"></i> fab fa-facebook
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-facebook-f"></i> fab fa-facebook-f
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-facebook-messenger"></i> fab fa-facebook-messenger
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-facebook-square"></i> fab fa-facebook-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-fast-backward"></i> fas fa-fast-backward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-fast-forward"></i> fas fa-fast-forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-fax"></i> fas fa-fax
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-feather"></i> fas fa-feather
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-female"></i> fas fa-female
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-fighter-jet"></i> fas fa-fighter-jet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file"></i> fas fa-file
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file"></i> far fa-file
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-alt"></i> fas fa-file-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-alt"></i> far fa-file-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-archive"></i> fas fa-file-archive
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-archive"></i> far fa-file-archive
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-audio"></i> fas fa-file-audio
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-audio"></i> far fa-file-audio
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-code"></i> fas fa-file-code
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-code"></i> far fa-file-code
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-excel"></i> fas fa-file-excel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-excel"></i> far fa-file-excel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-image"></i> fas fa-file-image
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-image"></i> far fa-file-image
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-medical"></i> fas fa-file-medical
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-medical-alt"></i> fas fa-file-medical-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-pdf"></i> fas fa-file-pdf
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-pdf"></i> far fa-file-pdf
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-powerpoint"></i> fas fa-file-powerpoint
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-powerpoint"></i> far fa-file-powerpoint
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-video"></i> fas fa-file-video
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-video"></i> far fa-file-video
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-file-word"></i> fas fa-file-word
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-file-word"></i> far fa-file-word
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-film"></i> fas fa-film
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-filter"></i> fas fa-filter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-fire"></i> fas fa-fire
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-fire-extinguisher"></i> fas fa-fire-extinguisher
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-firefox"></i> fab fa-firefox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-first-aid"></i> fas fa-first-aid
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-first-order"></i> fab fa-first-order
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-first-order-alt"></i> fab fa-first-order-alt 
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-firstdraft"></i> fab fa-firstdraft
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-flag"></i> fas fa-flag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-flag"></i> far fa-flag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-flag-checkered"></i> fas fa-flag-checkered
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-flask"></i> fas fa-flask
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-flickr"></i> fab fa-flickr
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-flipboard"></i> fab fa-flipboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-fly"></i> fab fa-fly
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-folder"></i> fas fa-folder
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-folder"></i> far fa-folder
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-folder-open"></i> fas fa-folder-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-folder-open"></i> far fa-folder-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-font"></i> fas fa-font
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-font-awesome"></i> fab fa-font-awesome
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-font-awesome-alt"></i> fab fa-font-awesome-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-font-awesome-flag"></i> fab fa-font-awesome-flag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-fonticons"></i> fab fa-fonticons
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-fonticons-fi"></i> fab fa-fonticons-fi
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-football-ball"></i> fas fa-football-ball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-fort-awesome"></i> fab fa-fort-awesome
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-fort-awesome-alt"></i> fab fa-fort-awesome-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-forumbee"></i> fab fa-forumbee
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-forward"></i> fas fa-forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-foursquare"></i> fab fa-foursquare
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-free-code-camp"></i> fab fa-free-code-camp
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-freebsd"></i> fab fa-freebsd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-frog"></i> fas fa-frog
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-frown"></i> fas fa-frown
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-frown"></i> far fa-frown
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-fulcrum"></i> fab fa-fulcrum
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-futbol"></i> fas fa-futbol
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-futbol"></i> far fa-futbol
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-galactic-republic"></i> fab fa-galactic-republic
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-galactic-senate"></i> fab fa-galactic-senate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-gamepad"></i> fas fa-gamepad
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-gas-pump"></i> fas fa-gas-pump
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-gavel"></i> fas fa-gavel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-gem"></i> fas fa-gem
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-gem"></i> far fa-gem
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-genderless"></i> fas fa-genderless
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-get-pocket"></i> fab fa-get-pocket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gg"></i> fab fa-gg
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gg-circle"></i> fab fa-gg-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-gift"></i> fas fa-gift
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-git"></i> fab fa-git
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-git-square"></i> fab fa-git-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-github"></i> fab fa-github
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-github-alt"></i> fab fa-github-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-github-square"></i> fab fa-github-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gitkraken"></i> fab fa-gitkraken
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gitlab"></i> fab fa-gitlab
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gitter"></i> fab fa-gitter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-glass-glass-cocktail"></i> fas fa-glass-glass-cocktail
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-glasses"></i> fas fa-glasses
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-glide"></i> fab fa-glide
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-glide-g"></i> fab fa-glide-g
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-globe"></i> fas fa-globe
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gofore"></i> fab fa-gofore
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-golf-ball"></i> fas fa-golf-ball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-goodreads"></i> fab fa-goodreads
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-goodreads-g"></i> fab fa-goodreads-g
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-google"></i> fab fa-google
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-google-drive"></i> fab fa-google-drive
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-google-play"></i> fab fa-google-play
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-google-plus"></i> fab fa-google-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-google-plus-g"></i> fab fa-google-plus-g
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-google-plus-square"></i> fab fa-google-plus-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-google-wallet"></i> fab fa-google-wallet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-graduation-cap"></i> fas fa-graduation-cap
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gratipay"></i> fab fa-gratipay
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-grav"></i> fab fa-grav
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-greater-than"></i> fas fa-greater-than
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-greater-than-equal"></i> fas fa-greater-than-equal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gripfire"></i> fab fa-gripfire
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-grunt"></i> fab fa-grunt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-gulp"></i> fab fa-gulp
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-h-square"></i> fas fa-h-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-hacker-news"></i> fab fa-hacker-news
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-hacker-news-square"></i> fab fa-hacker-news-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-holding"></i> fas fa-hand-holding
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-holding-heart"></i> fas fa-hand-holding-heart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-holding-usd"></i> fas fa-hand-holding-usd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-lizard"></i> fas fa-hand-lizard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-lizard"></i> far fa-hand-lizard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-paper"></i> fas fa-hand-paper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-paper"></i> far fa-hand-paper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-peace"></i> fas fa-hand-peace
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-peace"></i> far fa-hand-peace
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-point-down"></i> fas fa-hand-point-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-point-down"></i> far fa-hand-point-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-point-left"></i> fas fa-hand-point-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-point-left"></i> far fa-hand-point-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-point-right"></i> fas fa-hand-point-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-point-right"></i> far fa-hand-point-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-point-up"></i> fas fa-hand-point-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-point-up"></i> far fa-hand-point-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-pointer"></i> fas fa-hand-pointer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-pointer"></i> far fa-hand-pointer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-rock"></i> fas fa-hand-rock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-rock"></i> far fa-hand-rock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-scissors"></i> fas fa-hand-scissors
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-scissors"></i> far fa-hand-scissors
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hand-spock"></i> fas fa-hand-spock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hand-spock"></i> far fa-hand-spock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hands"></i> fas fa-hands
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hands-helping"></i> fas fa-hands-helping
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-handshake"></i> fas fa-handshake
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-handshake"></i> far fa-handshake
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hashtag"></i> fas fa-hashtag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hdd"></i> fas fa-hdd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hdd"></i> far fa-hdd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-heading"></i> fas fa-heading
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-headphones"></i> fas fa-headphones
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-heart"></i> fas fa-heart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-heart"></i> far fa-heart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-heartbeat"></i> fas fa-heartbeat
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-helicopter"></i> fas fa-helicopter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-hips"></i> fab fa-hips
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-hire-a-helper"></i> fab fa-hire-a-helper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-history"></i> fas fa-history
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hockey-puck"></i> fas fa-hockey-puck
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-home"></i> fas fa-home
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-hooli"></i> fab fa-hooli
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hospital"></i> fas fa-hospital
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hospital"></i> far fa-hospital
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hospital-alt"></i> fas fa-hospital-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hospital-symbol"></i> fas fa-hospital-symbol
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-hotjar"></i> fab fa-hotjar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hourglass"></i> fas fa-hourglass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-hourglass"></i> far fa-hourglass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hourglass-half"></i> fas fa-hourglass-half
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-hourglass-start"></i> fas fa-hourglass-start
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-houzz"></i> fab fa-houzz
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-html5"></i> fab fa-html5
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-hubspot"></i> fab fa-hubspot
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-i-cursor"></i> fas fa-i-cursor
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-id-badge"></i> fas fa-id-badge
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-id-badge"></i> far fa-id-badge 
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-id-card"></i> fas fa-id-card
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-id-card"></i> far fa-id-card
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-id-card-alt"></i> fas fa-id-card-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-image"></i> fas fa-image
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-image"></i> far fa-image
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-images"></i> fas fa-images
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-images"></i> far fa-images
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-imdb"></i> fab fa-imdb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-inbox"></i> fas fa-inbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-indent"></i> fas fa-indent
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-industry"></i> fas fa-industry
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-infinity"></i> fas fa-infinity
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-info"></i> fas fa-info
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-info-circle"></i> fas fa-info-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-instagram"></i> fab fa-instagram
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-internet-explorer"></i> fab fa-internet-explorer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-ioxhost"></i> fab fa-ioxhost
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-italic"></i> fas fa-italic
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-itunes"></i> fab fa-itunes
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-itunes-note"></i> fab fa-itunes-note
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-java"></i> fab fa-java
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-jedi-order"></i> fab fa-jedi-order
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-jenkins"></i> fab fa-jenkins
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-joget"></i> fab fa-joget
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-joomla"></i> fab fa-joomla
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-js"></i> fab fa-js
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-js-square"></i> fab fa-js-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-jsfiddle"></i> fab fa-jsfiddle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-key"></i> fas fa-key
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-keybase"></i> fab fa-keybase
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-keyboard"></i> fas fa-keyboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-keyboard"></i> far fa-keyboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-keycdn"></i> fab fa-keycdn
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-kickstarter"></i> fab fa-kickstarter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-kickstarter-k"></i> fab fa-kickstarter-k
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-kiwi-bird"></i> fas fa-kiwi-bird
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-korvue"></i> fab fa-korvue
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-language"></i> fas fa-language
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-laptop"></i> fas fa-laptop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-laravel"></i> fab fa-laravel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-lastfm"></i> fab fa-lastfm
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-lastfm-square"></i> fab fa-lastfm-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-leaf"></i> fas fa-leaf
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-leanpub"></i> fab fa-leanpub
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-lemon"></i> fas fa-lemon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-lemon"></i> far fa-lemon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-less"></i> fab fa-less
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-less-than"></i> fas fa-less-than
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-less-than-equal"></i> fas fa-less-than-equal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-level-down-alt"></i> fas fa-level-down-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-level-up-alt"></i> fas fa-level-up-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-life-ring"></i> fas fa-life-ring
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-life-ring"></i> far fa-life-ring
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-lightbulb"></i> fas fa-lightbulb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-lightbulb"></i> far fa-lightbulb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-line"></i> fab fa-line
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-link"></i> fas fa-link
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-linkedin"></i> fab fa-linkedin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-linkedin-in"></i> fab fa-linkedin-in
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-linode"></i> fab fa-linode
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-linux"></i> fab fa-linux
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-lira-sign"></i> fas fa-lira-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-list"></i> fas fa-list
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-list-alt"></i> fas fa-list-alts
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-list-alt"></i> far fa-list-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-list-ol"></i> fas fa-list-ol
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-list-ul"></i> fas fa-list-ul
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-location-arrow"></i> fas fa-location-arrow
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-lock"></i> fas fa-lock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-lock-open"></i> fas fa-lock-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-long-arrow-alt-down"></i> fas fa-long-arrow-alt-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-long-arrow-alt-left"></i> fas fa-long-arrow-alt-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-long-arrow-alt-right"></i> fas fa-long-arrow-alt-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-long-arrow-alt-up"></i> fas fa-long-arrow-alt-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-low-vision"></i> fas fa-low-vision
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-lyft"></i> fab fa-lyft
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-magento"></i> fab fa-magento
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-magic"></i> fas fa-magic
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-magnet"></i> fas fa-magnet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-male"></i> fas fa-male
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-mandalorian"></i> fab fa-mandalorian
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-map"></i> fas fa-map
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-map"></i> far fa-map
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-map-marker"></i> fas fa-map-marker
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-map-marker-alt"></i> fas fa-map-marker-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-map-pin"></i> fas fa-map-pin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-map-signs"></i> fas fa-map-signs
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mars"></i> fas fa-mars
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mars-double"></i> fas fa-mars-double
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mars-stroke"></i> fas fa-mars-stroke
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mars-stroke-h"></i> fas fa-mars-stroke-h
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mars-stroke-v"></i> fas fa-mars-stroke-v
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-mastodon"></i> fab fa-mastodon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-maxcdn"></i> fab fa-maxcdn
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-medapps"></i> fab fa-medapps
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-medium"></i> fab fa-medium
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-medium-m"></i> fab fa-medium-m
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-medkit"></i> fas fa-medkit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-medrt"></i> fab fa-medrt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-meetup"></i> fab fa-meetup
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-meh"></i> fas fa-meh
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-meh"></i> far fa-meh
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mercury"></i> fas fa-mercury
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-microchip"></i> fas fa-microchip
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-microphone"></i> fas fa-microphone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-microphone-alt"></i> fas fa-microphone-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-microphone-alt-slash"></i> fas fa-microphone-alt-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-microphone-slash"></i> fas fa-microphone-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-microsoft"></i> fab fa-microsoft
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-minus"></i> fas fa-minus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-minus-circle"></i> fas fa-minus-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-minus-square"></i> fas fa-minus-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-minus-square"></i> far fa-minus-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-mix"></i> fab fa-mix
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-mixcloud"></i> fab fa-mixcloud
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-mizuni"></i> fab fa-mizuni
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mobile"></i> fas fa-mobile
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mobile-alt"></i> fas fa-mobile-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-modx"></i> fab fa-modx
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-monero"></i> fab fa-monero
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-money-bill"></i> fas fa-money-bill
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-money-bill-alt"></i> fas fa-money-bill-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-money-bill-alt"></i> far fa-money-bill-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-money-bill-wave"></i> fas fa-money-bill-wave
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-money-bill-wave-alt"></i> fas fa-money-bill-wave-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-money-check"></i> fas fa-money-check
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-money-check-alt"></i> fas fa-money-check-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-moon"></i> fas fa-moon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-moon"></i> far fa-moon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-motorcycle"></i> fas fa-motorcycle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-mouse-pointer"></i> fas fa-mouse-pointer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-music"></i> fas fa-music
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-napster"></i> fab fa-napster
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-neuter"></i> fas fa-neuter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-newspaper"></i> fas fa-newspaper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-newspaper"></i> far fa-newspaper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-nintendo-switch"></i> fab fa-nintendo-switch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-node"></i> fab fa-node
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-node-js"></i> fab fa-node-js
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-not-equal"></i> fas fa-not-equal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-notes-medical"></i> fas fa-notes-medical
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-npm"></i> fab fa-npm
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-ns8"></i> fab fa-ns8
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-nutritionix"></i> fab fa-nutritionix
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-object-group"></i> fas fa-object-group
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-object-group"></i> far fa-object-group
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-object-ungroup"></i> fas fa-object-ungroup
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-object-ungroup"></i> far fa-object-ungroup
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-odnoklassniki"></i> fab fa-odnoklassniki 
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-odnoklassniki-square"></i> fab fa-odnoklassniki-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-old-republic"></i> fab fa-old-republic
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-opencart"></i> fab fa-opencart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-openid"></i> fab fa-openid
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-opera"></i> fab fa-opera
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-optin-monster"></i> fab fa-optin-monster
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-osi"></i> fab fa-osi
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-outdent"></i> fas fa-outdent
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-page4"></i> fab fa-page4
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pagelines"></i> fab fa-pagelines
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-paint-brush"></i> fas fa-paint-brush
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-palette"></i> fas fa-palette
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-palfed"></i> fab fa-palfed
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-pallet"></i> fas fa-pallet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-paper-plane"></i> fas fa-paper-plane
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-paper-plane"></i> far fa-paper-plane
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-paperclip"></i> fas fa-paperclip
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-parachute-box"></i> fas fa-parachute-box
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-paragraph"></i> fas fa-paragraph
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-parking"></i> fas fa-parking
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-paste"></i> fas fa-paste
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-patreon"></i> fab fa-patreon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-pause"></i> fas fa-pause
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-pause-circle"></i> fas fa-pause-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-pause-circle"></i> far fa-pause-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-paw"></i> fas fa-paw
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-paypal"></i> fab fa-paypal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-pen-square"></i> fas fa-pen-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-pencil-alt"></i> fas fa-pencil-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-people-carry"></i> fas fa-people-carry
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-percent"></i> fas fa-percent
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-percentage"></i> fas fa-percentage
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-periscope"></i> fab fa-periscope
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-phabricator"></i> fab fa-phabricator
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-phoenix-framework"></i> fab fa-phoenix-framework
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-phoenix-squadron"></i> fab fa-phoenix-squadron
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-phone"></i> fas fa-phone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-phone-slash"></i> fas fa-phone-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-phone-square"></i> fas fa-phone-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-phone-volume"></i> fas fa-phone-volume
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-php"></i> fab fa-php
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pied-piper"></i> fab fa-pied-piper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pied-piper-alt"></i> fab fa-pied-piper-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pied-piper-hat"></i> fab fa-pied-piper-hat
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pied-piper-pp"></i> fab fa-pied-piper-pp
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-piggy-bank"></i> fas fa-piggy-bank
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-pills"></i> fas fa-pills
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pinterest"></i> fab fa-pinterest
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pinterest-p"></i> fab fa-pinterest-p
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pinterest-square"></i> fab fa-pinterest-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-plane"></i> fas fa-plane
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-play"></i> fas fa-play
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-play-circle"></i> fas fa-play-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-play-circle"></i> far fa-play-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-playstation"></i> fab fa-playstation
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-plug"></i> fas fa-plug
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-plus"></i> fas fa-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-plus-circle"></i> fas fa-plus-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-plus-square"></i> fas fa-plus-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-plus-square"></i> far fa-plus-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-podcast"></i> fas fa-podcast
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-poo"></i> fas fa-poo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-portrait"></i> fas fa-portrait
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-pound-sign"></i> fas fa-pound-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-power-off"></i> fas fa-power-off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-prescription-bottle"></i> fas fa-prescription-bottle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-prescription-bottle-alt"></i> fas fa-prescription-bottle-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-print"></i> fas fa-print
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-procedures"></i> fas fa-procedures
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-product-hunt"></i> fab fa-product-hunt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-project-diagram"></i> fas fa-project-diagram
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-pushed"></i> fab fa-pushed
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-puzzle-piece"></i> fas fa-puzzle-piece
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-python"></i> fab fa-python
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-qq"></i> fab fa-qq
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-qrcode"></i> fas fa-qrcode
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-question"></i> fas fa-question
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-question-circle"></i> fas fa-question-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-question-circle"></i> far fa-question-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-quidditch"></i> fas fa-quidditch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-quinscape"></i> fab fa-quinscape
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-quora"></i> fab fa-quora
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-quote-left"></i> fas fa-quote-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-quote-right"></i> fas fa-quote-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-r-project"></i> fab fa-r-project
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-random"></i> fas fa-random
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-ravelry"></i> fab fa-ravelry
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-react"></i> fab fa-react
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-readme"></i> fab fa-readme
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-rebel"></i> fab fa-rebel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-receipt"></i> fas fa-receipt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-recycle"></i> fas fa-recycle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-red-river"></i> fab fa-red-river
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-reddit"></i> fab fa-reddit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-reddit-alien"></i> fab fa-reddit-alien
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-reddit-square"></i> fab fa-reddit-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-redo"></i> fas fa-redo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-redo-alt"></i> fas fa-redo-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-registered"></i> fas fa-registered
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-registered"></i> far fa-registered
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-rendact"></i> fab fa-rendact
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-renren"></i> fab fa-renren
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-reply"></i> fas fa-reply
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-reply-all"></i> fas fa-reply-all
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-replyd"></i> fab fa-replyd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-researchgate"></i> fab fa-researchgate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-resolving"></i> fab fa-resolving
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-retweet"></i> fas fa-retweet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ribbon"></i> fas fa-ribbon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-road"></i> fas fa-road
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-robot"></i> fas fa-robot
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-rocket"></i> fas fa-rocket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-rocketchat"></i> fab fa-rocketchat
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-rockrms"></i> fab fa-rockrms
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-rss"></i> fas fa-rss
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-rss-square"></i> fas fa-rss-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ruble-sign"></i> fas fa-ruble-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ruler"></i> fas fa-ruler
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ruler-combined"></i> fas fa-ruler-combined
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ruler-horizontal"></i> fas fa-ruler-horizontal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ruler-vertical"></i> fas fa-ruler-vertical
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-rupee-sign"></i> fas fa-rupee-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-safari"></i> fab fa-safari
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-sass"></i> fab fa-sass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-save"></i> fas fa-save
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-save"></i> far fa-save
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-schlix"></i> fab fa-schlix
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-school"></i> fas fa-school
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-screwdriver"></i> fas fa-screwdriver
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-scribd"></i> fab fa-scribd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-search"></i> fas fa-search
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-search-minus"></i> fas fa-search-minus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-search-plus"></i> fas fa-search-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-searchengin"></i> fab fa-searchengin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-seedling"></i> fas fa-seedling
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-sellcast"></i> fab fa-sellcast
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-sellsy"></i> fab fa-sellsy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-server"></i> fas fa-server
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-servicestack"></i> fab fa-servicestack
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-share"></i> fas fa-share
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-share-alt"></i> fas fa-share-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-share-alt-square"></i> fas fa-share-alt-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-share-square"></i> fas fa-share-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-share-square"></i> far fa-share-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-shekel-sign"></i> fas fa-shekel-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-shield-alt"></i> fas fa-shield-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ship"></i> fas fa-ship
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-shipping-fast"></i> fas fa-shipping-fast
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-shirtsinbulk"></i> fab fa-shirtsinbulk
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-shoe-prints"></i> fas fa-shoe-prints
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-shopping-bag"></i> fas fa-shopping-bag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-shopping-basket"></i> fas fa-shopping-basket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-shopping-cart"></i> fas fa-shopping-cart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-shower"></i> fas fa-shower
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sign"></i> fas fa-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sign-in-alt"></i> fas fa-sign-in-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sign-language"></i> fas fa-sign-language
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sign-out-alt"></i> fas fa-sign-out-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-signal"></i> fas fa-signal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-simplybuilt"></i> fab fa-simplybuilt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-sistrix"></i> fab fa-sistrix
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sitemap"></i> fas fa-sitemap
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-sith"></i> fab fa-sith
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-skull"></i> fas fa-skull
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-skyatlas"></i> fab fa-skyatlas
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-skype"></i> fab fa-skype
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-slack"></i> fab fa-slack
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-slack-hash"></i> fab fa-slack-hash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sliders-h"></i> fas fa-sliders-h
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-slideshare"></i> fab fa-slideshare
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-smile"></i> fas fa-smile
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-smile"></i> far fa-smile
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-smoking"></i> fas fa-smoking
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-smoking-ban"></i> fas fa-smoking-ban
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-snapchat"></i> fab fa-snapchat
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-snapchat-ghost"></i> fab fa-snapchat-ghost
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-snapchat-square"></i> fab fa-snapchat-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-snowflake"></i> fas fa-snowflake
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-snowflake"></i> far fa-snowflake
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort"></i> fas fa-sort
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort-alpha-down"></i> fas fa-sort-alpha-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort-alpha-up"></i> fas fa-sort-alpha-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort-amount-down"></i> fas fa-sort-amount-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort-amount-up"></i> fas fa-sort-amount-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort-down"></i> fas fa-sort-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort-numeric-down"></i> fas fa-sort-numeric-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort-numeric-up"></i> fas fa-sort-numeric-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sort-up"></i> fas fa-sort-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-soundcloud"></i> fab fa-soundcloud
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-space-shuttle"></i> fas fa-space-shuttle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-speakap"></i> fab fa-speakap
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-spinner"></i> fas fa-spinner
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-spotify"></i> fab fa-spotify
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-square"></i> fas fa-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-square"></i> far fa-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-square-full"></i> fas fa-square-full
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-stack-exchange"></i> fab fa-stack-exchange
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-stack-overflow"></i> fab fa-stack-overflow
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-star"></i> fas fa-star
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-star"></i> far fa-star
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-star-half"></i> fas fa-star-half
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-star-half"></i> far fa-star-half
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-staylinked"></i> fab fa-staylinked
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-steam"></i> fab fa-steam
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-steam-square"></i> fab fa-steam-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-steam-symbol"></i> fab fa-steam-symbol
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-step-backward"></i> fas fa-step-backward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-step-forward"></i> fas fa-step-forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-stethoscope"></i> fas fa-stethoscope
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-sticker-mule"></i> fab fa-sticker-mule
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sticky-note"></i> fas fa-sticky-note
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-sticky-note"></i> far fa-sticky-note
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-stop"></i> fas fa-stop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-stop-circle"></i> fas fa-stop-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-stop-circle"></i> far fa-stop-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-stopwatch"></i> fas fa-stopwatch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-store"></i> fas fa-store
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-store-alt"></i> fas fa-store-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-strava"></i> fab fa-strava
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-stream"></i> fas fa-stream
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-street-view"></i> fas fa-street-view
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-strikethrough"></i> fas fa-strikethrough
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-stripe"></i> fab fa-stripe
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-stripe-s"></i> fab fa-stripe-s 
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-stroopwafel"></i> fas fa-stroopwafel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-studiovinari"></i> fab fa-studiovinari
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-stumbleupon"></i> fab fa-stumbleupon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-stumbleupon-circle"></i> fab fa-stumbleupon-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-subscript"></i> fas fa-subscript
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-subway"></i> fas fa-subway
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-suitcase"></i> fas fa-suitcase
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sun"></i> fas fa-sun
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-sun"></i> far fa-sun
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-superpowers"></i> fab fa-superpowers
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-superscript"></i> fas fa-superscript
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-supple"></i> fab fa-supple
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sync"></i> fas fa-sync
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-sync-alt"></i> fas fa-sync-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-syringe"></i> fas fa-syringe
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-table"></i> fas fa-table
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-table-tennis"></i> fas fa-table-tennis
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tablet"></i> fas fa-tablet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tablet-alt"></i> fas fa-tablet-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tablets"></i> fas fa-tablets
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tachometer-alt"></i> fas fa-tachometer-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tag"></i> fas fa-tag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tags"></i> fas fa-tags
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tape"></i> fas fa-tape
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tasks"></i> fas fa-tasks
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-taxi"></i> fas fa-taxi
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-teamspeak"></i> fab fa-teamspeak
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-telegram"></i> fab fa-telegram
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-telegram-plane"></i> fab fa-telegram-plane
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-tencent-weibo"></i> fab fa-tencent-weibo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-terminal"></i> fas fa-terminal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-text-height"></i> fas fa-text-height
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-text-width"></i> fas fa-text-width
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-th"></i> fas fa-th
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-th-large"></i> fas fa-th-large
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-th-list"></i> fas fa-th-list
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-themeisle"></i> fab fa-themeisle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thermometer"></i> fas fa-thermometer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thermometer-empty"></i> fas fa-thermometer-empty
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thermometer-full"></i> fas fa-thermometer-full
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thermometer-half"></i> fas fa-thermometer-half
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thermometer-quarter"></i> fas fa-thermometer-quarter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thermometer-three-quarters"></i> fas fa-thermometer-three-quarters
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thumbs-down"></i> fas fa-thumbs-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-thumbs-down"></i> far fa-thumbs-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thumbs-up"></i> fas fa-thumbs-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-thumbs-up"></i> far fa-thumbs-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-thumbtack"></i> fas fa-thumbtack
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-ticket-alt"></i> fas fa-ticket-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-times"></i> fas fa-times
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-times-circle"></i> fas fa-times-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-times-circle"></i> far fa-times-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tint"></i> fas fa-tint
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-toggle-off"></i> fas fa-toggle-off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-toggle-on"></i> fas fa-toggle-on
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-toolbox"></i> fas fa-toolbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-trade-federation"></i> fab fa-trade-federation
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-trademark"></i> fas fa-trademark
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-train"></i> fas fa-train
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-transgender"></i> fas fa-transgender
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-transgender-alt"></i> fas fa-transgender-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-trash"></i> fas fa-trash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-trash-alt"></i> fas fa-trash-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-trash-alt"></i> far fa-trash-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tree"></i> fas fa-tree
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-trello"></i> fab fa-trello
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-tripadvisor"></i> fab fa-tripadvisor
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-trophy"></i> fas fa-trophy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-truck"></i> fas fa-truck
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-truck-loading"></i> fas fa-truck-loading
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-truck-moving"></i> fas fa-truck-moving
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tshirt"></i> fas fa-tshirt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tty"></i> fas fa-tty
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-tumblr"></i> fab fa-tumblr
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-tumblr-square"></i> fab fa-tumblr-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-tv"></i> fas fa-tv
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-twitch"></i> fab fa-twitch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-twitter"></i> fab fa-twitter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-twitter-square"></i> fab fa-twitter-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-typo3"></i> fab fa-typo3
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-uber"></i> fab fa-uber
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-uikit"></i> fab fa-uikit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-umbrella"></i> fas fa-umbrella
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-underline"></i> fas fa-underline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-undo"></i> fas fa-undo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-undo-alt"></i> fas fa-undo-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-uniregistry"></i> fab fa-uniregistry
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-universal-access"></i> fas fa-universal-access
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-university"></i> fas fa-university
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-unlink"></i> fas fa-unlink
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-unlock"></i> fas fa-unlock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-unlock-alt"></i> fas fa-unlock-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-untappd"></i> fab fa-untappd
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-upload"></i> fas fa-upload
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-usb"></i> fab fa-usb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user"></i> fas fa-user
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-user"></i> far fa-user
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-alt"></i> fas fa-user-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-alt-slash"></i> fas fa-user-alt-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-astronaut"></i> fas fa-user-astronaut
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-check"></i> fas fa-user-check
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-circle"></i> fas fa-user-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-user-circle"></i> far fa-user-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-clock"></i> fas fa-user-clock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-cog"></i> fas fa-user-cog
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-edit"></i> fas fa-user-edit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-friends"></i> fas fa-user-friends
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-graduate"></i> fas fa-user-graduate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-lock"></i> fas fa-user-lock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-md"></i> fas fa-user-md
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-minus"></i> fas fa-user-minus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-ninja"></i> fas fa-user-ninja
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-plus"></i> fas fa-user-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-secret"></i> fas fa-user-secret
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-shield"></i> fas fa-user-shield
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-slash"></i> fas fa-user-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-tag"></i> fas fa-user-tag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-tie"></i> fas fa-user-tie
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-user-times"></i> fas fa-user-times
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-users"></i> fas fa-users
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-users-cog"></i> fas fa-users-cog 
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-ussunnah"></i> fab fa-ussunnah
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-utensil-spoon"></i> fas fa-utensil-spoon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-utensils"></i> fas fa-utensils
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-vaadin"></i> fab fa-vaadin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-venus"></i> fas fa-venus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-venus-double"></i> fas fa-venus-double
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-venus-mars"></i> fas fa-venus-mars
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-viacoin"></i> fab fa-viacoin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-viadeo"></i> fab fa-viadeo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-viadeo-square"></i> fab fa-viadeo-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-vial"></i> fas fa-vial
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-vials"></i> fas fa-vials
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-viber"></i> fab fa-viber
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-video"></i> fas fa-video
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-video-slash"></i> fas fa-video-slash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-vimeo"></i> fab fa-vimeo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-vimeo-square"></i> fab fa-vimeo-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-vimeo-v"></i> fab fa-vimeo-v
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-vine"></i> fab fa-vine
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-vk"></i> fab fa-vk
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-vnv"></i> fab fa-vnv
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-volleyball-ball"></i> fas fa-volleyball-ball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-volume-down"></i> fas fa-volume-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-volume-off"></i> fas fa-volume-off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-volume-up"></i> fas fa-volume-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-vuejs"></i> fab fa-vuejs
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-walking"></i> fas fa-walking
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-wallet"></i> fas fa-wallet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-warehouse"></i> fas fa-warehouse
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-weibo"></i> fab fa-weibo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-weight"></i> fas fa-weight
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-weixin"></i> fab fa-weixin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-whatsapp"></i> fab fa-whatsapp
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-whatsapp-square"></i> fab fa-whatsapp-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-wheelchair"></i> fas fa-wheelchair
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-whmcs"></i> fab fa-whmcs
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-wifi"></i> fas fa-wifi
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-wikipedia-w"></i> fab fa-wikipedia-w
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-window-close"></i> fas fa-window-close
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-window-close"></i> far fa-window-close
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-window-maximize"></i> fas fa-window-maximize
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-window-maximize"></i> far fa-window-maximize
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-window-minimize"></i> fas fa-window-minimize
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-window-restore"></i> fas fa-window-restore
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="far fa-window-restore"></i> far fa-window-restore
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-windows"></i> fab fa-windows
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-wine-glass"></i> fas fa-wine-glass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-wolf-pack-battalion"></i> fab fa-wolf-pack-battalion
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-won-sign"></i> fas fa-won-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-wordpress"></i> fab fa-wordpress
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-wordpress-simple"></i> fab fa-wordpress-simple
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-wpbeginner"></i> fab fa-wpbeginner
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-wpexplorer"></i> fab fa-wpexplorer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-wpforms"></i> fab fa-wpforms
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-wrench"></i> fas fa-wrench
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-x-ray"></i> fas fa-x-ray
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-xbox"></i> fab fa-xbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-xing"></i> fab fa-xing
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-xing-square"></i> fab fa-xing-square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-y-combinator"></i> fab fa-y-combinator
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-yahoo"></i> fab fa-yahoo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-yandex"></i> fab fa-yandex
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-yandex-international"></i> fab fa-yandex-international
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-yelp"></i> fab fa-yelp
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fas fa-yen-sign"></i> fas fa-yen-sign
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-yoast"></i> fab fa-yoast
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-youtube"></i> fab fa-youtube
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="fab fa-youtube-square"></i> fab fa-youtube-square
                                            </div>
                                        </div>
                                    </section>
                                </div><!--end card-body-->
                            </div><!--end card-->
                        </div> <!-- end col -->
                    </div> <!-- end row --> 

                </div><!-- container -->



                <!-- Page Content-->
                <div class="page-content">
                        <!-- end page title end breadcrumb -->
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="mt-0 header-title">Examples</h4>
                                        <p class="text-muted mb-4"> Use <code>&lt;i class="typcn typcn-chart-pie-outline
                                                "&gt;&lt;/i&gt;</code>.
                                        </p>

                                        <div class="row icon-demo-content">
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-chart-pie-outline"></i> typcn typcn-chart-pie-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-chart-pie"></i> typcn typcn-chart-pie
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-chevron-left-outline"></i> typcn typcn-chevron-left-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-chevron-left"></i> typcn typcn-chevron-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-chevron-right-outline"></i> typcn typcn-chevron-right-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-chevron-right"></i> typcn typcn-chevron-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-clipboard"></i> typcn typcn-clipboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-cloud-storage"></i> typcn typcn-cloud-storage
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-cloud-storage-outline"></i> typcn typcn-cloud-storage-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-code-outline"></i> typcn typcn-code-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-code"></i> typcn typcn-code
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-coffee"></i> typcn typcn-coffee
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-cog-outline"></i> typcn typcn-cog-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-cog"></i> typcn typcn-cog
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-compass"></i> typcn typcn-compass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-contacts"></i> typcn typcn-contacts
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-credit-card"></i> typcn typcn-credit-card
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-css3"></i> typcn typcn-css3
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-database"></i> typcn typcn-database
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-delete-outline"></i> typcn typcn-delete-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-delete"></i> typcn typcn-delete
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-device-desktop"></i> typcn typcn-device-desktop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-device-laptop"></i> typcn typcn-device-laptop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-device-phone"></i> typcn typcn-device-phone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-device-tablet"></i> typcn typcn-device-tablet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-directions"></i> typcn typcn-directions
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-divide-outline"></i> typcn typcn-divide-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-divide"></i> typcn typcn-divide
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-document-add"></i> typcn typcn-document-add
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-document-delete"></i> typcn typcn-document-delete
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-document-text"></i> typcn typcn-document-text
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-document"></i> typcn typcn-document
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-download-outline"></i> typcn typcn-download-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-download"></i> typcn typcn-download
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-dropbox"></i> typcn typcn-dropbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-edit"></i> typcn typcn-edit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-eject-outline"></i> typcn typcn-eject-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-eject"></i> typcn typcn-eject
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-equals-outline"></i> typcn typcn-equals-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-equals"></i> typcn typcn-equals
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-export-outline"></i> typcn typcn-export-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-export"></i> typcn typcn-export
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-eye-outline"></i> typcn typcn-eye-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-eye"></i> typcn typcn-eye
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-feather"></i> typcn typcn-feather
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-film"></i> typcn typcn-film
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-filter"></i> typcn typcn-filter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-flag-outline"></i> typcn typcn-flag-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-flag"></i> typcn typcn-flag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-flash-outline"></i> typcn typcn-flash-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-flash"></i> typcn typcn-flash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-flow-children"></i> typcn typcn-flow-children
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-flow-merge"></i> typcn typcn-flow-merge
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-flow-parallel"></i> typcn typcn-flow-parallel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-flow-switch"></i> typcn typcn-flow-switch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-folder-add"></i> typcn typcn-folder-add
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-folder-delete"></i> typcn typcn-folder-delete
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-folder-open"></i> typcn typcn-folder-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-folder"></i> typcn typcn-folder
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-gift"></i> typcn typcn-gift
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-globe-outline"></i> typcn typcn-globe-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-globe"></i> typcn typcn-globe
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-group-outline"></i> typcn typcn-group-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-group"></i> typcn typcn-group
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-headphones"></i> typcn typcn-headphones
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-heart-full-outline"></i> typcn typcn-heart-full-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-heart-half-outline"></i> typcn typcn-heart-half-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-heart-outline"></i> typcn typcn-heart-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-heart"></i> typcn typcn-heart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-home-outline"></i> typcn typcn-home-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-home"></i> typcn typcn-home
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-html5"></i> typcn typcn-html5
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-image-outline"></i> typcn typcn-image-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-image"></i> typcn typcn-image
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-infinity-outline"></i> typcn typcn-infinity-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-infinity"></i> typcn typcn-infinity
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-info-large-outline"></i> typcn typcn-info-large-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-info-large"></i> typcn typcn-info-large
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-info-outline"></i> typcn typcn-info-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-info"></i> typcn typcn-info
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-input-checked-outline"></i> typcn typcn-input-checked-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-input-checked"></i> typcn typcn-input-checked
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-key-outline"></i> typcn typcn-key-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-key"></i> typcn typcn-key
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-keyboard"></i> typcn typcn-keyboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-leaf"></i> typcn typcn-leaf
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-lightbulb"></i> typcn typcn-lightbulb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-link-outline"></i> typcn typcn-link-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-link"></i> typcn typcn-link
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-location-arrow-outline"></i> typcn typcn-location-arrow-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-location-arrow"></i> typcn typcn-location-arrow
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-location-outline"></i> typcn typcn-location-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-location"></i> typcn typcn-location
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-lock-closed-outline"></i> typcn typcn-lock-closed-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-lock-closed"></i> typcn typcn-lock-closed
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-lock-open-outline"></i> typcn typcn-lock-open-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-lock-open"></i> typcn typcn-lock-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-mail"></i> typcn typcn-mail
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-map"></i> typcn typcn-map
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-eject-outline"></i> typcn typcn-media-eject-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-eject"></i> typcn typcn-media-eject
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-fast-forward-outline"></i> typcn typcn-media-fast-forward-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-fast-forward"></i> typcn typcn-media-fast-forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-pause-outline"></i> typcn typcn-media-pause-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-pause"></i> typcn typcn-media-pause
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-play-outline"></i> typcn typcn-media-play-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-play-reverse-outline"></i>  typcn typcn-media-play-reverse-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-play-reverse"></i> typcn typcn-media-play-reverse
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-play"></i> typcn typcn-media-play
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-record-outline"></i> typcn typcn-media-record-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-record"></i> typcn typcn-media-record
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-rewind-outline"></i> typcn typcn-media-rewind-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-rewind"></i> typcn typcn-media-rewind
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-stop-outline"></i> typcn typcn-media-stop-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-media-stop"></i> typcn typcn-media-stop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-message-typing"></i> typcn typcn-message-typing
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-message"></i> typcn typcn-message
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-messages"></i> typcn typcn-messages
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-microphone-outline"></i> typcn typcn-microphone-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-microphone"></i> typcn typcn-microphone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-minus-outline"></i> typcn typcn-minus-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-minus"></i> typcn typcn-minus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-mortar-board"></i> typcn typcn-mortar-board
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-news"></i> typcn typcn-news
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-notes-outline"></i> typcn typcn-notes-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-notes"></i> typcn typcn-notes
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-pen"></i> typcn typcn-pen
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-pencil"></i> typcn typcn-pencil
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-phone-outline"></i> typcn typcn-phone-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-phone"></i> typcn typcn-phone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-pi-outline"></i> typcn typcn-pi-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-pi"></i> typcn typcn-pi
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-pin-outline"></i> typcn typcn-pin-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-pin"></i> typcn typcn-pin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-pipette"></i> typcn typcn-pipette
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-plane-outline"></i> typcn typcn-plane-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-plane"></i> typcn typcn-plane
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-plug"></i> typcn typcn-plug
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-plus-outline"></i> typcn typcn-plus-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-plus"></i> typcn typcn-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-point-of-interest-outline"></i> typcn typcn-point-of-interest-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-point-of-interest"></i> typcn typcn-point-of-interest
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-power-outline"></i> typcn typcn-power-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-power"></i> typcn typcn-power
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-printer"></i> typcn typcn-printer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-puzzle-outline"></i> typcn typcn-puzzle-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-puzzle"></i> typcn typcn-puzzle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-radar-outline"></i> typcn typcn-radar-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-radar"></i> typcn typcn-radar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-refresh-outline"></i> typcn typcn-refresh-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-refresh"></i> typcn typcn-refresh
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-rss-outline"></i> typcn typcn-rss-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-rss"></i> typcn typcn-rss
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-scissors-outline"></i> typcn typcn-scissors-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-scissors"></i> typcn typcn-scissors
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-shopping-bag"></i> typcn typcn-shopping-bag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-shopping-cart"></i> typcn typcn-shopping-cart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-at-circular"></i> typcn typcn-social-at-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-dribbble-circular"></i> typcn typcn-social-dribbble-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-dribbble"></i> typcn typcn-social-dribbble
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-facebook-circular"></i> typcn typcn-social-facebook-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-facebook"></i> typcn typcn-social-facebook
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-flickr-circular"></i> typcn typcn-social-flickr-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-flickr"></i> typcn typcn-social-flickr
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-github-circular"></i> typcn typcn-social-github-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-github"></i> typcn typcn-social-github
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-google-plus-circular"></i> typcn typcn-social-google-plus-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-google-plus"></i> typcn typcn-social-google-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-instagram-circular"></i> typcn typcn-social-instagram-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-instagram"></i> typcn typcn-social-instagram
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-last-fm-circular"></i> typcn typcn-social-last-fm-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-last-fm"></i> typcn typcn-social-last-fm
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-linkedin-circular"></i> typcn typcn-social-linkedin-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-linkedin"></i> typcn typcn-social-linkedin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-pinterest-circular"></i> typcn typcn-social-pinterest-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-pinterest"></i> typcn typcn-social-pinterest
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-skype-outline"></i> typcn typcn-social-skype-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-skype"></i> typcn typcn-social-skype
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-tumbler-circular"></i> typcn typcn-social-tumbler-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-tumbler"></i> typcn typcn-social-tumbler
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-twitter-circular"></i> typcn typcn-social-twitter-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-twitter"></i> typcn typcn-social-twitter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-vimeo-circular"></i> typcn typcn-social-vimeo-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-vimeo"></i> typcn typcn-social-vimeo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-youtube-circular"></i> typcn typcn-social-youtube-circular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-social-youtube"></i> typcn typcn-social-youtube
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-sort-alphabetically-outline"></i> typcn typcn-sort-alphabetically-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-sort-alphabetically"></i> typcn typcn-sort-alphabetically
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-sort-numerically-outline"></i> typcn typcn-sort-numerically-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-sort-numerically"></i> typcn typcn-sort-numerically
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-spanner-outline"></i> typcn typcn-spanner-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-spanner"></i> typcn typcn-spanner
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-spiral"></i> typcn typcn-spiral
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-star-full-outline"></i> typcn typcn-star-full-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-star-half-outline"></i> typcn typcn-star-half-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-star-half"></i> typcn typcn-star-half
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-star-outline"></i> typcn typcn-star-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-star"></i> typcn typcn-star
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-starburst-outline"></i> typcn typcn-starburst-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-starburst"></i> typcn typcn-starburst
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-stopwatch"></i> typcn typcn-stopwatch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-support"></i> typcn typcn-support
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-tabs-outline"></i> typcn typcn-tabs-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-tag"></i> typcn typcn-tag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-tags"></i> typcn typcn-tags
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-th-large-outline"></i> typcn typcn-th-large-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-th-large"></i> typcn typcn-th-large
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-th-list-outline"></i> typcn typcn-th-list-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-th-list"></i> typcn typcn-th-list
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-th-menu-outline"></i> typcn typcn-th-menu-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-th-menu"></i> typcn typcn-th-menu
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-th-small-outline"></i> typcn typcn-th-small-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-th-small"></i> typcn typcn-th-small
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-thermometer"></i> typcn typcn-thermometer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-thumbs-down"></i> typcn typcn-thumbs-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-thumbs-ok"></i> typcn typcn-thumbs-ok
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-thumbs-up"></i> typcn typcn-thumbs-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-tick-outline"></i> typcn typcn-tick-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-tick"></i> typcn typcn-tick
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-ticket"></i> typcn typcn-ticket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-time"></i> typcn typcn-time
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-times-outline"></i> typcn typcn-times-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-times"></i> typcn typcn-times
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-trash"></i> typcn typcn-trash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-tree"></i> typcn typcn-tree
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-upload-outline"></i> typcn typcn-upload-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-upload"></i> typcn typcn-upload
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-user-add-outline"></i> typcn typcn-user-add-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-user-add"></i> typcn typcn-user-add
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-user-delete-outline"></i> typcn typcn-user-delete-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-user-delete"></i> typcn typcn-user-delete
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-user-outline"></i> typcn typcn-user-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-user"></i> typcn typcn-user
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-vendor-android"></i> typcn typcn-vendor-android
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-vendor-apple"></i> typcn typcn-vendor-apple
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-vendor-microsoft"></i> typcn typcn-vendor-microsoft
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-video-outline"></i> typcn typcn-video-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-video"></i> typcn typcn-video
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-volume-down"></i> typcn typcn-volume-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-volume-mute"></i> typcn typcn-volume-mute
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-volume-up"></i> typcn typcn-volume-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-volume"></i> typcn typcn-volume
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-warning-outline"></i> typcn typcn-warning-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-warning"></i> typcn typcn-warning
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-watch"></i> typcn typcn-watch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-waves-outline"></i> typcn typcn-waves-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-waves"></i> typcn typcn-waves
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-cloudy"></i> typcn typcn-weather-cloudy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-downpour"></i> typcn typcn-weather-downpour
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-night"></i> typcn typcn-weather-night
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-partly-sunny"></i> typcn typcn-weather-partly-sunny
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-shower"></i> typcn typcn-weather-shower
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-snow"></i> typcn typcn-weather-snow
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-stormy"></i> typcn typcn-weather-stormy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-sunny"></i> typcn typcn-weather-sunny
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-windy-cloudy"></i> typcn typcn-weather-windy-cloudy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-weather-windy"></i> typcn typcn-weather-windy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-wi-fi-outline"></i> typcn typcn-wi-fi-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-wi-fi"></i> typcn typcn-wi-fi
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-wine"></i> typcn typcn-wine
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-world-outline"></i> typcn typcn-world-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-world"></i> typcn typcn-world
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-zoom-in-outline"></i> typcn typcn-zoom-in-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-zoom-in"></i> typcn typcn-zoom-in
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-zoom-out-outline"></i> typcn typcn-zoom-out-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-zoom-out"></i> typcn typcn-zoom-out
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-zoom-outline"></i> typcn typcn-zoom-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="typcn typcn-zoom"></i> typcn typcn-zoom
                                            </div>

                                        </div> <!-- end row -->

                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->

                    </div><!-- container -->



                <!-- Page Content-->
                <div class="page-content">
                        <!-- end page title end breadcrumb -->
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="mt-0 header-title">Examples</h4>
                                        <p class="text-muted mb-4">Use <code>&lt;i
                                                class="dripicons-zoom-out"&gt;&lt;/i&gt;</code>.
                                        </p>

                                        <div class="row icon-demo-content">
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-alarm"></i> dripicons-alarm
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-align-center"></i> dripicons-align-center
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-align-justify"></i> dripicons-align-justify
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-align-left"></i> dripicons-align-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-align-right"></i> dripicons-align-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-anchor"></i> dripicons-anchor
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-archive"></i> dripicons-archive
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-arrow-down"></i> dripicons-arrow-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-arrow-left"></i> dripicons-arrow-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-arrow-right"></i> dripicons-arrow-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-arrow-thin-down"></i> dripicons-arrow-thin-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-arrow-thin-left"></i> dripicons-arrow-thin-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-arrow-thin-right"></i> dripicons-arrow-thin-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-arrow-thin-up"></i> dripicons-arrow-thin-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-arrow-up"></i> dripicons-arrow-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class=" dripicons-article"></i> dripicons-article
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-backspace"></i> dripicons-backspace
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-basket"></i> dripicons-basket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-basketball"></i> dripicons-basketball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-battery-empty"></i> dripicons-battery-empty
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-battery-full"></i> dripicons-battery-full
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-battery-low"></i> dripicons-battery-low
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-battery-medium"></i> dripicons-battery-medium
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-bell"></i> dripicons-bell
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-blog"></i> dripicons-blog
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-bluetooth"></i> dripicons-bluetooth
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-bold"></i> dripicons-bold
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-bookmark"></i> dripicons-bookmark
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-bookmarks"></i> dripicons-bookmarks
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-box"></i> dripicons-box
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-briefcase"></i> dripicons-briefcase
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-brightness-low"></i> dripicons-brightness-low
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-brightness-max"></i> dripicons-brightness-max
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-brightness-medium"></i> dripicons-brightness-medium
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-broadcast"></i> dripicons-broadcast
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-browser"></i> dripicons-browser
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-browser-upload"></i> dripicons-browser-upload
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-brush"></i> dripicons-brush
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-calendar"></i> dripicons-calendar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-camcorder"></i> dripicons-camcorder
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-camera"></i> dripicons-camera
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-card"></i> dripicons-card
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-cart"></i> dripicons-cart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-checklist"></i> dripicons-checklist
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-checkmark"></i> dripicons-checkmark
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-chevron-down"></i> dripicons-chevron-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-chevron-left"></i> dripicons-chevron-left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-chevron-right"></i> dripicons-chevron-right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-chevron-up"></i> dripicons-chevron-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-clipboard"></i> dripicons-clipboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-clock"></i> dripicons-clock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-clockwise"></i> dripicons-clockwise
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-cloud"></i> dripicons-cloud
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-cloud-download"></i> dripicons-cloud-download
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-cloud-upload"></i> dripicons-cloud-upload
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-code"></i> dripicons-code
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-contract"></i> dripicons-contract
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-contract-2"></i> dripicons-contract-2
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-conversation"></i> dripicons-conversation
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-copy"></i> dripicons-copy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-crop"></i> dripicons-crop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-cross"></i> dripicons-cross
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-crosshair"></i> dripicons-crosshair
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-cutlery"></i> dripicons-cutlery
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-device-desktop"></i> dripicons-device-desktop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-device-mobile"></i> dripicons-device-mobile
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-device-tablet"></i> dripicons-device-tablet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-direction"></i> dripicons-direction
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-disc"></i> dripicons-disc
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-document"></i> dripicons-document
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-document-delete"></i> dripicons-document-delete
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-document-edit"></i> dripicons-document-edit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-document-new"></i> dripicons-document-new
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-document-remove"></i> dripicons-document-remove
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-dot"></i> dripicons-dot
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-dots-2"></i> dripicons-dots-2
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-dots-3"></i> dripicons-dots-3
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-download"></i> dripicons-download
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-duplicate"></i> dripicons-duplicate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-enter"></i> dripicons-enter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-exit"></i> dripicons-exit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-expand"></i> dripicons-expand
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-expand-2"></i> dripicons-expand-2
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-experiment"></i> dripicons-experiment
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-export"></i> dripicons-export
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-feed"></i> dripicons-feed
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-flag"></i> dripicons-flag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-flashlight"></i> dripicons-flashlight
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-folder"></i> dripicons-folder
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-folder-open"></i> dripicons-folder-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-forward"></i> dripicons-forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-gaming"></i> dripicons-gaming
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-gear"></i> dripicons-gear
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-graduation"></i> dripicons-graduation
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-graph-bar"></i> dripicons-graph-bar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-graph-line"></i> dripicons-graph-line
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-graph-pie"></i> dripicons-graph-pie
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-headset"></i> dripicons-headset
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-heart"></i> dripicons-heart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-help"></i> dripicons-help
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-home"></i> dripicons-home
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-hourglass"></i> dripicons-hourglass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-inbox"></i> dripicons-inbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-information"></i> dripicons-information
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-italic"></i> dripicons-italic
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-jewel"></i> dripicons-jewel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-lifting"></i> dripicons-lifting
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-lightbulb"></i> dripicons-lightbulb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-link"></i> dripicons-link
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-link-broken"></i> dripicons-link-broken
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-list"></i> dripicons-list
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-loading"></i> dripicons-loading
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-location"></i> dripicons-location
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-lock"></i> dripicons-lock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-lock-open"></i> dripicons-lock-open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-mail"></i> dripicons-mail
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-map"></i> dripicons-map
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-media-loop"></i> dripicons-media-loop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-media-next"></i> dripicons-media-next
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-media-pause"></i> dripicons-media-pause
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-media-play"></i> dripicons-media-play
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-media-previous"></i> dripicons-media-previous
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-media-record"></i> dripicons-media-record
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-media-shuffle"></i> dripicons-media-shuffle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-media-stop"></i> dripicons-media-stop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-medical"></i> dripicons-medical
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-menu"></i> dripicons-menu
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-message"></i> dripicons-message
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-meter"></i> dripicons-meter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-microphone"></i> dripicons-microphone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-minus"></i> dripicons-minus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-monitor"></i> dripicons-monitor
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-move"></i> dripicons-move
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-music"></i> dripicons-music
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-network-1"></i> dripicons-network-1
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-network-2"></i> dripicons-network-2
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-network-3"></i> dripicons-network-3
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-network-4"></i> dripicons-network-4
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-network-5"></i> dripicons-network-5
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-pamphlet"></i> dripicons-pamphlet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-paperclip"></i> dripicons-paperclip
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-pencil"></i> dripicons-pencil
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-phone"></i> dripicons-phone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-photo"></i> dripicons-photo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-photo-group"></i> dripicons-photo-group
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-pill"></i> dripicons-pill
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-pin"></i> dripicons-pin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-plus"></i> dripicons-plus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-power"></i> dripicons-power
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-preview"></i> dripicons-preview
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-print"></i> dripicons-print
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-pulse"></i> dripicons-pulse
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-question"></i> dripicons-question
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-reply"></i> dripicons-reply
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-reply-all"></i> dripicons-reply-all
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-return"></i> dripicons-return
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-retweet"></i> dripicons-retweet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-rocket"></i> dripicons-rocket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-scale"></i> dripicons-scale
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-search"></i> dripicons-search
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-shopping-bag"></i> dripicons-shopping-bag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-skip"></i> dripicons-skip
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-stack"></i> dripicons-stack
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-star"></i> dripicons-star
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-stopwatch"></i> dripicons-stopwatch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-store"></i> dripicons-store
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-suitcase"></i> dripicons-suitcase
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-swap"></i> dripicons-swap
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-tag"></i> dripicons-tag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-tag-delete"></i> dripicons-tag-delete
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-tags"></i> dripicons-tags
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-thumbs-down"></i> dripicons-thumbs-down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-thumbs-up"></i> dripicons-thumbs-up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-ticket"></i> dripicons-ticket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-time-reverse"></i> dripicons-time-reverse
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-to-do"></i> dripicons-to-do
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-toggles"></i> dripicons-toggles
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-trash"></i> dripicons-trash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-trophy"></i> dripicons-trophy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-upload"></i> dripicons-upload
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-user"></i> dripicons-user
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-user-group"></i> dripicons-user-group
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-user-id"></i> dripicons-user-id
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-vibrate"></i> dripicons-vibrate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-view-apps"></i> dripicons-view-apps
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-view-list"></i> dripicons-view-list
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-view-list-large"></i> dripicons-view-list-large
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-view-thumb"></i> dripicons-view-thumb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-volume-full"></i> dripicons-volume-full
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-volume-low"></i> dripicons-volume-low
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-volume-medium"></i> dripicons-volume-medium
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-volume-off"></i> dripicons-volume-off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-wallet"></i> dripicons-wallet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-warning"></i> dripicons-warning
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-web"></i> dripicons-web
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-weight"></i> dripicons-weight
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-wifi"></i> dripicons-wifi
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-wrong"></i> dripicons-wrong
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-zoom-in"></i> dripicons-zoom-in
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <i class="dripicons-zoom-out"></i> dripicons-zoom-out
                                            </div>
                                        </div>
                                    </div> <!-- card-body-->
                                </div><!--end card-->
                            </div> <!-- end col -->
                        </div> <!-- end row -->

                    </div><!-- container -->



                <!-- Page Content-->
                <div class="page-content">

                        <!-- end page title end breadcrumb -->
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="mt-0 header-title">SVG 图标</h4>
                                        <p class="text-muted mb-4">Use SVG Icons.</p>

                                        <div class="row icon-demo-content">
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M416 277.333H277.333V416h-42.666V277.333H96v-42.666h138.667V96h42.666v138.667H416v42.666z"/>
                                                </svg>
                                                Add
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M256 48C141.125 48 48 141.125 48 256s93.125 208 208 208 208-93.125 208-208S370.875 48 256 48zm107 229h-86v86h-42v-86h-86v-42h86v-86h42v86h86v42z"/>
                                                </svg>
                                                Add Circle
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M448 336v-40L288 192V79.2c0-17.7-14.8-31.2-32-31.2s-32 13.5-32 31.2V192L64 296v40l160-48v113.6l-48 31.2V464l80-16 80 16v-31.2l-48-31.2V288l160 48z"/>
                                                </svg>
                                                Airplane
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M256 48C141.6 48 48 141.601 48 256s93.6 208 208 208 208-93.601 208-208S370.4 48 256 48zm24 312h-48v-40h48v40zm0-88h-48V144h48v128z"/>
                                                </svg>
                                                Alert
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M96 176h80V96H96v80zm120 240h80v-80h-80v80zm-120 0h80v-80H96v80zm0-120h80v-80H96v80zm120 0h80v-80h-80v80zM336 96v80h80V96h-80zm-120 80h80V96h-80v80zm120 120h80v-80h-80v80zm0 120h80v-80h-80v80z"/>
                                                </svg>
                                                Apps
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M464 152H360c0-57-46.562-103.859-104-103.859S152 95 152 152H48c18.688 216 13 312 13 312h389.999c-.001 0-5.688-98 13.001-312zM256 74.105c43.008 0 77.999 34.895 77.999 77.895H178c0-43 34.991-77.895 78-77.895zM204 397.64V228.867l142.999 84.387L204 397.64z"/>
                                                </svg>
                                                Appstore
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M453.594 100.001l-32.353-39.299C415.469 52.627 405.083 48 394.664 48H117.335c-10.416 0-20.801 4.627-26.576 12.702l-32.351 39.299C51.468 106.923 48 117.335 48 128.886v288.89C48 443.2 68.8 464 94.225 464h323.553C443.202 464 464 443.2 464 417.775v-288.89c0-11.55-3.463-21.962-10.406-28.884zM256 383.109L128.89 256h80.89v-46.224h92.443V256h80.89L256 383.109zM96.534 94.221L115.02 71.11h277.331l21.965 23.111H96.534z"/>
                                                </svg>
                                                Archive
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M427 234.625H167.296l119.702-119.702L256 85 85 256l171 171 29.922-29.924-118.626-119.701H427v-42.75z"/>
                                                </svg>
                                                Arrow Back
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M277.375 85v259.704l119.702-119.702L427 256 256 427 85 256l29.924-29.922 119.701 118.626V85h42.75z"/>
                                                </svg>
                                                Arrow Down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M128 192l128 128 128-128z"/>
                                                </svg>
                                                Arrow Dropdown
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M256 48C141.125 48 48 141.125 48 256s93.125 208 208 208 208-93.125 208-208S370.875 48 256 48zm0 272l-96-96h192l-96 96z"/>
                                                </svg>
                                                Arrow Dropdown-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M320 128L192 256l128 128z"/>
                                                </svg>
                                                Arrow Dropleft
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M464 256c0-114.875-93.125-208-208-208S48 141.125 48 256s93.125 208 208 208 208-93.125 208-208zm-272 0l96-96v192l-96-96z"/>
                                                </svg>
                                                Arrow Dropleft-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M192 128l128 128-128 128z"/>
                                                </svg>
                                                Arrow Dropright
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M256 464c114.875 0 208-93.125 208-208S370.875 48 256 48 48 141.125 48 256s93.125 208 208 208zm-32-112V160l96 96-96 96z"/>
                                                </svg>
                                                Arrow Dropright-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M128 320l128-128 128 128z"/>
                                                </svg>
                                                Arrow Dropup
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M464 256c0-114.875-93.125-208-208-208S48 141.125 48 256s93.125 208 208 208 208-93.125 208-208zm-112 32H160l96-96 96 96z"/>
                                                </svg>
                                                Arrow Dropup-circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M85 277.375h259.704L225.002 397.077 256 427l171-171L256 85l-29.922 29.924 118.626 119.701H85v42.75z"/>
                                                </svg>
                                                Arrow Forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M401.4 224h-214l83-79.4c11.9-12.5 11.9-32.7 0-45.2s-31.2-12.5-43.2 0L89 233.4c-6 5.8-9 13.7-9 22.4v.4c0 8.7 3 16.6 9 22.4l138.1 134c12 12.5 31.3 12.5 43.2 0 11.9-12.5 11.9-32.7 0-45.2l-83-79.4h214c16.9 0 30.6-14.3 30.6-32 .1-18-13.6-32-30.5-32z"/>
                                                </svg>
                                                Arrow Round Back
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M99.4 284.9l134 138.1c5.8 6 13.7 9 22.4 9h.4c8.7 0 16.6-3 22.4-9l134-138.1c12.5-12 12.5-31.3 0-43.2-12.5-11.9-32.7-11.9-45.2 0l-79.4 83v-214c0-16.9-14.3-30.6-32-30.6-18 0-32 13.7-32 30.6v214l-79.4-83c-12.5-11.9-32.7-11.9-45.2 0s-12.5 31.2 0 43.2z"/>
                                                </svg>
                                                Arrow Round Down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M284.9 412.6l138.1-134c6-5.8 9-13.7 9-22.4v-.4c0-8.7-3-16.6-9-22.4l-138.1-134c-12-12.5-31.3-12.5-43.2 0-11.9 12.5-11.9 32.7 0 45.2l83 79.4h-214c-17 0-30.7 14.3-30.7 32 0 18 13.7 32 30.6 32h214l-83 79.4c-11.9 12.5-11.9 32.7 0 45.2 12 12.5 31.3 12.5 43.3 0z"/>
                                                </svg>
                                                Arrow Round Forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M412.6 227.1L278.6 89c-5.8-6-13.7-9-22.4-9h-.4c-8.7 0-16.6 3-22.4 9l-134 138.1c-12.5 12-12.5 31.3 0 43.2 12.5 11.9 32.7 11.9 45.2 0l79.4-83v214c0 16.9 14.3 30.6 32 30.6 18 0 32-13.7 32-30.6v-214l79.4 83c12.5 11.9 32.7 11.9 45.2 0s12.5-31.2 0-43.2z"/>
                                                </svg>
                                                Arrow Round Up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M277.375 427V167.296l119.702 119.702L427 256 256 85 85 256l29.924 29.922 119.701-118.626V427h42.75z"/>
                                                </svg>
                                                Arrow Up
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M341.334 128v234.666C341.334 409.604 302.938 448 256 448c-46.937 0-85.333-38.396-85.333-85.334V117.334C170.667 87.469 194.135 64 224 64c29.864 0 53.333 23.469 53.333 53.334v245.333c0 11.729-9.605 21.333-21.334 21.333s-21.333-9.604-21.333-21.333V160h-32v202.667C202.667 392.531 226.135 416 256 416c29.865 0 53.334-23.469 53.334-53.333V117.334C309.334 70.401 270.938 32 224 32s-85.334 38.401-85.334 85.334v245.332C138.667 427.729 190.938 480 256 480c65.062 0 117.334-52.271 117.334-117.334V128h-32z"/>
                                                </svg>
                                                Attach
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M433.5 96H167.2c-12.2 0-21.8 6.2-28.2 15.6L43 256l96 144.2c6.4 9.4 16 15.8 28.2 15.8h266.2c19.5 0 35.5-16 35.5-35.6V131.6C469 112 453 96 433.5 96zm-53.3 223.8l-25 25.1-63.7-63.8-63.7 63.8-25-25.1 63.7-63.8-63.7-63.8 25-25.1 63.7 63.8 63.7-63.8 25 25.1-63.7 63.8 63.7 63.8z"/>
                                                </svg>
                                                Backspace
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M362.1 205.2L272.9 72.5C269 66.8 262.5 64 256 64c-6.5 0-13 2.8-16.9 8.7l-89.2 132.5H52.4c-11.2 0-20.4 9.1-20.4 20.2 0 1.8.2 3.6.8 5.5l51.7 187.5c4.7 17 20.4 29.5 39.1 29.5h264.7c18.7 0 34.4-12.5 39.3-29.5l51.7-187.5.6-5.5c0-11.1-9.2-20.2-20.4-20.2h-97.4zm-167.2 0l61.1-89 61.1 89H194.9zM256 367.1c-22.4 0-40.7-18.2-40.7-40.5s18.3-40.5 40.7-40.5 40.7 18.2 40.7 40.5-18.3 40.5-40.7 40.5z"/>
                                                </svg>
                                                Basket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M191.6 272c-3.8 55-26.4 107.1-64.5 147.7 31.6 25 70.9 41 112.9 44.3V272h-48.4zM272 464c42-3.3 81.5-19.4 113.1-44.5-38-40.6-60.5-92.5-64.3-147.5H272v192zM240 48c-42 3.2-80.5 19-111.9 43.6 38 40.9 60.3 93.4 63.7 148.4H240V48zM320.7 240c3.4-55 25.6-107.4 63.5-148.3C352.7 67.1 314 51.2 272 48v192h48.7zM408.6 114.2c-17.2 18.5-30.7 39.7-40.1 62.9-8.2 20.2-13.1 40.9-14.6 62.9H464c-3.7-48-24.1-92.2-55.4-125.8zM368.5 333.1c9.6 23.7 23.3 45.1 40.9 63.8C440.3 363.4 460.3 320 464 272H354.1c1.6 21 6.5 41.5 14.4 61.1zM143.9 177.1c-9.5-23.3-23-44.5-40.3-63.1-31.4 33.6-51.9 78-55.6 126h110.5c-1.6-22-6.5-42.8-14.6-62.9zM102.7 397.1c17.7-18.8 31.5-40.3 41.1-64 8-19.6 12.8-40.1 14.5-61.1H48c3.7 48 23.8 91.6 54.7 125.1z"/>
                                                </svg>
                                                Basketball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M338.2 76.8h-37.4V32h-89.6v44.8h-37.4c-16.4 0-29.8 13.4-29.8 29.8V450c0 16.6 13.4 30 29.8 30H338c16.6 0 30-13.4 30-29.8V106.6c0-16.4-13.4-29.8-29.8-29.8zM233.6 435.2V312h-44.8l89.6-168v123.2h44.8l-89.6 168z"/>
                                                </svg>
                                                Battery Charging
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M338.2 76.8h-37.4V32h-89.6v44.8h-37.4c-16.4 0-29.8 13.4-29.8 29.8V450c0 16.6 13.4 30 29.8 30H338c16.6 0 30-13.4 30-29.8V106.6c0-16.4-13.4-29.8-29.8-29.8zM320 432H192V124.8h128V432z"/>
                                                </svg>
                                                Battery Dead
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M338.2 76.8h-37.4V32h-89.6v44.8h-37.4c-16.4 0-29.8 13.4-29.8 29.8V450c0 16.6 13.4 30 29.8 30H338c16.6 0 30-13.4 30-29.8V106.6c0-16.4-13.4-29.8-29.8-29.8z"/>
                                                </svg>
                                                Battery Full
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M168.7 264.5c29 0 52.4-22.9 52.4-51.2s-23.4-51.2-52.4-51.2-52.4 22.9-52.4 51.2 23.5 51.2 52.4 51.2zm209.5-102.4H238.5v119.5H98.9V128H64v256h34.9v-51.2h314.2V384H448V230.4c0-37.7-31.2-68.3-69.8-68.3z"/>
                                                </svg>
                                                Bed
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M416 140h-16v-6c8.9-9 16-22.9 16-38 0-35.3-28.7-64-64-64-16.3 0-31.1 6.1-42.4 16.1C297.2 38 281.4 32 264.2 32c-15.8 0-30.4 5.1-42.3 13.7C212 37.2 199 32 184.9 32c-17.1 0-32.4 7.6-42.8 19.5-11.7-12-28-19.5-46.1-19.5-35.3 0-64 28.7-64 64 0 16.2 6.1 31 16 42.3V193c0 26.5 21.5 48 48 48v174.5c0 35.3 28.8 64.5 64.2 64.5H336c35.3 0 64.1-29.2 64.1-64.5V372h16c50 0 64-32.7 64-68v-96c-.1-35.3-17.1-68-64.1-68zm-64 52H144v-53.7c.3-.4.7-.8 1-1.2 1.2-1.5 2.4-3 3.5-4.6 1.5 1.2 3 2.4 4.6 3.4 9.1 6.1 20 9.7 31.7 9.7 6.4 0 12.6-1.1 18.3-3 12.8 20.2 35.3 33.7 61 33.7 22 0 41.7-9.9 54.9-25.4 5.7-6.7 10.2-14.4 13.1-22.9H352v64zM96 128.1v75c-9 0-16-7.2-16-16v-63.3c-8-4.5-13.4-12.1-15.3-21-.5-2.1-.7-4.4-.7-6.7 0-17.6 14.4-32 32-32 11.8 0 23.3 7.7 30.1 15.4s26.7 7.7 33.9 0c6.8-7.3 14.3-15.4 24.8-15.4 6 0 11.6 2.2 15.9 5.8 1.9 1.6 3.6 3.5 4.9 5.6 1.1 1.8 2 4.2 3.1 5.8 2.7 3.4 6.5 5.5 11.2 5.5 4.4 0 8.3-1.9 11-5 .6-.7 1.2-1.5 1.7-2.3 2-2.5 4.2-4.8 6.7-6.8 6.8-5.4 15.5-8.6 24.8-8.6 10.6 0 20.2 4.1 27.4 10.9 1.7 1.6 6.7 4.5 13.2 5.1 4.5.4 6.1.3 8.2 0 10.3-1.3 14.4-4.7 16.4-6.6 5.8-5.8 13.8-9.4 22.6-9.4 17.6 0 32 14.4 32 32 .2 3.1-.3 6.2-1.2 9.1-2.5-5.5-8.1-9.2-14.6-9.2h-55s-8.7-.7-8.7 8.2c0 8.9-2.9 17.1-7.8 23.7-7.3 9.9-19.1 16.4-32.4 16.4-14.9 0-27.9-8.1-34.8-20.2-1.6-2.7-2.8-5.6-3.7-8.6-.1-.6-.3-1.1-.4-1.6-2-5.9-7.5-10.2-14.1-10.2-3.9 0-7.5 1.5-10.2 4l-.1.1c-2.4 2.1-5.3 3.7-8.4 4.7-2.4.8-5 1.2-7.7 1.2-7.5 0-14.7-4-18.8-8.6-10-11.4-23.7-6.8-29.7-5.5-6 1.3-12.2 11.7-12.2 11.7-1.1 2.1-2.4 4-3.9 5.8-6 6.7-15.2 11-24.2 11zM432 304c0 17.7-6.3 24-24 24h-8V184h8c17.7 0 24 6.3 24 24v96z"/>
                                                </svg>
                                                Beer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M330.666 131.202c18.668 0 33.598-14.935 33.598-33.601S349.334 64 330.666 64C312 64 297.07 78.935 297.07 97.601s14.93 33.601 33.596 33.601zm56 130.132c-51.332 0-93.332 42-93.332 93.333s42 93.333 93.332 93.333C438 448 480 406 480 354.667s-42-93.333-93.334-93.333zm0 158.666c-36.402 0-65.332-28.93-65.332-65.333s28.93-65.333 65.332-65.333c36.404 0 65.334 28.93 65.334 65.333S423.07 420 386.666 420zm-81.069-196H384v-32h-58.845l-34.62-60.134c-5.605-9.333-15.869-15.864-27.07-15.864-8.399 0-16.798 3.732-22.399 9.333L169.334 194.4c-5.601 5.601-9.333 14-9.333 22.399 0 12.131 9.202 21.465 18.535 27.065L240 282.134V368h32V256l-39.333-32 42.929-44.533L305.597 224zm-180.264 37.334C74 261.334 32 303.334 32 354.667S74 448 125.333 448s93.333-42 93.333-93.333-41.999-93.333-93.333-93.333zm0 158.666C88.934 420 60 391.07 60 354.667s28.934-65.333 65.333-65.333 65.333 28.93 65.333 65.333S161.732 420 125.333 420z"/>
                                                </svg>
                                                Bicycle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M399 159.9L270.5 32H248v170L144.7 99.2 113 130.8 238.8 256 113 381.2l31.7 31.6L248 310v170h22.5L399 352.1 302.2 256l96.8-96.1zm-106-42.1l42.3 42.1L293 202v-84.2zm42.3 234.3L293 394.2V310l42.3 42.1z"/>
                                                </svg>
                                                Bluetooth
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M256 48c22 0 40 18 40 40s-18 40-40 40-40-18-40-40 18-40 40-40zm192 144.1H320V464h-42.7V320h-42.7v144H192V192.1H64v-42.7h384v42.7z"/>
                                                </svg>
                                                Body
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M272.2 350.6c-.8-8.2-8.2-14.6-17.3-14.6-8.3 0-15.2 5.4-16.9 12.5L221.1 441c-.5 2.3-.8 4.6-.8 7 0 17.7 15.5 32 34.7 32s34.7-14.3 34.7-32c0-2.9-.4-5.7-1.2-8.4l-16.3-89zM310.1 355zM404.3 390.3c-1.9-1.4-3.6-2.9-5.6-3.9l-68.9-47.5c-6.3-3.8-13-3.7-17.9.9-4.5 4.1-5.1 10.4-1.8 15.4l53 65.8c1 1.5 2.3 2.8 3.6 4.2 8.5 9.1 27.2 9.6 37.5 0 10.4-9.8 10.3-27.2.1-34.9zM382.2 335zM450.4 322.5l-64.5-2.3c-4.2-.6-8 2.1-8.7 6-.7 3.6 1.5 7.1 5.1 8.8h.1l62.5 17.8c9 1.9 19.1-2.3 19.1-11.6 0-11.9-3.3-17.5-13.6-18.7zM129.5 335zM129.5 335c3.6-1.6 5.7-5.2 5.1-8.8-.7-4-4.5-6.6-8.7-6l-64.5 2.3C51 323.7 48 329.3 48 341.1c0 9.3 9.9 13.6 18.8 11.6l62.5-17.8c.1.1.1.1.2.1zM182.2 338.8l-68.9 47.4c-2 1.1-3.9 2.4-5.6 3.9-10.4 9.6-10.4 25.1 0 34.6 10.4 9.6 27.1 9.6 37.5 0 1.4-1.3 2.6-2.7 3.6-4.2l53-65.6c3.3-5 2.7-11.2-1.8-15.3-4.8-4.5-12.6-4.8-17.8-.8zM256 32s30.2 35.4 30.2 64.4c0 27.8-18.2 50.3-45.9 50.3-27.9 0-48.9-22.5-48.9-50.3l.4-6.9c-27.2 32.3-43.5 76.2-43.5 121.8 0 59.6 48.2 107.8 107.8 107.8s107.8-48.2 107.8-107.8C363.8 138.7 328 53.7 256 32zm-3.9 246.7c-24 0-43.4-18.9-43.4-42.3 0-21.8 14.1-37.2 37.9-42 23.8-4.9 48.5-16.3 62.3-34.8 5.3 17.4 7.9 35.7 7.9 54.4 0 35.7-29 64.7-64.7 64.7z"/>
                                                </svg>
                                                Bonfire
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M426.2 80.4l-170.2 32-170.2-32C64 77 48 97.3 48 118v244.5c0 20.7 16 32.6 37.8 37.6L256 432l170.2-32c21.8-5 37.8-16.9 37.8-37.6V118c0-20.7-16-41-37.8-37.6zm0 282l-151.2 32V149.9l151.2-32v244.5zm-189.2 32l-151.2-32V118L237 150v244.4z"/>
                                                </svg>
                                                Book
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M360 64H152c-22.002 0-40 17.998-40 40v344l144-64 144 64V104c0-22.002-17.998-40-40-40z"/>
                                                </svg>
                                                Bookmark
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M405.2 64h-21c15 5.7 22.8 20.6 22.8 42.7v298.7c0 22.1-7 37.3-22.8 42.7h21c23.7 0 42.8-19.2 42.8-42.7V106.7c0-23.5-19.1-42.7-42.8-42.7zM345.5 64.2c-1.4-.1-2.8-.2-4.2-.2H106.7C83.2 64 64 83.2 64 106.7v298.7c0 23.5 19.2 42.7 42.7 42.7h234.7c1.4 0 2.8-.1 4.2-.2 21.5-2.1 38.5-20.4 38.5-42.5V106.7c-.1-22.1-17.1-40.4-38.6-42.5zM208 256l-56-32-56 32V96h112v160z"/>
                                                </svg>
                                                Bookmarks
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M276 304h-40c-15.4 0-28-12.6-28-28v-40c0-15.4 12.6-28 28-28h40c15.4 0 28 12.6 28 28v40c0 15.4-12.6 28-28 28zM176 280v-48c0-18.2 8.7-34.4 22.2-44.6C192 160 96 96 64 96c-17.6 0-32 14.4-32 32v256c0 17.6 14.3 32 32 32 32 0 128-64 134.2-91.4-13.5-10.2-22.2-26.4-22.2-44.6zM448 96c-32 0-128 64-134.2 91.4 13.5 10.2 22.2 26.4 22.2 44.6v48c0 18.2-8.7 34.4-22.2 44.6C320 352 416 416 448 416c17.7 0 32-14.4 32-32V128c0-17.6-14.4-32-32-32z"/>
                                                </svg>
                                                Bowtie
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M352 144v-39.6C352 82 334 64 311.6 64H200.4C178 64 160 82 160 104.4V144H48v263.6C48 430 66 448 88.4 448h335.2c22.4 0 40.4-18 40.4-40.4V144H352zm-40 0H200v-40h112v40z"/>
                                                </svg>
                                                Briefcase
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M424 64H88c-26.6 0-48 21.6-48 48v288c0 26.4 21.4 48 48 48h336c26.4 0 48-21.6 48-48V112c0-26.4-21.4-48-48-48zm0 336H88V176h336v224z"/>
                                                </svg>
                                                Browsers
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M149.9 302.2c-39.1 0-70.7 31-70.7 69.3 0 30.3-27.3 46.2-47.2 46.2C53.7 446 90.7 464 126.3 464c52.1 0 94.3-41.4 94.3-92.4 0-38.4-31.6-69.4-70.7-69.4zM473.1 85.7l-31.6-31c-9.2-9-24-9-33.2 0L197 261.8l64.8 63.5 211.2-207c9.3-9 9.3-23.6.1-32.6z"/>
                                                </svg>
                                                Brush
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M448 160h-67.4c-10.8-18.7-25.7-34.8-43.7-47L376 73.8 342.2 40l-52.1 52.1C279 89.4 267.8 88 256 88s-23 1.4-33.8 4.1L169.8 40 136 73.8l38.9 39.1c-17.8 12.2-32.6 28.3-43.4 47H64v48h50.2c-1.2 7.9-2.2 15.8-2.2 24v24H64v48h48v24c0 8.2 1 16.1 2.2 24H64v48h67.4c25 43 71.3 72 124.6 72s99.6-29 124.6-72H448v-48h-50.2c1.2-7.9 2.2-15.8 2.2-24v-24h48v-48h-48v-24c0-8.2-1-16.1-2.2-24H448V160z"/>
                                                </svg>
                                                Bug
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M474.1 398.2L289.1 212c18.3-47 8.1-102.3-30.5-141.1C217.9 30 156.9 21.8 108.1 44.3l87.4 88-61 61.4-89.5-88c-24.3 49-14.1 110.4 26.5 151.3 38.6 38.9 93.5 49.1 140.3 30.7l185 186.2c8.1 8.2 20.3 8.2 28.5 0l46.8-47c10.2-8.3 10.2-22.6 2-28.7z"/>
                                                </svg>
                                                Build
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M192 428c0 10.6 8.6 20 20 20h88c11.4 0 20-9.4 20-20v-18H192v18zm64-364c-79.7 0-144 59.9-144 134 0 45.7 24.1 86.2 61.4 110.6V352c0 10.6 9.3 19.2 20.6 19.2h123.9c11.4 0 20.6-8.6 20.6-19.2v-43.4C375.9 284.2 400 243.7 400 198c0-74.1-64.3-134-144-134z"/>
                                                </svg>
                                                Bulb
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M80 352c0 19.198 13.864 24.531 26.667 36.271v38.396c0 11.729 9.599 21.334 21.333 21.334h21.333c11.734 0 21.334-9.604 21.334-21.334v-21.333h170.666v21.333c0 11.729 9.604 21.334 21.334 21.334H384c11.729 0 21.333-9.604 21.333-21.334v-38.396C418.136 376.531 432 370.136 432 352V148.334C432 73.667 349.864 64 256 64S80 73.667 80 148.334V352zm80 15.989c-18.136 0-32-13.864-32-32 0-18.135 13.864-32 32-32s32 13.865 32 32c0 18.136-13.864 32-32 32zm192 0c-18.136 0-32-13.864-32-32 0-18.135 13.864-32 32-32s32 13.865 32 32c0 18.136-13.864 32-32 32zm32-122.656H128V138.667h256v106.666z"/>
                                                </svg>
                                                Bus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M261 149.3V64H48v384h416V149.3H261zm-127.8 256H90.6v-42.7h42.6v42.7zm0-85.3H90.6v-42.7h42.6V320zm0-85.3H90.6V192h42.6v42.7zm0-85.4H90.6v-42.7h42.6v42.7zm85.2 256h-42.6v-42.7h42.6v42.7zm0-85.3h-42.6v-42.7h42.6V320zm0-85.3h-42.6V192h42.6v42.7zm0-85.4h-42.6v-42.7h42.6v42.7zm203 256H261v-42.7h42.6V320H261v-42.7h42.6v-42.7H261V192h160.4v213.3zm-37.6-170.6h-42.6v42.7h42.6v-42.7zm0 85.3h-42.6v42.7h42.6V320z"/>
                                                </svg>
                                                Business
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M48 400h368v48H48zM424 64H80v224c0 44 36 80 80 80h144c44 0 80-36 80-80v-64h40c22 0 40-18 40-40v-80c0-22-18-40-40-40zm0 112h-40v-64h40v64z"/>
                                                </svg>
                                                Cafe
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M368 48H144c-26.6 0-48 21.6-48 48v320c0 26.4 21.4 48 48 48h224c26.4 0 48-21.6 48-48V96c0-26.4-21.4-48-48-48zM200 416h-48v-48h48v48zm0-88h-48v-48h48v48zm0-88h-48v-48h48v48zm80 176h-48v-48h48v48zm0-88h-48v-48h48v48zm0-88h-48v-48h48v48zm80 176h-48V280h48v136zm0-176h-48v-48h48v48zm0-96H152V96h208v48z"/>
                                                </svg>
                                                Calculator
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M368.005 272h-96v96h96v-96zm-32-208v32h-160V64h-48v32h-24.01c-22.002 0-40 17.998-40 40v272c0 22.002 17.998 40 40 40h304.01c22.002 0 40-17.998 40-40V136c0-22.002-17.998-40-40-40h-24V64h-48zm72 344h-304.01V196h304.01v212z"/>
                                                </svg>
                                                Calendar
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M426.666 330.667a250.385 250.385 0 0 1-75.729-11.729c-7.469-2.136-16-1.073-21.332 5.333l-46.939 46.928c-60.802-30.928-109.864-80-140.802-140.803l46.939-46.927c5.332-5.333 7.462-13.864 5.332-21.333-8.537-24.531-12.802-50.136-12.802-76.803C181.333 73.604 171.734 64 160 64H85.333C73.599 64 64 73.604 64 85.333 64 285.864 226.136 448 426.666 448c11.73 0 21.334-9.604 21.334-21.333V352c0-11.729-9.604-21.333-21.334-21.333z"/>
                                                </svg>
                                                Call
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M403.208 117.333c-4.271-12.802-16-21.333-29.875-21.333H138.667c-13.875 0-25.604 8.531-29.875 21.333L64 234.667v160C64 406.396 73.604 416 85.333 416h21.334c11.729 0 21.333-9.604 21.333-21.333V384h256v10.667c0 11.729 9.604 21.333 21.333 21.333h21.334c11.729 0 21.333-9.604 21.333-21.333v-160l-44.792-117.334zM138.667 320c-18.125 0-32-13.865-32-32s13.875-32 32-32 32 13.866 32 32-13.875 32-32 32zm234.666 0c-18.125 0-32-13.865-32-32s13.875-32 32-32 32 13.866 32 32-13.875 32-32 32zM106.667 213.333l32-85.333h234.666l32 85.333H106.667z"/>
                                                </svg>
                                                Car
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M435.2 80H76.8c-24.9 0-44.6 19.6-44.6 44L32 388c0 24.4 19.9 44 44.8 44h358.4c24.9 0 44.8-19.6 44.8-44V124c0-24.4-19.9-44-44.8-44zm0 308H76.8V256h358.4v132zm0-220H76.8v-44h358.4v44z"/>
                                                </svg>
                                                Card
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M169.6 377.6c-22.882 0-41.6 18.718-41.6 41.601 0 22.882 18.718 41.6 41.6 41.6s41.601-18.718 41.601-41.6c-.001-22.884-18.72-41.601-41.601-41.601zM48 51.2v41.6h41.6l74.883 151.682-31.308 50.954c-3.118 5.2-5.2 12.482-5.2 19.765 0 27.85 19.025 41.6 44.825 41.6H416v-40H177.893c-3.118 0-5.2-2.082-5.2-5.2 0-1.036 2.207-5.2 2.207-5.2l20.782-32.8h154.954c15.601 0 29.128-8.317 36.4-21.836l74.882-128.8c1.237-2.461 2.082-6.246 2.082-10.399 0-11.446-9.364-19.765-20.8-19.765H135.364L115.6 51.2H48zm326.399 326.4c-22.882 0-41.6 18.718-41.6 41.601 0 22.882 18.718 41.6 41.6 41.6S416 442.082 416 419.2c0-22.883-18.719-41.6-41.601-41.6z"/>
                                                </svg>
                                                Cart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M32 96v256h448V96H32zm160.5 224h-80.4c0-26.6-21.5-48.1-48.1-48.1V192c35.3 0 64-28.7 64-64h64.5c-19.9 23.5-32.5 57.8-32.5 96s12.6 72.5 32.5 96zM448 271.9c-26 0-48 21.5-48 48.1h-80.5c19.9-23.5 32.5-57.8 32.5-96s-12.6-72.5-32.5-96H384c0 35.3 28.7 64 64 64v79.9zM32 384h448v32H32z"/>
                                                </svg>
                                                Cash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M64 448h384V64L64 448z"/>
                                                </svg>
                                                Cellular
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M405.333 64H106.667C83.198 64 64 83.198 64 106.667v298.666C64 428.802 83.198 448 106.667 448h298.666C428.802 448 448 428.802 448 405.333V106.667C448 83.198 428.802 64 405.333 64zm-192 298.667L106.667 256l29.864-29.864 76.802 76.802 162.136-162.136 29.864 29.865-192 192z"/>
                                                </svg>
                                                Checkbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M168.531 215.469l-29.864 29.864 96 96L448 128l-29.864-29.864-183.469 182.395-66.136-65.062zm236.802 189.864H106.667V106.667H320V64H106.667C83.198 64 64 83.198 64 106.667v298.666C64 428.802 83.198 448 106.667 448h298.666C428.802 448 448 428.802 448 405.333V234.667h-42.667v170.666z"/>
                                                </svg>
                                                Checkbox Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M186.301 339.893L96 249.461l-32 30.507L186.301 402 448 140.506 416 110z"/></svg>
                                                Checkark
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.6 48 48 141.6 48 256s93.6 208 208 208 208-93.6 208-208S370.4 48 256 48zm-42.7 318.9L106.7 260.3l29.9-29.9 76.8 76.8 162.1-162.1 29.9 29.9-192.1 191.9z"/></svg>
                                                Checkmark Circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M170.718 216.482L141.6 245.6l93.6 93.6 208-208-29.118-29.118L235.2 279.918l-64.482-63.436zM422.4 256c0 91.518-74.883 166.4-166.4 166.4S89.6 347.518 89.6 256 164.482 89.6 256 89.6c15.6 0 31.2 2.082 45.764 6.241L334 63.6C310.082 53.2 284.082 48 256 48 141.6 48 48 141.6 48 256s93.6 208 208 208 208-93.6 208-208h-41.6z"/></svg>
                                                Checkmark Circle Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M405.333 80h-87.35C310.879 52.396 285.821 32 256 32s-54.879 20.396-61.983 48h-87.35C83.198 80 64 99.198 64 122.667v314.665C64 460.801 83.198 480 106.667 480h298.666C428.802 480 448 460.801 448 437.332V122.667C448 99.198 428.802 80 405.333 80zM256 80c11.729 0 21.333 9.599 21.333 21.333s-9.604 21.334-21.333 21.334-21.333-9.6-21.333-21.334S244.271 80 256 80zm152 360H104V120h40v72h224v-72h40v320z"/></svg>
                                                Clipboard
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M403.1 108.9c-81.2-81.2-212.9-81.2-294.2 0-81.3 81.2-81.2 212.9 0 294.2 81.2 81.2 212.9 81.2 294.2 0 81.2-81.2 81.2-213 0-294.2zm-16.5 53.2c7.6-4.4 17.5-1.8 21.9 5.9 4.4 7.6 1.8 17.5-5.9 21.9-7.6 4.4-17.5 1.8-21.9-5.9-4.4-7.6-1.8-17.5 5.9-21.9zM80 256c0-8.8 7.2-16 16-16s16 7.2 16 16-7.2 16-16 16-16-7.2-16-16zm45.4 93.9c-7.6 4.4-17.5 1.8-21.9-5.9-4.4-7.6-1.8-17.5 5.9-21.9 7.6-4.4 17.5-1.8 21.9 5.9 4.4 7.6 1.8 17.5-5.9 21.9zm5.9-165.9c-4.4 7.6-14.2 10.3-21.9 5.9-7.6-4.4-10.3-14.2-5.9-21.9 4.4-7.6 14.2-10.3 21.9-5.9 7.7 4.4 10.3 14.3 5.9 21.9zm36.7-80.4c7.6-4.4 17.5-1.8 21.9 5.9 4.4 7.6 1.8 17.5-5.9 21.9s-17.5 1.8-21.9-5.9c-4.4-7.7-1.7-17.5 5.9-21.9zm-7.8 110.7l15.6-26.6 95.2 56.9V384h-31V260.6l-79.8-46.3zm29.7 188.3c-4.4 7.6-14.2 10.3-21.9 5.9s-10.3-14.2-5.9-21.9c4.4-7.6 14.2-10.3 21.9-5.9 7.6 4.4 10.3 14.2 5.9 21.9zM256 432c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16-7.2 16-16 16zm0-320c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16-7.2 16-16 16zm88 296.4c-7.6 4.4-17.5 1.8-21.9-5.9-4.4-7.6-1.8-17.5 5.9-21.9 7.6-4.4 17.5-1.8 21.9 5.9 4.4 7.7 1.7 17.5-5.9 21.9zm5.9-283c-4.4 7.6-14.2 10.3-21.9 5.9s-10.3-14.2-5.9-21.9c4.4-7.6 14.2-10.3 21.9-5.9s10.3 14.3 5.9 21.9zM408.4 344c-4.4 7.6-14.2 10.3-21.9 5.9-7.6-4.4-10.3-14.2-5.9-21.9 4.4-7.6 14.2-10.3 21.9-5.9 7.7 4.4 10.3 14.3 5.9 21.9zm7.6-72c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16-7.2 16-16 16z"/></svg>
                                                Clock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M405 136.798L375.202 107 256 226.202 136.798 107 107 136.798 226.202 256 107 375.202 136.798 405 256 285.798 375.202 405 405 375.202 285.798 256z"/></svg>
                                                Close
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C140.559 48 48 140.559 48 256c0 115.436 92.559 208 208 208 115.435 0 208-92.564 208-208 0-115.441-92.564-208-208-208zm104.002 282.881l-29.12 29.117L256 285.117l-74.881 74.881-29.121-29.117L226.881 256l-74.883-74.881 29.121-29.116L256 226.881l74.881-74.878 29.12 29.116L285.119 256l74.883 74.881z"/></svg>
                                                Close Circle
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M403.002 217.001C388.998 148.002 328.998 96 256 96c-57.998 0-107.998 32.998-132.998 81.001C63.002 183.002 16 233.998 16 296c0 65.996 53.999 120 120 120h260c55 0 100-45 100-100 0-52.998-40.996-96.001-92.998-98.999z"/></svg>
                                                Cloud
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.6 48 48 141.6 48 256s93.6 208 208 208 208-93.6 208-208S370.4 48 256 48zm93.6 291.2H172.801c-34.318 0-62.4-28.082-62.4-62.399 0-34.319 28.082-62.4 62.4-62.4h3.117c9.364-36.4 41.601-62.399 80.083-62.399 45.764 0 83.199 37.435 83.199 83.198h10.4c29.118 0 52 22.882 52 52.001 0 29.117-22.882 51.999-52 51.999z"/></svg>
                                                Cloud Circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M403.002 217.001C388.998 148.002 328.998 96 256 96c-57.998 0-107.998 32.998-132.998 81.001C63.002 183.002 16 233.998 16 296c0 65.996 53.999 120 120 120h260c55 0 100-45 100-100 0-52.998-40.996-96.001-92.998-98.999zM213.333 362.667L138.667 288l29.864-29.864 44.802 44.802L324.271 192l29.865 29.864-140.803 140.803z"/></svg>
                                                Cloud Done
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M403.002 217.001C388.998 148.002 328.998 96 256 96c-57.998 0-107.998 32.998-132.998 81.001C63.002 183.002 16 233.998 16 296c0 65.996 53.999 120 120 120h260c55 0 100-45 100-100 0-52.998-40.996-96.001-92.998-98.999zM224 268v-76h64v76h68L256 368 156 268h68z"/></svg>
                                                Cloud Download
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M403.001 217.001C388.997 148.002 328.998 96 256 96c-57.998 0-107.999 32.998-132.997 81C63.002 183.002 16 233.998 16 296c0 65.996 54.004 120 120 120h260c55 0 100-45 100-100.001 0-52.997-40.997-95.999-92.999-98.998zM396 376H136c-44.004 0-80-35.996-80-80 0-44 35.996-80 80-80h14.004c12.998-46 55-80 105.996-80 60.996 0 110 49 110 110v10h30c32.998 0 60 27.003 60 60 0 32.998-27.002 60-60 60z"/></svg>
                                                Cloud Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M403.002 217.001C388.998 148.002 328.998 96 256 96c-57.998 0-107.998 32.998-132.998 81.001C63.002 183.002 16 233.998 16 296c0 65.996 53.999 120 120 120h260c55 0 100-45 100-100 0-52.998-40.996-96.001-92.998-98.999zM288 276v76h-64v-76h-68l100-100 100 100h-68z"/></svg>
                                                Cloud Upload
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M190.4 354.1L91.9 256l98.4-98.1-30-29.9L32 256l128.4 128 30-29.9zm131.2 0L420 256l-98.4-98.1 30-29.9L480 256 351.6 384l-30-29.9z"/></svg>
                                                Code
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 288v-64h-34.7c-2-12.1-5.2-23.8-9.3-35l30-17.3-32-55.4-30 17.3c-7.7-9.3-16.3-17.9-25.6-25.6l17.3-30-55.4-32L323 76c-11.2-4.2-22.9-7.3-35-9.3V32h-64v34.7c-12.1 2-23.8 5.2-35 9.3l-17.3-30-55.4 32 17.3 30c-9.3 7.7-17.9 16.3-25.6 25.6l-30-17.3-32 55.4L76 189c-4.2 11.2-7.3 22.9-9.3 35H32v64h34.7c2 12.1 5.2 23.8 9.3 35l-30 17.3 32 55.4 30-17.3c7.7 9.3 16.3 17.9 25.6 25.6l-17.3 30 55.4 32 17.3-30c11.2 4.2 22.9 7.3 35 9.3V480h64v-34.7c12.1-2 23.8-5.2 35-9.3l17.3 30 55.4-32-17.3-30c9.3-7.7 17.9-16.3 25.6-25.6l30 17.3 32-55.4-30-17.3c4.2-11.2 7.3-22.9 9.3-35H480zm-224-64c17.7 0 32 14.3 32 32s-14.3 32-32 32-32-14.3-32-32 14.3-32 32-32zM141.2 343c-18.3-24.2-29.2-54.3-29.2-87 0-6.1.4-12.1 1.1-18l46.9 17.1v.9c0 17.8 4.9 34.5 13.3 48.8L141.2 343zm40.7-148L135 177.9c20.1-31.1 51.8-53.9 89-62.3v49.9c-16.6 5.9-31.1 16.2-42.1 29.5zM256 400c-23.7 0-46-5.7-65.8-15.9l32.1-38.2c10.5 3.9 21.8 6.1 33.7 6.1s23.2-2.2 33.7-6.1l32.1 38.2C302 394.3 279.7 400 256 400zm32-234.5v-49.9c37.2 8.4 68.9 31.2 89 62.3L330.1 195c-11-13.3-25.5-23.6-42.1-29.5zM370.8 343l-32.1-38.2c8.4-14.3 13.3-31 13.3-48.8v-.9l46.9-17.1c.7 5.9 1.1 11.9 1.1 18 0 32.7-10.9 62.8-29.2 87z"/></svg>
                                                Cag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M136.5 77.7l37 67L32 285.7 216.4 464l152.4-148.6 54.4-11.4L166.4 48l-29.9 29.7zm184 208H114.9l102.8-102.3 102.8 102.3zM423.3 304s-56.7 61.5-56.7 92.1c0 30.7 25.4 55.5 56.7 55.5 31.3 0 56.7-24.9 56.7-55.5S423.3 304 423.3 304z"/></svg>
                                                Color Fill
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M441.8 120.1l-49.9-49.9c-8.3-8.3-21.8-8.3-30.1 0l-66.6 66.6L254.1 96 224 126.1l30.3 30.3L64 346.7V448h101.3l190.3-190.3 30.3 30.3 30.1-30.1-41-41 66.6-66.6c8.5-8.4 8.5-21.8.2-30.2zM147.6 405.4l-41-41 171.9-171.9 41 41-171.9 171.9z"/></svg>
                                                Color Filter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 64C150.401 64 64 150.401 64 256c0 105.604 86.401 192 192 192 18.136 0 32-13.864 32-32 0-8.531-3.198-16-8.531-21.333-5.333-5.334-8.531-12.803-8.531-21.334 0-18.135 13.864-32 32-32h38.396c58.667 0 106.667-48 106.667-106.666C448 140.802 361.604 64 256 64zM138.667 256c-18.136 0-32-13.864-32-32s13.864-32 32-32c18.135 0 32 13.864 32 32s-13.865 32-32 32zm64-85.333c-18.136 0-32-13.865-32-32 0-18.136 13.864-32 32-32 18.135 0 32 13.864 32 32 0 18.135-13.865 32-32 32zm106.666 0c-18.135 0-32-13.865-32-32 0-18.136 13.865-32 32-32 18.136 0 32 13.864 32 32 0 18.135-13.864 32-32 32zm64 85.333c-18.135 0-32-13.864-32-32s13.865-32 32-32c18.136 0 32 13.864 32 32s-13.864 32-32 32z"/></svg>
                                                Color Palette
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M200.8 157.2l-36.4 37.4L411.7 448l36.3-37.4zM181 64h37v68h-37zM181 262h37v68h-37zM270 176h69v37h-69zM305.6 115.8l-25.7-26.3-47.1 48.3 25.6 26.2zM168.8 137.8l-47.1-48.3-25.6 26.3 47.1 48.2zM96.1 277.9l25.6 26.2 47.1-48.2-25.6-26.3zM64 176h65v37H64z"/></svg>
                                                Color Wand
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 231.358c-13.442 0-24.643 11.2-24.643 24.642s11.2 24.643 24.643 24.643 24.643-11.2 24.643-24.643-11.201-24.642-24.643-24.642zM256 32C132.8 32 32 132.8 32 256s100.8 224 224 224 224-100.8 224-224S379.2 32 256 32zm49.284 273.284L121.6 390.4l85.116-183.679L390.4 121.6l-85.116 183.684z"/></svg>
                                                Compass
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.6 48 48 141.6 48 256s93.6 208 208 208 208-93.6 208-208S370.4 48 256 48zm0 62.4c34.3 0 62.4 28.1 62.4 62.4s-28.1 62.4-62.4 62.4-62.4-28.1-62.4-62.4 28.1-62.4 62.4-62.4zm0 300.4c-52 0-97.8-27-124.8-66.6 1-41.6 83.2-64.5 124.8-64.5s123.8 22.9 124.8 64.5c-27 39.5-72.8 66.6-124.8 66.6z"/></svg>
                                                Contact
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 371.2h76.795V448H192V320H64v51.2zm76.795-230.4H64V192h128V64h-51.205v76.8zM320 448h51.2v-76.8H448V320H320v128zm51.2-307.2V64H320v128h128v-51.2h-76.8z"/></svg>
                                                Contract
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48zm113.1 321.1C338.9 399.4 298.7 416 256 416V96c42.7 0 82.9 16.6 113.1 46.9C399.4 173.1 416 213.3 416 256s-16.6 82.9-46.9 113.1z"/></svg>
                                                Contrast
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M296 48H176.5C154.4 48 136 65.4 136 87.5V96h-7.5C106.4 96 88 113.4 88 135.5v288c0 22.1 18.4 40.5 40.5 40.5h208c22.1 0 39.5-18.4 39.5-40.5V416h8.5c22.1 0 39.5-18.4 39.5-40.5V176L296 48zm0 44.6l83.4 83.4H296V92.6zm48 330.9c0 4.7-3.4 8.5-7.5 8.5h-208c-4.4 0-8.5-4.1-8.5-8.5v-288c0-4.1 3.8-7.5 8.5-7.5h7.5v255.5c0 22.1 10.4 32.5 32.5 32.5H344v7.5zm48-48c0 4.7-3.4 8.5-7.5 8.5h-208c-4.4 0-8.5-4.1-8.5-8.5v-288c0-4.1 3.8-7.5 8.5-7.5H264v128h128v167.5z"/></svg>
                                                Copy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 368v80h80l235.727-235.729-79.999-79.998L64 368zm377.602-217.602c8.531-8.531 8.531-21.334 0-29.865l-50.135-50.135c-8.531-8.531-21.334-8.531-29.865 0l-39.468 39.469 79.999 79.998 39.469-39.467z"/></svg>
                                                Create
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M352 312.7h37.8V160c0-20.8-17-37.8-37.8-37.8H199.3V160H352v152.7zm-192 33.5V48h-37.8v74.2H48V160h74.2v186.2c0 20.8 17 37.8 37.8 37.8h192v80h37.8v-80H464v-37.8H160z"/></svg>
                                                Crop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M467.3 168.1c-1.8 0-3.5.3-5.1 1l-177.6 92.1h-.1c-7.6 4.7-12.5 12.5-12.5 21.4v185.9c0 6.4 5.6 11.5 12.7 11.5 2.2 0 4.3-.5 6.1-1.4.2-.1.4-.2.5-.3L466 385.6l.3-.1c8.2-4.5 13.7-12.7 13.7-22.1V179.6c0-6.4-5.7-11.5-12.7-11.5zM454.3 118.5L272.6 36.8S261.9 32 256 32c-5.9 0-16.5 4.8-16.5 4.8L57.6 118.5s-8 3.3-8 9.5c0 6.6 8.3 11.5 8.3 11.5l185.5 97.8c3.8 1.7 8.1 2.6 12.6 2.6 4.6 0 8.9-1 12.7-2.7l185.4-97.9s7.5-4 7.5-11.5c.1-6.3-7.3-9.3-7.3-9.3zM227.5 261.2L49.8 169c-1.5-.6-3.3-1-5.1-1-7 0-12.7 5.1-12.7 11.5v183.8c0 9.4 5.5 17.6 13.7 22.1l.2.1 174.7 92.7c1.9 1.1 4.2 1.7 6.6 1.7 7 0 12.7-5.2 12.7-11.5V282.6c.1-8.9-4.9-16.8-12.4-21.4z"/></svg>
                                                Cube
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M203.1 158.3c5.2-11.2 8.1-23.5 8.1-36.7 0-49.5-40.1-89.6-89.6-89.6S32 72.1 32 121.6s40.1 89.6 89.6 89.6c13.2 0 25.5-2.9 36.7-8.1l52.9 52.9-52.9 52.9c-11.2-5.2-23.5-8.1-36.7-8.1-49.5 0-89.6 40.1-89.6 89.6S72.1 480 121.6 480s89.6-40.1 89.6-89.6c0-13.2-2.9-25.5-8.1-36.7l52.9-52.9 156.8 156.8H480v-22.4L203.1 158.3zm-81.5 8.1c-24.6 0-44.8-19.9-44.8-44.8S97 76.8 121.6 76.8s44.8 19.9 44.8 44.8-20.2 44.8-44.8 44.8zm0 268.8c-24.6 0-44.8-19.9-44.8-44.8s20.2-44.8 44.8-44.8 44.8 19.9 44.8 44.8-20.2 44.8-44.8 44.8zm134.4-168c-6.3 0-11.2-4.9-11.2-11.2 0-6.3 4.9-11.2 11.2-11.2 6.3 0 11.2 4.9 11.2 11.2 0 6.3-4.9 11.2-11.2 11.2zM412.8 54.4L278.4 188.8l44.8 44.8L480 76.8V54.4h-67.2z"/></svg>
                                                Cut
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M437.333 32H74.667C51.198 32 32 51.197 32 74.666v282.667C32 380.802 51.198 400 74.667 400h138.666l-42.666 48v32h170.666v-32l-42.666-48h138.666C460.802 400 480 380.802 480 357.333V74.666C480 51.197 460.802 32 437.333 32zm0 288H74.667V74.666h362.666V320z"/></svg>
                                                Desktop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.2 48 48 141.2 48 256s93.2 208 208 208 208-93.2 208-208S370.8 48 256 48zm0 301.6c-51.8 0-93.6-41.8-93.6-93.6s41.8-93.6 93.6-93.6 93.6 41.8 93.6 93.6-41.8 93.6-93.6 93.6zm0-114.4c-11.4 0-20.8 9.4-20.8 20.8s9.4 20.8 20.8 20.8 20.8-9.4 20.8-20.8-9.4-20.8-20.8-20.8z"/></svg>
                                                Disc
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M288 48H136c-22.092 0-40 17.908-40 40v336c0 22.092 17.908 40 40 40h240c22.092 0 40-17.908 40-40V176L288 48zm-16 144V80l112 112H272z"/></svg>
                                                Document
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M387.581 139.712L356.755 109 216.913 248.319l30.831 30.719 139.837-139.326zM481.172 109L247.744 340.469l-91.39-91.051-30.827 30.715L247.744 403 512 139.712 481.172 109zM0 280.133L123.321 403l30.829-30.713L31.934 249.418 0 280.133z"/></svg>
                                                Done All
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 199.5h-91.4V64H187.4v135.5H96l160 158.1 160-158.1zM96 402.8V448h320v-45.2H96z"/></svg>
                                                Download
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 32C185.6 32 80 165.2 80 288.9S150.4 480 256 480s176-67.4 176-191.1S326.4 32 256 32z"/></svg>
                                                Egg
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M215.469 332.802l29.863 29.864L352 256 245.332 149.333l-29.863 29.865 55.469 55.469H64v42.666h205.864l-54.395 55.469zM405.334 64H106.666C83.198 64 64 83.198 64 106.666V192h42.666v-85.333h298.668v298.668H106.666V320H64v85.334C64 428.802 83.198 448 106.666 448h298.668C428.802 448 448 428.802 448 405.334V106.666C448 83.198 428.802 64 405.334 64z"/></svg>
                                                Exit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M396.795 396.8H320V448h128V320h-51.205zM396.8 115.205V192H448V64H320v51.205zM115.205 115.2H192V64H64v128h51.205zM115.2 396.795V320H64v128h128v-51.205z"/></svg>
                                                Expand
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 105c-101.8 0-188.4 62.4-224 151 35.6 88.6 122.2 151 224 151s188.4-62.4 224-151c-35.6-88.6-122.2-151-224-151zm0 251.7c-56 0-101.8-45.3-101.8-100.7S200 155.3 256 155.3 357.8 200.6 357.8 256 312 356.7 256 356.7zm0-161.1c-33.6 0-61.1 27.2-61.1 60.4s27.5 60.4 61.1 60.4 61.1-27.2 61.1-60.4-27.5-60.4-61.1-60.4z"/></svg>
                                                Eye
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256.1 144.8c56.2 0 101.9 45.3 101.9 101.1 0 13.1-2.6 25.5-7.3 37l59.5 59c30.8-25.5 55-58.4 69.9-96-35.3-88.7-122.3-151.6-224.2-151.6-28.5 0-55.8 5.1-81.1 14.1l44 43.7c11.6-4.6 24.1-7.3 37.3-7.3zM52.4 89.7l46.5 46.1 9.4 9.3c-33.9 26-60.4 60.8-76.3 100.8 35.2 88.7 122.2 151.6 224.1 151.6 31.6 0 61.7-6.1 89.2-17l8.6 8.5 59.7 59 25.9-25.7L78.2 64 52.4 89.7zM165 201.4l31.6 31.3c-1 4.2-1.6 8.7-1.6 13.1 0 33.5 27.3 60.6 61.1 60.6 4.5 0 9-.6 13.2-1.6l31.6 31.3c-13.6 6.7-28.7 10.7-44.8 10.7-56.2 0-101.9-45.3-101.9-101.1 0-15.8 4.1-30.7 10.8-44.3zm87.8-15.7l64.2 63.7.4-3.2c0-33.5-27.3-60.6-61.1-60.6l-3.5.1z"/></svg>
                                                Eye Off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 256L262.4 110v292L480 256zM32 110v292l217.6-146L32 110z"/></svg>
                                                Fast Forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M400 176c0-79.5-64.5-144-144-144S112 96.5 112 176c0 71.4 51.9 130.6 120 142v50h-72v48h72v64h48v-64h72v-48h-72v-50c68.1-11.4 120-70.6 120-142zm-240 0c0-52.9 43.1-96 96-96s96 43.1 96 96-43.1 96-96 96-96-43.1-96-96z"/></svg>
                                                Female
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M449.2 208H423v-32l-14.4-48H383V96l-15-48H144l-15 48v32h-25.6L89 176v32H62.8L48 256v165.3c0 23.5 35.2 42.7 58.7 42.7h314.7c21.8 0 42.7-19.7 42.7-41V256l-14.9-48zM176 96h160v32H176V96zm-41 80h242v32H135v-32zm282 112h-82.6c-7.4 36.5-39.7 64-78.4 64s-71-27.5-78.4-64H95v-32h322v32z"/></svg>
                                                Filing
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M376 64v42.667h-40V64H176v42.667h-40V64H96v384h40v-42.666h40V448h160v-42.666h40V448h40V64h-40zM176 362.667h-40V320h40v42.667zm0-85.333h-40v-42.667h40v42.667zM176 192h-40v-42.666h40V192zm200 170.667h-40V320h40v42.667zm0-85.333h-40v-42.667h40v42.667zM376 192h-40v-42.666h40V192z"/></svg>
                                                Film
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M434.3 315.5l29.7-29.7-29.7-29.8-74.3 74.3L181.7 152 256 77.7 226.3 48l-29.7 29.7L166.8 48l-44.5 44.5-29.8-29.7-29.7 29.7 29.7 29.7L48 166.8l29.7 29.7L48 226.3 77.7 256l74.3-74.3L330.3 360 256 434.3l29.7 29.7 29.7-29.7 29.7 29.7 44.5-44.5 29.7 29.7 29.7-29.7-29.7-29.7 44.5-44.5-29.5-29.8z"/></svg>
                                                Fitness
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M396 83.2c-13.8 1.7-31.1 4.2-49.6 4.2-28.8 0-55-6.8-81.5-12.2C238 69.7 210.2 64 180.8 64c-58.6 0-78.5 12.1-80.6 13.4L96 80.3V448h48V269.8c9.7-1.2 21.9-2 36.9-2 27.3 0 52.8 10 79.8 15.5 27.6 5.6 56 11.5 86.9 11.5 18.4 0 34.6-2.4 48.4-4 7.5-.9 14-1.7 20-2.7V80.2c-5 1-12.5 2.1-20 3z"/></svg>
                                                Flag
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M393.3 222.1l-.2 10.4c-.8 11.7-7.9 43.4-22.1 54.7 7-15.2 17.3-47.2 10.2-82.7C361.6 107 287.5 65.6 193 50l-17.2-2.2c39.5 47.2 56.1 81.7 49.7 116.8-2.3 12.6-10 23.4-14 31.6 0 0 2.4-12.9 2-28.7-.3-14.2-6.6-31-18-39.6 3.5 18.4-.8 33.5-9.1 47.7-24.7 42.2-85.4 57.8-90.4 135.8v3.8c0 53.7 25.6 99 68.7 125-6.8-12.3-12-35.2-5.7-60.2 4 23.7 14 36 24.9 51.8 8.2 11.7 19.1 19.3 33.1 24.9s31 7.2 47.9 7.2c55.8 0 91.4-18.1 119.1-50.5s32.1-68 32.1-106.4-8.5-60.9-22.8-84.9z"/></svg>
                                                Flame
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M160 48v224h64v192l128-256h-64l64-160H160z"/></svg>
                                                Flash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M128 298l64 64v118h128V362l64-64V176l-255.2.4L128 298zM234.8 32h42.4v64h-42.4V32zM80 110.4L109.9 80l44.9 45.6-29.9 30.4L80 110.4zm277.1 15.2l45-45.5 29.9 30.4-44.9 45.5-30-30.4z"/></svg>
                                                Flashlight
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M459.9 435.5L76.1 52.5 51.9 76.6 160 184.3V272h64v192l72-144 139.9 139.5zM352 208h-64l64-160H160v40.3l168 167.6z"/></svg>
                                                Flash Off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M436.9 354.4L336 192V96h32V48H144v48h32v96L76.1 354.4C67.7 370.3 63.6 385.8 64 400c1.1 36.5 28.7 64 65.1 64H385c36.3 0 62.1-27.6 63-64 .3-14.2-2.6-29.7-11.1-45.6zM155.1 304l29.5-48h143.1l29.8 48H155.1z"/></svg>
                                                Flask
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M405.1 256c25.2-11.9 42.9-37.1 42.9-66.9 0-41-33.6-74.3-75-74.3-15.9 0-30.3 4.8-42.6 13.1l.6-5.6c0-41-33.6-74.3-75-74.3s-75 33.3-75 74.3l.6 5.6c-12-8.3-26.7-13.1-42.6-13.1-41.4 0-75 33.3-75 74.3 0 29.7 17.7 55 42.9 66.9C81.7 267.9 64 293.1 64 322.9c0 41 33.6 74.3 75 74.3 15.9 0 30.3-4.8 42.6-13.1l-.6 5.6c0 41 33.6 74.3 75 74.3s75-33.3 75-74.3l-.6-5.6c12 8.3 26.7 13.1 42.6 13.1 41.4 0 75-33.3 75-74.3 0-29.8-17.7-55-42.9-66.9zM256 330.3c-41.4 0-75-33.3-75-74.3s33.6-74.3 75-74.3 75 33.3 75 74.3-33.6 74.3-75 74.3z"/></svg>
                                                Flower
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M213.338 96H74.666C51.197 96 32 115.198 32 138.667v234.666C32 396.802 51.197 416 74.666 416h362.668C460.803 416 480 396.802 480 373.333V186.667C480 163.198 460.803 144 437.334 144H256.006l-42.668-48z"/></svg>
                                                Folder
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M437.334 144H256.006l-42.668-48H74.666C51.197 96 32 115.198 32 138.667v234.666C32 396.802 51.197 416 74.666 416h362.668C460.803 416 480 396.802 480 373.333V186.667C480 163.198 460.803 144 437.334 144zM448 373.333c0 5.782-4.885 10.667-10.666 10.667H74.666C68.884 384 64 379.115 64 373.333V176h373.334c5.781 0 10.666 4.885 10.666 10.667v186.666z"/></svg>
                                                Folder Open
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.3 48 48 141.3 48 256s93.3 208 208 208 208-93.3 208-208S370.7 48 256 48zM127 238.2l39.2 17.9 17.1 66.9-15.6 29.3-57.2-.7C95.6 329 86.2 303.1 83 276.3l44-38.1zm217.3 114.1L328.7 323l17.1-67 39.1-17.8 44 38.1c-3.1 26.8-12.6 52.7-27.5 75.3l-57.1.7zm32.4-146.2l-43.6 19.6-61.1-51.6v-47.2l47.9-32.6c29.8 11.9 56.4 32.3 75.6 57.8l-18.8 54zM191.3 94.4l47.7 32.5v47.2l-61 51.5-43-19.6-18.7-53.6c19.3-26.1 45.1-46 75-58zM218.4 426c-.7-.2-1.3-.3-2-.5l-20.5-55.1 14.7-29.4h90.8l15 30.3-19.8 53.9c-1 .2-2 .5-3 .7-11.5 2.3-27 3.8-40.4 4.1-11.7-.1-23.4-1.5-34.8-4z"/></svg>
                                                Football
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M208 400h96v-47.994h-96V400zM32 112v47.994h448V112H32zm80 168.783h288v-49.555H112v49.555z"/></svg>
                                                Funnel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M424 134.5h-45.8c2.3-6.6 3.8-13.9 3.8-21.3 0-35.4-28.1-63.2-63-63.2-22.1 0-41.2 10.7-52.5 28L256 92.3l-10.5-14.5C234.2 60.7 215.1 48 193 48c-34.9 0-63 29.8-63 65.2 0 7.5 1.5 14.7 3.8 21.3H88c-23.3 0-41.8 19-41.8 42.7L46 421.8c0 23.7 17.4 42.2 40.7 42.2h336.7c23.3 0 42.7-18.5 42.7-42.2V177.2c-.1-23.7-18.8-42.7-42.1-42.7zM320 91c11.6 0 21 9.5 21 21 0 11.6-9.4 21-21 21s-21-9.5-21-21 9.4-21 21-21zm-128 0c11.6 0 21 9.5 21 21 0 11.6-9.4 21-21 21s-21-9.5-21-21 9.4-21 21-21zM88 177.2h106.7L151 237.5l34 25 50-69.1.2-.2-.2 228.6H88V177.2zm336 244.6H277V193.4l50 69.1 34-25-43.7-60.4H424v244.7z"/></svg>
                                                Gift
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 160c0-35.3-28.7-64-64-64s-64 28.7-64 64c0 23.7 12.9 44.3 32 55.4v8.6c0 19.9-7.8 33.7-25.3 44.9-15.4 9.8-38.1 17.1-67.5 21.5-14 2.1-25.7 6-35.2 10.7V151.4c19.1-11.1 32-31.7 32-55.4 0-35.3-28.7-64-64-64S96 60.7 96 96c0 23.7 12.9 44.3 32 55.4v209.2c-19.1 11.1-32 31.7-32 55.4 0 35.3 28.7 64 64 64s64-28.7 64-64c0-16.6-6.3-31.7-16.7-43.1 1.9-4.9 9.7-16.3 29.4-19.3 38.8-5.8 68.9-15.9 92.3-30.8 36-22.8 55-57 55-98.8v-8.6c19.1-11.1 32-31.7 32-55.4zM160 56c22.1 0 40 17.9 40 40s-17.9 40-40 40-40-17.9-40-40 17.9-40 40-40zm0 400c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40zm192-256c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40z"/></svg>
                                                Git Branch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 224h-99.8c-14.2-55.2-64.2-96-123.7-96S147 168.8 132.8 224H32v64h100.8c14.2 55.2 64.2 96 123.7 96s109.5-40.8 123.7-96H480v-64zM256.5 336c-44 0-79.8-35.9-79.8-80s35.8-80 79.8-80 79.8 35.9 79.8 80-35.8 80-79.8 80z"/></svg>
                                                Git Commit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M192 382h-22c-24.6 0-29-3.6-33.8-9.6-5.5-6.9-8.2-19.1-8.2-54.2V151.4c19.1-11.1 32-31.7 32-55.4 0-35.3-28.7-64-64-64S32 60.7 32 96c0 23.7 12.9 44.3 32 55.4v166.8c0 46.4 3.7 70.8 22.1 94 19.9 25.1 45 35.8 83.9 35.8h22v64l96-96-96-96v62zM96 56c22.1 0 40 17.9 40 40s-17.9 40-40 40-40-17.9-40-40 17.9-40 40-40zM448 360.6V190.8c0-46.4-3.7-70.8-22.1-94C406 71.7 380.9 62 342 62h-22V0l-96 96 96 96v-64h22c24.6 0 29 2.6 33.8 8.6 5.5 6.9 8.2 19.1 8.2 54.2v169.8c-19.1 11.1-32 31.7-32 55.4 0 35.3 28.7 64 64 64s64-28.7 64-64c0-23.7-12.9-44.3-32-55.4zM416 456c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40z"/></svg>
                                                Git Compare
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M384 224c-23.7 0-44.4 12.9-55.4 32-18.3-.5-52.4-4.1-75.5-18.1-32.3-19.4-64.6-53.1-87-90.5 15.7-11.7 26-30.3 26-51.4 0-35.3-28.7-64-64-64S64 60.7 64 96c0 23.7 12.9 44.3 32 55.4v209.2c-19.1 11.1-32 31.7-32 55.4 0 35.3 28.7 64 64 64s64-28.7 64-64c0-23.7-12.9-44.3-32-55.4V244.2c18.7 19.4 39.1 36 60 48.6 38.8 23.4 87 26.9 108.6 27.3 11.1 19.1 31.7 31.9 55.4 31.9 35.3 0 64-28.7 64-64s-28.7-64-64-64zM88 96c0-22.1 17.9-40 40-40s40 17.9 40 40-17.9 40-40 40-40-17.9-40-40zm80 320c0 22.1-17.9 40-40 40s-40-17.9-40-40 17.9-40 40-40 40 17.9 40 40zm216-88c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40z"/></svg>
                                                Git Merge
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M448 96c0-35.3-28.7-64-64-64s-64 28.7-64 64c0 23.6 12.9 44.3 32 55.4v52.8l-96 48-96-48v-52.8c19.1-11.1 32-31.8 32-55.4 0-35.3-28.7-64-64-64S64 60.7 64 96c0 23.6 12.9 44.3 32 55.4v92.4l128 64v52.8c-19.1 11.1-32 31.8-32 55.4 0 35.3 28.7 64 64 64s64-28.7 64-64c0-23.6-12.9-44.3-32-55.4v-52.8l128-64v-92.4c19.1-11.1 32-31.8 32-55.4zM128 56c22.1 0 40 17.9 40 40s-17.9 40-40 40-40-17.9-40-40 17.9-40 40-40zm128 400c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40zm128-320c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40z"/></svg>
                                                Git Network
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 376.6V206.8c0-46.4-3.7-70.8-22.1-94C374 87.7 348.9 77 310 77h-22V16l-96 96 96 96v-65h22c24.6 0 29 3.6 33.8 9.6 5.5 6.9 8.2 19.1 8.2 54.2v169.8c-19.1 11.1-32 31.7-32 55.4 0 35.3 28.7 64 64 64s64-28.7 64-64c0-23.7-12.9-44.3-32-55.4zM384 472c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40zM128 48c-35.3 0-64 28.7-64 64 0 23.7 12.9 44.3 32 55.4v209.2c-19.1 11.1-32 31.7-32 55.4 0 35.3 28.7 64 64 64s64-28.7 64-64c0-23.7-12.9-44.3-32-55.4V167.4c19.1-11.1 32-31.7 32-55.4 0-35.3-28.7-64-64-64zm0 424c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40zm0-320c-22.1 0-40-17.9-40-40s17.9-40 40-40 40 17.9 40 40-17.9 40-40 40z"/></svg>
                                                Git Pull request
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 176H272v.1h-32v-.1H32v48h11l5 21.5C64 313 88.5 336 144 336s96-17.4 96-90.5V224s1.5-16 16-16 16 16 16 16v21.8c0 73 42.1 90.2 97 90.2s79-25 95-90.2l5-21.8h11v-48z"/></svg>
                                                Glasses
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.124 48 48 141.125 48 256s93.124 208 208 208c114.875 0 208-93.125 208-208S370.875 48 256 48zm-21.549 384.999c-39.464-4.726-75.978-22.392-104.519-50.932C96.258 348.393 77.714 303.622 77.714 256c0-42.87 15.036-83.424 42.601-115.659.71 8.517 2.463 17.648 2.014 24.175-1.64 23.795-3.988 38.687 9.94 58.762 5.426 7.819 6.759 19.028 9.4 28.078 2.583 8.854 12.902 13.498 20.019 18.953 14.359 11.009 28.096 23.805 43.322 33.494 10.049 6.395 16.326 9.576 13.383 21.839-2.367 9.862-3.028 15.937-8.13 24.723-1.557 2.681 5.877 19.918 8.351 22.392 7.498 7.497 14.938 14.375 23.111 21.125 12.671 10.469-1.231 24.072-7.274 39.117zm147.616-50.932c-25.633 25.633-57.699 42.486-92.556 49.081 4.94-12.216 13.736-23.07 21.895-29.362 7.097-5.476 15.986-16.009 19.693-24.352 3.704-8.332 8.611-15.555 13.577-23.217 7.065-10.899-17.419-27.336-25.353-30.781-17.854-7.751-31.294-18.21-47.161-29.375-11.305-7.954-34.257 4.154-47.02-1.417-17.481-7.633-31.883-20.896-47.078-32.339-15.68-11.809-14.922-25.576-14.922-42.997 12.282.453 29.754-3.399 37.908 6.478 2.573 3.117 11.42 17.042 17.342 12.094 4.838-4.043-3.585-20.249-5.212-24.059-5.005-11.715 11.404-16.284 19.803-24.228 10.96-10.364 34.47-26.618 32.612-34.047s-23.524-28.477-36.249-25.193c-1.907.492-18.697 18.097-21.941 20.859.086-5.746.172-11.491.26-17.237.055-3.628-6.768-7.352-6.451-9.692.8-5.914 17.262-16.647 21.357-21.357-2.869-1.793-12.659-10.202-15.622-8.968-7.174 2.99-15.276 5.05-22.45 8.039 0-2.488-.302-4.825-.662-7.133a176.585 176.585 0 0 1 45.31-13.152l14.084 5.66 9.944 11.801 9.924 10.233 8.675 2.795 13.779-12.995L282 87.929V79.59c27.25 3.958 52.984 14.124 75.522 29.8-4.032.361-8.463.954-13.462 1.59-2.065-1.22-4.714-1.774-6.965-2.623 6.531 14.042 13.343 27.89 20.264 41.746 7.393 14.801 23.793 30.677 26.673 46.301 3.394 18.416 1.039 35.144 2.896 56.811 1.788 20.865 23.524 44.572 23.524 44.572s10.037 3.419 18.384 2.228c-7.781 30.783-23.733 59.014-46.769 82.052z"/></svg>
                                                Globe
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M409.6 64H102.4C81.3 64 64 81.3 64 102.4v307.2c0 21.1 17.3 38.4 38.4 38.4h307.2c21.1 0 38.4-17.3 38.4-38.4V102.4c0-21.1-17.3-38.4-38.4-38.4zM179.2 409.6h-76.8v-76.8h76.8v76.8zm0-115.2h-76.8v-76.8h76.8v76.8zm0-115.2h-76.8v-76.8h76.8v76.8zm115.2 230.4h-76.8v-76.8h76.8v76.8zm0-115.2h-76.8v-76.8h76.8v76.8zm0-115.2h-76.8v-76.8h76.8v76.8zm115.2 230.4h-76.8v-76.8h76.8v76.8zm0-115.2h-76.8v-76.8h76.8v76.8zm0-115.2h-76.8v-76.8h76.8v76.8z"/></svg>
                                                Grid
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M474.1 398.2L229.8 167.8s8.8-57.7 26.2-71.8c17.5-14.2 48-32 48-32V32c-32 0-58.8 8.3-96.9 27.3-38 18.9-66.8 47.8-74.4 55.4-7.6 7.6-18.1 19.5-24.7 28.9s-5.3 20.1-5.3 20.1l-19.7 17-4-4c-2.3-2.3-6.2-2.3-8.5 0l-36.8 36.8c-2.3 2.3-2.3 6.2 0 8.5l59.4 59.4c2.3 2.3 6.2 2.3 8.5 0l36.8-36.8c2.3-2.3 2.3-6.2 0-8.5l-10.3-10.3 14.6-14.3c6.8-3.7 25.4-8.9 39.1-5.1l214.9 267.3c8.1 8.2 20.3 8.2 28.5 0l46.8-47.1c10.3-8 10.3-22.3 2.1-28.4z"/></svg>
                                                Hammer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M450.679 273.5c-14.585-14.577-36.054-15.89-50.639-1.312l-41.687 41.664c-10.852 10.836-23.93 10.859-31.564 1.852-5.057-5.968-3.061-24.374-1.644-36.049l20.907-171.849c1.867-15.353-9.07-30.185-24.43-32.051-15.358-1.867-29.322 9.939-31.191 25.289L267.37 236.021c-1.205 3.358-3.79 3.938-4.081-.582L255.44 60c0-15.465-12.542-28-28.014-28-15.473 0-28.015 12.535-28.015 28l-.552 176.752c.146 2.04-1.604 2.624-1.92.294L172.016 99.077c-2.75-15.219-17.323-26.203-32.548-23.453-15.227 2.748-25.339 18.187-22.591 33.403l22.193 161.455c.023 2.872-.941 4.513-2.308.831l-33.109-88.517c-5.18-14.572-21.196-23.065-35.776-17.889-14.579 5.177-22.201 22.061-17.023 36.631l58.042 189.625c.303 1.046.624 2.085.953 3.118l.121.39c.011.031.025.058.035.088C126.079 444.233 172.57 480 227.427 480c35.116 0 71.591-12.378 99.357-33.672l.003-.002c29.99-18.051 126.071-121.347 126.071-121.347 14.587-14.577 12.408-36.899-2.179-51.479z"/></svg>
                                                Hand
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C140.563 48 48 141.6 48 256s92.563 208 208 208 208-93.6 208-208S370.401 48 256 48zm0 374.4c-91.518 0-166.404-74.883-166.404-166.4 0-91.518 74.887-166.4 166.404-166.4S422.404 164.482 422.404 256 347.518 422.4 256 422.4zm72.8-187.2c17.683 0 31.201-13.518 31.201-31.2s-13.519-31.2-31.201-31.2c-17.682 0-31.2 13.518-31.2 31.2s13.518 31.2 31.2 31.2zm-145.6 0c17.682 0 31.2-13.518 31.2-31.2s-13.519-31.2-31.2-31.2c-17.683 0-31.201 13.518-31.201 31.2s13.519 31.2 31.201 31.2zM256 370.4c48.883 0 89.436-30.164 106.081-72.801H149.919C166.564 340.236 207.117 370.4 256 370.4z"/></svg>
                                                Happy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C150 48 64 136.2 64 245.1v153.3c0 36.3 28.6 65.7 64 65.7h64V288h-85.3v-42.9c0-84.7 66.8-153.3 149.3-153.3s149.3 68.5 149.3 153.3V288H320v176h64c35.4 0 64-29.3 64-65.7V245.1C448 136.2 362 48 256 48z"/></svg>
                                                Headset
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 448l-30.164-27.211C118.718 322.442 48 258.61 48 179.095 48 114.221 97.918 64 162.4 64c36.399 0 70.717 16.742 93.6 43.947C278.882 80.742 313.199 64 349.6 64 414.082 64 464 114.221 464 179.095c0 79.516-70.719 143.348-177.836 241.694L256 448z"/></svg>
                                                Heart
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M51.9 76.6l25 25c-18.1 20.3-29 47.3-29 77.6 0 79.5 70.7 143.3 177.8 241.7L256 448l30.2-27.2c20.6-18.9 39.9-36.6 57.5-53.3l92.2 92 24-24-383.8-383-24.2 24.1zM464 179.1C464 114.2 414.1 64 349.6 64c-36.4 0-70.7 16.7-93.6 43.9C233.1 80.7 198.8 64 162.4 64c-8.4 0-16.5.9-24.3 2.5l253.7 253.1C437.3 270.9 464 228 464 179.1z"/></svg>
                                                Heart Dislike
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M349.6 64c-36.4 0-70.7 16.7-93.6 43.9C233.1 80.7 198.8 64 162.4 64 97.9 64 48 114.2 48 179.1c0 79.5 70.7 143.3 177.8 241.7L256 448l30.2-27.2C393.3 322.4 464 258.6 464 179.1 464 114.2 414.1 64 349.6 64zm-80.8 329.3l-4.2 3.9-8.6 7.8-8.6-7.8-4.2-3.9c-50.4-46.3-94-86.3-122.7-122-28-34.7-40.4-63.1-40.4-92.2 0-22.9 8.4-43.9 23.7-59.3 15.2-15.4 36-23.8 58.6-23.8 26.1 0 52 12.2 69.1 32.5l24.5 29.1 24.5-29.1c17.1-20.4 43-32.5 69.1-32.5 22.6 0 43.4 8.4 58.7 23.8 15.3 15.4 23.7 36.5 23.7 59.3 0 29-12.5 57.5-40.4 92.2-28.8 35.7-72.3 75.7-122.8 122z"/></svg>
                                                Heart Empty
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M349.6 64c-36.4 0-70.7 16.7-93.6 43.9C233.1 80.7 198.8 64 162.4 64 97.9 64 48 114.2 48 179.1c0 79.5 70.7 143.3 177.8 241.7L256 448l30.2-27.2C393.3 322.4 464 258.6 464 179.1 464 114.2 414.1 64 349.6 64zM256 406V157.7l24.5-29.1c17.1-20.4 43-32.5 69.1-32.5 22.6 0 43.4 8.4 58.7 23.8 15.3 15.4 23.7 36.5 23.7 59.3 0 29-12.5 57.5-40.4 92.2C362.8 307 306.4 359.7 256 406z"/></svg>
                                                Heart Half
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M289 448h-66v-65h66v65zm-1-98h-64c0-101 96-95.1 96-159 0-35.2-28.8-63.4-64-63.4S192 158 192 192h-64c0-71 57.3-128 128-128s128 56.4 128 127c0 79.9-96 89-96 159z"/></svg>
                                                Help
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48zm61 356l-12.2-39.6c13-5.8 24.9-14 35.3-24.4 10.4-10.4 18.6-22.3 24.4-35.3l39.5 12.1c-7.9 19.3-19.7 37-34.9 52.2-15.1 15.3-32.8 27.1-52.1 35zM195 108l12.2 39.6c-13 5.8-24.9 14-35.3 24.4-10.4 10.4-18.6 22.3-24.4 35.3L108 195.2c7.9-19.3 19.7-37 34.9-52.2 15.1-15.3 32.8-27.1 52.1-35zm61 84c35.3 0 64 28.7 64 64s-28.7 64-64 64-64-28.7-64-64 28.7-64 64-64zm113.1-49.1c15.2 15.2 26.9 32.9 34.9 52.1l-39.5 12.2c-5.9-13-14-24.9-24.4-35.3-10.4-10.4-22.3-18.6-35.3-24.4l12.1-39.5c19.3 7.9 37 19.7 52.2 34.9zM142.9 369.1c-15.2-15.1-27-32.8-34.9-52.1l39.5-12.2c5.9 13 14 24.9 24.4 35.3 10.4 10.4 22.3 18.6 35.3 24.4L195.1 404c-19.3-7.9-37-19.7-52.2-34.9z"/></svg>
                                                Help Buoy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.2 48 48 141.2 48 256s93.2 208 208 208 208-93.2 208-208S370.8 48 256 48zm21 333h-42v-42h42v42zm-.2-63h-41.6c0-67 62.4-62.2 62.4-103.8 0-22.9-18.7-41.7-41.6-41.7S214.4 192 214.4 214h-41.6c0-46 37.2-83 83.2-83s83.2 37.1 83.2 83.1c0 52-62.4 57.9-62.4 103.9z"/></svg>
                                                Help Circle
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M208 448V320h96v128h97.6V256H464L256 64 48 256h62.4v192z"/></svg>
                                                Home
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M128 48v122.8h.2l-.2.2 85.3 85-85.3 85.2.2.2h-.2V464h256V341.4h-.2l.2-.2-85.3-85.2 85.3-85-.2-.2h.2V48H128zm213.3 303.9v71.5H170.7v-71.5l85.3-85.2 85.3 85.2zM256 245.4l-85.3-85.2V87.6h170.7v72.5L256 245.4z"/></svg>
                                                HourGlass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M128.1 256l128 224 128-224zM392 161c3-9 4.7-22.7 4.7-32.9 0-53.1-43-96.1-96.1-96.1-31.4 0-59.2 15-76.8 38.3 0 0-9.1 14-10.8 29l-3.4-1c-2.3-9-3.7-20 1.6-31.5-7.4-2.5-9.4-2.8-17.6-2.8-41.7 0-75.6 33.8-75.6 75.6 0 6.3.8 15.5 2.3 21.4-13.9 3.5-24.3 16.1-24.3 31 0 17.6 14.4 32 32 32h256c17.6 0 32-14.4 32-32 0-14.8-10.2-27.4-24-31z"/></svg>
                                                Ice Cream
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M448 405.333V106.667C448 83.198 428.802 64 405.333 64H106.667C83.198 64 64 83.198 64 106.667v298.666C64 428.802 83.198 448 106.667 448h298.666C428.802 448 448 428.802 448 405.333zM181.333 288l53.334 64 74.666-96 96 128H106.667l74.666-96z"/></svg>
                                                Image
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M434.7 188c-18.8-18-43.8-28-70.5-28-26.6 0-51.6 9.9-70.4 27.9l-17.6 15.9 33.1 32.1 17-15.4.1-.1c10.1-9.6 23.5-15 37.7-15 14.2 0 27.6 5.3 37.7 14.9 10 9.6 15.4 22.3 15.4 35.8 0 13.5-5.5 26.1-15.4 35.6-10.1 9.6-23.5 15-37.7 15s-27.6-5.3-37.7-14.9L218.2 188c-18.9-18-43.9-28-70.4-28-26.7 0-51.7 9.9-70.5 28C58.4 206.1 48 230.2 48 256c0 25.7 10.4 49.9 29.3 68 18.8 18 43.8 28 70.5 28 26.7 0 51.7-9.9 70.4-28l37.8-36.1 37.7 36.1c18.9 18 43.9 28 70.4 28 26.7 0 51.7-9.9 70.4-27.9 19-18.1 29.4-42.2 29.4-68 .1-25.8-10.3-50-29.2-68.1zM185.5 291.7c-10.1 9.6-23.5 15-37.7 15-14.2 0-27.6-5.3-37.7-14.9-10-9.6-15.4-22.3-15.4-35.8 0-13.5 5.5-26.1 15.4-35.6 10.1-9.6 23.5-15 37.7-15 14.2 0 27.6 5.3 37.7 14.9l37.4 35.8-37.4 35.6z"/></svg>
                                                Infinite
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M232 235h48v137h-48zM232 140h48v48h-48z"/></svg>
                                                Information
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.2 48 48 141.2 48 256s93.2 208 208 208 208-93.2 208-208S370.8 48 256 48zm21 312h-42V235h42v125zm0-166h-42v-42h42v42z"/></svg>
                                                Information Circle
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 32s-23.4-.7-59.3 27.1C404 72 244.9 186.8 244.9 186.8l-168.8-4.2L32 222l109.8 55.2-8.6 10.8-87.9.1-7.2 40.5 63.1 48.7-26.6 59.8 60-26.4 48.7 63.1 40.5-7.2.1-87.8 10.9-8.5L290.1 480l39.3-44.1-4.2-168.7S440.1 108.2 453 91.6C480.7 55.5 480 32 480 32z"/></svg>
                                                Jet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg id="Layer_02" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><style>.st0{fill:#bcc1c2}</style><path class="st0" d="M117.3 42.7c-17.6 0-32 14.4-32 32v362.7c0 17.6 14.4 32 32 32H320V42.7H117.3zM384.7 42.7H368v426.7h16.7c23.1 0 42-18.9 42-42V84.7c0-23.1-18.9-42-42-42z"/></svg>
                                                Journal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M249.2 224c-14.2-40.2-55.1-72-100.2-72-57.2 0-101 46.8-101 104s45.8 104 103 104c45.1 0 84.1-31.8 98.2-72H352v64h69.1v-64H464v-64H249.2zm-97.6 66.5c-19 0-34.5-15.5-34.5-34.5s15.5-34.5 34.5-34.5 34.5 15.5 34.5 34.5-15.5 34.5-34.5 34.5z"/></svg>
                                                Key
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 398.5c-22.3 0-40.5 18.3-40.5 40.7 0 22.4 18.2 40.7 40.5 40.7s40.5-18.3 40.5-40.7c0-22.3-18.2-40.7-40.5-40.7zM136.5 32C114.2 32 96 50.3 96 72.7s18.2 40.7 40.5 40.7S177 95.1 177 72.7 158.8 32 136.5 32zm0 122.2c-22.3 0-40.5 18.3-40.5 40.7s18.2 40.7 40.5 40.7 40.5-18.3 40.5-40.7-18.2-40.7-40.5-40.7zm0 122.2c-22.3 0-40.5 18.3-40.5 40.7 0 22.4 18.2 40.7 40.5 40.7s40.5-18.3 40.5-40.7c0-22.4-18.2-40.7-40.5-40.7zm239-162.9c22.3 0 40.5-18.3 40.5-40.7S397.8 32 375.5 32 335 50.3 335 72.7s18.2 40.8 40.5 40.8zM256 276.4c-22.3 0-40.5 18.3-40.5 40.7 0 22.4 18.2 40.7 40.5 40.7s40.5-18.3 40.5-40.7c0-22.4-18.2-40.7-40.5-40.7zm119.5 0c-22.3 0-40.5 18.3-40.5 40.7 0 22.4 18.2 40.7 40.5 40.7s40.5-18.3 40.5-40.7c0-22.4-18.2-40.7-40.5-40.7zm0-122.2c-22.3 0-40.5 18.3-40.5 40.7s18.2 40.7 40.5 40.7 40.5-18.3 40.5-40.7-18.2-40.7-40.5-40.7zm-119.5 0c-22.3 0-40.5 18.3-40.5 40.7s18.2 40.7 40.5 40.7 40.5-18.3 40.5-40.7-18.2-40.7-40.5-40.7zM256 32c-22.3 0-40.5 18.3-40.5 40.7s18.2 40.7 40.5 40.7 40.5-18.3 40.5-40.7S278.3 32 256 32z"/></svg>
                                                Keypad
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M437.334 416C460.803 416 480 396.803 480 373.334V106.668C480 83.199 460.803 64 437.334 64H74.666C51.197 64 32 83.199 32 106.668v266.666C32 396.803 51.197 416 74.666 416H0c0 23.469 64 32 96 32h320c32 0 96-8.531 96-32h-74.666zM74.666 106.668h362.668v271.998H74.666V106.668zM256 434.666c-11.729 0-21.333-9.604-21.333-21.334 0-11.729 9.604-21.332 21.333-21.332s21.333 9.604 21.333 21.332c0 11.73-9.604 21.334-21.333 21.334z"/></svg>
                                                Laptop
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 287.6C416 120.9 256 32 256 32S96 120.9 96 287.6c0 118.8 81.3 140.5 128 143.2V480h64v-49.3c46.7-2.6 128-24.3 128-143.1z"/></svg>
                                                Leaf
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M74.6 256c0-38.3 31.1-69.4 69.4-69.4h88V144h-88c-61.8 0-112 50.2-112 112s50.2 112 112 112h88v-42.6h-88c-38.3 0-69.4-31.1-69.4-69.4zm85.4 22h192v-44H160v44zm208-134h-88v42.6h88c38.3 0 69.4 31.1 69.4 69.4s-31.1 69.4-69.4 69.4h-88V368h88c61.8 0 112-50.2 112-112s-50.2-112-112-112z"/></svg>
                                                Link
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M408 64H104c-22.091 0-40 17.908-40 40v304c0 22.092 17.909 40 40 40h304c22.092 0 40-17.908 40-40V104c0-22.092-17.908-40-40-40zM304 368H144v-48h160v48zm64-88H144v-48h224v48zm0-88H144v-48h224v48z"/></svg>
                                                Listbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 176c-44.004 0-80.001 36-80.001 80 0 44.004 35.997 80 80.001 80 44.005 0 79.999-35.996 79.999-80 0-44-35.994-80-79.999-80zm190.938 58.667c-9.605-88.531-81.074-160-169.605-169.599V32h-42.666v33.067c-88.531 9.599-160 81.068-169.604 169.599H32v42.667h33.062c9.604 88.531 81.072 160 169.604 169.604V480h42.666v-33.062c88.531-9.604 160-81.073 169.605-169.604H480v-42.667h-33.062zM256 405.333c-82.137 0-149.334-67.198-149.334-149.333 0-82.136 67.197-149.333 149.334-149.333 82.135 0 149.332 67.198 149.332 149.333S338.135 405.333 256 405.333z"/></svg>
                                                Locate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M376 186h-20v-40c0-55-45-100-100-100S156 91 156 146v40h-20c-22.002 0-40 17.998-40 40v200c0 22.002 17.998 40 40 40h240c22.002 0 40-17.998 40-40V226c0-22.002-17.998-40-40-40zM256 368c-22.002 0-40-17.998-40-40s17.998-40 40-40 40 17.998 40 40-17.998 40-40 40zm62.002-182H193.998v-40c0-34.004 28.003-62.002 62.002-62.002 34.004 0 62.002 27.998 62.002 62.002v40z"/></svg>
                                                Lock
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M383.6 98.8C352.1 65.8 308 48.2 256 48c-51.9.2-96 17.8-127.5 50.8C96.8 132 80 178.8 80 234c0 43.5 1.8 69.2 12.9 115.8 0 0 22.7 75.7 35.5 104.1 3.5 7.8 7.4 11.8 15.5 9.3 6.4-2 46.8-17.9 54.7-21.6 7.9-3.6 11.6-8.6 8.9-15.2-3.8-9.2-33.9-95.6-33.9-95.6-8.4-36.3-11.6-53.9-11.6-94.3 0-28.2 9.8-54.1 27.7-72.9 17.5-18.3 41-28.4 66.3-28.4s48.8 10.1 66.3 28.4c17.9 18.8 27.7 44.6 27.7 72.8 0 40-3.2 64-11.7 94.4s-32.2 90.1-33.9 95.6c-1.7 5.6 2.1 12.5 8.9 15.2 6.8 2.7 49.3 19.6 54.7 21.6 5.4 2 10.6.6 14.5-7.7 4-8.3 24.6-61.4 36.5-105.7 12-44.3 13-72.3 13-115.8 0-55.2-16.7-101.9-48.4-135.2zM173.1 419.7l-22.9 9.6c-6.9-16.3-17.2-43.2-25.9-77.2l22-6.5 26.8 74.1zm188.6 9.6l-22.9-9.6c7.2-16.6 19.1-45.1 26.6-74.1l22 6.5c-8.4 33.9-18.7 60.9-25.7 77.2z"/></svg>
                                                Magnet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M437.332 80H74.668C51.199 80 32 99.198 32 122.667v266.666C32 412.802 51.199 432 74.668 432h362.664C460.801 432 480 412.802 480 389.333V122.667C480 99.198 460.801 80 437.332 80zM432 170.667L256 288 80 170.667V128l176 117.333L432 128v42.667z"/></svg>
                                                Mail
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 201.667c0-14.933-7.469-28.803-20.271-36.266L256 64 52.271 165.401C40.531 172.864 32 186.734 32 201.667v203.666C32 428.802 51.197 448 74.666 448h362.668C460.803 448 480 428.802 480 405.333V201.667zM256 304L84.631 192 256 106.667 427.369 192 256 304z"/></svg>
                                                Mail Open
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 48H288v48h94.1L275.4 202.6C251.9 185.9 223.1 176 192 176c-79.5 0-144 64.5-144 144s64.5 144 144 144 144-64.5 144-144c0-31.1-9.9-59.9-26.6-83.4L416 129.9V224h48V48h-48zM192 416c-52.9 0-96-43.1-96-96s43.1-96 96-96 96 43.1 96 96-43.1 96-96 96z"/></svg>
                                                Male
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 106.6c20.6.1 37.3-16.6 37.3-37.3 0-20.6-16.7-37.3-37.3-37.3-20.6 0-37.3 16.7-37.3 37.3 0 20.6 16.7 37.3 37.3 37.3zM293.4 115h-74.8c-28.2 0-46.6 24.8-46.6 48.4V277c0 22 31 22 31 0V172h6v285.6c0 30.4 42 29.4 43 0V293h8v164.7c1.7 31.2 43 28.2 43-.1V172h5v105c0 22 32 22 32 0V163.4c0-23.5-18.5-48.4-46.6-48.4z"/></svg>
                                                Man
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M437.333 64c-2.176 0-4.396 1.369-9.176 3.207L320 108.802 192 64 71.469 104.531C67.197 105.604 64 109.864 64 115.197v322.136C64 443.729 68.271 448 74.666 448c1.828 0 6.505-2.33 9.087-3.319L192 403.197 320 448l120.531-40.531c4.271-1.073 7.469-5.334 7.469-10.667V74.666C448 68.271 443.729 64 437.333 64zM320 405.333l-128-44.802V106.666l128 44.803v253.864z"/></svg>
                                                Map
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M351.9 256L460 193.6l-48-83.2-108 62.4V48h-96v124.8l-108-62.4-48 83.2L160.1 256 52 318.4l48 83.2 108-62.4V464h96V339.2l108 62.4 48-83.2z"/></svg>
                                                Medical
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M352 144v-39.6C352 82 334 64 311.6 64H200.4C178 64 160 82 160 104.4V144H48v263.6C48 430 66 448 88.4 448h335.2c22.4 0 40.4-18 40.4-40.4V144H352zm-152-40h112v40H200v-40zm136 224h-56v56h-48v-56h-56v-48h56v-56h48v56h56v48z"/></svg>
                                                Medkit
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 384h384v-42.666H64V384zm0-106.666h384v-42.667H64v42.667zM64 128v42.665h384V128H64z"/></svg>
                                                Menu
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 320c37.712 0 68.571-30.924 68.571-68.714V100.714C324.571 62.924 293.712 32 256 32s-68.571 30.924-68.571 68.714v150.572c0 37.79 30.859 68.714 68.571 68.714zm121.139-75.452c0 68.714-58.282 116.815-121.139 116.815s-121.139-48.102-121.139-116.815H96c0 77.873 61.719 143.153 137.144 153.465V480h45.713v-81.987C354.281 386.561 416 322.421 416 244.548h-38.861z"/></svg>
                                                Mic
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M367.951 354.654l-26.616-26.562-9.568-9.548-4.698-4.706L187 174.041v.346L76.112 63.531 51.921 87.572 187 222.47v28.816c0 37.79 31.121 68.714 68.91 68.714a68.6 68.6 0 0 0 24.565-4.545l32.389 32.274c-17.333 8.793-36.812 13.86-56.782 13.86-62.986 0-121.365-48.59-121.365-116.59H95.773C95.773 322 158 387.701 233 398.013V480h46v-81.987c22-3.352 43.066-11.222 61.627-22.622l95.278 95.078 24.033-24-33.847-33.785-58.216-57.959 58.224 57.959-58.148-58.03zM325 251.286V100.714C325 62.924 293.791 32 256 32s-69 30.924-69 68.714v25.244l137.109 136.968c.67-3.791.891-7.679.891-11.64zM416.439 245h-38.941c0 20.496-5.498 39.676-14.931 56.197l27.572 27.516c16.523-24.11 26.3-52.787 26.3-83.713zM459.999 446.427l-33.897-33.743 33.855 33.785z"/></svg>
                                                Mic Off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M384 112V84.4c0-29-24.5-52.4-54.8-52.4H182.9C152.5 32 128 55.4 128 84.4V112h152v37H128v43h152v37H128v43h152v37H128v41.8c0 29 24.5 52.2 54.9 52.2H213v77h86v-77h30.2c30.3 0 54.8-23.2 54.8-52.2V309h-56v-37h56v-43h-56v-37h56v-43h-56v-37h56z"/></svg>
                                                Microphone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M195 125c0-26.3 5.3-51.3 14.9-74.1C118.7 73 51 155.1 51 253c0 114.8 93.2 208 208 208 97.9 0 180-67.7 202.1-158.9-22.8 9.6-47.9 14.9-74.1 14.9-106 0-192-86-192-192z"/></svg>
                                                Moon
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M296 136c0-22.002-17.998-40-40-40s-40 17.998-40 40 17.998 40 40 40 40-17.998 40-40zm0 240c0-22.002-17.998-40-40-40s-40 17.998-40 40 17.998 40 40 40 40-17.998 40-40zm0-120c0-22.002-17.998-40-40-40s-40 17.998-40 40 17.998 40 40 40 40-17.998 40-40z"/></svg>
                                                More
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 256l-96-96v64h-96v-96h64l-96-96-96 96h64v96h-96v-64l-96 96 96 96v-64h96v96h-64l96 96 96-96h-64v-96h96v64z"/></svg>
                                                Move
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 64v225.1c-12.6-7.3-27.1-11.7-42.7-11.7-47.1 0-85.3 38.2-85.3 85.3s38.2 85.3 85.3 85.3 85.3-38.2 85.3-85.3V149.3H384V64H256z"/></svg>
                                                Musical Note
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M160 64v257.6c-8.2-2.7-17.2-4.1-26.6-4.1-38.3 0-69.4 27.1-69.4 65.4 0 38.3 31.1 65.1 69.4 65.1 38.3 0 69.6-28.2 69.6-69.1V200h202v121.6c-8.2-2.7-17.2-4.1-26.6-4.1-38.3 0-69.4 27.1-69.4 65.4 0 38.3 31.1 65.1 69.4 65.1 38.3 0 69.6-28.2 69.6-69.1V64H160zm245 96H203v-53h202v53z"/></svg>
                                                Musical Notes
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 64L96 433.062 110.938 448 256 384l145.062 64L416 433.062z"/></svg>
                                                Navigate
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 464c22.779 0 41.411-18.719 41.411-41.6h-82.823c0 22.881 18.633 41.6 41.412 41.6zm134.589-124.8V224.8c0-63.44-44.516-117.518-103.53-131.041V79.2c0-17.682-13.457-31.2-31.059-31.2s-31.059 13.518-31.059 31.2v14.559c-59.015 13.523-103.53 67.601-103.53 131.041v114.4L80 380.8v20.8h352v-20.8l-41.411-41.6z"/></svg>
                                                Notification
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M257 120.471c7.083 0 23.911 4.479 23.911 4.479 45.589 10.447 77.678 52.439 77.678 99.85V352.412l9.321 9.364 7.788 7.823H136.302l7.788-7.823 9.321-9.364V224.8c0-47.41 32.089-89.403 77.678-99.85 0 0 18.043-4.479 23.911-4.479M256 48c-17.602 0-31.059 13.518-31.059 31.2v14.559c-59.015 13.523-103.53 67.601-103.53 131.041v114.4L80 380.8v20.8h352v-20.8l-41.411-41.6V224.8c0-63.44-44.516-117.518-103.53-131.041V79.2c0-17.682-13.457-31.2-31.059-31.2zm41.411 374.4h-82.823c0 22.881 18.633 41.6 41.412 41.6s41.411-18.719 41.411-41.6z"/></svg>
                                                Notification Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M336 272c0-29.8-16.3-55.7-40.4-69.5l73.1-124.1C335.6 59.1 297.1 48 256 48c-41.2 0-79.9 11.2-113.1 30.6l71.6 125C191.4 217.6 176 243 176 272H32c0 83.3 46.9 153.4 114.4 192l70.1-122.4c11.7 6.6 25.1 10.4 39.5 10.4 14.3 0 27.7-3.8 39.3-10.3L365.6 464C433.1 425.4 480 355.3 480 272H336z"/></svg>
                                                Nuclear
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M357.2 235.6L274.7 153h-.8c-8.1-6-18.2-10.3-28.4-10.3-13.7 0-26.1 6.3-34.3 16.3h-.6L53 414.1v.8c-3 6.2-5 13.3-5 20.8 0 24.4 19.7 44.3 44.3 44.3 9.4 0 18-2.9 27.4-9.1l232.9-168.1c10.9-8.3 17.4-21.6 17.4-36 0-12-4.7-23.2-12.8-31.2zM464 145.1l-29.2-49-36.6 20.3 31.5-55.9L380.6 32l-67.3 127.8 41.3 41.4z"/></svg>
                                                Nutrition
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M405.34 405.332H106.66V106.668H240V64H106.66C83.191 64 64 83.197 64 106.668v298.664C64 428.803 83.191 448 106.66 448h298.68c23.469 0 42.66-19.197 42.66-42.668V272h-42.66v133.332zM288 64v42.668h87.474L159.999 322.133l29.866 29.866 215.476-215.47V224H448V64H288z"/></svg>
                                                Open
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M369.5 32H142.4C81.5 32 32 82.6 32 144.6v222.8c0 62 49.5 112.6 110.4 112.6h227.2c60.9 0 110.5-50.6 110.5-112.6V144.6C480 82.6 430.5 32 369.5 32zM175 251v.7c0 10.9-9.1 20.4-19.9 20.4h-23.3c-10.8 0-19.9-9.5-19.9-20.4V148.1c1-10.8 9.2-20.2 19.9-20.2h23.3c10.9 0 19.9 9.8 19.9 20.8V251zm122 147.4c0 11.4-8.9 17.6-20.1 17.6h-41.8c-11.2 0-20.1-8.1-20.1-19.6v-29.3c0-23.3 18.1-42.3 41-42.3s41 19 41 42.3v31.3zM400 251v.7c0 10.9-9.1 20.4-19.9 20.4h-24.3c-10.8 0-19.9-9.5-19.9-20.4V148.1c1-10.8 9.2-20.2 19.9-20.2h24.3c10.8 0 19.9 9.8 19.9 20.8V251z"/></svg>
                                                Outlet
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M48 270.9l118.9 44.6L181.7 464 256 360l104 104L464 48 48 270.9zm294.9 126L260 313.4 374.9 152 193.6 289.8 124.9 265l291-156.2-73 288.1z"/></svg>
                                                Paper Plane
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M248.03 116.81l24.679-24.678 19.233 19.234-24.678 24.677zM176 125.7c-45.3 0-82.3 37-82.3 82.3 0 17.5 5.5 33.7 14.9 47 15.3-13 33.9-22.6 54.7-27.6l13.2-16.6c13.6-17.1 30.7-30.2 50.8-38.9 6.1-2.6 12.4-4.8 19-6.6-14.5-23.7-40.6-39.6-70.3-39.6zM162 64h28v41h-28zM32 194h41v28H32zM81.6 276.8l-.8-.8-24.7 24.7 19.2 19.2 24.7-24.7zM79.289 92.13l24.678 24.678-19.233 19.233-24.678-24.678zM405.6 288.6C394.7 233.4 346.2 192 288 192c-34 0-65.1 11.9-86.5 38.8 29.4 2.2 56.7 13 77.8 33.9 15.6 15.6 26.6 34.6 32.1 55.3h-28.7c-13.1-37.3-48-64-90.6-64-5.1 0-12.3.6-17.7 1.7C128.6 267.1 96 305 96 352c0 53 43 96 96 96h208c44.2 0 80-35.8 80-80 0-42.2-32.8-76.5-74.4-79.4z"/></svg>
                                                Partly Sunny
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M96 448h106.7V64H96v384zM309.3 64v384H416V64H309.3z"/></svg>
                                                Pause
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M459.5 165.9c-4.7-10.5-12.7-18.1-23.1-22-4.8-1.7-9.7-2.6-14.8-2.6-21.7 0-43.7 16.7-54.9 41.6-13.8 30.9-5.8 61 18.6 70.3 4.9 1.8 10.1 2.8 15.6 2.8 22.1 0 44.6-15.3 55.9-38.1 8.5-17.5 9.5-36.8 2.7-52zM145.3 182.8c-11.1-24.9-33.2-41.6-54.9-41.6-5.1 0-10.1.9-14.8 2.6-10.4 3.9-18.3 11.5-23.1 22-6.9 15.2-5.9 34.6 2.7 51.9 11.3 22.8 33.8 38.1 55.9 38.1 5.4 0 10.7-.9 15.6-2.8 24.4-9.1 32.4-39.3 18.6-70.2zM193.5 179.4c2 .1 4 0 6-.2 11.7-.9 22.3-5.9 30.6-14.3 13.4-13.6 17.1-34.9 14.3-56.8-4.3-33.7-25.8-59-54.8-60.1 0 0-4.1 0-6.2.2-12.8 1.1-24.4 6.5-33.5 15.9-13.3 13.6-19.7 33.7-17.1 53.8 4.3 33.4 30.9 60.4 60.7 61.5zM256 224c-69.3 0-138.7 97.1-138.7 176.3 0 23.6 11.8 42.6 23.5 50.4 14.4 9.6 24.5 13.4 45.5 13.4 13.4 0 21.6-2.5 28.1-6.1 12.3-6.7 25.9-10.4 39.9-10.4h3.5c14 0 27.6 3.8 39.9 10.4 6.5 3.5 14.7 6.1 28.1 6.1 21.1 0 31.2-3.8 45.5-13.4 11.6-7.8 23.5-26.8 23.5-50.4C394.7 321 325.3 224 256 224zM312.6 179.1c2 .2 4 .2 6 .2 29.8-1.1 56.5-28 60.8-61.5 2.6-20.2-3.8-40.4-17.1-53.8-9.2-9.3-20.3-14.6-33.1-15.6-2.1-.2-6.7-.2-6.7-.2-28.9 1.1-50.4 26.1-54.8 59.9-2.8 21.9.9 43.3 14.3 56.8 8.4 8.3 19 13.2 30.6 14.2z"/></svg>
                                                Paw
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M337.454 232c33.599 0 61.092-27.002 61.092-60 0-32.997-27.493-60-61.092-60s-61.09 27.003-61.09 60c0 32.998 27.491 60 61.09 60zm-162.908 0c33.599 0 61.09-27.002 61.09-60 0-32.997-27.491-60-61.09-60s-61.092 27.003-61.092 60c0 32.998 27.493 60 61.092 60zm0 44C126.688 276 32 298.998 32 346v54h288v-54c0-47.002-97.599-70-145.454-70zm162.908 11.003c-6.105 0-10.325 0-17.454.997 23.426 17.002 32 28 32 58v54h128v-54c0-47.002-94.688-58.997-142.546-58.997z"/></svg>
                                                People
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 256c52.805 0 96-43.201 96-96s-43.195-96-96-96-96 43.201-96 96 43.195 96 96 96zm0 48c-63.598 0-192 32.402-192 96v48h384v-48c0-63.598-128.402-96-192-96z"/></svg>
                                                Person
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M304 256c52.805 0 96-43.201 96-96s-43.195-96-96-96-96 43.201-96 96 43.195 96 96 96zm0 48c-63.598 0-192 32.402-192 96v48h384v-48c0-63.598-128.402-96-192-96zM112 224v-64H80v64H16v32h64v64h32v-64h64v-32h-64z"/></svg>
                                                Person Add
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 358.856V153.143C480 130.512 461.674 112 439.272 112H72.728C50.326 112 32 130.512 32 153.143v205.713C32 381.488 50.326 400 72.728 400h366.545C461.674 400 480 381.488 480 358.856zM112 364V148h288v216H112z"/></svg>
                                                Phone Landscape
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M358.856 32H153.143C130.512 32 112 50.326 112 72.728v366.545C112 461.674 130.512 480 153.143 480h205.713C381.488 480 400 461.674 400 439.272V72.728C400 50.326 381.488 32 358.856 32zM364 400H148V112h216v288z"/></svg>
                                                Phone Portrait
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 32c-88.004 0-160 70.557-160 156.801C96 306.4 256 480 256 480s160-173.6 160-291.199C416 102.557 344.004 32 256 32zm0 212.801c-31.996 0-57.144-24.645-57.144-56 0-31.357 25.147-56 57.144-56s57.144 24.643 57.144 56c0 31.355-25.148 56-57.144 56z"/></svg>
                                                Pin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 48l42.9 379.2c2.6 20.8 20.5 36.8 42.5 36.8h213.3c22 0 39.9-16 42.5-36.8L448 48H64zm327 124.8H121l-9.4-83.2h288.6l-9.2 83.2z"/></svg>
                                                Pint
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M96 52v408l320-204L96 52z"/></svg>
                                                Play
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.2 48 48 141.2 48 256s93.2 208 208 208 208-93.2 208-208S370.8 48 256 48zm-41.6 301.6V162.4L339.2 256l-124.8 93.6z"/></svg>
                                                Play Circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M32 224h128v192H32zM192 128h128v288H192zM352 288h128v128H352z"/></svg>
                                                Podium
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M279.1 48h-46.2v231.1h46.2V48zm111.6 50.2L357.9 131c36.5 29.4 59.9 74.4 59.9 125 0 89.4-72.3 161.8-161.8 161.8S94.2 345.4 94.2 256c0-50.6 23.3-95.7 59.6-125.3l-32.6-32.6C76.4 136.3 48 192.7 48 256c0 114.9 93.1 208 208 208s208-93.1 208-208c0-63.3-28.4-119.7-73.3-157.8z"/></svg>
                                                Power
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 64H257.6L76.5 251.6c-8 8-12.3 18.5-12.5 29-.3 11.3 3.9 22.6 12.5 31.2l123.7 123.6c8 8 20.8 12.5 28.8 12.5s22.8-3.9 31.4-12.5L448 256V96l-32-32zm-30.7 102.7c-21.7 6.1-41.3-10-41.3-30.7 0-17.7 14.3-32 32-32 20.7 0 36.8 19.6 30.7 41.3-2.9 10.3-11.1 18.5-21.4 21.4z"/></svg>
                                                Pricetag
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                Print
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M428 269c-21.5 0-40.6 13.1-48.4 33h-41.2L307 221.3c-2.7-8.2-10.3-13.7-19-13.7h-.4c-8.8.2-16.4 6-18.8 14.5l-33.6 135.4-55.5-291.8C178 55.6 169.6 48 160 48c-9.5 0-16.9 6.2-19.4 16.2L90.3 302H32v40h74c9.2 0 17.2-6.2 19.4-15.2l30.7-160.6 54.1 282.1c1.5 8.8 8.9 15.1 18.6 15.7h1.2c9.3 0 16.9-5.3 19.2-13.5l40.2-162.9 15.5 40.7c2.7 8.2 10.3 13.7 19 13.7h56.4c8.3 19 27.1 31 47.6 31 13.9 0 26.9-5.6 36.8-15.8 9.8-10.1 15.2-23.3 15.2-37.2.1-28.6-22.7-51-51.9-51z"/></svg>
                                                Pulse
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M96 124.2c0-6.9 5.2-12.2 12.2-12.2H176V64h-66.8C75.7 64 48 90.7 48 124.2V192h48v-67.8zM403.6 64H336v48h67.2c6.9 0 12.8 5.2 12.8 12.2V192h48v-67.8c0-33.5-27-60.2-60.4-60.2zM416 386.8c0 6.9-5.2 12.2-12.2 12.2H336v49h67.8c33.5 0 60.2-27.7 60.2-61.2V320h-48v66.8zM108.2 399c-6.9 0-12.2-5.2-12.2-12.2V320H48v66.8c0 33.5 27.7 61.2 61.2 61.2H176v-49h-67.8z"/></svg>
                                                QR Scanner
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M96.4 416h77.1l50.9-96.6V96h-160v223.4h77.1L96.4 416zm224 0h77.1l50-96.6V96H288.4v223.4h82l-50 96.6z"/></svg>
                                                Quete
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M73.8 141.9c-15.2 6-25.8 21.8-25.8 39.5v256c0 23.5 18.5 42.7 41.6 42.7h332.8c23.1 0 41.6-19.2 41.6-42.7v-256c0-23.7-18.5-42.7-41.6-42.7H179l171.8-71.3L336.7 32 73.8 141.9zM160 438c-35.4 0-64-28.6-64-64s28.6-64 64-64 64 28.6 64 64-28.6 64-64 64zm256-171.3h-32v-46.2h-44.8v46.2H96v-85.3h320v85.3z"/></svg>
                                                Radio
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.601 48 48 141.601 48 256s93.601 208 208 208 208-93.601 208-208S370.399 48 256 48zm0 374.399c-91.518 0-166.399-74.882-166.399-166.399S164.482 89.6 256 89.6 422.4 164.482 422.4 256 347.518 422.399 256 422.399z"/></svg>
                                                Radio Button Off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 152c-57.2 0-104 46.8-104 104s46.8 104 104 104 104-46.8 104-104-46.8-104-104-104zm0-104C141.601 48 48 141.601 48 256s93.601 208 208 208 208-93.601 208-208S370.399 48 256 48zm0 374.4c-91.518 0-166.4-74.883-166.4-166.4S164.482 89.6 256 89.6 422.4 164.482 422.4 256 347.518 422.4 256 422.4z"/></svg>
                                                Radio Button On
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M139 400s-23 25.3-23 40.7c0 12.8 10.3 23.3 23 23.3s23-10.5 23-23.3c0-15.4-23-40.7-23-40.7zM217 368s-23 25.3-23 40.7c0 12.8 10.4 23.3 23 23.3 12.7 0 23-10.5 23-23.3 0-15.4-23-40.7-23-40.7zM295 400s-23 25.3-23 40.7c0 12.8 10.3 23.3 23 23.3 12.6 0 23-10.5 23-23.3 0-15.4-23-40.7-23-40.7zM373 368s-23 25.3-23 40.7c0 12.8 10.4 23.3 23 23.3 12.7 0 23-10.5 23-23.3 0-15.4-23-40.7-23-40.7zM393.2 161.2C380.5 96.6 323.9 48 256 48c-39.7 0-76 14-100.9 45.4 34.3 2.6 66.1 15.2 90.7 39.8 18.2 18.2 31 40.5 37.4 64.8h-33.5c-15.3-43.7-56-75-105.7-75-6 0-14.3.7-20.6 2C70 136 32 180.4 32 235.5 32 297.6 79.4 352 141.2 352h242.7c51.5 0 96.2-46 96.2-97.8-.1-49.4-38.4-89.6-86.9-93z"/></svg>
                                                Rainy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M369.8 160c-53.4 0-96.2 42.8-96.2 96 0 23.6 7.9 44.5 21.9 61.1h-78.8c14-16.6 21.9-37.5 21.9-61.1 0-53.2-42.9-96-96.2-96S46 202.8 46 256s42.9 96 96.2 96h227.5c53.4 0 96.2-42.8 96.2-96s-42.8-96-96.1-96zM142.2 317.1C108.1 317.1 81 290 81 256s27.1-61.1 61.2-61.1 61.2 27.1 61.2 61.1-27 61.1-61.2 61.1zm227.6 0c-34.1 0-61.2-27.1-61.2-61.1s27.1-61.1 61.2-61.1S431 222 431 256s-27.1 61.1-61.2 61.1z"/></svg>
                                                Recording
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M32 337.2L83.8 352c22.9-69.7 88.7-117.8 166-117.8 42.8 0 81.5 15.7 111.8 41.1L282.5 352H480V160l-79.6 76.3c-40.4-35.2-92.8-56.8-150.7-56.8-101.5.1-187.3 66.2-217.7 157.7z"/></svg>
                                                Redo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 388c-72.597 0-132-59.405-132-132 0-72.601 59.403-132 132-132 36.3 0 69.299 15.4 92.406 39.601L278 234h154V80l-51.698 51.702C348.406 99.798 304.406 80 256 80c-96.797 0-176 79.203-176 176s78.094 176 176 176c81.045 0 148.287-54.134 169.401-128H378.85c-18.745 49.561-67.138 84-122.85 84z"/></svg>
                                                Refresh
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.6 48 48 141.6 48 256s93.6 208 208 208 208-93.6 208-208S370.4 48 256 48zm112 194h-98l44.8-44.8C300.1 181.8 279.1 172 256 172c-46.2 0-84 37.8-84 84s37.8 84 84 84c34.9 0 65.3-21.2 77.6-52h29.8c-13.9 46.3-56.3 80-107.4 80-62.3 0-112-50.4-112-112s50.4-112 112-112c30.8 0 58.8 12.6 79.1 32.9L368 144v98z"/></svg>
                                                Refresh Circle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M96 235h320v42H96z"/></svg>
                                                Remove
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48C141.125 48 48 141.125 48 256s93.125 208 208 208 208-93.125 208-208S370.875 48 256 48zm107 229H149v-42h214v42z"/></svg>
                                                Remove Circle
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M96 348h320v36H96zM96 128h320v36H96zM96 200.7h320v35.6H96zM96 275.8h320v35.6H96z"/></svg>
                                                Reorder
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M149.3 152h213.3v62.4l85.3-83.2L362.7 48v62.4h-256v124.8h42.7V152zm213.4 208H149.3v-62.4L64 380.8l85.3 83.2v-62.4h256V276.8h-42.7V360z"/></svg>
                                                Repeat
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M297.6 48l64.9 64.9-249.6 249.6L48 297.6V464h166.4l-64.9-64.9 249.6-249.6 64.9 64.9V48z"/></svg>
                                                Resize
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M432.8 136v96H122.3l84.4-86.2-33.2-33.8L32 256l141.5 144 33.2-33.8-84.4-86.2H480V136h-47.2z"/></svg>
                                                Return Left
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M32 136v144h357.7l-84.4 86.2 33.2 33.8L480 256 338.5 112l-33.2 33.8 84.4 86.2H79.2v-96H32z"/></svg>
                                                Return Right
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M440 96h-88l-32-32H192l-32 32H72c-22.1 0-40 17.9-40 40v272c0 22.1 17.9 40 40 40h368c22.1 0 40-17.9 40-40V136c0-22.1-17.9-40-40-40zm-72 171h-97.7l44.8-45.1c-14.7-15.4-35.7-25.5-58.8-25.5-46.2 0-84 37.8-84 84s37.8 84 84 84c35.5 0 66.2-21.5 78.2-53.5h29.6c-13.4 47-56.2 81.5-107.8 81.5-62.3 0-112-50.4-112-112s50.4-112 112-112c30.8 0 58.7 12.6 79 32.9l32.8-32.9V267z"/></svg>
                                                Reverse Camera
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M249.6 402V110L32 256l217.6 146zm12.8-146L480 402V110L262.4 256z"/></svg>
                                                Rewind
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 32c-70.7 0-128 57.3-128 128s57.3 128 128 128 128-57.3 128-128S326.7 32 256 32zm0 208c-44.2 0-80-35.8-80-80s35.8-80 80-80 80 35.8 80 80-35.8 80-80 80zM193.7 307.4c-19.1-8.1-36.2-19.6-50.8-34.3-1.4-1.4-2.8-2.8-4.1-4.3L64 400h96l48 80 48-105.8 25.5-56.2c-8.4 1.3-16.9 2-25.5 2-21.6 0-42.5-4.2-62.3-12.6zM373.3 268.9c-1.3 1.4-2.7 2.9-4.1 4.3-14.6 14.6-31.7 26.2-50.7 34.2L294 361.2l-21.9 48.4L304 480l48-80h96l-74.7-131.1z"/></svg>
                                                Rebbon
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M260.6 214.8c23.8-40.9 48-71.6 91.4-96.4 8.3-4.8 21.2-8 22.8-8.9C290.7 83.7 256 32 256 32s-34.7 51.7-120.5 76.5c5.8 3.4 16.5 6.5 30.7 13.7 34.5 17.4 62.5 51.3 94.4 92.6zM246.3 253.4C186.7 161.2 131.4 126.8 48 126.8c54.2 78.6 52 174.6 52 215.4 0 76.1 69.8 137.8 156 137.8 57.6 0 107.9-27.6 135-68.7-35.5-27.6-85.1-65.7-144.7-157.9zM464 126.8s-55.2-2.3-85.2 15.4c-43 25.5-74.4 61.3-95.4 103.2 38.8 52 73 87.9 95.4 109.4 10.7 10.2 19.8 18.2 27.5 24.5 3.7-11.8 5.8-24.3 5.8-37.2-.1-40.8-17.4-114.1 51.9-215.3z"/></svg>
                                                Rose
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M362.7 64h-256C83 64 64 83.2 64 106.7v298.7c0 23.5 19 42.7 42.7 42.7h298.7c23.5 0 42.7-19.2 42.7-42.7v-256L362.7 64zM256 405.3c-35.4 0-64-28.6-64-64s28.6-64 64-64 64 28.6 64 64-28.6 64-64 64zM320 192H106.7v-85.3H320V192z"/></svg>
                                                Save
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M113.5 281.2v85.3L256 448l142.5-81.5v-85.3L256 362.7l-142.5-81.5zM256 64L32 192l224 128 183.3-104.7v147.4H480V192L256 64z"/></svg>
                                                School
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M337.509 305.372h-17.501l-6.571-5.486c20.791-25.232 33.922-57.054 33.922-93.257C347.358 127.632 283.896 64 205.135 64 127.452 64 64 127.632 64 206.629s63.452 142.628 142.225 142.628c35.011 0 67.831-13.167 92.991-34.008l6.561 5.487v17.551L415.18 448 448 415.086 337.509 305.372zm-131.284 0c-54.702 0-98.463-43.887-98.463-98.743 0-54.858 43.761-98.742 98.463-98.742 54.7 0 98.462 43.884 98.462 98.742 0 54.856-43.762 98.743-98.462 98.743z"/></svg>
                                                Search
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M48 448l416-192L48 64v149.333L346 256 48 298.667z"/></svg>
                                                Send
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M413.967 276.8c1.06-6.235 1.06-13.518 1.06-20.8s-1.06-13.518-1.06-20.8l44.667-34.318c4.26-3.118 5.319-8.317 2.13-13.518L418.215 115.6c-2.129-4.164-8.507-6.235-12.767-4.164l-53.186 20.801c-10.638-8.318-23.394-15.601-36.16-20.801l-7.448-55.117c-1.06-4.154-5.319-8.318-10.638-8.318h-85.098c-5.318 0-9.577 4.164-10.637 8.318l-8.508 55.117c-12.767 5.2-24.464 12.482-36.171 20.801l-53.186-20.801c-5.319-2.071-10.638 0-12.767 4.164L49.1 187.365c-2.119 4.153-1.061 10.399 2.129 13.518L96.97 235.2c0 7.282-1.06 13.518-1.06 20.8s1.06 13.518 1.06 20.8l-44.668 34.318c-4.26 3.118-5.318 8.317-2.13 13.518L92.721 396.4c2.13 4.164 8.508 6.235 12.767 4.164l53.187-20.801c10.637 8.318 23.394 15.601 36.16 20.801l8.508 55.117c1.069 5.2 5.318 8.318 10.637 8.318h85.098c5.319 0 9.578-4.164 10.638-8.318l8.518-55.117c12.757-5.2 24.464-12.482 36.16-20.801l53.187 20.801c5.318 2.071 10.637 0 12.767-4.164l42.549-71.765c2.129-4.153 1.06-10.399-2.13-13.518l-46.8-34.317zm-158.499 52c-41.489 0-74.46-32.235-74.46-72.8s32.971-72.8 74.46-72.8 74.461 32.235 74.461 72.8-32.972 72.8-74.461 72.8z"/></svg>
                                                Setting
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M383.822 344.427c-16.045 0-31.024 5.326-41.721 15.979l-152.957-88.42c1.071-5.328 2.142-9.593 2.142-14.919 0-5.328-1.071-9.593-2.142-14.919l150.826-87.35c11.762 10.653 26.741 17.041 43.852 17.041 35.295 0 64.178-28.766 64.178-63.92C448 72.767 419.117 44 383.822 44c-35.297 0-64.179 28.767-64.179 63.92 0 5.327 1.065 9.593 2.142 14.919l-150.821 87.35c-11.767-10.654-26.741-17.041-43.856-17.041-35.296 0-63.108 28.766-63.108 63.92 0 35.153 28.877 63.92 64.178 63.92 17.115 0 32.089-6.389 43.856-17.042l151.891 88.421c-1.076 4.255-2.141 8.521-2.141 13.847 0 34.094 27.806 61.787 62.037 61.787 34.229 0 62.036-27.693 62.036-61.787.001-34.094-27.805-61.787-62.035-61.787z"/></svg>
                                                Share
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M448 248L288 96v85.334C138.666 202.667 85.333 309.334 64 416c53.333-74.666 117.333-108.802 224-108.802v87.469L448 248z"/></svg>
                                                Share-alt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M320 64c-11.1 19.1-40.3 32-64 32s-52.9-12.9-64-32L64 96v96l77-16-13 272h256l-13-272 77 16V96L320 64z"/></svg>
                                                Shirt
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M222.2 188.1L97.8 64 64 97.8l124.1 124.1 34.1-33.8zM316 64l49 49L64 414.2 97.8 448 399 147l49 49V64H316zm7.9 225.8l-33.8 33.8 75.1 75.1L316 448h132V316l-49 49-75.1-75.2z"/></svg>
                                                Shuffle
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M170.7 256L448 448V64L170.7 256zM64 64h64v384H64z"/></svg>
                                                Skip backward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 64v384l277.3-192L64 64zM384 64h64v384h-64z"/></svg>
                                                Skip Forward
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M461.4 298.5l-8.3-30.9-88 23.6-60.4-34.9 60.4-34.9 88 23.6 8.3-30.9-57.1-15.3 57.7-33.3-24-41.5-56.6 32.7 15.3-57.1-30.9-8.3-23.6 88-62.2 35.9v-71.1l64.5-64.4-22.7-22.6L280 98.9V32h-48v65.6l-41.7-41.7-22.6 22.6 64.3 64.4v71.4l-60.7-35-23.6-88-30.9 8.3 15.3 57.1-57.7-33.4-24 41.6 56.7 32.7L50 212.9l8.3 30.9 87.9-23.6 62.6 36.1-62.6 36.2-87.9-23.6-8.3 30.9 57.1 15.3-56.7 32.7 24 41.5 57.7-33.3-15.3 57 30.9 8.3 23.6-87.9 60.7-35.1v70.9l-64.3 64.4 22.6 22.6 41.7-41.8V480h48v-66.8l41.9 41.7 22.5-22.6L280 368v-70.6l62.2 36 23.6 87.9 30.9-8.3-15.3-57 56.6 32.7 24-41.6-57.7-33.3z"/></svg>
                                                Snow
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M405.333 64H106.667C83.198 64 64 83.198 64 106.667v298.666C64 428.802 83.198 448 106.667 448h298.666C428.802 448 448 428.802 448 405.333V106.667C448 83.198 428.802 64 405.333 64z"/></svg>
                                                Square
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M405.3 106.7v298.7H106.7V106.7h298.6m0-42.7H106.7C83.2 64 64 83.2 64 106.7v298.7c0 23.5 19.2 42.7 42.7 42.7h298.7c23.5 0 42.7-19.2 42.7-42.7V106.7C448 83.2 428.8 64 405.3 64z"/></svg>
                                                Square Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 372.686L380.83 448l-33.021-142.066L458 210.409l-145.267-12.475L256 64l-56.743 133.934L54 210.409l110.192 95.525L131.161 448z"/></svg>
                                                Star
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M458 210.409l-145.267-12.476L256 64l-56.743 133.934L54 210.409l110.192 95.524L131.161 448 256 372.686 380.83 448l-33.021-142.066L458 210.409zM272.531 345.287L256 335.313l-.002-189.277 27.27 64.379 7.52 17.751 19.208 1.65 69.846 5.998-52.993 45.939-14.576 12.636 4.367 18.788 15.875 68.299-59.984-36.189z"/></svg>
                                                Star Half
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M458 210.409l-145.267-12.476L256 64l-56.743 133.934L54 210.409l110.192 95.524L131.161 448 256 372.686 380.83 448l-33.021-142.066L458 210.409zM272.531 345.286L256 335.312l-16.53 9.973-59.988 36.191 15.879-68.296 4.369-18.79-14.577-12.637-52.994-45.939 69.836-5.998 19.206-1.65 7.521-17.75 27.276-64.381 27.27 64.379 7.52 17.751 19.208 1.65 69.846 5.998-52.993 45.939-14.576 12.636 4.367 18.788 15.875 68.299-59.984-36.189z"/></svg>
                                                Star Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M176 64h64v384h-64zM80 336h64v112H80zM272 272h64v176h-64zM368 176h64v272h-64z"/></svg>
                                                Stats
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48c-93.864 0-176 10.668-176 85.334v213.332c0 41.604 33.062 74.666 74.667 74.666L128 448v16h256v-16l-26.667-26.668c41.604 0 74.667-33.062 74.667-74.666V133.334C432 58.668 349.864 48 256 48zm-96 336c-18.136 0-32-13.865-32-32 0-18.137 13.864-32 32-32s32 13.863 32 32c0 18.135-13.864 32-32 32zm80-144H128v-96h112v96zm112 144c-18.136 0-32-13.865-32-32 0-18.137 13.864-32 32-32s32 13.863 32 32c0 18.135-13.864 32-32 32zm32-144H272v-96h112v96z"/></svg>
                                                Subway
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M277.3 32h-42.7v64h42.7V32zm129.1 43.7L368 114.1l29.9 29.9 38.4-38.4-29.9-29.9zm-300.8 0l-29.9 29.9 38.4 38.4 29.9-29.9-38.4-38.4zM256 128c-70.4 0-128 57.6-128 128s57.6 128 128 128 128-57.6 128-128-57.6-128-128-128zm224 106.7h-64v42.7h64v-42.7zm-384 0H32v42.7h64v-42.7zM397.9 368L368 397.9l38.4 38.4 29.9-29.9-38.4-38.4zm-283.8 0l-38.4 38.4 29.9 29.9 38.4-38.4-29.9-29.9zm163.2 48h-42.7v64h42.7v-64z"/></svg>
                                                Sunny
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M131.3 231.1L32 330.6l99.3 99.4v-74.6h174.5v-49.7H131.3v-74.6zM480 181.4L380.7 82v74.6H206.2v49.7h174.5v74.6l99.3-99.5z"/></svg>
                                                Swap
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M168 216h94.9c14.5 14.8 34.7 24 57.1 24 44.2 0 80-35.8 80-80s-35.8-80-80-80c-22.4 0-42.6 9.2-57.1 24H168c-30.8 0-56 25.2-56 56s25.2 56 56 56zm-16.9-72.9c4.6-4.6 10.6-7.1 16.9-7.1h75.7c-2.4 7.6-3.7 15.6-3.7 24s1.3 16.4 3.7 24H168c-6.3 0-12.4-2.5-16.9-7.1-4.6-4.6-7.1-10.6-7.1-16.9s2.5-12.4 7.1-16.9zM344 296h-94.9c-14.5-14.8-34.7-24-57.1-24-44.2 0-80 35.8-80 80s35.8 80 80 80c22.4 0 42.6-9.2 57.1-24H344c30.8 0 56-25.2 56-56s-25.2-56-56-56zm16.9 72.9c-4.6 4.6-10.6 7.1-16.9 7.1h-75.7c2.4-7.6 3.7-15.6 3.7-24s-1.3-16.4-3.7-24H344c6.3 0 12.4 2.5 16.9 7.1 4.6 4.6 7.1 10.6 7.1 16.9s-2.5 12.4-7.1 16.9z"/></svg>
                                                Switch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 93.09V32l-80 81.454 80 81.456v-61.093c65.996 0 120 54.982 120 122.183 0 20.363-5 39.714-14.004 57.016L391 342.547c15.996-25.457 25-54.988 25-86.547 0-89.599-72.002-162.91-160-162.91zm0 285.094c-66.001 0-120-54.988-120-122.184 0-20.363 5-39.709 13.999-57.02L121 169.454C104.999 193.89 96 224.436 96 256c0 89.599 72.002 162.91 160 162.91V480l80-81.453-80-81.457v61.094z"/></svg>
                                                Sync
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M32 120v272c0 13.3 10.7 24 24 24h400c13.3 0 24-10.7 24-24V120c0-13.3-10.7-24-24-24H56c-13.3 0-24 10.7-24 24zm384 8v256H80V128h336zm46 128c0 7.7-6.5 14-14.1 14-7.5 0-14-6.2-14-14 0-7.7 6.4-14.1 14-14.1 7.6.1 14.1 6.4 14.1 14.1z"/></svg>
                                                Table Landscape
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M392 32H120c-13.3 0-24 10.7-24 24v400c0 13.3 10.7 24 24 24h272c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24zm-8 384H128V80h256v336zm-128 46c-7.7 0-14-6.5-14-14.1 0-7.5 6.2-14 14-14 7.7 0 14.1 6.4 14.1 14-.1 7.6-6.4 14.1-14.1 14.1z"/></svg>
                                                Table Portrait
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M408 64H96c-22.002 0-32 17.998-32 40v344l64-64h280c22.002 0 40-17.998 40-40V104c0-22.002-17.998-40-40-40zM198.4 242H160v-40h38.4v40zm76.8 0h-38.4v-40h38.4v40zm76.8 0h-38.4v-40H352v40z"/></svg>
                                                Text
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M303 300.2V78.4c0-25.7-21-46.5-47-46.5s-47 20.8-47 46.5v221.9c-29 16.5-48.9 47.8-48.9 83.7 0 53 43 96 96 96s96-43 96-96c0-36-20.1-67.3-49.1-83.8zM240 78.4c0-8 7.7-14.5 16-14.5s16 6.5 16 14.5V128h-32V78.4z"/></svg>
                                                Thermometer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M314 64H142c-15.7 0-28.6 9.6-34.2 23.4L50.6 222.8c-1.7 4.4-2.6 9-2.6 14v38.6c0 21.1 17 44.6 37.8 44.6h119.3l-18 81.5-.6 6c0 7.9 3.2 15.1 8.3 20.3l20 20.1L341 320.7c6.8-6.9 11-16.5 11-27.1v-192c0-21.1-17.2-37.6-38-37.6zM400 64h64v224h-64z"/></svg>
                                                Thumbs Down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M198 448h172c15.7 0 28.6-9.6 34.2-23.4l57.1-135.4c1.7-4.4 2.6-9 2.6-14v-38.6c0-21.1-17-44.6-37.8-44.6H306.9l18-81.5.6-6c0-7.9-3.2-15.1-8.3-20.3L297 64 171 191.3c-6.8 6.9-11 16.5-11 27.1v192c0 21.1 17.2 37.6 38 37.6zM48 224h64v224H48z"/></svg>
                                                Thumbs Up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M393.2 161.2C380.5 96.6 323.9 48 256 48c-39.7 0-76 14-100.9 45.4 34.3 2.6 66.1 15.2 90.7 39.8 18.2 18.2 31 40.5 37.4 64.8h-33.5c-15.3-43.7-56-75-105.7-75-6 0-14.3.7-20.6 2C70 136 32 180.4 32 235.5 32 297.6 82.2 336 144 336h68V233h99.1l-33.2 67H311l-18 36h93.7c51.5 0 93.3-30 93.3-81.8 0-49.4-38.3-89.6-86.8-93zM212 368h22v96l59-128h-81z"/></svg>
                                                Thunderstorm
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M232.9 371.6c0 12.7 10.4 23.1 23.1 23.1s23.1-10.4 23.1-23.1c0-12.7-10.4-23.1-23.1-23.1s-23.1 10.3-23.1 23.1zm0-323.6v92.4h46.2V96.1c78.3 11.3 138.7 78.3 138.7 159.9 0 89.4-72.3 161.8-161.8 161.8S94.2 345.4 94.2 256c0-38.8 13.6-74.4 36.5-102.2L256 279.1l32.6-32.6L131.4 89.4v.5C80.8 127.7 48 187.8 48 256c0 114.9 92.9 208 208 208 114.9 0 208-93.1 208-208S370.9 48 256 48h-23.1zm161.8 208c0-12.7-10.4-23.1-23.1-23.1-12.7 0-23.1 10.4-23.1 23.1s10.4 23.1 23.1 23.1c12.7 0 23.1-10.4 23.1-23.1zm-277.4 0c0 12.7 10.4 23.1 23.1 23.1s23.1-10.4 23.1-23.1-10.4-23.1-23.1-23.1-23.1 10.4-23.1 23.1z"/></svg>
                                                Timer
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48c-88 0-176 10.9-176 87.6v208c0 42.3 34.5 76.6 77 76.6L124 453v11h49.1l44-43.8H300l44 43.8h44v-10.9l-33-32.8c42.5 0 77-34.4 77-76.6v-208C432 58.9 353.2 48 256 48zm-99 328.4c-18.3 0-33-14.7-33-32.8s14.7-32.8 33-32.8 33 14.7 33 32.8-14.7 32.8-33 32.8zm77-153.2H124v-87.6h110v87.6zm44 0v-87.6h110v87.6H278zm77 153.2c-18.3 0-33-14.7-33-32.8s14.7-32.8 33-32.8 33 14.7 33 32.8-14.7 32.8-33 32.8z"/></svg>
                                                Train
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M352 32v35h63.1l-81.4 80.5c-7.5-7.2-13.2-11-13.2-11C302.2 123.6 280 116 256 116c-30.2 0-57.6 12-77.8 31.4l-15.2-15 31.4-31.4-28.5-28.5-31.5 31.5-37.5-37H160V32H32v128h35V91.3l40.3 39.9-31.2 31.2 28.5 28.5 31.4-31.4 19.4 19.2c-7.3 14.9-11.5 31.7-11.5 49.5 0 54.8 39.5 100.4 91.1 110.2v45.3h-63V424h63v56h42v-56h63v-40.2h-63v-45.3c50.8-9.9 91.2-55.5 91.2-110.3 0-17.7-4.2-34.8-11.5-49.6L445 91.3V160h35V32H352zm-96 258c-35.3 0-64-28.7-64-64s28.7-64 64-64 64 28.7 64 64-28.7 64-64 64z"/></svg>
                                                Transgender
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M128 405.429C128 428.846 147.198 448 170.667 448h170.667C364.802 448 384 428.846 384 405.429V160H128v245.429zM416 96h-80l-26.785-32H202.786L176 96H96v32h320V96z"/></svg>
                                                Trash
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 397V262.5l-51.3 51.3-141.1-141-89.6 89.7L63.6 128 32 159.6l166 166.3 89.6-89.7 109.3 109.4-51.3 51.4H480z"/></svg>
                                                Trending Down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M345.6 128l51.3 51.3-109.3 109.4-89.6-89.6L32 365.4 63.6 397 198 262.5l89.6 89.7 141.1-141 51.3 51.3V128H345.6z"/></svg>
                                                Trending Up
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M392 105c.9-27 .2-56 .1-57H119.3c0 1-.8 30 .1 57H48c0 68 9.9 102.3 21 126.7S95.4 277 127.7 302c30.1 23.3 95.5 53.6 104.3 57.6v28.3c-4.6 10-23.5 28.2-83.3 28.2H128v48h256v-48h-25.7c-60.7 0-75-19.1-78.3-28.2v-28.3c9.3-4.6 80.9-40.3 104.4-57.5 25.2-18.4 50.9-51.5 58.7-70.3S464 167 464 105h-72zM109.6 211.9c-8.8-18.2-14-37.9-15.7-61.9h28.7c.7 6 1.4 11.3 2.3 16.3 6.6 39.2 14.8 70.2 25.7 96.5-17.3-13.5-31.3-30.8-41-50.9zm292.8 0c-9.9 20.3-24 37.7-41.6 51.3 11-26.2 19-56.8 25.8-96.9.8-5 1.6-10.3 2.3-16.3h29.3c-1.8 24-6.9 43.7-15.8 61.9z"/></svg>
                                                Trophy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M439.3 76H72.7C50.3 76 32 94 32 116v240c0 22 18.3 40 40.7 40h101.8v40h162.9v-40h101.8c22.4 0 40.5-18 40.5-40l.2-240c.1-22-18.2-40-40.6-40zm0 280H72.7V116h366.5v240z"/></svg>
                                                TV
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M410.1 244.1c12 0 26.6 10.9 33.8 25.9H464c-.3-50-21.2-101.5-59.4-140.9-36.3-37.4-83-60.5-132.6-65.7-3-9-11.5-15.4-21.6-15.4-10 0-18.5 6.5-21.5 15.3C125.3 73.8 48 159.7 48 266.2c0 1.1.1 1.8.4 3.8h21.8c6.8-15 22.2-25.9 35.3-25.9 17 0 31.5 10.9 36.5 25.9h19.8c4.1-15 16.9-25.7 33-25.7 17.8 0 33.1 14.5 34.1 32.6v118.3c0 9.3.1 24.1-13.4 24.1-6.9 0-16.6-1.8-16.6-16V382h-43v21.3c0 34.6 23.6 60.7 60 60.7 19.5 0 33.3-8.5 43.5-18.7 13.1-13.2 13.5-34.7 13.5-50.1V276.1c2-25.8 23.9-31.7 41.9-31.7 17.2 0 32.3 11.6 37.8 25.6h20.5c5.1-15 19.8-25.9 37-25.9z"/></svg>
                                                Umbrella
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M262.3 179.6c-57.9 0-110.3 21.6-150.7 56.8L32 160v192h197.5l-79.1-76.8c30.4-25.3 69-41.1 111.8-41.1 77.3 0 143.1 48.2 166 117.8l51.8-14.8c-30.4-91.4-116.2-157.5-217.7-157.5z"/></svg>
                                                Undo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M376 186h-20v-40c0-55-45-100-100-100S156 91 156 146h37.998c0-34.004 28.003-62.002 62.002-62.002 34.004 0 62.002 27.998 62.002 62.002H318v40H136c-22.002 0-40 17.998-40 40v200c0 22.002 17.998 40 40 40h240c22.002 0 40-17.998 40-40V226c0-22.002-17.998-40-40-40zM256 368c-22.002 0-40-17.998-40-40s17.998-40 40-40 40 17.998 40 40-17.998 40-40 40z"/></svg>
                                                Unlock
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M384 219.5v-85.2c0-13.4-11.2-24.3-24.9-24.3H56.9C43.2 110 32 120.9 32 134.3v243.3C32 391 43.2 402 56.9 402h302.2c13.7 0 24.9-11 24.9-24.3v-85.2l96 97.3V122.2l-96 97.3z"/></svg>
                                                Videocam
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 192v128h85.334L256 431.543V80.458L149.334 192H64zm288 64c0-38.399-21.333-72.407-53.333-88.863v176.636C330.667 328.408 352 294.4 352 256zM298.667 64v44.978C360.531 127.632 405.334 186.882 405.334 256c0 69.119-44.803 128.369-106.667 147.022V448C384 428.254 448 349.257 448 256c0-93.256-64-172.254-149.333-192z"/></svg>
                                                Volume High
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 192v128h85.334L256 431.543V80.458L149.334 192H64zm288 64c0-38.399-21.333-72.407-53.333-88.863v176.636C330.667 328.408 352 294.4 352 256z"/></svg>
                                                Volume low
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 192v128h85.334L256 431.543V80.458L149.334 192H64z"/></svg>
                                                Volume Mute
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M405.5 256c0 22.717-4.883 44.362-13.603 63.855l31.88 31.88C439.283 323.33 448 290.653 448 256c0-93.256-64-172.254-149-192v44.978C361 127.632 405.5 186.882 405.5 256zM256 80.458l-51.021 52.48L256 183.957zM420.842 396.885L91.116 67.157l-24 24 90.499 90.413-8.28 10.43H64v128h85.334L256 431.543V280l94.915 94.686C335.795 387.443 318 397.213 299 403.022V448c31-7.172 58.996-22.163 82.315-42.809l39.61 39.693 24-24.043-24.002-24.039-.081.083z"/><path d="M352.188 256c0-38.399-21.188-72.407-53.188-88.863v59.82l50.801 50.801A100.596 100.596 0 0 0 352.188 256z"/></svg>
                                                Volume Off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M288 112c22.223 0 39.997-17.776 39.997-40 0-22.225-17.774-40-39.997-40s-40.003 17.775-40.003 40c0 22.224 17.78 40 40.003 40zM288 232h104v-40h-72l-44.802-69.333c-7.698-11.667-18.136-18.136-30.933-18.136-3.198 0-8.828.531-12.799 1.747L120 144v112h40v-80l40.531-16L120 480h40l56.698-164.271L267 384v96h38V352l-57.031-96 19.745-61.864L288 232z"/></svg>
                                                Walk
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M32 464h448L256 48 32 464zm248-64h-48v-48h48v48zm0-80h-48v-96h48v96z"/></svg>
                                                Warning
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M416 256c0-51.001-24.004-96.001-60.996-125L336 16H176l-19.004 115C120.004 159.999 96 204.999 96 256c0 50.996 24.004 95.996 60.996 125L176 496h160l19.004-115C391.996 351.996 416 306.996 416 256zm-280 0c0-66.001 54.004-120 120-120s120 53.999 120 120c0 65.996-54.004 120-120 120s-120-54.004-120-120z"/></svg>
                                                Watch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M380.5 163.3L256 32 131.5 163.3c-68.6 72.4-68.6 190 0 262.4C165.8 461.9 210.9 480 256 480s90.2-18.1 124.5-54.3c68.7-72.4 68.7-190 0-262.4z"/></svg>
                                                Water
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 228.719c-22.879 0-41.597 18.529-41.597 41.18 0 22.652 18.718 41.182 41.597 41.182 22.878 0 41.597-18.529 41.597-41.182 0-22.651-18.719-41.18-41.597-41.18zm124.8 41.179c0-67.946-56.163-123.539-124.8-123.539s-124.8 55.593-124.8 123.539c0 45.303 24.961 85.447 62.396 107.072l20.807-36.032c-24.972-14.417-41.604-40.153-41.604-71.04 0-45.295 37.433-82.358 83.201-82.358 45.771 0 83.201 37.063 83.201 82.358 0 30.887-16.633 56.623-41.604 71.04l20.807 36.032c37.433-21.624 62.396-61.769 62.396-107.072zM256 64C141.597 64 48 156.654 48 269.898 48 346.085 89.592 411.968 152 448l20.799-36.032c-49.919-28.824-83.207-81.324-83.207-142.069 0-90.593 74.891-164.718 166.408-164.718 91.517 0 166.406 74.125 166.406 164.718 0 60.745-33.284 114.271-83.205 142.069L360 448c62.406-36.032 104-101.915 104-178.102C464 156.654 370.403 64 256 64z"/></svg>
                                                Wifi
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M234.667 277.333V408H128v40h256v-40H277.333V277.333L448 106.667V64H64v42.667l170.667 170.666zm-74.667-128l-42.667-42.666h277.334L352 149.333H160z"/></svg>
                                                Wine
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M190.4 148.6L161 252.9c-6.3 22.8 20.7 31.7 27.3 10.3l26.3-96.2h7.4l-45.2 169H219v127c0 23 32 23 32 0V336h10v127c0 23 31 23 31 0V336h43.4l-46.2-169h8.4l26.3 96.2c6.5 21.9 33.3 12.5 27.3-10.2l-29.4-104.4c-4-11.8-18.2-32.6-42-33.6h-47.3c-24.6 1-38.7 21.6-42.1 33.6zM292.6 69.2c0-20.6-16.4-37.3-36.6-37.3-20.2 0-36.6 16.7-36.6 37.3 0 20.6 16.4 37.3 36.6 37.3 20.2 0 36.6-16.7 36.6-37.3z"/></svg>
                                                Woman
                                            </div>
                                        </div>
                                        <h4 class="mt-0 header-title">Duel Color Examples</h4>
                                        <p class="text-muted mb-4">Use SVG Icons.</p>
                                        <div class="row icon-demo-content">
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M363 277h-86v86h-42v-86h-86v-42h86v-86h42v86h86v42z"/>
                                                    <path d="M256 90c44.3 0 86 17.3 117.4 48.6C404.7 170 422 211.7 422 256s-17.3 86-48.6 117.4C342 404.7 300.3 422 256 422c-44.3 0-86-17.3-117.4-48.6C107.3 342 90 300.3 90 256c0-44.3 17.3-86 48.6-117.4C170 107.3 211.7 90 256 90m0-42C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48z"/>
                                                </svg>
                                                Add Circle-outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M154.7 464h266.7c23.5 0 42.7-19.2 42.7-42.7V154.7c0-23.5-19.2-42.7-42.7-42.7H154.7c-23.5 0-42.7 19.2-42.7 42.7v266.7c0 23.4 19.2 42.6 42.7 42.6z"/>
                                                    <path d="M90.7 48h266.7c23.5 0 42.7 19.2 42.7 42.7V96H138.7C115.2 96 96 115.2 96 138.7V400h-5.3C67.2 400 48 380.8 48 357.3V90.7C48 67.2 67.2 48 90.7 48z"/>
                                                </svg>
                                                Albums
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M32 256c14.1 35 36.2 66 64 90.6V165.4C68.2 190 46.1 221 32 256zM480 256c-14.1-35-36.2-66-64-90.6v181.2c27.8-24.6 49.9-55.6 64-90.6z"/>
                                                    <g>
                                                        <path d="M256 105c-47.1 0-91 13.4-128 36.5v228.9c37 23.1 80.9 36.5 128 36.5s91-13.4 128-36.5V141.5c-37-23.1-80.9-36.5-128-36.5zm96 135v64h-32v-32h-48v32h-32v-32h-48v32h-32v-96h32v32h48v-32h32v32h48v-32h32v32z"/>
                                                    </g>
                                                </svg>
                                                American Football
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M379.4 178.3l-87.2 133.4C299 320 303 330.5 303 342c0 26.5-21.5 48-48 48s-48-21.5-48-48c0-3 .3-6 .8-8.9l-57.6-33.5c-8.6 8.3-20.3 13.4-33.3 13.4-8.6 0-16.6-2.3-23.6-6.2L32 364.2v57.2c0 23.5 19.2 42.7 42.7 42.7h362.7c23.5 0 42.7-19.2 42.7-42.7V208.8l-58.6-38.9c-8.1 6.3-18.3 10.1-29.4 10.1-4.4 0-8.7-.6-12.7-1.7z"/>
                                                    <path d="M117 217c26.5 0 48 21.5 48 48 0 2.1-.2 4.2-.4 6.2l60.1 33.6c8.3-6.8 18.8-10.8 30.4-10.8 3.6 0 7.1.4 10.4 1.1l87.4-135.4c-5.6-7.8-8.9-17.4-8.9-27.8 0-26.5 21.5-48 48-48s48 21.5 48 48c0 3.9-.5 7.7-1.3 11.3l41.3 27.6V90.7c0-23.5-19.2-42.7-42.7-42.7H74.7C51.2 48 32 67.2 32 90.7V320l40-38.3c-1.9-5.2-3-10.8-3-16.7 0-26.5 21.5-48 48-48z"/>
                                                </svg>
                                                Analytics
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M256 32C132.288 32 32 132.288 32 256s100.288 224 224 224 224-100.288 224-224S379.712 32 256 32zm135.765 359.765C355.5 428.028 307.285 448 256 448s-99.5-19.972-135.765-56.235C83.972 355.5 64 307.285 64 256s19.972-99.5 56.235-135.765C156.5 83.972 204.715 64 256 64s99.5 19.972 135.765 56.235C428.028 156.5 448 204.715 448 256s-19.972 99.5-56.235 135.765z"/>
                                                    <path d="M200.043 106.067c-40.631 15.171-73.434 46.382-90.717 85.933H256l-55.957-85.933zM412.797 288A160.723 160.723 0 0 0 416 256c0-36.624-12.314-70.367-33.016-97.334L311 288h101.797zM359.973 134.395C332.007 110.461 295.694 96 256 96c-7.966 0-15.794.591-23.448 1.715L310.852 224l49.121-89.605zM99.204 224A160.65 160.65 0 0 0 96 256c0 36.639 12.324 70.394 33.041 97.366L201 224H99.204zM311.959 405.932c40.631-15.171 73.433-46.382 90.715-85.932H256l55.959 85.932zM152.046 377.621C180.009 401.545 216.314 416 256 416c7.969 0 15.799-.592 23.456-1.716L201.164 288l-49.118 89.621z"/>
                                                </svg>
                                                Aperture
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M265.6 212.3c-10.5 0-18.5 4.4-24 13.2-5.5 8.8-9.1 22-10.8 39.6-.9 11.7 0 20.5 2.7 26.5s7.1 9 13.1 9c5.5 0 10.3-1.5 14.6-4.4 4.3-2.9 8.1-8.3 11.3-16.2l6.1-66c-2.2-.5-4.4-.9-6.5-1.2-2.3-.4-4.4-.5-6.5-.5z"/>
                                                    <path d="M256 48C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48zm127.8 201.9c-.9 21.4-7.6 39.9-20 55.6-12.4 15.6-31 23.4-55.6 23.4-8.2 0-15.3-2.2-21.2-6.6-6-4.4-10.2-10.7-12.6-18.8-4.1 8.3-9.4 14.5-15.7 18.6-6.3 4.1-13.7 6.2-22.2 6.2-15.1 0-26.6-5.8-34.6-17.3s-10.9-26.8-8.8-45.9c2.6-24.4 10-44 22.2-58.7 12.2-14.7 27-22 44.4-22 12.2 0 22.1 1.3 29.5 3.8 7.4 2.5 15.6 5.7 24.5 11l-.5-.1h.8l-7.7 83.4c-.5 8.5.1 14.6 1.7 17.8 1.7 3.2 3.9 4.9 6.7 4.9 11.3 0 20.4-5.1 27.2-15.6 6.8-10.5 10.6-23.6 11.4-39.6 1.6-33-5.1-58.7-20.2-77.1-15.1-18.4-38.3-27.7-69.7-27.7-30.5 0-54.8 9.9-72.8 29.8s-27.7 46.9-29.3 81.2c-1.7 33.4 5.6 59.8 21.9 79.1 16.3 19.4 39.7 29.1 70.3 29.1 8.5 0 17.3-.9 26.5-2.7 9.1-1.8 17.1-4.1 23.7-6.8l5.8 24.2c-6.8 4.1-15.4 7.3-25.9 9.6-10.5 2.3-20.7 3.4-30.7 3.4-40.8 0-72.3-12.1-94.3-36.4-22-24.2-32.2-57.4-30.5-99.6 1.8-41.8 14.9-74.9 39.1-99.4 24.3-24.5 56.5-36.7 96.7-36.7 39.5 0 69.8 11.6 90.7 34.7 21.2 23.2 30.8 54.9 29.2 95.2z"/>
                                                </svg>
                                                At
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M88 128h48v256H88zM232 128h48v256h-48zM160 144h48v224h-48zM304 144h48v224h-48zM376 128h48v256h-48z"/><path d="M104 104V56H16v400h88v-48H64V104zM408 56v48h40v304h-40v48h88V56z"/>
                                                </svg>
                                                Barcode
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M365.9 402.6L343 416.1l-16-28 20.2-11.9c-5.2-8.5-9.8-17.4-13.9-26.7-1.4-3.1-2.7-6.3-3.9-9.5l-25.1 5.8-7.1-31.6 22.6-5.2c-2.8-12.1-4.7-24-5.5-37H290v-32h24.3c.8-12 2.7-24.8 5.5-36.8l-22.6-5.2 7.1-31.6 25.1 5.8c1.3-3.2 2.6-6.4 4-9.6 4.1-9.2 8.7-18.1 13.8-26.6L327 124.1l16-28 22.8 13.5c5.2-6.4 10.8-12.5 16.7-18.3C347.4 64.1 303.5 48 256 48s-91.4 16.1-126.5 43.2c5.9 5.8 11.5 12 16.7 18.3L169 96.1l16 28-20.2 11.9c5.1 8.5 9.8 17.4 13.8 26.6 1.4 3.2 2.7 6.4 4 9.6l25.1-5.8 7.1 31.6-22.6 5.2c2.8 12.1 4.6 24.8 5.5 36.8H222v32h-24.3c-.8 13-2.7 24.9-5.5 37l22.6 5.2-7.1 31.6-25.1-5.8c-1.2 3.2-2.5 6.3-3.9 9.5-4.1 9.2-8.7 18.1-13.9 26.7l20.2 11.9-16 28-22.9-13.5c-5.2 6.3-10.7 12.4-16.6 18.2 35.1 27.1 79 43.2 126.5 43.2s91.4-16.1 126.5-43.2c-5.9-5.8-11.4-11.9-16.6-18.2z"/>
                                                    <path d="M393.8 126l18.1 10.7-16 28-21.2-12.5c-5 8.3-9.5 16.9-13.3 25.9-.2.4-.4.9-.5 1.3l21 4.9-7.1 31.6-23.9-5.5c-2.3 9.7-3.8 19.6-4.6 29.6H370v32h-23.6c.8 10 2.3 20 4.6 29.8l23.9-5.5 7.1 31.6-21 4.9c.2.4.3.8.5 1.2 3.8 9 8.3 17.7 13.3 26l21.1-12.4 16 28-18 10.6c3.3 3.9 6.8 7.7 10.5 11.3l2 2C442 362 464 311.4 464 256s-22-106-57.7-143.4c-.7.7-1.4 1.3-2 2-3.7 3.7-7.2 7.5-10.5 11.4zM118.2 386.1l-18-10.6 16-28 21.1 12.4c5.1-8.3 9.5-17 13.3-26 .2-.4.3-.8.5-1.2l-21-4.9 7.1-31.6 23.9 5.5c2.3-9.8 3.8-19.8 4.6-29.8H142v-32h23.6c-.8-10-2.3-19.9-4.6-29.6l-23.9 5.5-7.1-31.6 21-4.9c-.2-.4-.3-.9-.5-1.3-3.8-9-8.2-17.7-13.3-25.9L116 164.6l-16-28 18.1-10.7c-3.4-3.9-6.9-7.7-10.6-11.4l-2-2C70 150 48 200.6 48 256s22 106 57.7 143.4c.7-.7 1.4-1.3 2-2 3.6-3.6 7.1-7.4 10.5-11.3z"/>
                                                </svg>
                                                Baseball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M448.1 34.9c0-1.2-.4-2.9-2.9-2.9H128.5c-54.3 0-64.4 27.4-64.4 39.8C94.4 76 96 76.5 96 108.5v307c0 35.3 28.9 64.5 64.3 64.5H368c35.3 0 64-29.2 64-64.5V73.3c2.2-17.5 12-31.8 13.1-33.5 1.2-1.9 3-3.8 3-4.9zM354.2 432H176.3c-15.9 0-29.7-11.9-32.3-27.1V80h240v319.7c0 18-12.4 32.3-29.8 32.3z"/>
                                                    <path d="M182 160v226c0 4.4 3.6 8 8 8h148c4.4 0 8-3.6 8-8V160H182z"/>
                                                </svg>
                                                Beaker
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M84.255 413h1.063c34.123 0 63.977-19.021 85.305-42.494 21.325 23.473 51.18 42.762 85.304 42.762s63.979-19.334 85.305-42.806C362.559 393.934 392.412 413 426.535 413h1.062l51.253-138.78c2.126-5.329 1.063-11.641-1.07-16.976-2.136-5.333-7.237-8.487-12.567-10.623L427 234.133v-98.15C427 112.51 407.344 93 383.884 93h-63.979l-15.993-53h-95.969l-15.995 53h-63.979C104.511 93 85 112.51 85 135.982v98.15l-38.074 12.533c-5.33 2.136-10.582 5.334-12.718 10.667-2.135 5.335-3.158 10.49-1.031 16.887L84.255 413zM128 136h256v84.261l-128-41.605-128 41.605V136z"/>
                                                    <path d="M341.231 408.007c-52.253 36.267-118.356 36.258-170.608-.009 0 0-57.638 64.002-106.632 64.002h21.327c29.854 0 58.646-11.726 85.305-25.594 53.315 27.734 117.293 27.728 170.608-.007C367.89 460.268 396.681 472 426.535 472h21.328c-47.651 0-106.632-63.993-106.632-63.993z"/>
                                                </svg>
                                                Boat
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <circle cx="256" cy="280" r="63"/>
                                                    <path d="M440 96h-88l-32-32H192l-32 32H72c-22.092 0-40 17.908-40 40v272c0 22.092 17.908 40 40 40h368c22.092 0 40-17.908 40-40V136c0-22.092-17.908-40-40-40zM256 392c-61.855 0-112-50.145-112-112s50.145-112 112-112 112 50.145 112 112-50.145 112-112 112z"/>
                                                </svg>
                                                Camera
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M391.553 64H57.607C53.131 64 48 67.745 48 72.159v214.217c0 4.413 5.131 8.624 9.607 8.624H115v88.894L205.128 295h186.425c4.477 0 7.447-4.211 7.447-8.624V72.159c0-4.414-2.971-8.159-7.447-8.159z"/>
                                                    <path d="M456.396 127H424v166.57c0 15.987-6.915 26.43-25.152 26.43H218.096l-38.905 39h129.688L399 448v-89h57.396c4.478 0 7.604-4.262 7.604-8.682V136.103c0-4.414-3.126-9.103-7.604-9.103z"/>
                                                </svg>
                                                Chat Boxes
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                    <path d="M132.8 368c-20.2 0-44.8-24.6-44.8-44.8V160h-9.6C61.7 160 48 173.7 48 190.4V464l58.5-58h215.1c16.7 0 30.4-14.1 30.4-30.9V368H132.8z"/>
                                                    <path d="M429.1 48H149.9C130.7 48 115 63.7 115 82.9V309c0 19.2 15.7 35 34.9 35h238.2l75.9 53V82.9c0-19.2-15.7-34.9-34.9-34.9z"/>
                                                </svg>
                                                Chat Bubbles
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 90c44.3 0 86 17.3 117.4 48.6C404.7 170 422 211.7 422 256s-17.3 86-48.6 117.4C342 404.7 300.3 422 256 422s-86-17.3-117.4-48.6C107.3 342 90 300.3 90 256s17.3-86 48.6-117.4C170 107.3 211.7 90 256 90m0-42C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48z"/><path d="M360 330.9L330.9 360 256 285.1 181.1 360 152 330.9l74.9-74.9-74.9-74.9 29.1-29.1 74.9 74.9 74.9-74.9 29.1 29.1-74.9 74.9z"/></svg>
                                                Close Circle Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M123.4 183c.4-.1.8-.1 1.2-.2-.5.1-.8.2-1.2.2z"/><path d="M393.2 219.2C380.5 154.6 323.9 106 256 106c-39.7 0-76 14-100.9 45.4 34.3 2.6 66.1 15.2 90.7 39.8 18.2 18.2 31 40.5 37.4 64.8h-33.5c-15.3-43.7-56-75-105.7-75-6 0-14.3.7-20.6 2C70 194 32 238.4 32 293.5 32 355.6 82.2 406 144 406h242.7c51.5 0 93.3-42 93.3-93.8 0-49.4-38.3-89.6-86.8-93z"/></svg>
                                                Cloudy
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M123.4 183c.4-.1.8-.1 1.2-.2-.5.1-.8.2-1.2.2zM341.5 303.4C330.7 247.7 282.2 206 224 206c-34 0-65.1 12-86.5 39.1 29.4 2.2 56.7 13.1 77.7 34.2 15.6 15.7 26.6 34.9 32.1 55.8h-28.7c-13.1-37.6-48-64.5-90.6-64.5-5.1 0-12.3.6-17.7 1.7-45.7 9.4-78.3 47.6-78.3 95 0 53.4 43 96.8 96 96.8h208c44.1 0 80-36.1 80-80.6-.1-42.7-32.9-77.2-74.5-80.1z"/><path d="M112.5 225.4c13.6-17.3 30.7-30.5 50.8-39.2 18.4-8 38.8-12 60.7-12 6.1 0 12.2.4 18.2 1.1-6.1-18.1-9.4-37.6-9.4-57.8 0-24.6 4.9-48.1 13.8-69.4C161.9 68.7 99 145.7 99 237.3c0 1.6 0 3.2.1 4.8.1 0 .2-.1.3-.1l13.1-16.6zM417.6 306.8c13.3 14.2 22.6 31.5 27.1 50.1 16.5-21.4 28.7-46.4 35.3-73.5-21.2 9-44.5 13.9-68.9 13.9h-3.6c3.5 2.9 6.9 6.1 10.1 9.5z"/></svg>
                                                Cloudy Night
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M234.6 160v125.7l-44.7-43.6L160 272l96 96 96-96-29.9-31-44.7 44.7V160h-42.8z"/><path d="M190.4 354.1L91.9 256l98.4-98.1-30-29.9L32 256l128.4 128 30-29.9zm131.2 0L420 256l-98.4-98.1 30-29.9L480 256 351.6 384l-30-29.9z"/></svg>
                                                Code Download
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M190.4 354.1L91.9 256l98.4-98.1-30-29.9L32 256l128.4 128 30-29.9zm131.2 0L420 256l-98.4-98.1 30-29.9L480 256 351.6 384l-30-29.9z"/><path d="M155.6 276h40v-40h-40v40zm200.8-40h-40v40h40v-40zM236 276h40v-40h-40v40z"/></svg>
                                                Code Working
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M430.9 393.4l-119.6-119-58.1-57.9-13.4-13.3c15.9-40.6 7.1-88.2-26.6-121.7-35.4-35.3-88.5-42.3-131-22.9l76.1 75.8-53.1 52.9-77.9-75.8C6.2 153.8 15 206.7 50.4 242c33.6 33.5 81.4 42.3 122.1 26.5l14.4 14.3L81.7 388c-7.6 5.7-7.6 19 1.9 26.6l43.8 43.7c7.6 7.6 19.1 7.6 26.7 0l96.1-112.4 113.4 112.9c7.1 7.1 17.7 7.1 24.8 0l40.7-40.6c8.9-7.1 8.9-19.5 1.8-24.8z"/><path d="M494.4 216.6l-34.5-34.1c-2.2-2.2-5.8-2.2-8 0l-3.7 3.7-18.5-15.8s1.2-10-4.9-18.7c-6.2-8.7-16.1-19.8-23.2-26.9-7.1-7-34.1-33.9-69.7-51.4C296.2 55.7 271 48 241 48v29.7s28.7 16.6 45.1 29.7c16.3 13.1 16.8 59.5 16.8 59.5l-28.5 28.5 56.5 56.1 31-36.3c12.9-3.5 23.8-3.8 30.2-.3l13.7 13.3-9.6 9.5c-2.2 2.2-2.2 5.7 0 7.9l34.5 34.1c2.2 2.2 5.8 2.2 8 0l55.7-55.2c2.1-2.2 2.1-5.8 0-7.9z"/></svg>
                                                Construct
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M239.208 343.937c-17.78 10.103-38.342 15.876-60.255 15.876-21.909 0-42.467-5.771-60.246-15.87C71.544 358.331 42.643 406 32 448h293.912c-10.639-42-39.537-89.683-86.704-104.063zM178.953 120.035c-58.479 0-105.886 47.394-105.886 105.858 0 58.464 47.407 105.857 105.886 105.857s105.886-47.394 105.886-105.857c0-58.464-47.408-105.858-105.886-105.858zm0 186.488c-33.671 0-62.445-22.513-73.997-50.523H252.95c-11.554 28.011-40.326 50.523-73.997 50.523z"/><g><path d="M322.602 384H480c-10.638-42-39.537-81.691-86.703-96.072-17.781 10.104-38.343 15.873-60.256 15.873-14.823 0-29.024-2.654-42.168-7.49-7.445 12.47-16.927 25.592-27.974 34.906C289.245 341.354 309.146 364 322.602 384zM306.545 200h100.493c-11.554 28-40.327 50.293-73.997 50.293-8.875 0-17.404-1.692-25.375-4.51a128.411 128.411 0 0 1-6.52 25.118c10.066 3.174 20.779 4.862 31.895 4.862 58.479 0 105.886-47.41 105.886-105.872 0-58.465-47.407-105.866-105.886-105.866-37.49 0-70.427 19.703-89.243 49.09C275.607 131.383 298.961 163 306.545 200z"/></g></svg>
                                                Contacts
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M128 176h256v128H128z"/><path d="M448 96H64c-8.8 0-16 7.2-16 16v256c0 8.8 6.9 16 15.8 16H448c8.8 0 16-7.2 16-16V112c0-8.8-7.2-16-16-16zm-32 240H96V144h320v192zM80 464h57l22.5-64h-56.4zM279.4 48h-46.8l-11.5 32h69.8zM375 464h57l-23-64h-56.5zM232 400h48v32h-48z"/></svg>
                                                Easel
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M78.1 205.6c-2.4 0-4.9-.6-7.1-1.9-6.7-3.9-9-12.4-5.1-19.1 17.8-30 71.9-100.1 190.1-100.1 51.2 0 96.1 13.6 133.4 40.4 30.7 22 47.9 46.9 56.1 58.9 4.4 6.4 2.7 15-3.7 19.4-6.4 4.3-15.2 2.7-19.6-3.7-14.9-21.6-60.1-87.2-166.2-87.2-103.6 0-150.4 60.4-165.7 86.3-2.6 4.6-7.3 7-12.2 7z"/><path d="M315.5 480c-1.2 0-2.3-.1-3.5-.4-85.7-21.5-117.7-108.1-119-111.7l-.2-.8c-.7-2.5-17.9-61.9 8.5-96.7 12.1-15.9 30.5-24 54.8-24 22.6 0 38.9 7.1 50.1 21.8 9.2 12 12.9 26.8 16.5 41.1 7.5 29.7 12.9 45.3 44.1 46.9 13.7.7 22.7-7.4 27.8-14.3 13.8-18.8 16.2-49.5 5.8-76.5-13.4-35-60.8-100.9-144.4-100.9-35.7 0-68.5 11.6-94.8 33.4-21.8 18.1-39.1 43.6-47.4 69.8-15.4 48.8 4.8 125.5 5 126.2 2 7.4-2.5 15.1-10 17-7.5 2-15.3-2.5-17.3-9.9-.9-3.5-22.5-85.3-4.7-141.7C106.2 198.2 166 136.6 256 136.6c41.6 0 80.9 14.3 113.7 41.3 25.4 21 46.2 49.2 57 77.4 13.8 36 10.1 76.4-9.4 102.8-13 17.6-31.5 26.8-52 25.8-53.4-2.7-63-40.4-70-67.9-7.2-28.2-11.8-41.8-39.3-41.8-15.1 0-25.7 4.2-32.3 12.9-9 11.9-9.7 30.5-8.7 44 1 14.1 4 25.5 4.7 27.8 2.2 5.6 30.8 76.5 99.3 93.7 7.6 1.9 12.1 9.5 10.2 16.9-1.7 6.3-7.4 10.5-13.7 10.5z"/><path d="M205.5 473.6c-3.8 0-7.5-1.5-10.3-4.4-34.3-36.4-53.7-77.1-61-128v-.3c-4.1-33.7 1.9-81.4 31.3-114.2 21.7-24.2 52.2-36.5 90.5-36.5 45.3 0 80.9 21.3 103.1 61.5 16.1 29.2 19.3 58.3 19.4 59.5.8 7.7-4.9 14.5-12.6 15.3-7.7.8-14.7-4.8-15.5-12.4 0-.3-2.8-25.3-16.5-49.7-17.2-30.7-43.4-46.3-78-46.3-29.9 0-53.3 9.1-69.4 27.1-23.2 25.9-27.7 65.8-24.5 92.2 6.4 45 23.5 80.8 53.7 112.8 5.3 5.6 5 14.5-.7 19.7-2.6 2.4-6.1 3.7-9.5 3.7z"/><path d="M363.5 433.5c-30 0-55.5-8.4-75.9-25.1-41-33.4-45.6-87.8-45.8-90.1-.6-7.7 5.2-14.4 13-15 7.8-.6 14.5 5.1 15.1 12.8.1.8 4.2 45.3 35.8 70.9 18.7 15.1 43.7 21.1 74.5 17.6 7.7-.9 14.7 4.6 15.6 12.3.9 7.7-4.7 14.6-12.4 15.4-6.8.8-13.5 1.2-19.9 1.2zM387.2 62.6C375.5 54.9 334 32 256 32c-81.9 0-123.5 25.3-132.7 31.7-.6.4-1.2.8-1.7 1.3-.1.1-.2.1-.2.1-2.9 2.6-4.7 6.3-4.7 10.4 0 7.7 6.3 13.9 14.1 13.9 3.1 0 5.9-1 8.2-2.6l-.1.1c.4-.3 36.3-27 117.1-27s116.7 26.8 117.1 27l-.1-.1.2-.2c2.4 1.8 5.3 2.8 8.5 2.8 7.8 0 14.1-6.2 14.1-13.9 0-5.8-3.5-10.8-8.6-12.9z"/></svg>
                                                Finger Print
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 90c44.3 0 86 17.3 117.4 48.6C404.7 170 422 211.7 422 256s-17.3 86-48.6 117.4C342 404.7 300.3 422 256 422s-86-17.3-117.4-48.6C107.3 342 90 300.3 90 256s17.3-86 48.6-117.4C170 107.3 211.7 90 256 90m0-42C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48z"/><path d="M235 339h42v42h-42zM276.8 318h-41.6c0-67 62.4-62.2 62.4-103.8 0-22.9-18.7-41.7-41.6-41.7S214.4 192 214.4 214h-41.6c0-46 37.2-83 83.2-83s83.2 37.1 83.2 83.1c0 52-62.4 57.9-62.4 103.9z"/></svg>
                                                Help Circle Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M457.6 140.2l-82.5-4-4.8-53.8c-1-11.3-11.1-19.2-22.9-18.3L51.5 88.4c-11.8 1-20.3 10.5-19.4 21.7l21.2 235.8c1 11.3 11.2 19.2 22.9 18.3l15-1.2-2.4 45.8c-.6 12.6 9.2 22.8 22.4 23.5L441.3 448c13.2.6 24.1-8.6 24.8-21.2L480 163.5c.6-12.5-9.3-22.7-22.4-23.3zm-354.9 5.3l-7.1 134.8L78.1 305 62 127v-.5-.5c1-5 4.4-9 9.6-9.4l261-21.4c5.2-.4 9.7 3 10.5 7.9 0 .2.3.2.3.4 0 .1.3.2.3.4l2.7 30.8-219-10.5c-13.2-.4-24.1 8.8-24.7 21.3zm334 236.9l-84.8-99.5-37.4 34.3-69.2-80.8-122.7 130.7L133 168v-.4c1-5.4 6.2-9.3 11.9-9l291.2 14c5.8.3 10.3 4.7 10.4 10.2 0 .2.3.3.3.5l-10.1 199.1z"/><path d="M384 256c17.6 0 32-14.4 32-32s-14.3-32-32-32c-17.6 0-32 14.3-32 32s14.3 32 32 32z"/></svg>
                                                Images
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 90c44.3 0 86 17.3 117.4 48.6C404.7 170 422 211.7 422 256s-17.3 86-48.6 117.4C342 404.7 300.3 422 256 422s-86-17.3-117.4-48.6C107.3 342 90 300.3 90 256s17.3-86 48.6-117.4C170 107.3 211.7 90 256 90m0-42C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48z"/><path d="M277 360h-42V235h42v125zm0-166h-42v-42h42v42z"/></svg>
                                                Information Circle Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M80 280h256v48H80zM80 184h320v48H80zM80 88h352v48H80z"/><g><path d="M80 376h288v48H80z"/></g></svg>
                                                List
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 48c-42.9 0-84.2 13-119.2 37.5-34.2 24-60.2 57.2-75.1 96.1L58 192h45.7l1.9-5c8.2-17.8 19.4-33.9 33.5-48 31.2-31.2 72.7-48.4 116.9-48.4s85.7 17.2 116.9 48.4c31.2 31.2 48.4 72.7 48.4 116.9 0 44.1-17.2 85.7-48.4 116.9-31.2 31.2-72.7 48.4-116.9 48.4-44.1 0-85.6-17.2-116.9-48.4-14-14-25.3-30.1-33.5-47.9l-1.9-5H58l3.6 10.4c14.9 38.9 40.9 72.1 75.1 96.1C171.8 451.1 213 464 256 464c114.7 0 208-93.3 208-208S370.7 48 256 48z"/><path d="M48 277.4h189.7l-43.6 44.7L224 352l96-96-96-96-31 29.9 44.7 44.7H48v42.8z"/></svg>
                                                Log In
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M192 277.4h189.7l-43.6 44.7L368 352l96-96-96-96-31 29.9 44.7 44.7H192v42.8z"/><path d="M255.7 421.3c-44.1 0-85.5-17.2-116.7-48.4-31.2-31.2-48.3-72.7-48.3-116.9 0-44.1 17.2-85.7 48.3-116.9 31.2-31.2 72.6-48.4 116.7-48.4 44 0 85.3 17.1 116.5 48.2l30.3-30.3c-8.5-8.4-17.8-16.2-27.7-23.2C339.7 61 298.6 48 255.7 48 141.2 48 48 141.3 48 256s93.2 208 207.7 208c42.9 0 84-13 119-37.5 10-7 19.2-14.7 27.7-23.2l-30.2-30.2c-31.1 31.1-72.5 48.2-116.5 48.2zM448.004 256.847l-.849-.848.849-.849.848.849z"/></svg>
                                                Log Out
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><circle cx="432" cy="128" r="64"/><path d="M382.9 203.4L256 288 80 170.7V128l176 117.3 101.1-67.4c-9.5-14.3-15.1-31.5-15.1-49.9 0-17.6 5.1-34.1 13.9-48H74.7C51.2 80 32 99.2 32 122.7v266.7c0 23.5 19.2 42.7 42.7 42.7h362.7c23.5 0 42.7-19.2 42.7-42.7V204.1c-13.9 8.8-30.4 13.9-48 13.9-18.2 0-35.1-5.4-49.2-14.6z"/></svg>
                                                Mail Unread
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M273.5 152.1H48l54.1-103.9h240.7z"/><circle cx="256.2" cy="377.2" r="86.6"/><path d="M348.9 299.1l115.1-147-69.3-103.9L256.4 256c32.3 0 62.7 12.7 85.5 35.5 2.5 2.5 4.8 5 7 7.6zM205.8 266.6L152.3 186H48.4l90.1 161.5c5.2-21.2 16.1-40.6 32-56.4 10.4-10.3 22.3-18.6 35.3-24.5z"/></svg>
                                                Medal
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M382.1 143.4l-23.1 23c14.7 14.7 23.9 35.2 23.9 57.6s-9.2 42.9-23.9 57.6l23.1 23.1c20.6-20.6 33.4-49.2 33.4-80.6s-12.8-60.1-33.4-80.7z"/><path d="M428.2 99l-22.7 22.7c26.1 26.1 42.3 62.4 42.3 102.3 0 39.8-16.1 76.1-42.3 102.3l22.7 22.7c31.9-32.1 51.8-76.3 51.8-125s-19.8-92.9-51.8-125zM320 184.1V80h-32l-96 80H64l-32 16v112l32 16 80 128h48l-30-128h30l96 64h32V263.9c18.4-1.7 32-18.9 32-39.9s-13.6-38.2-32-39.9z"/></svg>
                                                Megaphone
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 463.656c22.814 0 41.475-18.656 41.475-41.656h-82.95c0 23 18.661 41.656 41.475 41.656z"/><path d="M131.083 107.172l.053.074L98.09 74.277 74.004 98.383l63.042 63.153C126.888 180.521 121 202.196 121 225.07v114.555l-41 41.656V402h297.743l36.182 36.33 24.079-24.301L425.9 402h.316L131.083 107.172zM391 225.07c0-63.526-45-117.677-104-131.218V79.274c0-17.706-13.371-31.243-31-31.243-17.628 0-31 13.537-31 31.243v14.578c-15 3.438-29.048 9.501-41.75 17.663L391 319.355V225.07z"/></svg>
                                                Notification Off
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M32 384h272v32H32zM400 384h80v32h-80zM384 447.5c0 17.949-14.327 32.5-32 32.5-17.673 0-32-14.551-32-32.5v-95c0-17.949 14.327-32.5 32-32.5 17.673 0 32 14.551 32 32.5v95z"/><g><path d="M32 240h80v32H32zM208 240h272v32H208zM192 303.5c0 17.949-14.327 32.5-32 32.5-17.673 0-32-14.551-32-32.5v-95c0-17.949 14.327-32.5 32-32.5 17.673 0 32 14.551 32 32.5v95z"/></g><g><path d="M32 96h272v32H32zM400 96h80v32h-80zM384 159.5c0 17.949-14.327 32.5-32 32.5-17.673 0-32-14.551-32-32.5v-95c0-17.949 14.327-32.5 32-32.5 17.673 0 32 14.551 32 32.5v95z"/></g></svg>
                                                Options
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M464 64H192c-8.8 0-16 7.7-16 16.5V112H74c-23.1 0-42 18.9-42 42v207.5c0 47.6 39 86.5 86 86.5h279.7c45.1 0 82.3-36.9 82.3-82V80c0-8.8-7.2-16-16-16zm-288 80v192h-42V163.2c0-6.8-.8-13.3-3.3-19.2H176zm-17 255.4C148 410 133.2 416 118.5 416c-14.5 0-28.1-5.7-38.5-16-10.3-10.3-16-24-16-38.5V163.2c0-10.6 8.4-19.2 19-19.2s19 8.6 19 19.2V352c0 8.8 7.2 16 16 16h57.5c-1.5 11.6-7.2 22.6-16.5 31.4zM448 366c0 13.3-5.4 25.8-14.9 35.3-9.5 9.5-22.2 14.7-35.4 14.7H187.3c12.8-14.9 20.7-33.9 20.7-54.5V97h240v269z"/><path d="M248 136h160v56H248zM248 224h160v32H248zM248 288h160v32H248zM408 352H248s0 32-8 32h148.7c19.3 0 19.3-21 19.3-32z"/></svg>
                                                Paper
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M400 421.3V154.7c0-23.5-19.2-42.7-42.7-42.7H90.7C67.2 112 48 131.2 48 154.7v266.7c0 23.5 19.2 42.7 42.7 42.7h266.7c23.4-.1 42.6-19.3 42.6-42.8zM157.3 304l45.3 64 66.7-96 88 128H90.7l66.6-96z"/><path d="M421.3 48H154.7C131.2 48 112 67.2 112 90.7V96h261.3c23.5 0 42.7 19.2 42.7 42.7V400h5.3c23.5 0 42.7-19.2 42.7-42.7V90.7c0-23.5-19.2-42.7-42.7-42.7z"/></svg>
                                                Photos
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M32.6 256H256V32.6c-5-.4-10.6-.6-16-.6-114.9 0-208 93.1-208 208 0 5.4.2 11 .6 16z"/><path d="M109.8 402.2C147.9 449.6 206.4 480 272 480c114.9 0 208-93.1 208-208 0-65.6-30.4-124.1-77.8-162.2C370.5 84.3 331 67.9 288 64.6V288H64.6c3.3 43 19.7 82.5 45.2 114.2z"/></svg>
                                                Pie
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M407.2 130.4C360.7 111.5 309.8 102 256 102c-53.9 0-108.3 10.3-151.2 28-8.1 3.3-15.3 9-10.1 19.5S255.9 480 255.9 480l161-329.9c3.2-6.9.9-15.4-9.7-19.7zm-221 73.6c-18.7 0-32-14.3-32-32s13.3-32 32-32 32 14.3 32 32-13.3 32-32 32zM256 347c-18.7 0-32-14.3-32-32s13.3-32 32-32 32 14.3 32 32-13.3 32-32 32zm69.8-123c-18.7 0-32-14.3-32-32s13.3-32 32-32 32 14.3 32 32-13.3 32-32 32z"/><path d="M436.9 66C384.7 45.4 320.3 32 256 32c-64.3 0-127.6 12.1-180.9 33.4C70.4 67.3 64 71 64 79.2l9.7 24.1c2.8 4.9 8.7 8.2 15.1 8.2 1.8 0 4.3-.3 7.3-1.5 49-18.9 103.1-29.6 160-29.6 56.9 0 115.2 11.6 160 29.6 3.6 1.4 5.6 1.5 7.3 1.5 6.6 0 12.2-3.3 15-8.1l9.8-24.1c-.2-7.3-5-10.8-11.3-13.3z"/></svg>
                                                Pizza
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M135.7 151c-2.5 3-4.9 6-7.2 9.2 32.2 36.3 76.1 76.5 124.2 113.7 37.8 29.2 76.3 55.2 111.4 75.1 5.9 3.3 11.7 6.5 17.3 9.4 2.5-3 4.9-6 7.2-9.2 11.7-16.1 18.1-33.2 23.3-53.6.8-3.2 1.5-6.4 2.1-9.5 15.8-83-35.6-164.9-118.5-185.9-37-9.4-74.1-5.1-106.3 9.7-21.4 9.9-38.2 22.9-53.5 41.1z"/><path d="M418.2 326.8c-4.1 11-7.4 17.5-7.4 17.5 18.2 21.1 24.6 33.9 31.9 46.4 2.4 4.1 7.4 13.1.9 12.4-1.7-.3-3.5-.7-5.5-1.3-21.3-5.4-51.2-18.7-84.3-37.4-35.8-20.3-74.9-46.7-113.3-76.3-51.1-39.5-97.5-82.3-130.6-120.5-15.3-17.6-27.6-34.2-35.7-47.9-2.4-4.1-3.9-6.3-5.6-10.4-2.5-6.2 5-5.1 7-4.6 14.9 3.8 35 9.9 58.2 23.8 0 0 4.3-4.8 13.9-11.4-22.8-15.4-44.6-27.7-65.2-35.5-23.1-8.8-41.1-6.8-47.5 3.7-12.2 19.9 14 72.3 65.3 132-21.5 86 30.6 173.3 116.5 195 41.1 10.4 82.4 3.9 116.8-15 38.1 17.6 72.1 28.6 96.9 34.9 23.9 6.1 40.4 5.5 46.8-4.9 11.1-18.2-12.1-51.8-59.1-100.5z"/></svg>
                                                Planet
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M442 107v141L229.2 451.7c8 8 20.8 12.3 28.8 12.3s22.8-3.7 31.4-12.3L480 272V144l-38-37z"/><path d="M384 48H224L44.3 235.6c-8 8-12 17.8-12.3 28.4-.3 11.3 3.7 23.3 12.3 31.9l123.8 123.6c8 8 20.8 12.5 28.8 12.5s22.7-3.9 31.3-12.5L416 240V80l-32-32zm-30.7 102.7c-21.7 6.1-41.3-10-41.3-30.7 0-17.7 14.3-32 32-32 20.7 0 36.8 19.6 30.7 41.3-2.9 10.3-11.1 18.5-21.4 21.4z"/></svg>
                                                Pricetags
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 90c44.3 0 86 17.3 117.4 48.6C404.7 170 422 211.7 422 256s-17.3 86-48.6 117.4C342 404.7 300.3 422 256 422s-86-17.3-117.4-48.6C107.3 342 90 300.3 90 256s17.3-86 48.6-117.4C170 107.3 211.7 90 256 90m0-42C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48z"/><path d="M363 277H149v-42h214v42z"/></svg>
                                                Remove Circle Outline
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M164.852 279.939l61.834-60.251L73.72 71.706c-33.626 32.764-33.626 86.677 0 119.44l91.132 88.793z"/><path d="M312.389 241.88c33.636 14.802 80.283 4.232 113.91-29.593 41.222-40.165 49.909-98.303 17.363-128.96-31.465-31.71-91.131-23.245-132.354 16.921-34.718 33.825-45.566 79.276-30.374 110.986-47.739 47.568-211.552 207.173-211.552 207.173L99.759 448l149.71-145.866L399.177 448l30.374-29.593-149.709-145.869 32.547-30.658z"/></svg>
                                                Restaurant
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 421.6c-18.1 0-33.2-6.8-42.9-10.9-5.4-2.3-11.3 1.8-10.9 7.6l3.5 51c.2 3.1 3.8 4.7 6.3 2.8l14.5-11c1.8-1.4 4.5-.9 5.7 1l20.5 32.1c1.5 2.4 5.1 2.4 6.6 0l20.5-32.1c1.2-1.9 3.9-2.4 5.7-1l14.5 11c2.5 1.9 6.1.3 6.3-2.8l3.5-51c.4-5.8-5.5-10-10.9-7.6-9.8 4.1-24.8 10.9-42.9 10.9z"/><path d="M397.7 293.1l-48-49.1c0-158-93.2-228-93.2-228s-94.1 70-94.1 228l-48 49.1c-1.8 1.8-2.6 4.5-2.2 7.1L130.6 412c.9 5.7 7.1 8.5 11.8 5.4l67.1-45.4s20.7 20 47.1 20c26.4 0 46.1-20 46.1-20l67.1 45.4c4.6 3.1 10.8.3 11.8-5.4l18.5-111.9c.2-2.6-.6-5.2-2.4-7zM256.5 192c-17 0-30.7-14.3-30.7-32s13.8-32 30.7-32c17 0 30.7 14.3 30.7 32s-13.7 32-30.7 32z"/></svg>
                                                Rocket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 288c-45.443 0-83.675 26.076-102.205 64h204.41c-18.53-37.924-56.762-64-102.205-64z"/><path d="M256 48C140.563 48 48 141.6 48 256s92.563 208 208 208 208-93.6 208-208S370.401 48 256 48zm0 374.4c-91.518 0-166.404-74.883-166.404-166.4 0-91.518 74.887-166.4 166.404-166.4S422.404 164.482 422.404 256 347.518 422.4 256 422.4z"/><path d="M328.8 235.2c17.683 0 31.201-13.518 31.201-31.2s-13.519-31.2-31.201-31.2c-17.682 0-31.2 13.518-31.2 31.2s13.518 31.2 31.2 31.2zM183.2 235.2c17.682 0 31.2-13.518 31.2-31.2s-13.519-31.2-31.2-31.2c-17.683 0-31.201 13.518-31.201 31.2s13.519 31.2 31.201 31.2z"/></svg>
                                                Sad
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M128 416h256v48H128zM256 288c17.7 0 32-14.3 32-32s-14.3-32-32-32c-3 0-6 .4-8.8 1.2l-66.7-48.7-4 3.5 48.9 66.7c-.9 2.9-1.4 6-1.4 9.3 0 17.7 14.3 32 32 32z"/><path d="M256 48C141.1 48 48 141.1 48 256c0 48.3 16.5 92.7 44.1 128h58.8l4-4 22.1-22.1-22.9-22.9-22.1 22c-19.9-24.3-32.1-54-35.2-85H128v-32H96.8c3.1-31 15.3-60.7 35.2-85l22.1 22 22.9-22.9-22-22.1c24.3-19.9 54-32.1 85-35.2V128h32V96.8c31 3.1 60.7 15.3 85 35.2l-22 22.1 22.9 22.9 22.1-22c19.9 24.3 32.1 54 35.2 85H384v32h31.2c-3.1 31-15.3 60.7-35.2 85l-22.1-22-22.9 22.9 22.1 22.1 4 4h58.8c27.6-35.3 44.1-79.7 44.1-128 0-114.9-93.1-208-208-208z"/></svg>
                                                Speedometer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M232 306.667h48V176h-48v130.667z"/><path d="M407.67 170.271l30.786-30.786-33.942-33.941-30.785 30.786C341.217 111.057 300.369 96 256 96 149.961 96 64 181.961 64 288s85.961 192 192 192 192-85.961 192-192c0-44.369-15.057-85.217-40.33-117.729zm-45.604 223.795C333.734 422.398 296.066 438 256 438s-77.735-15.602-106.066-43.934C121.602 365.735 106 328.066 106 288s15.602-77.735 43.934-106.066C178.265 153.602 215.934 138 256 138s77.734 15.602 106.066 43.934C390.398 210.265 406 247.934 406 288s-15.602 77.735-43.934 106.066zM192 32h128v48H192z"/></svg>
                                                Stopwatch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M383.8 92.2C348.5 64.5 304.1 48 256 48c-48 0-92.3 16.5-127.6 44 41.6 44.8 64.3 103 64 164.3-.3 61-23.3 118.6-64.9 162.9 35.4 28 80.1 44.8 128.5 44.8 48.5 0 93.3-16.8 128.8-45-41.5-44.3-64.5-101.8-64.8-162.7-.3-61.2 22.3-119.3 63.8-164.1z"/><path d="M353.1 255.1c0 26.9 5.1 53 15.1 77.8 9.6 23.6 23.3 44.9 40.8 63.6 34.1-37.1 55-86.5 55-140.5 0-54.5-21.2-104.2-55.8-141.4-17.1 18.5-30.6 39.6-40 62.7-10 24.8-15.1 51-15.1 77.8zM159.3 255.1c0-26.9-5.1-53-15.1-77.8-9.4-23.2-22.9-44.4-40.2-62.9-34.7 37.2-56 87-56 141.6 0 54.2 21 103.6 55.2 140.7 17.6-18.7 31.4-40.1 41-63.8 10-24.7 15.1-50.9 15.1-77.8z"/></svg>
                                                Tennisball
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><g fill-opacity=".9"><path d="M255.8 48C141 48 48 141.2 48 256s93 208 207.8 208c115 0 208.2-93.2 208.2-208S370.8 48 255.8 48zm.2 374.4c-91.9 0-166.4-74.5-166.4-166.4S164.1 89.6 256 89.6 422.4 164.1 422.4 256 347.9 422.4 256 422.4z"/><path d="M266.4 152h-31.2v124.8l109.2 65.5 15.6-25.6-93.6-55.5V152z"/></g></svg>
                                                Time
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M405.3 32H106.7C83.2 32 64 51.2 64 74.7v362.7c0 23.5 19.2 42.7 42.7 42.7h298.7c23.5 0 42.7-19.2 42.7-42.7V74.7C448 51.2 428.8 32 405.3 32zm-4 405.3H110.7c-2.2 0-4-1.8-4-4V78.7c0-2.2 1.8-4 4-4h290.7c2.2 0 4 1.8 4 4v354.7c-.1 2.1-1.9 3.9-4.1 3.9z"/><path d="M145 194v204c0 1.1.9 2 2 2h218c1.1 0 2-.9 2-2V194c0-1.1-.9-2-2-2H147c-1.1 0-2 .9-2 2zM145 114.7v34c0 1.1.9 2 2 2h171c1.1 0 2-.9 2-2v-34c0-1.1-.9-2-2-2H147c-1.1 0-2 .9-2 2z"/></svg>
                                                Today
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M202.7 341.3V170.7c0-23.5 19-42.7 42.7-42.7h197v-21.3c0-23.5-18.9-42.7-42.3-42.7H92c-23.7 0-44 18.5-44 42v300c0 23.5 20.3 42 44 42h308c23.5 0 42.3-19.2 42.3-42.7V384h-197c-23.6 0-42.6-19.2-42.6-42.7z"/><path d="M245 186v140c0 8.8 7.2 16 16 16h187c8.8 0 16-7.2 16-16V186c0-8.8-7.2-16-16-16H261c-8.8 0-16 7.2-16 16zm77.1 101.9c-19.3 1.2-35.2-14.7-34-34 1-15.9 13.9-28.8 29.9-29.9 19.3-1.2 35.2 14.7 34 34-1.1 16-14 28.9-29.9 29.9z"/></svg>
                                                Wallet
                                            </div>
                                        </div>
                                        <h4 class="mt-0 header-title">Logo Duel Color Examples</h4>
                                        <p class="text-muted mb-4">Use SVG Icons.</p>
                                        <div class="row icon-demo-content">
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M144 268.4V358c0 6.9 4.5 14 11.4 14H184v52c0 13.3 10.7 24 24 24s24-10.7 24-24v-52h49v52c0 7.5 3.4 14.2 8.8 18.6 3.9 3.4 9.1 5.4 14.7 5.4h.5c13.3 0 24-10.7 24-24v-52h27.6c7 0 11.4-7.1 11.4-13.9V192H144v76.4zM408 176c-13.3 0-24 10.7-24 24v96c0 13.3 10.7 24 24 24s24-10.7 24-24v-96c0-13.3-10.7-24-24-24zM104 176c-13.3 0-24 10.7-24 24v96c0 13.3 10.7 24 24 24s24-10.7 24-24v-96c0-13.3-10.7-24-24-24z"/><g><path d="M311.2 89.1l18.5-21.9c.4-.5-.2-1.6-1.3-2.5-1.1-.8-2.4-1-2.7-.4l-19.2 22.8c-13.6-5.4-30.2-8.8-50.6-8.8-20.5-.1-37.2 3.2-50.8 8.5l-19-22.4c-.4-.5-1.6-.4-2.7.4s-1.7 1.8-1.3 2.5l18.3 21.6c-48.2 20.9-55.4 72.2-56.4 87.2h223.6c-.9-15.1-8-65.7-56.4-87zm-104.4 49.8c-7.4 0-13.5-6-13.5-13.3 0-7.3 6-13.3 13.5-13.3 7.4 0 13.5 6 13.5 13.3 0 7.3-6 13.3-13.5 13.3zm98.4 0c-7.4 0-13.5-6-13.5-13.3 0-7.3 6-13.3 13.5-13.3 7.4 0 13.5 6 13.5 13.3 0 7.3-6.1 13.3-13.5 13.3z"/></g></svg>
                                                Android
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M213.573 256h84.846l-42.427-89.356z"/><path d="M255.981 32L32 112l46.12 272L256 480l177.75-96L480 112 255.981 32zM344 352l-26.589-56H194.584L168 352h-40L256 72l128 280h-40z"/></svg>
                                                Angular
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M333.6 153.9c-33.6 0-47.8 16.5-71.2 16.5-24 0-42.3-16.4-71.4-16.4-28.5 0-58.9 17.9-78.2 48.4-27.1 43-22.5 124 21.4 193 15.7 24.7 36.7 52.4 64.2 52.7h.5c23.9 0 31-16.1 63.9-16.3h.5c32.4 0 38.9 16.2 62.7 16.2h.5c27.5-.3 49.6-31 65.3-55.6 11.3-17.7 15.5-26.6 24.2-46.6-63.5-24.8-73.7-117.4-10.9-152.9-19.2-24.7-46.1-39-71.5-39z"/><path d="M326.2 64c-20 1.4-43.3 14.5-57 31.6-12.4 15.5-22.6 38.5-18.6 60.8h1.6c21.3 0 43.1-13.2 55.8-30.1 12.3-16.1 21.6-38.9 18.2-62.3z"/></svg>
                                                Apple
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M70.7 164.5l169.2 81.7c4.4 2.1 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c8.9-4.3 8.9-11.3 0-15.6L272.1 67.2c-4.4-2.1-10.3-3.2-16.1-3.2s-11.7 1.1-16.1 3.2L70.7 148.9c-8.9 4.3-8.9 11.3 0 15.6z"/><path d="M441.3 248.2s-30.9-14.9-35-16.9-5.2-1.9-9.5.1S272 291.6 272 291.6c-4.5 2.1-10.3 3.2-16.1 3.2s-11.7-1.1-16.1-3.2c0 0-117.3-56.6-122.8-59.3-6-2.9-7.7-2.9-13.1-.3l-33.4 16.1c-8.9 4.3-8.9 11.3 0 15.6l169.2 81.7c4.4 2.1 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c9.1-4.2 9.1-11.2.2-15.5z"/><path d="M441.3 347.5s-30.9-14.9-35-16.9-5.2-1.9-9.5.1S272.1 391 272.1 391c-4.5 2.1-10.3 3.2-16.1 3.2s-11.7-1.1-16.1-3.2c0 0-117.3-56.6-122.8-59.3-6-2.9-7.7-2.9-13.1-.3l-33.4 16.1c-8.9 4.3-8.9 11.3 0 15.6l169.2 81.7c4.4 2.2 10.3 3.2 16.1 3.2s11.7-1.1 16.1-3.2l169.2-81.7c9-4.3 9-11.3.1-15.6z"/></svg>
                                                Buffer
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M188.8 255.925c0 36.946 30.243 67.178 67.2 67.178s67.199-30.231 67.199-67.178c0-36.945-30.242-67.179-67.199-67.179s-67.2 30.234-67.2 67.179z"/><path d="M476.752 217.795c-.009.005-.016.038-.024.042-1.701-9.877-4.04-19.838-6.989-28.838h-.107c2.983 9 5.352 19 7.072 29h-.002c-1.719-10-4.088-20-7.07-29h-155.39c19.044 17 31.358 40.175 31.358 67.052 0 16.796-4.484 31.284-12.314 44.724L231.044 478.452s-.009.264-.014.264l-.01.284h.015l-.005-.262c8.203.92 16.531 1.262 24.97 1.262 6.842 0 13.609-.393 20.299-1.002a223.86 223.86 0 0 0 29.777-4.733C405.68 451.525 480 362.404 480 255.941c0-12.999-1.121-25.753-3.248-38.146z"/><path d="M256 345.496c-33.601 0-61.601-17.91-77.285-44.785L76.006 123.047l-.137-.236a223.516 223.516 0 0 0-25.903 45.123C38.407 194.945 32 224.686 32 255.925c0 62.695 25.784 119.36 67.316 160.009 29.342 28.719 66.545 49.433 108.088 58.619l.029-.051 77.683-134.604c-8.959 3.358-19.031 5.598-29.116 5.598z"/><path d="M91.292 104.575l77.35 133.25C176.483 197.513 212.315 166 256 166h205.172c-6.921-15-15.594-30.324-25.779-43.938.039.021.078.053.117.074C445.644 135.712 454.278 151 461.172 166h.172c-6.884-15-15.514-30.38-25.668-43.99-.115-.06-.229-.168-.342-.257C394.475 67.267 329.359 32 256 32c-26.372 0-51.673 4.569-75.172 12.936-34.615 12.327-65.303 32.917-89.687 59.406l.142.243.009-.01z"/></svg>
                                                Chrome
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M32 96v320h448V96H32zm406 159.8c0 23.4-1.4 41.2-3.3 70.2s-16.8 49.4-51.7 52.6c-34.9 3.2-83.8 3.5-127 3.4-42.9.1-92-.1-127-3.4-34.9-3.2-49.7-23.6-51.7-52.6S74 279.2 74 255.8c0-23.4.1-38.6 3.3-70.2s20.1-49.2 51.7-52.4 86-3.2 127-3.2 95.4 0 127 3.2c31.6 3.2 48.5 20.9 51.7 52.4 3.2 31.6 3.3 46.9 3.3 70.2z"/><path d="M357.5 280.4v.7c0 16.3-10.1 25.9-23.6 25.9-13.5 0-22.6-10.8-23.9-25.9 0 0-1.2-7.9-1.2-23.9s1.4-26 1.4-26c2.4-17 10.7-25.9 24.2-25.9 13.4 0 24.1 11.6 24.1 29.2v.5h45.1c0-21.9-5.5-41.6-16.6-54-11-12.4-27.5-18.6-49.3-18.6-10.9 0-20.9 1.4-30 4.3-9.1 2.9-17 7.9-23.6 15.1-6.6 7.2-11.7 16.8-15.4 28.9-3.6 12.1-5.5 27.3-5.5 45.7 0 18 1.5 33 4.4 45.1 3 12.1 7.3 21.7 13.1 28.9 5.8 7.2 13.1 12.2 21.8 15 8.8 2.8 19.1 4.2 30.9 4.2 25 0 43-6.4 53.8-18.7 10.8-12.3 16.2-30.3 16.2-53.9h-46.1c.2 0 .2 2.5.2 3.4zM202.6 280.4v.7c0 16.3-10.1 25.9-23.6 25.9-13.5 0-22.6-10.8-23.9-25.9 0 0-1.2-7.9-1.2-23.9s1.4-26 1.4-26c2.4-17 10.7-25.9 24.2-25.9 13.4 0 24.1 11.6 24.1 29.2v.5h45.1c0-21.9-5.5-41.6-16.6-54-11-12.4-27.5-18.6-49.3-18.6-10.9 0-20.9 1.4-30 4.3-9.1 2.9-17 7.9-23.6 15.1-6.6 7.2-11.7 16.8-15.4 28.9-3.6 12.1-5.5 27.3-5.5 45.7 0 18 1.5 33 4.4 45.1 3 12.1 7.3 21.7 13.1 28.9 5.8 7.2 13.1 12.2 21.8 15 8.8 2.8 19.1 4.2 30.9 4.2 25 0 43-6.4 53.8-18.7 10.8-12.3 16.2-30.3 16.2-53.9h-46.1c.2 0 .2 2.5.2 3.4z"/></svg>
                                                Close Captioning
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M241.239 303.936c-15.322-10.357-30.742-20.569-46.062-30.93-2.03-1.373-3.43-1.472-5.502-.029l-38.871 26.154C181.966 319.905 244 361.317 244 361.317v-53.786c-.012-1.224-1.553-2.78-2.761-3.595zM195.092 240.666c15.454-10.16 30.851-20.409 46.109-30.86 1.486-1.018 2.775-3.509 2.799-5.334v-51.706s-62.033 41.124-93.262 61.942c13.7 9.159 26.671 17.913 39.787 26.443 1.02.662 3.396.284 4.567-.485zM269.838 209.354a4521.517 4521.517 0 0 0 47.627 31.815c.916.604 2.92.602 3.839 0l39.751-26.467L268 152.484v53.35c.01 1.201.805 2.821 1.838 3.52zM258.109 230.369c-1.21-.802-3.611-.528-4.743.168-4.817 2.962-9.463 6.203-14.164 9.355-8.248 5.53-25.356 17.023-25.356 17.023l38.842 25.865c1.748 1.157 4.436 1.22 6.26.111l39.014-25.993c.001 0-34.079-22.701-39.853-26.529zM141 237.116v39.609l29.622-19.838z"/><path d="M256 32C132.288 32 32 132.288 32 256s100.288 224 224 224 224-100.288 224-224S379.712 32 256 32zm139 265.006c0 5.785-2.652 9.868-7.511 13.094a38019.909 38019.909 0 0 0-123.286 82.188c-5.854 3.918-11.174 3.754-16.984-.137-40.783-27.314-81.719-54.546-122.625-81.676-5.11-3.389-7.594-7.557-7.594-13.73v-79.729c0-6.141 2.521-10.332 7.624-13.716 40.906-27.13 81.939-54.363 122.724-81.676 5.818-3.896 11.094-4.007 16.938-.095a41090.004 41090.004 0 0 0 123.261 82.195c4.678 3.106 7.453 6.943 7.453 12.66v80.622z"/><path d="M316.247 273.234a3826.352 3826.352 0 0 1-45.386 30.332c-2.412 1.588-2.888 3.318-2.861 6.189v51.346l93.039-62.004-38.527-25.882c-2.345-1.604-3.93-1.567-6.265.019zM370 276.676V237.06l-29.59 19.873z"/></svg>
                                                Codepen
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M177 77L64 150.9l78.1 62.7L256 143.1zM64 276.3l113 73.9 79-66.1-113.9-70.5zM256 284.1l79 66.1 113-73.9-78.1-62.7zM448 150.9L335 77l-79 66.1 113.9 70.5z"/><path d="M256.2 298.3l-79.8 66-34.4-22.2V367l114 68 114-68v-24.9l-34.2 22.2z"/></svg>
                                                Dropbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M135.1 204.6c-10.7 0-19.3 8.7-19.3 19.4s8.7 19.4 19.3 19.4c10.6 0 19.3-8.7 19.3-19.4s-8.6-19.4-19.3-19.4z"/><path d="M466.3 248.9c-21.2-88.5-43.6-135.5-88.5-148.8-9.8-2.9-18.1-4-25.7-4-27.6 0-46.9 14.7-96.1 14.7-49.2 0-68.5-14.7-96.1-14.7-7.7 0-16 1.1-25.7 4-44.9 13.3-67.3 60.4-88.5 148.8-21.2 88.5-17.3 152.4 7.7 164.3 4.1 1.9 8.2 2.8 12.5 2.8 21.7 0 45.1-23.8 67.7-52 25.7-32.1 32.1-33 110.3-33h24.3c78.1 0 84.6.8 110.3 33 22.5 28.2 46 52 67.7 52 4.2 0 8.4-.9 12.5-2.8 24.9-12 28.7-75.9 7.6-164.3zm-331.1 14.7c-21.6 0-39.2-17.8-39.2-39.6s17.6-39.6 39.2-39.6c21.7 0 39.2 17.8 39.2 39.6.1 21.9-17.5 39.6-39.2 39.6zm172.9-19.5c-11.1 0-20.1-9-20.1-20.1 0-11.1 9-20.1 20.1-20.1 11.1 0 20.1 9 20.1 20.1 0 11.1-9 20.1-20.1 20.1zM352 288c-11.1 0-20.1-9-20.1-20 0-11.2 9-20.1 20.1-20.1 11.1 0 20.1 8.9 20.1 20.1 0 11-9 20-20.1 20zm0-87.8c-11.1 0-20.1-9-20.1-20.1 0-11.1 9-20.1 20.1-20.1 11.1 0 20.1 9 20.1 20.1 0 11.1-9 20.1-20.1 20.1zm43.9 43.9c-11.1 0-20.1-9-20.1-20.1 0-11.1 9-20.1 20.1-20.1 11.1 0 20.1 9 20.1 20.1 0 11.1-9 20.1-20.1 20.1z"/></svg>
                                                Game Controller B
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M290.4 145L227 96l63.6 102.2z"/><path d="M329 96v163h-36.4l-63.2-98.6 1.7 98.6H191V152l-37.3-29.3c1 1.2 2 2.4 2.9 3.7 10 13.9 15 30.5 15 50.5 0 49.2-30.6 82.1-76.9 82.1H32v.4L231.6 416H480V214.1L329 96z"/><path d="M129.9 178.1c0-29-14.2-45.1-39.7-45.1H71v89h19c26 0 39.9-15.4 39.9-43.9z"/></svg>
                                                Designer News
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M336 96c21.2 0 41.3 8.4 56.5 23.5S416 154.8 416 176v160c0 21.2-8.4 41.3-23.5 56.5S357.2 416 336 416H176c-21.2 0-41.3-8.4-56.5-23.5S96 357.2 96 336V176c0-21.2 8.4-41.3 23.5-56.5S154.8 96 176 96h160m0-32H176c-61.6 0-112 50.4-112 112v160c0 61.6 50.4 112 112 112h160c61.6 0 112-50.4 112-112V176c0-61.6-50.4-112-112-112z"/><path d="M360 176c-13.3 0-24-10.7-24-24s10.7-24 24-24c13.2 0 24 10.7 24 24s-10.8 24-24 24zM256 192c35.3 0 64 28.7 64 64s-28.7 64-64 64-64-28.7-64-64 28.7-64 64-64m0-32c-53 0-96 43-96 96s43 96 96 96 96-43 96-96-43-96-96-96z"/></svg>
                                                Instagram
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 161.2c-52.3 0-94.8 42.5-94.8 94.8s42.5 94.8 94.8 94.8 94.8-42.5 94.8-94.8-42.5-94.8-94.8-94.8z"/><circle cx="392.1" cy="126.4" r="43.2"/><path d="M445.3 169.8l-1.8-4-2.9 3.3c-7.1 8-16.1 14.2-26.1 17.9l-2.8 1 1.1 2.7c8.6 20.7 13 42.7 13 65.2 0 93.7-76.2 169.9-169.9 169.9S86.1 349.7 86.1 256 162.3 86.1 256 86.1c25.4 0 49.9 5.5 72.8 16.4l2.7 1.3 1.2-2.7c4.2-9.8 10.8-18.5 19.2-25.2l3.4-2.7-3.9-2C321.6 55.8 289.5 48 256 48 141.3 48 48 141.3 48 256s93.3 208 208 208 208-93.3 208-208c0-30-6.3-59-18.7-86.2z"/></svg>
                                                Ionic
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M255.917 480a32.536 32.536 0 0 1-16.633-4.599l-52.985-32.44c-7.914-4.562-4.023-6.203-1.443-7.141 10.565-3.781 13.713-5.657 24.947-12.285 1.206-.667 2.747-.424 3.955.322l39.71 23.504c1.476.85 3.557.85 4.931 0l155.188-92.246c1.475-.877 2.415-2.646 2.415-4.441V163.869c0-1.85-.94-3.592-2.449-4.528l-155.12-94.672c-1.478-.894-3.421-.894-4.898 0L98.516 159.374c-1.544.903-2.516 2.698-2.516 4.495v186.805c0 1.813.972 3.513 2.481 4.389l39.929 23.972c23.61 12.204 37.59-.17 37.59-14.611V180.725c0-2.652 2.047-4.727 4.596-4.727h22.809c2.515 0 4.597 2.072 4.597 4.727v183.698c0 32.563-19.353 51.248-49.199 51.248-9.156 0-16.397 0-36.552-10.279l-41.584-24.781C70.371 374.459 64 362.965 64 350.656V161.191c0-12.316 6.371-23.784 16.665-29.917L239.35 36.41c10.027-5.88 23.374-5.88 33.332 0l158.65 94.864C441.63 137.423 448 148.899 448 161.191v189.465c0 12.309-6.37 23.75-16.668 29.953l-158.65 94.774a32.52 32.52 0 0 1-16.698 4.599l-.067.018z"/><path d="M304.943 351.998c-64.61 0-84.006-31.61-84.006-59.271 0-2.629 2.048-4.729 4.562-4.729h20.521c2.282 0 4.227 1.7 4.562 4.016 3.084 21.602 16.748 31.15 54.324 31.15 33.399 0 47.091-10.346 47.091-28.684 0-10.592-3.463-18.424-55.407-23.697-43.427-4.441-70.288-14.373-70.288-50.295 0-33.135 26.996-52.49 72.234-52.49 46.128 0 76.462 14 79.173 50.829.102 1.337-.368 2.629-1.241 3.644-.871.965-2.078 1.527-3.353 1.527h-20.591c-2.146 0-4.024-1.562-4.459-3.713-4.401-16.953-16.97-23.402-49.563-23.402-36.486 0-40.746 12.753-40.746 22.607 0 11.963 5.031 15.441 54.294 22.172 48.761 6.663 71.933 16.117 71.933 51.552 0 35.781-28.808 58.783-79.075 58.783l.035.001z"/></svg>
                                                Nodejs
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M360 256h16v48h-16zM112 304h129.6l-48-48H112z"/><path d="M364.5 60.1c-.4-.2-.7-.4-1-.6-10.9-6-22.5-10.7-34.4-14.8l-5.4-1.8C302.3 36.1 279.6 32 256 32 132.3 32 32 132.3 32 256c0 84.3 46.6 157.6 115.4 195.8.4.2.7.5 1.1.7 10.9 6 22.5 10.7 34.4 14.8l5.4 1.8c21.4 6.8 44 10.9 67.7 10.9 123.7 0 224-100.3 224-224 0-84.3-46.6-157.7-115.5-195.9zM256 426.4c-9.3 0-18.4-.9-27.2-2.4-9.8-1.6-19.3-4.1-28.5-7.3-1.9-.6-3.8-1.2-5.6-1.9-6.5-2.5-12.9-5.3-19-8.6-53.6-28.7-90.1-85.2-90.1-150.3 0-37.2 12.4-71.4 32.7-99.4l237.2 237.2c-28.1 20.3-62.3 32.7-99.5 32.7zm137.8-71L156.6 118.2c28-20.2 62.1-32.6 99.4-32.6 9.3 0 18.3.9 27.2 2.4 9.8 1.6 19.3 4.1 28.5 7.3 1.8.6 3.7 1.2 5.6 1.9 6.2 2.4 12.2 5 18 8.1 54.2 28.5 91.2 85.3 91.2 150.8-.1 37.2-12.5 71.3-32.7 99.3z"/><path d="M352 256h-34l34 34zM384 256h16v48h-16zM360.1 212.7c-8.8-4.1-22-5.7-45.6-5.7h-3.6c-12.7.1-15.9-.1-20-6.1-2.8-4.2-1-14.8 3.7-21.9 1.6-2.4 1.8-5.6.4-8.2-1.4-2.6-4.1-4.2-7-4.3-.1 0-9.4-.1-18.3-3.9-10.6-4.5-15.6-12.1-15.6-23.1 0-25.8 21.8-27.7 22.8-27.7v-16c-12 0-38.8 11-38.8 43.7 0 17.5 9 31 25.7 38 4.2 1.7 8.4 2.9 12 3.6-3.3 9.8-3.6 20.9 1.7 28.7 9 13.3 20.3 13.2 33.3 13.1h3.5c26.3 0 34.6 2.3 38.9 4.3 5.7 2.6 6.8 7.5 6.6 15.7v1h16v-1c0-7.1.3-22.8-15.7-30.2z"/><path d="M400 244c0-25.7-3-39.2-9.1-49.6C382.3 180 368.5 172 352 172h-17.4c2.9-8.3 5.4-19.8 3.5-30.9-3.2-18.8-19.1-30-43.1-30v16c21 0 26.1 9.1 27.4 16.7 2.5 14.5-6.8 32.1-6.9 32.3-1.4 2.5-1.3 5.5.1 7.9s4.1 3.9 6.9 3.9H352c10.9 0 19.4 4.9 25.1 14.6 3.1 5.3 6.9 13.5 6.9 41.4h16v.1z"/></svg>
                                                No Smoking
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg id="Layer_03" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><style>.st0{fill:#bcc1c2}</style><path class="st0" d="M227.6 213.1H256v57.1h-28.4z"/><path class="st0" d="M0 156v171.4h142.2V356H256v-28.6h256V156H0zm142.2 142.9h-28.4v-85.7H85.3v85.7H28.4V184.6h113.8v114.3zm142.2 0h-56.9v28.6h-56.9V184.6h113.8v114.3zm199.2 0h-28.4v-85.7h-28.4v85.7h-28.4v-85.7H370v85.7h-56.9V184.6h170.7v114.3z"/></svg>
                                                NPM
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M178.4 287.5c-9.1 0-16.9 4.2-23.2 12.8-6.3 8.5-9.4 19-9.4 31.4 0 12.5 3.2 23 9.4 31.5 6.3 8.5 14 12.8 23.2 12.8 8.5 0 15.9-4.3 22.1-12.8 6.3-8.5 9.4-19 9.4-31.5 0-12.4-3.2-22.9-9.4-31.4-6.3-8.6-13.6-12.8-22.1-12.8zM334.7 287.5c-9 0-16.9 4.2-23.2 12.8-6.3 8.5-9.4 19-9.4 31.4 0 12.5 3.2 23 9.4 31.5 6.3 8.5 14.1 12.8 23.2 12.8 8.5 0 15.9-4.3 22.2-12.8 6.3-8.5 9.4-19 9.4-31.5 0-12.4-3.2-22.9-9.4-31.4-6.3-8.6-13.6-12.8-22.2-12.8z"/><path d="M445.8 172c-.1 0 2.7-14.3.3-39.2-2.2-24.9-7.5-47.8-16.1-68.8 0 0-4.4.8-12.8 2.9s-22.1 6.3-40.9 14.8c-18.5 8.5-38 19.8-58.3 33.5-13.8-3.9-34.4-5.9-62-5.9-26.3 0-46.9 2-62 5.9-44.6-30.9-81.9-48-112.1-51.2-8.6 21-13.9 44-16 69-2.4 24.9.4 39.3.4 39.3C42 198.6 32 236.5 32 267.8c0 24.2.7 46.1 6.1 65.5 5.6 19.3 12.7 35.1 21.1 47.2 8.6 12.1 19 22.8 31.6 31.9 12.5 9.3 24 16 34.4 20.2 10.5 4.4 22.4 7.6 36 9.9 13.3 2.4 23.4 3.6 30.5 4 0 0 28 1.5 64.4 1.5s64.3-1.5 64.3-1.5c7-.4 17.1-1.6 30.5-4 13.5-2.3 25.5-5.6 35.9-9.9 10.4-4.3 21.9-10.9 34.5-20.2 12.5-9 22.9-19.7 31.5-31.9 8.4-12.1 15.5-27.9 21.1-47.2 5.5-19.4 6.1-41.4 6.1-65.6 0-30.3-10-68.7-34.2-95.7zm-65.4 233.6c-27.9 13.1-68.9 18.4-123.3 18.4H255c-54.4 0-95.4-5.2-122.8-18.4-27.5-13.1-41.3-40.1-41.3-80.7 0-24.3 8.6-44 25.5-59.1 7.4-6.5 16.4-11 27.6-13.7 11.1-2.6 21.4-2.8 31-2.5 9.4.4 22.6 2.2 39.3 3.5 16.8 1.3 29.3 3 41.8 3 11.7 0 27.2-2 52.1-4 25-2 43.5-3 55.5-1 12.3 2 23 6.2 32.1 14.7 17.7 15.8 26.6 35.5 26.6 59.1-.1 40.6-14.2 67.6-42 80.7z"/></svg>
                                                Octocat
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M399.8 203c-.8-17.1-3.3-34.5-10.8-50.1-4.1-8.6-9.7-16.5-16.5-23.2-6.3-6.4-13.6-11.7-21.3-16.3-17.1-10.2-37.5-17-84.4-31S192 64 192 64v358.3l79.9 25.7s.1-198.8.1-299.5v-3.8c0-9.3 7.5-16.8 16.1-16.8h.5c8.5 0 15.5 7.5 15.5 16.8V278c11 5.3 29.2 9.3 41.8 9.1 8.3.2 16.7-1.7 24-5.7 7.6-4.1 13.9-10.4 18.4-17.8 5.1-8.3 8.2-17.8 9.9-27.3 1.9-10.8 2-22.1 1.6-33.3zM86.7 357.8c27.4-9.8 89.3-29.5 89.3-29.5v-47.2s-76.5 24.8-111.3 37.1c-8.6 3.1-17.3 5.9-25.7 9.5-9.8 4.1-19.4 8.7-28.1 14.8-3.8 2.6-7.2 5.9-9.2 10.1s-2.2 9.2-.5 13.6c2 5.1 5.8 9.3 10.1 12.6 7.8 5.9 17.1 9.5 26.4 12.2 28.4 9.4 58.4 14 88.4 13.3 14.5-.2 36-1.9 50-4.4v-42s-11 2.5-41.3 12.5c-4.6 1.5-9.2 3.3-14 4.3-7.1 1.6-14.4 2.1-21.6 2.2-6.5-.3-13.2-.7-19.3-3.1-2.2-1-4.6-2.2-5.5-4.6-.8-2 .3-4 1.7-5.4 2.8-2.9 6.8-4.5 10.6-6z"/><path d="M512 345.9c-.1-6-3.7-11.2-7.9-15-7.1-6.3-15.9-10.3-24.7-13.5-5.5-1.9-9.3-3.3-14.7-5-25.2-8.2-51.9-11.2-78.3-11.3-8 .3-23.1.5-31 1.4-21.9 2.5-67.3 15.4-67.3 15.4v48.8s67.5-21.6 96.5-31.8c9.7-3.3 20.1-4.6 30.3-4.6 6.5.2 13.2.7 19.4 3.1 2.2.9 4.5 2.2 5.5 4.5.9 2.6-.9 5-2.9 6.5-4.7 3.8-10.7 5.3-16.2 7.4-41 14.5-132.7 44.7-132.7 44.7v47s117.2-39.6 170.8-58.8c8.9-3.3 17.9-6.1 26.4-10.4 7.9-4 15.8-8.6 21.8-15.3 3.1-3.6 5-8 5-13.1z"/></svg>
                                                Play Station
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M193.46 249.056a65.316 65.316 0 0 1 11.586-1.041l-3.122-.015h103.823c4.503 0 8.806-.617 12.908-1.754 19.37-5.363 33.345-22.537 33.345-43.663v-87.224c0-24.832-21.15-43.484-46.289-47.606-15.931-2.624-39.258-3.827-55.089-3.749-15.829.086-30.981 1.404-44.277 3.749C167.143 74.576 160 88.928 160 115.359V144h96v16H128.82c-35.628 0-64.538 42.571-64.813 95.242-.002.253-.007.505-.007.758 0 9.523.94 18.72 2.685 27.404C74.648 323.07 99.451 352 128.82 352H144v-45.935c0-26.827 20.146-51.733 49.46-57.009zm10.196-122.054c-9.592 0-17.384-7.785-17.384-17.403 0-9.664 7.774-17.52 17.384-17.52 9.574 0 17.399 7.855 17.399 17.52.001 9.618-7.809 17.403-17.399 17.403z"/><path d="M443.951 222.543C434.78 186.021 411.033 160 383.18 160H368v40.672c0 33.915-22.286 58.474-49.489 62.681a53.943 53.943 0 0 1-8.301.646H206.351a51.41 51.41 0 0 0-13.049 1.672C174.18 270.689 160 286.6 160 307.236v87.227c0 24.832 24.977 39.426 49.481 46.551 29.327 8.531 61.267 10.068 96.366 0C329.15 434.354 352 420.893 352 394.463V368h-96v-16h127.18c25.24 0 47.107-21.365 57.814-52.549C445.474 286.404 448 271.641 448 256c0-11.768-1.433-23.038-4.049-33.457zM307.867 382.82c9.59 0 17.381 7.785 17.381 17.4 0 9.65-7.791 17.521-17.381 17.521-9.577 0-17.399-7.871-17.399-17.521 0-9.63 7.806-17.4 17.399-17.4z"/></svg>
                                                Python
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><circle cx="322.3" cy="288.4" r="31.8"/><circle cx="190.3" cy="288.4" r="31.8"/><path d="M480.5 251c0-27.7-22.2-50.2-49.5-50.2-13 0-24.7 5-33.6 13.3-33.2-23.4-78.4-38.5-128.7-40.7L292 95.7l69.6 13.9c.2 24.7 20.1 44.7 44.5 44.7 24.6 0 44.5-20.2 44.5-45.1S430.7 64 406.1 64c-18.6 0-34.5 11.6-41.2 28l-85.2-17-29.4 98.2-7.1.2c-50.3 2.2-95.5 17.4-128.7 40.7-8.8-8.3-20.6-13.3-33.6-13.3-27.3 0-49.5 22.5-49.5 50.2 0 19.6 11 36.5 27.1 44.8-.8 4.9-1.2 9.8-1.2 14.8C57.5 386.4 146.4 448 256 448s198.5-61.6 198.5-137.5c0-5-.4-9.9-1.1-14.8 16.1-8.3 27.1-25.2 27.1-44.7zM406.1 81.9c14.8 0 26.8 12.2 26.8 27.2s-12 27.2-26.8 27.2-26.8-12.2-26.8-27.2 12-27.2 26.8-27.2zM49.2 251c0-17.8 14.3-32.2 31.8-32.2 7.2 0 13.9 2.5 19.2 6.6-17.3 15.2-30.1 33-37 52.4-8.4-5.9-14-15.7-14-26.8zm337.2 141.9C351.8 416.8 305.5 430 256 430s-95.8-13.2-130.4-37.1c-32.5-22.5-50.4-51.8-50.4-82.4 0-3.2.2-6.5.6-9.7.7-6 2.2-11.9 4.3-17.7 5.6-15.6 16-30.3 30.7-43.4 4.4-3.9 9.2-7.7 14.4-11.3.1-.1.3-.2.4-.3C160.2 204.2 206.5 191 256 191s95.8 13.2 130.4 37.1c.1.1.3.2.4.3 5.2 3.6 10 7.4 14.4 11.3 14.7 13.1 25.1 27.8 30.7 43.4 2.1 5.8 3.5 11.7 4.3 17.7.4 3.2.6 6.4.6 9.7 0 30.6-17.9 59.9-50.4 82.4zm62.4-115.2c-6.9-19.4-19.7-37.2-37-52.4 5.3-4.1 12-6.6 19.2-6.6 17.5 0 31.8 14.5 31.8 32.2 0 11.2-5.6 21-14 26.8z"/><path d="M320.5 357.9c-.2.2-24.2 24.2-64.5 24.4-40.9-.2-64.4-24.2-64.6-24.4l-12.6 12.4c1.2 1.2 29.6 29.5 77.2 29.7 47.6-.2 75.9-28.5 77.1-29.7l-12.6-12.4z"/></svg>
                                                Reddit
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M119.9 336.1c-30.8 0-55.9 25.1-55.9 55.8 0 30.8 25.1 55.6 55.9 55.6 30.9 0 55.9-24.9 55.9-55.6 0-30.7-25-55.8-55.9-55.8z"/><path d="M64 192v79.9c48 0 94.1 14.2 128 48.1 33.9 33.9 48 79.9 48 128h80c0-139.9-116-256-256-256z"/><path d="M64 64v79.9c171 0 303.9 133 303.9 304.1H448C448 236.3 276 64 64 64z"/></svg>
                                                RSS
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M213.6 236.216l64.003-21.438 20.708 61.823-64.004 21.438z"/><path d="M213.6 236.216l64.003-21.438 20.708 61.823-64.004 21.438z"/><path d="M475.9 190C426.4 25 355-13.4 190 36.1S-13.4 157 36.1 322 157 525.4 322 475.9 525.4 355 475.9 190zm-83.3 107.1l-31.1 10.4 10.7 32.2c4.2 13-2.7 27.2-15.7 31.5-2.7.8-5.8 1.5-8.4 1.2-10-.4-19.6-6.9-23-16.9l-10.7-32.2-64.1 21.5L261 377c4.2 13-2.7 27.2-15.7 31.5-2.7.8-5.8 1.5-8.4 1.2-10-.4-19.6-6.9-23-16.9L203 360.4l-31 10.3c-2.7.8-5.8 1.5-8.4 1.2-10-.4-19.6-6.9-23-16.9-4.2-13 2.7-27.2 15.7-31.5l31.1-10.4-20.7-61.8-31.1 10.4c-2.7.8-5.8 1.5-8.4 1.2-10-.4-19.6-6.9-23-16.9-4.2-13 2.7-27.2 15.7-31.5l31.1-10.4-10.9-32.1c-4.2-13 2.7-27.2 15.7-31.5 13-4.2 27.2 2.7 31.5 15.7l10.7 32.2 64.1-21.5-10.7-32.2c-4.2-13 2.7-27.2 15.7-31.5 13-4.2 27.2 2.7 31.5 15.7l10.7 32.2 31.1-10.4c13-4.2 27.2 2.7 31.5 15.7 4.2 13-2.7 27.2-15.7 31.5l-31.1 10.4 20.7 61.8 31.1-10.4c13-4.2 27.2 2.7 31.5 15.7 4.2 13.2-2.7 27.4-15.8 31.7z"/></svg>
                                                Slack
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M80 32l-32 80v304h96v64h64l64-64h80l112-112V32H80zm336 256l-64 64h-96.001L192 416v-64h-80V80h304v208z"/><path d="M320 143h48v129h-48zM208 143h48v129h-48z"/></svg>
                                                Twitch
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M259 271.3L226.2 367h-.1l-25.4 73.1c1.8.5 3.5.9 5.3 1.4h.3c15.8 4.2 32.4 6.5 49.5 6.5 8.5 0 16.8-.5 24.9-1.8 11.2-1.4 22-3.8 32.5-7.1 2.6-.8 5.2-1.7 7.8-2.6-2.8-6-8.8-19.3-9.1-19.9L259 271.3zM80.8 180.5C70.8 203.1 64 230.9 64 256c0 6.3.3 12.6.9 18.8 6.9 71.2 52.9 131 116.1 157.9 2.6 1.1 5.3 2.2 8 3.2L96 180.6c-8-.3-9.5.2-15.2-.1z"/><path d="M430.2 175.4c-4.3-9.3-9.4-18.2-15.1-26.6-1.6-2.4-3.4-4.8-5.1-7.2-21.5-28.8-50.8-51.4-84.9-64.6-21.4-8.4-44.8-13-69.2-13-60.3 0-114.2 28-149.4 71.7-6.5 8-12.3 16.6-17.5 25.6 14.2.1 31.8.1 33.8.1 18.1 0 46-2.2 46-2.2 9.4-.6 10.4 13.1 1.1 14.2 0 0-9.4 1.1-19.8 1.6L213 362l37.8-113.3-26.8-73.6c-9.4-.5-18.1-1.6-18.1-1.6-9.4-.5-8.2-14.8 1-14.2 0 0 28.5 2.2 45.5 2.2 18.1 0 46-2.2 46-2.2 9.3-.6 10.5 13.1 1.1 14.2 0 0-9.3 1.1-19.7 1.6l62.3 185.6 17.3-57.6c8.7-22.4 13.1-40.9 13.1-55.7 0-21.3-7.7-36.1-14.3-47.6-8.7-14.3-16.9-26.3-16.9-40.4 0-15.9 12-30.7 29-30.7h2.2c26.2-.7 34.8 25.3 35.9 43v.6c.4 7.2.1 12.5.1 18.8 0 17.4-3.3 37.1-13.1 61.8l-39 112.8-22.3 65.7c1.8-.8 3.5-1.6 5.3-2.5 56.7-27.4 98-82 106.7-146.7 1.3-8.5 1.9-17.2 1.9-26 0-28.9-6.4-56.3-17.8-80.8z"/></svg>
                                                Wordpress
                                            </div>
                                        </div>
                                        <h4 class="mt-0 header-title">Logo Examples</h4>
                                        <p class="text-muted mb-4">Use SVG Icons.</p>
                                        <div class="row icon-demo-content">


                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M452.9 64.2c-.7-.1-1.5-.2-2.2-.2H61.5c-7.4-.1-13.4 5.9-13.5 13.5 0 .8 0 1.6.2 2.4l56.6 352.5c.7 4.3 2.9 8.2 6.1 11.1 3.2 2.9 7.4 4.5 11.7 4.5H394c6.6.1 12.3-4.8 13.3-11.5L441 224H316l-16 96h-88l-22.3-126.9h256.2l18-113.1c1.1-7.5-3.8-14.6-11-15.8z"/></svg>
                                                Bitbucket
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M410.5 279.2c-5-11.5-12.7-21.6-28.1-30.1-8.2-4.5-16.1-7.8-25.4-10 5.4-2.5 10-5.4 16.3-11 7.5-6.6 13.1-15.7 15.6-23.3 2.6-7.5 4.1-18 3.5-28.2-1.1-16.8-4.4-33.1-13.2-44.8-8.8-11.7-21.2-20.7-37.6-27-12.6-4.8-25.5-7.8-45.5-8.9V32h-40v64h-32V32h-41v64H96v48h27.9c8.7 0 14.6.8 17.6 2.3 3.1 1.5 5.3 3.5 6.5 6 1.3 2.5 1.9 8.4 1.9 17.5V343c0 9-.6 14.8-1.9 17.4-1.3 2.6-2 4.9-5.1 6.3-3.1 1.4-3.2 1.3-11.8 1.3h-26.4L96 416h87v64h41v-64h32v64h40v-64.4c26-1.3 44.5-4.7 59.4-10.3 19.3-7.2 34.1-17.7 44.7-31.5 10.6-13.8 14.9-34.9 15.8-51.2.7-14.5-.9-33.2-5.4-43.4zM224 150h32v74h-32v-74zm0 212v-90h32v90h-32zm72-208.1c6 2.5 9.9 7.5 13.8 12.7 4.3 5.7 6.5 13.3 6.5 21.4 0 7.8-2.9 14.5-7.5 20.5-3.8 4.9-6.8 8.3-12.8 11.1v-65.7zm28.8 186.7c-7.8 6.9-12.3 10.1-22.1 13.8-2 .8-4.7 1.4-6.7 1.9v-82.8c5 .8 7.6 1.8 11.3 3.4 7.8 3.3 15.2 6.9 19.8 13.2 4.6 6.3 8 15.6 8 24.7 0 10.9-2.8 19.2-10.3 25.8z"/></svg>
                                                Bitcoin
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256.282 339.488zM64 32l34.946 403.219L255.767 480l157.259-44.85L448 32H64zm290.676 334.898l-98.607 28.125-98.458-28.248L150.864 289h48.253l3.433 39.562 53.586 15.163.132.273h.034l53.467-14.852L315.381 265H203l-4-50h120.646l4.396-51H140l-4-49h240.58l-21.904 251.898z"/></svg>
                                                Css3
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 64C150 64 64 150 64 256c0 106.1 86 192 192 192s192-85.9 192-192c0-106-86-192-192-192zm121.9 88.5c21.6 25.4 35.3 57.6 37.7 92.9-34.6-1.8-76-1.8-109.2 1.3-4.2-10.6-8.5-21-13.2-31 38.3-16.6 67.8-38.4 84.7-63.2zM256 96c38.8 0 74.4 13.8 102.1 36.8-17.4 22-44.7 41.1-78.7 55.6-18.6-34.4-40-64-62.8-87.3 12.7-3.2 25.8-5.1 39.4-5.1zm-72.4 17.5c23.1 23 44.8 52.3 63.8 86.6-36.1 11-77.5 17.3-121.7 17.3-8.4 0-16.6-.3-24.7-.8 11.5-45.1 42-82.5 82.6-103.1zM96.3 248.4c9.1.4 18.3.6 27.6.5 50.4-.6 97.3-8.5 137.6-21.4 3.8 7.9 7.4 16 10.8 24.3-5.5 1.3-10.4 2.7-14.3 4.3-55.1 23.1-98.5 60.4-122 105.5-24.8-28.2-40-65.1-40-105.6 0-2.6.1-5.1.3-7.6zM256 416c-37 0-71-12.6-98.1-33.7 21.3-42.2 59.3-77.1 107.2-98.8 4.5-2.1 10.5-3.8 17.4-5.3 5.7 15.8 10.8 32.2 15.3 49.2 6.9 26.5 11.8 52.7 14.8 78.1C295 412.2 276 416 256 416zm86.5-25.5c-3-25.7-7.9-52.1-14.9-78.9-3.4-13-7.3-25.6-11.5-37.9 31.4-2.6 69-2.2 98.9 0-5.4 49.1-33 91.3-72.5 116.8z"/></svg>
                                                Dribbble
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M234 272v-48h131.094l7.149-48H234v-1.83c0-35.92 14.975-58.086 79.25-58.086 26.264 0 55.867 2.498 93.189 8.742L416 59.866C377.988 51.123 345.306 48 310.057 48 195.326 48 146 89.225 146 165.43V176H96v48h50v48H96v48h50v26.57C146 422.774 195.297 464 310.027 464c35.25 0 67.848-3.123 105.859-11.866l-9.619-64.96c-37.322 6.244-66.781 8.742-93.045 8.742-64.276 0-79.223-18.739-79.223-63.086V320h116.795l7.148-48H234z"/></svg>
                                                Euro
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M426.8 64H85.2C73.5 64 64 73.5 64 85.2v341.6c0 11.7 9.5 21.2 21.2 21.2H256V296h-45.9v-56H256v-41.4c0-49.6 34.4-76.6 78.7-76.6 21.2 0 44 1.6 49.3 2.3v51.8h-35.3c-24.1 0-28.7 11.4-28.7 28.2V240h57.4l-7.5 56H320v152h106.8c11.7 0 21.2-9.5 21.2-21.2V85.2c0-11.7-9.5-21.2-21.2-21.2z"/></svg>
                                                Facebook
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M352 64H160c-52.8 0-96 43.2-96 96v192c0 52.8 43.2 96 96 96h192c52.8 0 96-43.2 96-96V160c0-52.8-43.2-96-96-96zM184 304c-26.5 0-48-21.5-48-48s21.5-48 48-48 48 21.5 48 48-21.5 48-48 48zm144 0c-26.5 0-48-21.5-48-48s21.5-48 48-48 48 21.5 48 48-21.5 48-48 48z"/></svg>
                                                Flickr
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M376.764 32H138.541C105.666 32 96 56.798 96 72.414v379.64c0 17.591 9.425 24.117 14.718 26.267 5.299 2.155 19.916 3.971 28.673-6.168 0 0 112.469-130.895 114.4-132.834 2.921-2.93 2.921-2.93 5.844-2.93h72.767c30.574 0 35.49-21.869 38.684-34.752 2.659-10.789 32.489-163.962 42.452-212.559C421.143 51.993 411.745 32 376.764 32zm-5.678 269.637c2.659-10.789 32.489-163.962 42.452-212.559m-50.846 7.592l-9.999 51.734c-1.195 5.65-8.287 11.595-14.863 11.595h-95.917C231.473 160 224 166.138 224 176.602v13.448c0 10.473 7.519 17.894 17.965 17.894h81.848c7.374 0 14.61 8.109 13.016 16.005-1.602 7.908-9.086 46.569-9.984 50.89-.902 4.328-5.845 11.725-14.611 11.725h-64.269c-11.705 0-15.244 1.533-23.074 11.293-7.837 9.77-78.256 94.592-78.256 94.592-.713.822-1.41.584-1.41-.312V95.896c0-6.684 5.793-14.523 14.479-14.523h191.173c7.035-.001 13.611 6.631 11.815 15.297z"/></svg>
                                                Foursquare
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M502.6 115c-22.5-43.7-58-51-58-51s15.5 32 16 51c.4 16.1-5.5 28-27.2 33.5s-30.8-2-47.8-17.5-41.6-26.5-72.6-28c-40-2-77 9-77 9-20-25 20-80 20-80-74.5 29.5-93.7 83.3-96 113.7-1.9 24.1 8.5 40.8 8.5 40.8s-.5 27.8-5 42c-3.1 9.8-16.9 25-26 34.5-12.2 12.7-12.5 38.5 0 57s44 27.5 67 39.5 31.5 21 31.5 21 1 8.3.5 15.3-3.2 14-9 18.2c-5.5 3.9-15.5.5-20.5-2s-5-6.2-10.5-8-7.3-4-6.5-11 2-9-3.5-18.5-18.5-9.5-29.5-8-17.3 6.8-17.3 6.8l-16.3-10s8.5-15.6 5.2-35.6c-7.3-43.8-50-62.8-50-62.8L89 309.3s1.1-2.6 6.4-6.4 8.1-3.6 8.1-3.6 6.6 7.6 9.1 25.3c2.5 18-6.7 27.2-6.7 27.2l-28.3-18 1-14.5L39.8 309 56 345.7l15-4 24 22.7s-15.7 11.7-33 11.7c-11 0-22-6-22-6s-1.4-1-.8-5.5c.7-5 6.8-12.5 6.8-12.5H0s27.3 38.7 65 38.7c31 0 44.2-12.5 44.2-12.5L128 397s3 5.5 0 7-7 3.5-9 15 18 29 18 29c21.8 17.8 7 32 7 32h272c-9-13-22.5-18-32-32 0 0-44.8-58.4-1.8-90.4 57.4-42.7 42.8-69.4 41.2-101.4 0 0 31.8-6.6 59.3-33.6s38.9-70.8 19.9-107.6zM195 203c-16.9 4.5-22.5 35.5-22.5 35.5 1.5-63 57.5-93 65-89s-6.5 39-21 64c0 0-8-14.1-21.5-10.5zm37 15s18-56 37.5-59.5 41.5 21 41.5 62-26 65.4-42.8 69.2c-16.5 3.8-23 2-23 2s27.5-21.6 23.5-56.8c-2.8-24.7-31.4-24.2-36.7-16.9z"/></svg>
                                                Freebsd Devil
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M369.3 146H142.7C81.5 146 32 191.5 32 255.4c0 64 49.5 110.6 110.7 110.6h226.5c61.2 0 110.7-46.6 110.7-110.6.1-63.9-49.4-109.4-110.6-109.4zM200 266.7c0 2.7-2.4 5.3-5.2 5.3H160v35.1c0 2.8-3.1 4.9-5.8 4.9h-21.4c-2.6 0-4.8-1.9-4.8-4.5V272H92.9c-2.8 0-4.9-3.1-4.9-5.8v-21.4c0-2.6 1.9-4.8 4.5-4.8H128v-34.8c0-2.8 1.9-5.2 4.6-5.2h22.1c2.7 0 5.3 2.4 5.3 5.2V240h34.8c2.8 0 5.2 1.9 5.2 4.6v22.1zm119.8 8.8c-10.7 0-19.5-8.6-19.5-19.2s8.7-19.2 19.5-19.2 19.5 8.6 19.5 19.2-8.8 19.2-19.5 19.2zm42.5 41.8c-10.7 0-19.5-8.5-19.5-19.1 0-10.6 8.7-19.2 19.5-19.2s19.5 8.5 19.5 19.2c0 10.6-8.7 19.1-19.5 19.1zm0-83.7c-10.7 0-19.5-8.6-19.5-19.1 0-10.6 8.7-19.2 19.5-19.2s19.5 8.6 19.5 19.2c0 10.5-8.7 19.1-19.5 19.1zm42.6 41.9c-10.7 0-19.4-8.6-19.4-19.2s8.7-19.2 19.4-19.2 19.5 8.6 19.5 19.2c-.1 10.6-8.8 19.2-19.5 19.2z"/></svg>
                                                Game Controller A
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 32C132.3 32 32 134.9 32 261.7c0 101.5 64.2 187.5 153.2 217.9 1.4.3 2.6.4 3.8.4 8.3 0 11.5-6.1 11.5-11.4 0-5.5-.2-19.9-.3-39.1-8.4 1.9-15.9 2.7-22.6 2.7-43.1 0-52.9-33.5-52.9-33.5-10.2-26.5-24.9-33.6-24.9-33.6-19.5-13.7-.1-14.1 1.4-14.1h.1c22.5 2 34.3 23.8 34.3 23.8 11.2 19.6 26.2 25.1 39.6 25.1 10.5 0 20-3.4 25.6-6 2-14.8 7.8-24.9 14.2-30.7-49.7-5.8-102-25.5-102-113.5 0-25.1 8.7-45.6 23-61.6-2.3-5.8-10-29.2 2.2-60.8 0 0 1.6-.5 5-.5 8.1 0 26.4 3.1 56.6 24.1 17.9-5.1 37-7.6 56.1-7.7 19 .1 38.2 2.6 56.1 7.7 30.2-21 48.5-24.1 56.6-24.1 3.4 0 5 .5 5 .5 12.2 31.6 4.5 55 2.2 60.8 14.3 16.1 23 36.6 23 61.6 0 88.2-52.4 107.6-102.3 113.3 8 7.1 15.2 21.1 15.2 42.5 0 30.7-.3 55.5-.3 63 0 5.4 3.1 11.5 11.4 11.5 1.2 0 2.6-.1 4-.4C415.9 449.2 480 363.1 480 261.7 480 134.9 379.7 32 256 32z"/></svg>
                                                Github
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M457.6 224l-2.1-8.9H262V297h115.6c-12 57-67.7 87-113.2 87-33.1 0-68-13.9-91.1-36.3-23.7-23-38.8-56.9-38.8-91.8 0-34.5 15.5-69 38.1-91.7 22.5-22.6 56.6-35.4 90.5-35.4 38.8 0 66.6 20.6 77 30l58.2-57.9c-17.1-15-64-52.8-137.1-52.8-56.4 0-110.5 21.6-150 61C72.2 147.9 52 204 52 256s19.1 105.4 56.9 144.5c40.4 41.7 97.6 63.5 156.5 63.5 53.6 0 104.4-21 140.6-59.1 35.6-37.5 54-89.4 54-143.8 0-22.9-2.3-36.5-2.4-37.1z"/></svg>
                                                Google
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M318.2 230.9l-1.6-7H160V288h90.7c-9.4 45-48.4 63.6-84.1 63.6-26 0-50.2-7.8-68.3-25.3-18.6-18.1-28.9-43.1-28.9-70.4 0-27.1 9.8-51.8 27.6-69.6 17.7-17.7 42-25.4 68.7-25.4 30.5 0 49.9 13.8 58.1 21.1l48-47.7C258.3 122.6 221.5 93 164.1 93c-44.3 0-86.7 16.8-117.7 47.8C15.9 171.3 0 215.2 0 256s15 82.6 44.6 113.3C76.3 402 121.2 419 167.5 419c42.1 0 81.9-16.5 110.3-46.3 28-29.4 42.4-70.1 42.4-112.7-.1-18-1.9-28.7-2-29.1zM512 224h-57v-57h-41v57h-57v41h57v57h41v-57h57z"/></svg>
                                                Googleplus
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 64v384h384V64H64zm214 215v72h-40v-72l-66-120h47.1l39.7 83.6 38-83.6H342l-64 120z"/></svg>
                                                Hacker News
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M64 32l34.936 403.213L255.769 480l157.245-44.854L448 32H64zm307.997 132h-184l3.991 51h176.008l-13.505 151.386-98.5 28.094-98.682-27.976L150.545 289h48.254l3.423 39.287 53.769 14.781 53.422-14.915L314.987 264H147.986l-12.571-149.589 240.789.016L371.997 164z"/></svg>
                                                HTML5
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M468.4 269.2c-2.7-34.2-12.2-59.2-32.9-57.3 6.4 14.6 12.2 48.1 8.7 72-1.4-25.9-6.3-50.2-17.2-72-32.1-64.6-100.6-107.4-177.5-103.1-85.9 4.8-155 66.7-172 146.8l-11.4 1.6c-17.2 2.4-26.9 34.9-21.7 72.5 5.3 37.7 23.5 66.2 40.7 63.8l15.8-2.2c34.7 56.3 98.5 92.3 169.3 88.4 85.3-4.7 154-65.9 171.7-145.2l7.4-.4c15.2-2.5 21.8-31.2 19.1-64.9zM90.3 264c10.7 8.2 25.4 28.3 29.1 55.1 3.9 27.7-4.8 54.1-13.4 64.3 6-14.8 8.1-37.3 4.7-61.9-3.3-24-11-44.7-20.4-57.5zm183.8 116.2c-8.5.5-15.8-6-16.3-14.5s6-15.7 14.6-16.2c8.5-.5 15.8 6 16.3 14.5s-6.1 15.7-14.6 16.2zm81-4.7c-8.5.5-15.8-6-16.3-14.5s6-15.7 14.6-16.2c8.5-.5 15.8 6 16.3 14.5.4 8.5-6.1 15.8-14.6 16.2zM165.5 70s0 .1 0 0c.1.1.1.2.1.2.1.2.2.3.3.5v.1c.4 1 1.1 1.9 2.3 2.7 2 1.5 5 2.4 8.6 3 3.4.5 7.5.7 11.9.5 1 0 1.9-.1 2.9-.2-.4-.4-.8-.9-1.2-1.3h-1.3c-4.3.1-8.2-.2-11.6-.9-3.5-.7-6.4-1.8-8.4-3.4-.6-.5-1-.9-1.4-1.4-.2-.7-.2-1.5 0-2.3.5-2.3 2.4-4.8 5.5-7.4 2.7-2.3 6.4-4.7 10.9-7 .9-.4 1.7-.9 2.6-1.3.1-.1.3-.1.5-.2-.8 3.3-.9 6.9-.2 10.5 2.3 11.9 11.6 20.3 23.2 20.6l4 24.3 12.7-2-4-24.3c10.8-4.6 16.3-16.1 14-28-.7-3.5-2-6.7-3.9-9.5-5.3-.8-15.6-.8-29.2 2.1 1.1-.3 2.1-.7 3.2-1 7.6-2.1 14.9-3.5 21.5-4.2.6-.1 1.2-.1 1.8-.2 1.2-.1 2.4-.2 3.5-.3h.6c4.1-.2 7.7-.1 10.8.3 2.4.3 4.4.8 6.1 1.4-.6.9-.9 2-.9 3.2 0 2.7 1.8 5 4.3 5.8-.6.9-1.3 1.9-2.1 2.8-.8.9-1.8 1.9-2.9 2.8-1.1.9-2.3 1.8-3.5 2.7l-6.5 3.8-.3 1.5c.1 0 .2-.1.2-.1l8.4-4.7c1.2-.8 2.4-1.6 3.4-2.4 1.2-.9 2.2-1.8 3.2-2.8.9-.9 1.7-1.9 2.4-2.8l.3-.6c3-.4 5.4-2.9 5.4-6 0-3.4-2.7-6.1-6.1-6.1-1 0-1.9.3-2.8.7-2-1.2-4.8-2.1-8.2-2.7-4.3-.8-9.6-1-15.5-.6-.7 0-1.4.1-2.1.2-.7.1-1.3.2-2 .2-5.3-3.5-11.9-5-18.7-3.7-7.9 1.5-14.2 6.5-17.8 13-1.3.5-2.6 1.1-3.8 1.7-.7.3-1.3.6-2 .9-5.9 2.9-10.6 6.1-13.9 9.1-3.1 2.9-4.9 5.7-5.3 8.3-.2 1.4 0 2.8.7 4 .1.1.2.3.3.5z"/></svg>
                                                Ionitron
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M208 88.001h-80v212.498c0 52.58-18.032 67.261-49.412 67.261-14.705 0-27.948-2.521-38.25-6.063L32 423.904C46.7 428.966 69.259 432 86.907 432 158.955 432 208 398.129 208 301.02V88.001zM382.463 80C305.02 80 256 123.998 256 182.154c0 50.083 37.751 81.44 92.641 101.665 39.7 14.158 55.392 26.808 55.392 47.539 0 22.756-18.139 37.425-52.448 37.425-31.863 0-60.789-10.64-80.394-21.255v-.021L256 410.727c18.639 10.638 53.441 21.255 91.167 21.255C437.854 431.98 480 383.43 480 326.284c0-48.55-26.958-79.9-85.278-102.163-43.139-17.191-61.27-26.795-61.27-48.542 0-17.2 15.688-32.869 48.043-32.869 31.846 0 53.744 10.707 66.505 17.291l19.125-64C447.125 87.22 420.188 80 382.463 80z"/></svg>
                                                Javascript
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M417.2 64H96.8C79.3 64 64 76.6 64 93.9V415c0 17.4 15.3 32.9 32.8 32.9h320.3c17.6 0 30.8-15.6 30.8-32.9V93.9C448 76.6 434.7 64 417.2 64zM183 384h-55V213h55v171zm-25.6-197h-.4c-17.6 0-29-13.1-29-29.5 0-16.7 11.7-29.5 29.7-29.5s29 12.7 29.4 29.5c0 16.4-11.4 29.5-29.7 29.5zM384 384h-55v-93.5c0-22.4-8-37.7-27.9-37.7-15.2 0-24.2 10.3-28.2 20.3-1.5 3.6-1.9 8.5-1.9 13.5V384h-55V213h55v23.8c8-11.4 20.5-27.8 49.6-27.8 36.1 0 63.4 23.8 63.4 75.1V384z"/></svg>
                                                Linkedin
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M447.659 96H64.341C46.504 96 32 110.484 32 128.308v255.349C32 401.493 46.504 416 64.341 416h383.318C465.496 416 480 401.493 480 383.656V128.308C480 110.484 465.496 96 447.659 96zM284.023 352h-56.048v-96l-42.04 53.878L143.913 256v96H87.869V160h56.044l42.022 67.98 42.04-67.98h56.048v192zm83.657 0l-69.635-96h42v-96h56.043v96h42.027l-70.453 96h.018z"/></svg>
                                                Mark Down
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M443.6 208.4c-3.1-1.9-2.2-6.6 1.3-7.3l5.3-1.1c7.1 0 22.4-2.3 25.6-5.4 3.1-3.2 4.2-5.4 4.2-8.2s-1.7-7.7-4.8-11.1c-3-3.4-16-5.2-23.7-6.2s-8.7 0-10.7 1.2c-2 1.3-2.8 9.5-3.1 15-.1 1.2-.9 2.2-2.1 2.5l-.4.1c-3.3.7-6.6-1.1-7.8-4.3-4.6-13-10.7-32.5-19.4-48.4-11.5-20.8-23.5-27.4-28.5-29-4.9-1.5-9.4-2.6-43-6.1-33.8-3.6-63.1-4.1-80.5-4.1s-46.7.5-80.6 4.1c-33.6 3.4-38.1 4.5-43 6.1-5 1.6-17 8.2-28.5 29-9.4 17.1-15.7 38.3-20.4 51.3-.6 1.5-2.2 2.4-3.8 2.1-3.1-.7-5.4-3.3-5.6-6.5-.4-5-1.2-10.7-2.9-11.7-2-1.3-3-2.2-10.7-1.2s-20.6 2.8-23.7 6.2c-3 3.4-4.7 8.3-4.7 11.1s1.1 5.1 4.2 8.3c3.1 3.2 18.5 5.4 25.6 5.4l5.3 1.1c3.5.7 4.4 5.4 1.3 7.3-9.1 5.7-23.2 15.3-32.3 25.6 0 0-4.1 28.7-4.1 62.1 0 48 5.8 92.4 5.8 92.4 1.8.3 3.6.6 5.3.9 0 1.2.7 13.1 2 21.2.3 2 1.3 5.5 6.2 5.5h64.7c1.9 0 5.1-1.6 5.1-3.7l1-17c7.2.1 3.2.1 10.9 0 24.8-.3 15.6-7.5 27.1-7.3 11.3.2 55 3 96 3s84.7-2.8 96-3c11.5-.2 2.3 7.1 27.1 7.3 7.7.1 4.7.1 11.9 0l1 17c0 2.1 3.2 3.7 5.1 3.7h63.5c4.9 0 5.9-3.5 6.2-5.5 1.3-8.1 1.9-19.9 2-21.2l5.4-.9s5.8-44.3 5.8-92.4c0-33.5-4.1-62.1-4.1-62.1-9.3-10.5-23.4-20.1-32.5-25.8zm-320.2-53.6c2.2-5.1 5.9-11.6 10-17.2 5-6.7 12.4-11.2 20.6-12.5 16.7-2.7 52.6-7.3 101.9-7.3 49.3 0 85.2 4.6 101.9 7.3 8.2 1.3 15.6 5.8 20.6 12.5 4.2 5.6 7.9 12.1 10.1 17.2 3.9 9.2 10.4 30.7 9.4 33.2-1 2.5 1 3.7-12.2 2.6-13.1-1-90.6-2.1-129.7-2.1-39.2 0-116.7 1.1-129.7 2.1-13.2 1.1-11.3-.2-12.2-2.6s5.4-24 9.3-33.2zm8.4 116c-9.9 0-29.8-1-34.5-1.2-4.7-.1-8.8 3.8-11.2 3.8s-25.5-3.6-28-14.9c-1.7-7.5-1.1-15.2-.6-19.5.3-1.9 1.9-3.4 3.8-3.5 14.4-.5 29.2.5 55.3 7.9 17.3 4.9 29.8 12.6 36.9 17.8 2.8 2.1 1.8 6.5-1.7 7.2-6.1 1.1-14.4 2.4-20 2.4zm210.4 73c-12.7 1.7-58.5 2.2-86.2 2.2s-73.5-.5-86.2-2.2c-13.1-1.7-29.8-17.3-18.4-30.2 7.6-8.5 20.8-13.6 48.9-17.3 29.8-3.8 48.6-4.3 55.6-4.3s25.8.5 55.6 4.3c28.1 3.7 43.2 9.6 48.9 17.3 10.4 13.8-5.1 28.4-18.2 30.2zm111.7-85.2c-2.5 11.2-25.6 14.9-28 14.9s-6.5-3.9-11.2-3.8c-4.7.2-24.6 1.2-34.5 1.2-5.5 0-13.8-1.3-20-2.4-3.5-.6-4.5-5.1-1.7-7.2 7.1-5.2 19.6-12.9 36.9-17.8 26.1-7.4 40.8-8.4 55.3-7.9 2 .1 3.6 1.5 3.8 3.5.5 4.3 1.1 12-.6 19.5z"/></svg>
                                                Model
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 32C132.3 32 32 132.3 32 256c0 91.7 55.2 170.5 134.1 205.2-.6-15.6-.1-34.4 3.9-51.4 4.3-18.2 28.8-122.1 28.8-122.1s-7.2-14.3-7.2-35.4c0-33.2 19.2-58 43.2-58 20.4 0 30.2 15.3 30.2 33.6 0 20.5-13.1 51.1-19.8 79.5-5.6 23.8 11.9 43.1 35.4 43.1 42.4 0 71-54.5 71-119.1 0-49.1-33.1-85.8-93.2-85.8-67.9 0-110.3 50.7-110.3 107.3 0 19.5 5.8 33.3 14.8 43.9 4.1 4.9 4.7 6.9 3.2 12.5-1.1 4.1-3.5 14-4.6 18-1.5 5.7-6.1 7.7-11.2 5.6-31.3-12.8-45.9-47-45.9-85.6 0-63.6 53.7-139.9 160.1-139.9 85.5 0 141.8 61.9 141.8 128.3 0 87.9-48.9 153.5-120.9 153.5-24.2 0-46.9-13.1-54.7-27.9 0 0-13 51.6-15.8 61.6-4.7 17.3-14 34.5-22.5 48 20.1 5.9 41.4 9.2 63.5 9.2 123.7 0 224-100.3 224-224C480 132.3 379.7 32 256 32z"/></svg>
                                                Pinterest
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M392.3 96h-77.9L160.8 348.6 109.9 256l87.7-160h-77.9L32 256l87.7 160h77.9l153.7-252.6 50.8 92.6-87.7 160h77.9L480 256 392.3 96z"/></svg>
                                                Polymer
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M511.784 329.108c-1.67-13.599-9.236-24.146-20.795-32.416 2.857 2.04 5.275 3.766-.055-.041-7.189-5.131-3.38-2.411-.047-.032-28.5-20.301-65.676-15.789-96.733-4.511-12.447-20.295-12.987-35.783-5.816-57.937.929-2.8.295-4.354-2.624-5.604-7.086-3.03-17.291-1.427-24.422.463-2.462.646-4.254 1.9-4.8 4.381-5.154 24.243-21.009 46.448-34.828 66.886-9.731-18.652-8.96-33.087-2.414-52.516.798-2.366.431-3.624-1.937-4.879-7.26-3.757-18.401-1.912-25.8.276-8.509 2.482-21.29 44.594-25.372 52.946-8.531 17.442-16.091 44.665-30.585 58.502-12.3-15.807 22.526-51.517 10.882-65.851-3.938-4.848-11.063-4.723-15.586-.616 1.085-7.608 1.648-12.609-.32-19.063-2.081-6.79-7.361-10.687-15.09-10.49-17.995.527-33.843 13.815-44.641 26.397-10.277 12.105-37.381 19.627-51.953 26.927-25.032-21.807-79.221-44.947-80.632-82.081-1.528-41.846 48.319-70.245 81.597-87.228 43.28-22.104 109.961-49.608 159.138-25.436 13.049 6.414 18.299 20.171 14.707 33.348-9.368 34.366-47.198 57.293-80.103 67.807-16.189 5.175-33.969 9.027-51.1 8.026-22.955-1.343-40.83-15.224-43.281-16.086-2.049-.389-1.888 2.261-1.347 3.664 23.816 62.433 144.417 16.681 175.956-15.371 15.189-15.421 24.413-30.365 28.351-53.894 4.616-27.583-15.634-44.842-31.004-51.957-77.918-36.072-185.636 11.168-244.553 59.327-25.568 20.901-57.552 54.11-42.874 88.946 15.93 37.805 64.736 57.19 96.503 80.312-25.704 12.773-57.862 25.983-74.518 49.933-9.524 13.729-12.903 28.359-5.811 43.966 12.572 27.568 58.285 15.622 77.573 3.471 17.67-11.13 29.563-26.07 34.7-45.228 4.455-16.609 3.541-33.866-3.856-49.512l28.585-14.458c-7.697 23.076-11.097 52.003 4.881 72.855 6.402 8.338 23.017 8.675 29.817.311 8.816-10.943 14.664-24.655 20.503-37.206-.682 9.373-1.856 19.996 1.377 28.165 3.71 9.373 12.126 11.291 20.792 5.343 26.52-18.203 43.398-68.652 56.463-98.062 3.552 12.829 7.473 24.548 13.957 36.376 1.602 2.903 1.407 4.774-.796 7.195-9.685 10.675-32.826 28.479-35.069 42.899-.524 3.371 1.713 6.599 5.686 7.37 15.573 3.108 32.838-2.531 45.482-11.078 13.188-8.922 17.446-21.087 14.245-35.515-4.576-20.771 10.993-43.98 25.801-61.03 2.719 12.908 6.816 25.331 14.143 36.606-13.075 11.483-32.58 27.764-29.779 46.939.988 6.865 7.135 11.301 14.514 9.736 15.783-3.324 29.416-10.113 39.37-22.146 9.023-10.855 5.792-22.701 1.856-34.635 23.872-6.815 48.022-8.177 71.831-.027 11.495 3.91 20.755 10.5 26.248 20.818 6.726 12.644 2.939 24.292-10.05 32.604-3.287 2.104-5.562 3.833-4.45 4.743 1.112.911 4.9 2.113 13.284-3.152 8.384-5.267 13.51-12.383 14.823-21.725a37.09 37.09 0 0 0-.024-7.755zm-398.838 25.259c-1.358 16.673-9.636 30.193-23.175 41.114-7.617 6.158-17.102 11.176-26.52 12.092-9.418.917-16.751-1.461-17.378-11.23-1.764-27.493 40.923-54.424 64.625-62.533 2.02 6.86 3.011 13.666 2.432 20.587l.016-.03zm103.102-72.453c-3.903 22.309-14.83 62.347-32.314 78.336-2.356 2.143-4.61 2.018-5.809-.771-10.345-24.059 3.671-73.669 33.082-81.328 3.457-.889 5.602.582 5.041 3.763zm70.311 81.768c8.422-8.962 16.834-17.916 25.269-26.927 1.043 10.021-17.571 29.964-25.269 26.927zm80.714-17.696c-2.348 1.273-7.621 2.515-7.827.835-1.482-12.085 11.816-24.874 20.067-30.867 4.453 11.343-.818 23.834-12.24 30.032z"/></svg>
                                                Sass
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M436.9 296.8c2.8-12.5 4.2-25.4 4.2-38.7 0-99.7-82-180.6-183.2-180.6-10.7 0-21.1.9-31.3 2.6C210.3 69.9 191 64 170.2 64 111.6 64 64 110.9 64 168.7c0 19.4 5.3 37.5 14.6 53-2.4 11.7-3.7 23.9-3.7 36.3 0 99.8 82 180.6 183.1 180.6 11.5 0 22.7-1 33.5-3 15 7.9 32.1 12.4 50.2 12.4 58.7 0 106.2-46.9 106.2-104.7.1-16.7-3.9-32.5-11-46.5zm-85 47.5c-8.5 11.8-21 21.2-37.2 27.8-16.1 6.6-35.3 9.9-57.3 9.9-26.3 0-48.3-4.6-65.6-13.6-12.3-6.6-22.4-15.4-30.2-26.4-7.8-11-11.7-22-11.7-32.6 0-6.6 2.6-12.3 7.6-17.1 5-4.6 11.5-7 19.1-7 6.3 0 11.7 1.8 16.1 5.5 4.2 3.5 7.8 8.7 10.7 15.5 3.3 7.3 6.8 13.5 10.6 18.4 3.6 4.7 8.7 8.6 15.3 11.7 6.7 3.1 15.6 4.7 26.6 4.7 15.1 0 27.5-3.2 36.8-9.5 9.2-6.1 13.6-13.5 13.6-22.5 0-7.1-2.3-12.7-7.1-17.1-5-4.6-11.5-8.2-19.6-10.6-8.3-2.6-19.6-5.3-33.6-8.2-19-4-35.1-8.8-48-14.2-13.1-5.5-23.7-13.2-31.5-22.7-7.9-9.7-11.8-21.9-11.8-36.2 0-13.7 4.2-25.9 12.4-36.5 8.2-10.5 20.1-18.7 35.6-24.3 15.2-5.6 33.3-8.4 53.7-8.4 16.4 0 30.7 1.9 42.7 5.5 12.1 3.7 22.2 8.7 30.3 14.9 8 6.2 14 12.8 17.8 19.7 3.8 7 5.7 13.9 5.7 20.6 0 6.4-2.5 12.3-7.5 17.4-5 5.1-11.3 7.8-18.8 7.8-6.8 0-12.1-1.6-15.8-4.8-3.4-3-7-7.6-10.9-14.3-4.6-8.5-10.1-15.3-16.4-20.1-6.2-4.6-16.4-7-30.6-7-13.1 0-23.8 2.6-31.7 7.7-7.6 4.9-11.3 10.6-11.3 17.3 0 4.1 1.2 7.5 3.7 10.5 2.6 3.1 6.2 5.9 10.9 8.2 4.8 2.4 9.8 4.3 14.7 5.6 5.1 1.4 13.6 3.5 25.3 6.1 14.9 3.1 28.5 6.7 40.5 10.4 12.2 3.9 22.7 8.6 31.3 14.1 8.8 5.6 15.7 12.9 20.7 21.5 4.9 8.6 7.4 19.4 7.4 31.8.4 15.1-3.9 28.7-12.5 40.5z"/></svg>
                                                Skype
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M495.998 360.389l-.189-14.501-14.398-1.278c-15.413-1.396-43.8-7.219-54.301-16.9-16.281-15.011-35.688-36.199-35.688-51.893 0-1.014 0-2.546 4.15-5.186 4.985-3.174 12.589-5.584 19.297-7.71 5.217-1.654 10.144-3.217 14.394-5.236 9.236-4.39 18.498-15.978 17.471-28.807-1.215-15.166-14.424-27.046-30.072-27.046-4.021 0-8.068.76-12.027 2.259-8.027 3.041-13.743 4.41-17.705 4.962.747-9.319 1.791-20.12 3.211-30.67 5.111-37.948-5.281-73.509-29.264-101.042C335.498 48.208 297.376 32 256.283 32H256c-41.093 0-79.215 16.208-104.591 45.341-23.982 27.534-34.375 63.345-29.265 101.292 1.416 10.51 2.46 21.231 3.21 30.618-3.97-.559-9.686-1.998-17.703-5.034-3.965-1.502-8.017-2.295-12.043-2.295-15.641-.001-28.844 11.852-30.057 27.003-1.027 12.818 8.235 24.393 17.47 28.783 4.251 2.02 9.181 3.578 14.4 5.232 6.707 2.125 14.309 4.532 19.293 7.703 4.147 2.639 4.147 4.168 4.147 5.182 0 8.66-6.191 24.691-35.688 51.888-10.499 9.681-39.055 15.501-54.588 16.897l-14.572 1.311L16 360.603c0 1.679.312 10.546 6.485 20.319 5.246 8.306 16.073 19.283 37.863 24.407a1139.713 1139.713 0 0 0 15.208 3.454c2.306.512 4.555 1.01 6.454 1.453l.081.623c.9 7.004 1.611 12.535 4.392 17.75 2.453 4.6 8.574 12.316 22.015 12.316 2.478 0 5.249-.246 8.472-.751 1.672-.263 3.386-.554 5.2-.863 7.116-1.212 15.182-2.587 23.451-2.587 10.277 0 18.732 2.188 25.846 6.688 4.531 2.867 8.892 5.972 13.509 9.26C202.967 465.481 223.358 480 256 480c32.726 0 53.293-14.582 71.439-27.446 4.576-3.244 8.898-6.309 13.377-9.142 7.113-4.5 15.568-6.688 25.846-6.688 8.27 0 16.334 1.375 23.449 2.586 1.814.311 3.529.602 5.202.864 3.223.505 5.993.751 8.472.751 13.44 0 19.562-7.715 22.015-12.313 2.781-5.214 3.492-10.746 4.392-17.749l.082-.629c1.898-.441 4.148-.941 6.455-1.452 4.023-.892 9.029-2.001 15.206-3.454 21.851-5.139 32.611-16.17 37.79-24.518 6.097-9.828 6.296-18.736 6.273-20.421zM208 128c8.836 0 16 10.745 16 24s-7.164 24-16 24-16-10.745-16-24 7.164-24 16-24zm103.615 77.698C296.368 220.725 276.617 229 256 229c-20.838 0-40.604-8.29-55.657-23.343a8 8 0 1 1 11.313-11.313C223.688 206.374 239.436 213 256 213c16.387 0 32.15-6.64 44.385-18.698a8 8 0 0 1 11.23 11.396zM304 176c-8.836 0-16-10.746-16-24s7.164-24 16-24 16 10.746 16 24-7.164 24-16 24z"/></svg>
                                                Snapchat
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M478.8 208.2c0 19.8-16.1 36-36 36-19.8 0-36-16.1-36-36 0-19.8 16.1-36 36-36 19.8 0 36 16.2 36 36zM442.6 139c-38.1 0-69 30.7-69.4 68.7l-43.2 62c-1.8-.2-3.6-.3-5.4-.3-9.7 0-18.7 2.7-26.4 7.3L102.4 198c-5.1-23.2-25.9-40.7-50.6-40.7C23.3 157.2 0 180.6 0 209.1s23.3 51.8 51.8 51.8c9.7 0 18.7-2.7 26.4-7.3L274 332.2c5.1 23.3 25.8 40.8 50.6 40.8 26.8 0 49-20.6 51.5-46.7l66.5-48.6c38.3 0 69.4-31 69.4-69.3S480.9 139 442.6 139zm0 22.9c25.7 0 46.5 20.9 46.5 46.5 0 25.7-20.9 46.4-46.5 46.4-25.7 0-46.5-20.8-46.5-46.4 0-25.7 20.8-46.5 46.5-46.5zm-390.8 9c14.6 0 27.3 8.2 33.7 20.2l-18.9-7.6v.1c-15.3-5.5-32.2 2-38.3 17.1-6.1 15.2.9 32.3 15.7 38.9v.1l16.1 6.4c-2.6.6-5.4.9-8.2.9-21.1 0-38.1-17-38.1-38.1-.1-20.9 16.9-38 38-38zm272.8 112.2c21.1 0 38.1 17 38.1 38.1s-17 38.1-38.1 38.1c-14.7 0-27.4-8.2-33.7-20.3 6.3 2.5 12.5 5 18.8 7.6 15.5 6.2 33.2-1.3 39.4-16.8 6.2-15.5-1.3-33.1-16.9-39.4l-15.9-6.4c2.8-.5 5.5-.9 8.3-.9z"/></svg>
                                                Steam
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M321.2 396.3c-11.8 0-22.4-2.8-31.5-8.3-6.9-4.1-11.5-9.6-14-16.4-2.6-6.9-3.6-22.3-3.6-46.4V224h96v-64h-96V48h-61.9c-2.7 21.5-7.5 44.7-14.5 58.6-7 13.9-14 25.8-25.6 35.7-11.6 9.9-25.6 17.9-41.9 23.3V224h48v140.4c0 19 2 33.5 5.9 43.5 4 10 11.1 19.5 21.4 28.4 10.3 8.9 22.8 15.7 37.3 20.5 14.6 4.8 31.4 7.2 50.4 7.2 16.7 0 30.3-1.7 44.7-5.1 14.4-3.4 30.5-9.3 48.2-17.6v-65.6c-20.9 13.7-41.8 20.6-62.9 20.6z"/></svg>
                                                Tumblr
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M426.3 396c-6.7-4-13.2-11-12-18.8 2.3-15.3 2.5-21.5-.2-25.8-1.9-3.2-5.5-5-8.6-5.8 2-2.5 3.1-5.4 3.8-10.9 1.3-10-4.7-41-12.7-65.7s-29.9-50-44.7-68c-26-31.8-22.8-39.2-26.3-99.7C323.4 62.8 306.3 32 256 32s-67 32-67 59c0 28.7 2 51 2 51 1.3 33.4 1 39.4-8 55.3-4.9 8.7-27 30-35.7 44.7s-7.6 29.5-24.6 52.8c-12.4 17-13.8 28.4-9.7 44-7 8.2-3.6 19.9-5 24.9-2.6 8.7-13.7 10.3-22.3 11s-15.3 0-18.7 5.3.7 16 4.3 30-7.3 15-7.3 31 30 16 59.7 22.7 40.7 16.3 56 16.3 26.8-10.2 38-19.3c7.2-5.9 29-3.7 42.3-3.7s34.3-.6 45.7 2.4S317 480 345 480s34.7-20.7 61-34.3 42-20 42-29.7-15-16-21.7-20zm-226.5 55.5c-1.3 13-12.6 17.1-24.1 16.1-13-1.1-29-7.6-44.1-12.1s-35.5-7.5-49-9.9c-15.3-2.7 0-13.6-.2-34.2-.1-8-7.1-19.4-4.2-24.7s17.3-2.4 22.3-3.8 12.7-5.7 15.3-11.9c1.4-3.4 1.8-17.7 2.9-22.8 1.1-4.9 7.9-7.2 22.2.1s28.9 38.1 42.3 59.8 17.9 30.4 16.6 43.4zm118.5-65.8c2 10.3 3.2 24.5.7 36.3s-7 15.5-10.7 23c-2.2-6.8 5.3-13.8 4.4-30.8-.5-9.5-.8-7.8-11.5 1.8-12.2 10.8-27.6 20.1-53 22.5-21 2-32.5-8.3-32.5-8.3 5 16-4.3 24.7-4.3 24.7.3-3.7.8-14.3-2.5-21.6-4-9-9.3-18.7-9.3-18.7s8.6-2.7 11.6-10 2-17.3-8.7-27.7-52.5-37.6-55.9-42.1c-4.9-6.5-6.7-10.2-7-23.2s5.4-24.8 4.3-20.3c-.8 3.2.1 6.8.1 19.8s7.6 23.3 13.9 25c9.5 2.6 2-26.1 8-53.1s11.7-32.8 19.2-43.8 19.2-20.5 17-43.1-.1-20.1 5.1-11.8c4 6.5 13.3 24 24.7 22 19.4-3.3 43.9-24.6 47.6-28.2 3.7-3.6.7-7.1-2.3-5.8-15.5 6.7-44.3 21.5-51.5 18.2s-18.1-20.6-16.8-19.5c15.4 13.6 19.9 11.1 26.4 9 8.4-2.8 12.8-4.3 28.5-11.3s20.7-5.3 22.3-8.7-.4-6.7-4.7-5.7c-6.4 1.5-3.4 5.1-22.7 12.3-25.3 9.5-33.3 10.3-44 3-8.6-5.9-15-12.7-15-16.7s8.3-8.3 12.3-11.3 12.3-10.9 12.3-10.9 1-7.2-.6-12.7c-1.9-6.5-7.8-9.3-11.9-8.1-4.1 1.1-8 5.5-6.8 14.8 1 8.3 7 11 7 11s-2.7 3.5-5.2 4.7c0 0-.8-.3-3.5-6.3s-6.6-19.5-.3-31.1 19.6-5.2 23.8 3.8c3.9 8.3 2.4 22.7 2.4 22.7 6-2.2 13-2 21 3.5-7.1-29.8 9.5-41.1 22-41.1s22.3 9.6 22.3 25c0 12-3.5 18.2-6.9 22-4.1-.5-8.2-1.5-6.3-3.4 1.3-1.4 4.4-5.7 4.4-13.2s-5.9-13.7-13.7-13.7c-9.2 0-12.6 8.3-13.7 13s-.4 8.6-.2 10.4c.6 5 10.9 9.6 23.9 12.9s11.3 9 8.3 25.3 6.3 18.3 14.3 33.8 5.7 21.8 15.9 35.2 19 47.8 16.4 76.8c-.9 10.5-3.9 10.2 7.3 6.7 5.6-1.7 12-2.7 12-2.7 3.1-6.3 3.4-16.3 3.5-22.3.2-13.5.7-41.5-26.7-71.5 0 0 29.5 21.7 34 62 2.5 22.3-2 32.4-2 32.4 5.3 1.3 9.8 7.3 12.6 11.8 3.7 6.1-3.9-5.8-20-5.8-8.5 0-15.3 3.9-18.5 7.9s-3.1 7.6-3.2 11.7c-7.1-1.2-12.4 0-16.8 4.9-5.6 7-2.8 24.2-.8 34.6zm90.1 47.2c-24.1 10.4-32.7 23.5-47.7 31.5s-27.7 2.3-33.7-8 10.4-28.2 4.7-59.6c-4.4-24.2-6.3-31-4.9-36.8 1.4-5.5 9.4-4.4 11.5-3.9 1.3 5.4 6.7 19.5 27 19.5 0 0 23.2 2.6 32.7-21.2 0 0 5.7-.2 7.2 3.5 2.3 5.8-2.9 16.5-2.8 21.3.3 15.7 11.7 21.1 28.4 32 8.2 5.6 2.1 11.1-22.4 21.7z"/></svg>
                                                Tux
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M492 109.5c-17.4 7.7-36 12.9-55.6 15.3 20-12 35.4-31 42.6-53.6-18.7 11.1-39.4 19.2-61.5 23.5C399.8 75.8 374.6 64 346.8 64c-53.5 0-96.8 43.4-96.8 96.9 0 7.6.8 15 2.5 22.1-80.5-4-151.9-42.6-199.6-101.3-8.3 14.3-13.1 31-13.1 48.7 0 33.6 17.2 63.3 43.2 80.7-16-.4-31-4.8-44-12.1v1.2c0 47 33.4 86.1 77.7 95-8.1 2.2-16.7 3.4-25.5 3.4-6.2 0-12.3-.6-18.2-1.8 12.3 38.5 48.1 66.5 90.5 67.3-33.1 26-74.9 41.5-120.3 41.5-7.8 0-15.5-.5-23.1-1.4C62.8 432 113.7 448 168.3 448 346.6 448 444 300.3 444 172.2c0-4.2-.1-8.4-.3-12.5C462.6 146 479 129 492 109.5z"/></svg>
                                                Twitter
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M411.387 303.256c-3.119-9.577-7.891-18.561-14.301-26.952-6.422-8.382-14.396-15.826-23.93-22.331-9.539-6.498-20.721-11.63-33.553-15.4-5.143-1.363-14.189-3.506-26.104-6.418-8.516-2.074-16.5-4.2-25.5-6.367V120.065c9 2.396 15.252 6.202 21.926 10.43C324.204 139.535 333.157 155 335.78 176h69.174c-.654-18-4.65-32.76-11.996-46.02-8.07-14.543-18.977-27.024-32.73-36.956-13.75-9.922-30.225-17.49-48.377-22.455C303.967 68.416 297 66.605 288 65.386V32h-64v33.167c-7 1.044-15.148 2.445-22.426 4.25-17.242 4.283-32.388 10.868-45.951 19.764-13.571 8.905-24.352 20.112-32.604 33.627-8.251 13.523-12.312 29.52-12.312 48 0 9.585 1.407 18.993 4.157 28.235 2.752 9.241 7.442 17.967 14.042 26.181 6.603 8.214 15.495 15.658 26.687 22.332 11.183 6.672 24.705 12.064 41.576 16.171 9.287 2.345 18.83 4.534 26.83 6.576v119.586c-11-2.919-21.889-7.399-30.678-13.479-9.17-6.327-16.066-13.953-21.198-23.884-4.779-9.229-7.073-20.526-7.407-32.526H96c.695 21 5.25 39.494 13.672 55.371 8.799 16.604 20.533 29.96 35.204 40.562 14.662 10.613 31.393 18.356 51.198 23.491 8.885 2.304 18.926 3.96 27.926 5.23V480h64v-34.54c10-1.069 18.957-2.69 28.527-4.879 18.701-4.273 35.645-11.036 50.316-20.276 14.662-9.24 26.621-21.128 35.611-35.681 8.98-14.541 13.545-32.085 13.545-52.619.001-9.578-1.501-19.164-4.612-28.749zM224 209.699c-12-3.743-23.912-9.088-32.051-16.048-8.621-7.355-12.673-17.534-12.673-30.545 0-9.241 2.414-16.94 7.004-23.102 4.58-6.161 9.912-11.038 16.88-14.631 6.18-3.189 13.84-5.565 20.84-7.138v91.464zm118.902 149.772c-2.939 6.673-7.699 12.576-14.303 17.711-6.602 5.133-15.744 9.328-26.377 12.577-4.5 1.378-8.223 2.444-14.223 3.236v-107.11c10 2.624 18.18 5.332 26.326 8.131 8.062 2.744 15.748 7.443 22.537 14.116 6.785 6.676 10.309 17.03 10.309 31.06.001 6.85-1.337 13.605-4.269 20.279z"/></svg>
                                                USD
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M476.9 114c-5-23.4-17.5-38.8-40.6-46.3s-64.9-4.5-94.1 16.8c-29.9 21.8-47.6 59.7-53.8 83.8 14.7-6.3 24-7.7 39-6.9s24.5 12 24.9 25.3c.3 9.8-.2 18.7-3.6 27.7-10.8 28.7-27.7 56.5-47.6 80.8-2.9 3.6-6.4 6.9-10 9.9-10.2 8.3-18.8 6.1-25.4-5.2-5.4-9.3-9-18.9-12.2-29.1-12.4-39.7-16.8-80.9-23.8-121.6-3.3-19.5-7-39.8-18-56.9-11.6-17.8-28.6-24.6-50-22-14.7 1.8-36.9 17.5-47.8 26.4 0 0-56 46.9-81.8 71.4l21.2 27s17.9-12.5 27.5-18.3c5.7-3.4 12.4-4.1 17.2.2 4.5 3.9 9.6 9 12.3 14.1 5.7 10.7 11.2 21.9 14.7 33.4 13.2 44.3 25.5 88.7 37.8 133.3 6.3 22.8 13.9 44.2 28 63.6 19.3 26.6 39.6 32.7 70.9 21.5 25.4-9.1 46.6-26.2 66-43.9 33.1-30.2 59.1-65.4 85.5-101.2 20.4-27.7 37.3-55.7 51.4-87 13.9-31 19.4-63.5 12.3-96.8z"/></svg>
                                                Vimeo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M427 299.1c-8.6-8-15.7-12.8-18.5-20.5-1-2.7-1.3-4.3-1-7.6.4-6 5.5-13.8 39.6-58.9 14.2-18.8 32.7-41.5 32.7-58.5 0-11-4.5-13.7-20.8-13.7h-74c-6.5 0-10.9 8.9-13.6 16.4-2.8 7.5-8.2 19-21.4 43.8-13.8 26-32.3 48.8-40 52.4-2.2 1-3.6 1-5.5.8-1.2-.1-3.8-.8-6.2-3.7-2.3-2.8-5.9-7.7-4.5-53.9.8-25.8 3.7-43.8-1.7-54.8-1.1-2.2-3.5-4.5-4.8-5.5-7.7-5.5-29.4-7.5-48-7.5s-32.9 2.1-40 4.2c-7.1 2.1-15.1 6.9-18.9 12-2.5 3.3 4.3 1.6 10.9 4.6 4 1.8 9.3 4.6 11.2 9.3 8 20.8 9.7 37.3 5.3 66.7-1.1 7.2-2.3 18.5-6.6 25.5-2.4 3.9-7.9 3.6-9.5 3.1-16.1-4.9-28.6-26-41.2-50.7-13.1-25.8-19.8-43.9-23.4-51.3s-9.1-11.4-18.4-11.4H42.3c-5.2 0-9.9 4.3-9.9 9 0 11 18.6 43 29.8 66 20.2 41.4 46.7 81.4 82.4 120.2C182 376.3 233 384 249.3 384s29-.6 33.3-1.5c2-.4 4.1-1.3 5.7-2.5 7.1-5.5 5.8-16 6.3-24.2.5-8.4 1.4-19.5 7-26 5.2-6.1 11.1-7.8 18.6-4.1 7 3.5 12 9.4 17.2 15.1 10.1 10.9 19.3 23.2 31.3 32.2 5.5 4.1 11.5 6.7 17.9 8.7 8.5 2.6 16.5 2.7 25.3 2.3 9.7-.4 17-.3 29-.3s27.7.5 33.1-3.5c2.6-2 6-5 6-11.3 0-11.9-12.2-31.7-53-69.8z"/></svg>
                                                VK
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M260.062 32C138.605 32 40.134 129.701 40.134 250.232c0 41.23 11.532 79.79 31.559 112.687L32 480l121.764-38.682c31.508 17.285 67.745 27.146 106.298 27.146C381.535 468.464 480 370.749 480 250.232 480 129.701 381.535 32 260.062 32zm109.362 301.11c-5.174 12.827-28.574 24.533-38.899 25.072-10.314.547-10.608 7.994-66.84-16.434-56.225-24.434-90.052-83.844-92.719-87.67-2.669-3.812-21.78-31.047-20.749-58.455 1.038-27.413 16.047-40.346 21.404-45.725 5.351-5.387 11.486-6.352 15.232-6.413 4.428-.072 7.296-.132 10.573-.011 3.274.124 8.192-.685 12.45 10.639 4.256 11.323 14.443 39.153 15.746 41.989 1.302 2.839 2.108 6.126.102 9.771-2.012 3.653-3.042 5.935-5.961 9.083-2.935 3.148-6.174 7.042-8.792 9.449-2.92 2.665-5.97 5.572-2.9 11.269 3.068 5.693 13.653 24.356 29.779 39.736 20.725 19.771 38.598 26.329 44.098 29.317 5.515 3.004 8.806 2.67 12.226-.929 3.404-3.599 14.639-15.746 18.596-21.169 3.955-5.438 7.661-4.373 12.742-2.329 5.078 2.052 32.157 16.556 37.673 19.551 5.51 2.989 9.193 4.529 10.51 6.9 1.317 2.38.901 13.531-4.271 26.359z"/></svg>
                                                Whatsapp
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 265H232v179l248 36V265zM216 265H32v150l184 26.7V265zM480 32L232 67.4V249h248V32zM216 69.7L32 96v153h184V69.7z"/></svg>
                                                Windows
                                            </div>

                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M126.8 248.3c39.7-58.6 77.9-92.8 77.9-92.8s-42.1-48.9-92.8-67.4l-3.3-.8C61.7 128.4 32 188.7 32 256c0 50.7 16.9 97.5 45.2 135 0-4.4.6-70.3 49.6-142.7zM480 256c0-67.3-29.7-127.6-76.6-168.7l-3.2.9c-50.7 18.5-92.9 67.4-92.9 67.4s38.2 34.2 77.9 92.8c49 72.4 49.6 138.3 49.5 142.7C463.2 353.5 480 306.7 480 256zM201.2 80.9c29.3 13.1 54.6 34.6 54.6 34.6s25.5-21.4 54.8-34.6c36.8-16.5 64.9-11.3 72.3-9.5C346.8 46.6 303.1 32 256 32s-90.8 14.6-126.9 39.4c7.2-1.8 35.2-7.1 72.1 9.5zM358.7 292.9C312.4 236 255.8 199 255.8 199s-56.3 37-102.7 93.9c-39.8 48.9-54.6 84.8-62.6 107.8l-1.3 4.8c41 45.7 100.5 74.5 166.8 74.5s125.8-28.8 166.8-74.5l-1.4-4.8c-8-23-22.9-58.9-62.7-107.8z"/></svg>
                                                Xbox
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M313.8 303.9L469 32H365L209.4 303.8c-.4.7-.4 1.1 0 1.7l98.9 173.8c.4.7.8.7 1.6.7H413l-99.3-174.7c-.2-.3-.1-1 .1-1.4zM221.9 216.2L163 113c-.5-.8-1-1-2-1H65l58.9 104.4c.1.2.2.6.1.8L43 352h96.8c.8 0 1.2-.2 1.6-.9l80.5-133.7c.1-.3.1-.9 0-1.2z"/></svg>
                                                Xing
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M384.6 68.4c-11.3 0-22.5-.8-32.6-4.4l-96 160-96-160c-10.1 3.6-20.7 4.4-32 4.4-11.1 0-22.1-.9-32-4.4l128 212.7V448c10-3.5 20.8-4.4 32-4.4s22 .9 32 4.4V277L416 64c-9.9 3.4-20.3 4.4-31.4 4.4z"/></svg>
                                                Yahoo
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M448 32h-80L256 253.128 144 32H64l112.368 208H128v48h73.564L216 319v17h-88v48h88v96h80v-96h88v-48h-88v-17l14.891-31H384v-48h-48.289L448 32z"/></svg>
                                                Yen
                                            </div>
                                            <div class="col-sm-6 col-md-4 col-xl-3">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M508.6 148.8c0-45-33.1-81.2-74-81.2C379.2 65 322.7 64 265 64h-18c-57.6 0-114.2 1-169.6 3.6C36.6 67.6 3.5 104 3.5 149 1 184.6-.1 220.2 0 255.8c-.1 35.6 1 71.2 3.4 106.9 0 45 33.1 81.5 73.9 81.5 58.2 2.7 117.9 3.9 178.6 3.8 60.8.2 120.3-1 178.6-3.8 40.9 0 74-36.5 74-81.5 2.4-35.7 3.5-71.3 3.4-107 .2-35.6-.9-71.2-3.3-106.9zM207 353.9V157.4l145 98.2-145 98.3z"/></svg>
                                                Youtube
                                            </div>
                                        </div>
                                    </div> <!-- card-body-->
                                </div><!--end card-->
                            </div> <!-- end col -->
                        </div> <!-- end row -->

                    </div><!-- container -->


<?php
include('footer.php');
?>