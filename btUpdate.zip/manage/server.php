<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include('header.php');

//服务器列表
$numrows=$DB->query("SELECT * from `wcms_server` WHERE 1")->rowCount();
$list=$DB->query("SELECT * FROM `wcms_server` WHERE 1 order by `sid` asc")->fetchAll();
//添加、修改服务器
$sid = intval(daddslashes($_GET['sid']));
$type = daddslashes($_GET['type']);

if ($type == 'edit' && $sid) {
    $row = $DB->query("SELECT * from `wcms_server` WHERE `sid`={$sid} limit 1")->fetch();
    $title = '修改服务器';
    $result = 1; //修改用户
} else if ($type == 'add') {
    $title = '添加服务器';
    $result = 2; //添加服务器
} else {
    $result = 3; //服务器列表
}
?>

<?php if ($result == 3){ ?>
<!-- Page Content-->
<div class="page-content">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="float-right">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                            <li class="breadcrumb-item active">服务器列表</li>
                        </ol>
                    </div>
                    <h4 class="page-title">管理模块</h4>
                </div><!--end page-title-box-->
            </div><!--end col-->
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">服务器列表</h4>
                        <p class="text-muted mb-4 font-13">
                            Available my sites.
                            <a href="server.php?type=add" class="btn m-b-xs btn-sm btn-primary btn-addon">
                                <i class="fa fa-edit"></i>添加服务器
                            </a>
                        </p>
                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>编号</th>
                                <th>服务器名称</th>
                                <th>宝塔管理地址</th>
                                <th>默认域名</th>
                                <th>是否启用</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($list as $res) {
                                if($res['active']==1){
                                    $serveractive="<span style='color:green;'>启用中</span>";
                                }elseif($res['active']==0){
                                    $serveractive="<span style='color:red;'>暂停中</span>";
                                }
                                  echo '
                                    <tr id="' . $res['sid'] . '">
                                        <td>' . $res['sid'] . '</td>
                                        <td>' . $res['sname'] . '</td>
                                        <td>' . $res['api'] . '</td>
                                        <td>' . $res['domain'] . '</td>
                                        <td>' . $serveractive . '</td>
                                        <td>
                                        <a  href="#" onclick="checkServer(' . $res['sid'] . ')" class="btn m-b-xs btn-sm btn-success btn-addon" >检测状态</a>
                                          <a href="server.php?type=edit&sid=' . $res['sid'] . '" class="btn m-b-xs btn-sm btn-primary btn-addon" >修改</a>
                                          <a href="#" onclick="delServer(' . $res['sid'] . ')" class="btn m-b-xs btn-sm btn-danger btn-addon" >删除</a>
                                        </td>
                                    </tr>   
                                 ';
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div><!-- container -->

    <?php } else if ($result == 2){ ?>
    <!-- Page Content-->
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="float-right">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                <li class="breadcrumb-item active"><?php echo $title ?></li>
                            </ol>
                        </div>
                        <h4 class="page-title">管理模块</h4>
                    </div><!--end page-title-box-->
                </div><!--end col-->
            </div>
            <!-- end page title end breadcrumb -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                            <p class="text-muted mb-3">userAdd.
                            </p>
                            <form action="#" method="post">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">服务器名称</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="sname">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">宝塔面板管理地址</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="api" placeholder="例如: 192.168.1.1:8888">
                                                <pre ><font color="#006400">不需要带http:// 且端口号后面字符也不需要带</font></pre>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">宝塔API密钥</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="pass" placeholder="宝塔面板->面板设置中查看">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">绑定域名</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="domain" placeholder="泛解析到服务器IP">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-text-input"
                                                   class="col-sm-2 col-form-label text-left">网站存放路径</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="text" name="sitepath">
                                                <pre><font color="#006400">默认请填写/www/wwwroot/</font></pre>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label text-left">是否启用</label>
                                            <div class="col-sm-10">
                                                <select class="custom-select" id="active">
                                                    <option value="1">启用</option>
                                                    <option value="0">禁用</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end card-body-->
                                <div class="row">
                                    <div class="col-sm-10 ml-auto">
                                        <button type="button" class="btn btn-primary" id="addServer">保存数据</button>
                                    </div>
                                </div>
                            </form>
                        </div><!--end card-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end row-->
        </div><!-- container -->
        <?php } else if ($result == 1){ ?>
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="float-right">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0);">管理模块</a></li>
                                    <li class="breadcrumb-item active"><?php echo $title ?></li>
                                </ol>
                            </div>
                            <h4 class="page-title">管理模块</h4>
                        </div><!--end page-title-box-->
                    </div><!--end col-->
                </div>
                <!-- end page title end breadcrumb -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="mt-0 header-title"><?php echo $title ?></h4>
                                <p class="text-muted mb-3">userEdit.
                                </p>
                                <form action="#" method="post">
                                    <input class="form-control" type="hidden" name="sid" value="<?php echo $row['sid']?>">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">服务器名称</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="sname" value="<?php echo $row['sname']?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">宝塔面板管理地址</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="api" value="<?php echo $row['api']?>">
                                                    <pre ><font color="#006400">不需要带http://</font></pre>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">宝塔API密钥</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="pass" value="<?php echo $row['pass']?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">绑定域名</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="domain" value="<?php echo $row['domain']?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-text-input"
                                                       class="col-sm-2 col-form-label text-left">网站存放路径</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="sitepath" value="<?php echo $row['sitepath']?>">
                                                    <pre><font color="#006400">默认请填写:/www/wwwroot/</font></pre>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label text-left">是否启用</label>
                                                <div class="col-sm-10">
                                                    <select class="custom-select" id="active">
                                                        <?php if ($row['active'] == 0) { ?>
                                                            <option value="0" >禁用</option>
                                                            <option value="1">启用</option>
                                                        <?php } else { ?>
                                                            <option value="1">启用</option>
                                                            <option value="0">禁用</option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!--end card-body-->
                                    <div class="row">
                                        <div class="col-sm-10 ml-auto">
                                            <button type="button" class="btn btn-primary" id="editServer">保存数据</button>
                                        </div>
                                    </div>
                                </form>
                            </div><!--end card-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end row-->
            </div><!-- container -->
            <?php } ?>

            <?php
            include('footer.php');
            ?>
            <script>
                function delServer(sid) {
                    layer.confirm('确认删除 ' + sid + ' 吗?', {
                        btn: ['是', '否'], btn1: function () {
                            $.ajax({
                                url: './ajax.php?act=delServer',
                                type: 'POST',
                                dataType: 'json',
                                data: { sid: sid },
                                success: function (data) {
                                    if (data.code == 1) {
                                        layer.msg(data.msg, { icon: 1, time: 2000, shade: 0.4 }, function () {
                                            var del="#"+sid;
                                            $(del).remove();
                                        });
                                    } else {
                                        layer.msg(data.msg, { icon: 2, time: 2000, shade: 0.4 });
                                    }
                                },
                                error:function () {
                                    layer.alert("网络连接错误");
                                }
                            });
                        }
                    });
                }

                $("#editServer").click(function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: 'ajax.php?act=editServer',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            sid: $("input[name='sid']").val(),
                            sname: $("input[name='sname']").val(),
                            api: $("input[name='api']").val(),
                            pass: $("input[name='pass']").val(),
                            domain: $("input[name='domain']").val(),
                            sitepath: $("input[name='sitepath']").val(),
                            active: $("#active").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, { icon: 1, time: 1000, shade: 0.4 }, function () {
                                    location.href = data.url;
                                });
                            }else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error:function () {
                            layer.alert("网络连接错误");
                        }
                    })
                })


                $("#addServer").click(function () {
                    var ii = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 15000});
                    $.ajax({
                        url: 'ajax.php?act=addServer',
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            sname: $("input[name='sname']").val(),
                            port: $("input[name='port']").val(),
                            api: $("input[name='api']").val(),
                            pass: $("input[name='pass']").val(),
                            domain: $("input[name='domain']").val(),
                            sitepath: $("input[name='sitepath']").val(),
                            active: $("#active").val()
                        },
                        success: function (data) {
                            layer.close(ii);
                            if(data.code == 1) {
                                layer.msg(data.msg, { icon: 1, time: 1000, shade: 0.4 }, function () {
                                    location.href = data.url;
                                });
                            }else{
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error:function () {
                            layer.alert("网络异常");
                        }
                    })
                })

                function checkServer(sid){
                    var ii = layer.msg('正在检测···', { icon: 16, shade: 0.01, time: 15000 });
                    $.ajax({
                        url: "ajax.php?act=checkServer",
                        type: 'POST',
                        dataType: 'json',
                        data: {sid: sid},
                        success: function (data) {
                            layer.close(ii);
                            if (data.code == 1) {
                                layer.msg(data.msg, { icon: 1, time: 2000, shade: 0.4 });
                            }else {
                                layer.msg(data.msg, { icon: 2, time: 2000, shade: 0.4 });
                            }
                        },
                        error:function () {
                            layer.alert("网络连接错误!");
                        }
                    });
                }
            </script>
