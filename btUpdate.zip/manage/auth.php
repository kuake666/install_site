<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------

include("../app/common.php");
$act = isset($_GET['act']) ? daddslashes($_GET['act']) : null;

@header('Content-Type: application/json; charset=UTF-8');

switch ($act) {
    case 'login':
        $username = trim(strip_tags(daddslashes($_POST['user'])));
        $password = trim(strip_tags(daddslashes($_POST['pass'])));
        $isNologin = trim(strip_tags(daddslashes($_POST['isNologin'])));
        if ($password == null || $username == null) {
            $result = array("code"=>-1,"msg"=>"请填写管理员账号密码后再登陆");
            exit(json_encode($result));
        }
        $userrow = $DB->query("SELECT * FROM wcms_user WHERE `username`='{$username}' limit 1")->fetch();
        $password = md5($password);
        if ($username == $userrow['username'] && $password == $userrow['password']) {
            saveLog($userrow['uid'], "登录后台管理系统");
            /*
            $city = getCityByIp($clientIp);
            $city = $city['city'];
            $userLog = $DB->query("SELECT `uid` FROM `wcms_log` WHERE `uid`='{$userrow['uid']}' and `city`='{$city}' and `type`='登录用户中心' ")->rowCount();//判断异地
            $userLogAll = $DB->query("SELECT `uid` FROM `wcms_log` WHERE `uid`='{$userrow['uid']}' and `type`='登录用户中心'")->rowCount(); //总共登陆次数

            if ($userLogAll > 10 && $userLog < 5) { //在用户登陆第十次之后， 如果发生异地登陆开始执行
                //符合特定条件 发送邮件功能
                //如果当前登陆账户在此地登陆次数少于5次 则发送邮件
                $mail_name = $userrow['email'] ? $userrow['email'] : $conf["mail_name"];
                send_mail($mail_name, $conf["web_name"] . "-异地登陆提醒", '尊敬客户您好：');
            }
            */
            if (!$isNologin || $isNologin = 0) { //未开启30天免登录
                $expiretime = time() + 604800;
            } else {
                $expiretime = time() + 2592000;
            }
            $session = md5($username . $password . $password_hash);
            $token = authcode("{$username}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
            setcookie("admin_token", $token, $expiretime);

            exit('{"code":1,"msg":"尊敬的 ' . $userrow['nickname'] . ' ,登录成功!"}');
        } else {
            $result = array("code"=>-1,"msg"=>"管理员用户名或管理员密码不正确");
            exit(json_encode($result));
        }

        break;

    case 'logout':
        setcookie("user_token", "", time() - 604800);
        setcookie("admin_token", "", time() - 604800);
        $result = array("code"=>1,"msg"=>"退出成功");
        exit(json_encode($result));
        break;

    default:

        break;


}

?>