<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
?>

<footer class="footer text-center text-sm-left">
    &copy; 2020 <?php echo $conf['web_name']?> <span class="text-muted d-none d-sm-inline-block float-right">
        版本 : Build<?php echo VER?>  <?php echo VERSION_NAME?></span>
</footer><!--end footer-->
</div>
<!-- end page content -->
</div>
<!-- end page-wrapper -->

<!-- jQuery  -->
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/metisMenu.min.js"></script>
<script src="../assets/js/waves.min.js"></script>
<script src="../assets/js/jquery.slimscroll.min.js"></script>

<script src="../assets/plugins/moment/moment.js"></script>

<script src="../assets/plugins/creditcard/card.js"></script>

<!-- Required datatable js -->
<script src="../assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Buttons examples -->
<script src="../assets/plugins/datatables/dataTables.buttons.min.js"></script>
<script src="../assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
<script src="../assets/plugins/datatables/buttons.html5.min.js"></script>
<script src="../assets/plugins/datatables/buttons.print.min.js"></script>

<!--apexcharts-->
<!--<script src="../assets/plugins/apexcharts/apexcharts.min.js"></script>
<script src="../assets/pages/jquery.analytics_dashboard.init.js"></script>-->

<!-- Responsive examples -->
<script src="../assets/plugins/datatables/dataTables.responsive.min.js"></script>
<script src="../assets/plugins/datatables/responsive.bootstrap4.min.js"></script>
<script src="../assets/pages/jquery.datatable.init.js"></script>
<!-- App js -->
<script src="../assets/js/app.js"></script>

<!--引入layer-->
<script src="../assets/js/layer/layer.js"></script>

<script>
    $('#datatable').DataTable();

</script>





</body>
</html>
