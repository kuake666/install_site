<?php
/* *
 * 码支付异步通知页面
 */

require_once("./common.php");
require_once(SYSTEM_ROOT."codepay/codepay_config.php");
ksort($_POST); //排序post参数
reset($_POST); //内部指针指向数组中的第一个元素
$sign = '';
foreach ($_POST AS $key => $val) {
    if ($val == '') continue;
    if ($key != 'sign') {
        if ($sign != '') {
            $sign .= "&";
            $urls .= "&";
        }
        $sign .= "$key=$val"; //拼接为url参数形式
        $urls .= "$key=" . urlencode($val); //拼接为url参数形式
    }
}

if ($conf['alipay_api']!=5 && $conf['qqpay_api']!=5 && $conf['wxpay_api']!=5) {
	exit('fail');
} elseif (!$_POST['pay_no'] || md5($sign . $codepay_config['key']) != $_POST['sign']) { //不合法的数据 KEY密钥为你的密钥
    exit('fail');
} else { //合法的数据

    $out_trade_no = daddslashes($_POST['param']);

    //支付宝交易号
    $trade_no = daddslashes($_POST['pay_no']);

    $srow=$DB->get_row("SELECT * FROM  `wcms_order` WHERE `order_no`='{$out_trade_no}' limit 1 for update");
    if($srow['status']==0) {
          $DB->query("update `wcms_order` set `status` ='1' where `order_no`='{$out_trade_no}'");
		    //增加余额
          	//充值的金额 $srow['money']
          	//用户的余额 $userrow['money']
          	//用户充值后的余额 $user['money'] = $userrow['money']+$srow['money'];
          
          	//查询到充值的用户
            $user=$DB->query("SELECT * FROM `wcms_user` WHERE `uid`='{$srow['uid']}' limit 1")->fetch();
            $user['money'] = $user['money']+$srow['money'];
            $DB->query("update `wcms_user` set `money` ='{$user['money']}' where `uid`='{$user['uid']}'")->fetch();
    }
    exit('success');
}

?>