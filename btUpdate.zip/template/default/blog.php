<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------
include 'header.php';
$list=$DB->query("SELECT * FROM  `wcms_news` WHERE `type`='1' order by date desc")->fetchAll();

?>



<header id="fh5co-header" class="fh5co-cover fh5co-cover-sm" role="banner" style="background-image:url(https://kuake.coding.net/p/static/d/static/git/raw/master/baota/img/20200102213404jC.jpg);" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-7 text-left">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeInUp">
							<h1 class="mb30">解决方案</h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	

	<div id="fh5co-blog" class="fh5co-bg-section">
		<div class="container">
			<div class="row animate-box row-pb-md" data-animate-effect="fadeInUp">
				<div class="col-md-8 col-md-offset-2 text-left fh5co-heading">
					<span>Thoughts &amp; Ideas</span>
					<h2>解决方案</h2>
					<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
				</div>
			</div>
			<div class="row">

                <?php foreach ($list as $res){
                    $title = mb_substr($res['title'], 0, 6, 'utf-8');
                    $res['title'] = $title . "...";
                    $res['content'] = mb_substr($res['content'], 0, 5, 'utf-8');
                    $newContent = $content . "...";
                    ?>
                    <div class="col-md-4 col-sm-6 animate-box" data-animate-effect="fadeInUp">
                        <div class="fh5co-post">
                            <span class="fh5co-date"><?php echo $res['date']?></span>
                            <h3><a href="../consumer/index.php"><?php echo $res['title']?></a></h3>
                            <p>  <?php echo $res['content']?></p>
                               <p class="author"><img src="./assets/default/images/person1.jpg" alt="Free HTML5 Bootstrap Template by gettemplates.co"> <cite> 系统管理员</cite></p>
                        </div>
                    </div>
                <?php }?>
				<div class="clearfix visible-md-block"></div>


			</div>
		</div>
	</div>



<?php
include 'footer.php';

?>