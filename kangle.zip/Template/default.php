<!--阿拉丁建站系统-夸克QQ79517721 -->
<!DOCTYPE html>
<html> 
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title><?php echo $config['title']?>-<?php echo $config['titles']?></title>
       <meta name="keywords" content="<?php echo $config['keywords']?>">          
        <meta name="description" content="<?php echo $config['description']?>">
		<link rel="shortcut icon" href="assets/aladdinlogo/favicon.ico">
<!-- Material Design fonts -->


<!-- Bootstrap -->
<link href="assets/material/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/material/css/font-awesome.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="assets/material/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
<link href="assets/material/css/animate.css" rel="stylesheet" type="text/css">

<!-- Bootstrap Material Design -->
<link href="assets/material/css/material-design.css" rel="stylesheet">
<link href="assets/material/css/ripples.min.css" rel="stylesheet">


<link href="assets/material/css/snackbar.min.css" rel="stylesheet">

<!-- Custome Styles -->
<link href="assets/material/css/style.css" rel="stylesheet" type="text/css"> 

</head>
<body> 
<!--Header_section-->
<header id="header_wrapper">
<div class="navbar navbar-default">
		<div class="container">
		  <div class="navbar-header">


			<a class="navbar-brand" href="javascript:void(0)"><i class="material-icons"><?php echo $config['title'] ?></i></a>
		  </div>
		  <div id="main-nav" class="navbar-collapse collapse navbar-responsive-collapse navStyle">
				<ul class="nav navbar-nav" id="mainNav">
				  <li class="active"><a href="#hero_section" class="scroll-link">首页</a></li>
				  <li><a href="#aboutUs" class="scroll-link">关于建站</a></li>
				  <li><a href="#service" class="scroll-link">网站展示</a></li>
			
				</ul>
		  </div>
		</div>
	  </div>

</header>
<!--Hero_Section-->
<section id="hero_section" class="top_cont_outer">
<div class="hero_wrapper">
<div class="container">
  <div class="hero_section">
	<div class="row">
	  <div class="col-lg-5 col-sm-7">
		<div class="top_left_cont zoomIn wow animated"> 
		  <h2> <strong><?php echo $config['title']?></strong> </h2>
		  <p>智能建站系统-全网独家开发一键建站系统，高效、安全、便捷.</p>
		  <a href="<?=$custom_template?>/Reg.php" class="btn btn-raised btn-lg">在线注册</a> <a href="<?=$custom_template?>/Login.php" class="btn btn-raised btn-lg">网站登录</a></div>
	  </div>
	  <div class="col-lg-7 col-sm-5">
		<img src="assets/material/img/main_device_image.png" class="zoomIn wow animated" alt="" />
	  </div>
	</div>
  </div>
</div>
</div>
</section>
<!--Hero_Section-->  

<!--Aboutus-->
<section id="aboutUs">
<div class="inner_wrapper">
<div class="container">
<h2>关于建站</h2>
<div class="inner_section">
<div class="row">

	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
		<div class=" delay-01s animated fadeInDown wow animated">
		<h3>我们是您值得信赖的云建站商家</h3><br/> 
		<p> <?php echo $config['title'] ?>是一个一键搭建网站的系统,用户可一键搭建各种网站,一部手机即可在线管理，专属的网站后台,让您体验做站长的乐趣.</p> <br/>
<p>使用<?php echo $config['title'] ?>，无需购买主机无需技术，注册登陆后充值搭建即可使用，您可以随时在电脑/手机/平板登陆本网站进行功能设置.</p>
          <p> 分布式服务器全天24H处理业务，客户站点所在服务器为托管于宿迁优质高防机房实体服务器，保障业务正常运营.  .</p>
          <p>独家登录地点异常、重要操作异常邮件通知，保障您的财产不受损失.</p>
          <p>客服24小时随叫随到 为您解答任何问题 让您的体验更加愉快.</p>
</div>  
   </div>	
  </div> 
</div>
</div> 
</div>
</section>
<!--Service-->
<section  id="service">
<div class="container">
<h2>网站展示</h2>
<div class="service_wrapper">
  <div class="row">
	<div class="col-lg-4 col-md-4 col-sm-4">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">彩虹网1</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i2/2784095818/O1CN016h573w1sqgpk9tP2c_!!2784095818.jpg">
	  </div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-4 borderLeft">			
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">彩虹网2</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01Aqubsq1sqgpkkAbqd_!!2784095818.jpg">
		  </div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-4 borderLeft">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">易支付</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01bTA50p1sqgphcMrS7_!!2784095818.jpg">
	  </div>
	</div>
  </div>
   <div class="row borderTop">
	<div class="col-lg-4 col-md-4 col-sm-4 mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">淘客网</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i1/2784095818/O1CN01FFmaLP1sqgpwvsOit_!!2784095818.jpg">
	  </div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-4 borderLeft mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">影视网</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i2/2784095818/O1CN01YZW51F1sqgpiUmEhP_!!2784095818.jpg">
	  </div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-4 borderLeft mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">博客网</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01Ajy6Ps1sqgpwbGlEv_!!2784095818.jpg">
	  </div>
	</div>
  </div>
  
     <div class="row borderTop">
	<div class="col-lg-4 col-md-4 col-sm-4 mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">同学录</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i1/2784095818/O1CN01LAwbUU1sqgpwbFksw_!!2784095818.jpg">
	  </div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-4 borderLeft mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">表白墙</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01oFIXQw1sqgpuUj1dG_!!2784095818.jpg">
	  </div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-4 borderLeft mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">论坛网</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i1/2784095818/O1CN01wN514K1sqgpgReiMK_!!2784095818.jpg">
	  </div>
	</div>
  </div>
  
     <div class="row borderTop">
	<div class="col-lg-4 col-md-4 col-sm-4 mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">要饭网</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i2/2784095818/O1CN01msjW861sqgpj7Ku3q_!!2784095818.jpg">
	  </div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-4 borderLeft mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">个人导航网</h3>
             <img class="img-responsive" src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01o9kchg1sqgphcLNzt_!!2784095818.jpg">
	  </div>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-4 borderLeft mrgTop">
	  <div class="service_block withripple">
		<h3 class="animated fadeInUp wow">表情网</h3>
     <img class="img-responsive" src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN012zEeri1sqgpkBpdRo_!!2784095818.jpg">
	  </div>
	</div>
  </div>
  
  

  
  
  
  
</div>
</div>
</section>
<!--Service-->





<!--Footer-->
<footer class="footer_wrapper" id="contact">

<div class="container">
<div class="footer_bottom"><span>Copyright &copy; 2019.Company name All rights reserved. <a href="./"  title="建站系统"><?php echo $config['footer'] ?></a></span> </div>
</div>
</footer>


<script src="assets/material/js/jquery-1.10.2.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script src="assets/material/js/ripples.min.js"></script>
<script src="assets/material/js/material.min.js"></script>
<script src="assets/material/js/snackbar.min.js"></script>

<!-- Script Files -->
<script type="text/javascript" src="assets/material/js/jquery-scrolltofixed.js"></script>
<script type="text/javascript" src="assets/material/js/jquery.nav.js"></script> 
<script type="text/javascript" src="assets/material/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="assets/material/js/jquery.isotope.js"></script>
<script src="assets/material/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script type="text/javascript" src="assets/material/js/custom.js"></script> 

<script>
$(function () {
$.material.init(); 
});
</script>

</body>
</html>

<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->