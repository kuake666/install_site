<!--阿拉丁建站系统-夸克QQ79517721 -->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="keywords" content="<?php echo $config['keywords']?>">          
        <meta name="description" content="<?php echo $config['description']?>">
<title><?php echo $config['title']?>-<?php echo $config['titles']?></title>
<link rel="shortcut icon" href="./assets/aladdinlogo/favicon.ico">
<!-- Bootstrap Core CSS -->
<link href="./assets/aladdin2/./assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Animation -->
<link rel="stylesheet" href="./assets/aladdin2/css/animate.css">
<!-- prettyphoto -->
<!-- Bootsrap modal -->
<link rel="stylesheet" href="./assets/aladdin2/css/bootstrap-modal-carousel.css">
<!-- Custom CSS -->
<link href="./assets/aladdin2/css/theme.css" rel="stylesheet">
<!-- Responsive styles-->
<link rel="stylesheet" href="./assets/aladdin2/css/responsive.css">
<!-- Custom Fonts -->
<!-- FontAwesome -->
<link rel="stylesheet" href="./assets/aladdin2/css/font-awesome.min.css">
<!-- Elegant icon font -->
<link rel="stylesheet" href="./assets/aladdin2/css/line-icons.min.css">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
<!-- Navigation -->
<nav class="navbar navbar-custom navbar-fixed-top">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse"> <i class="fa fa-bars"></i> </button>
			<a class="navbar-brand page-scroll" href="#page-top"> 
				<img src="./assets/aladdinlogo/aladdin.png" alt="" class="img-responsive"> 
			</a>
		</div>
		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse navbar-right navbar-main-collapse">
			<ul class="nav navbar-nav">
				<li class="active"><a href="#section-intro" class="page-scroll">首页</a></li>
				<li><a class="page-scroll" href="<?=$custom_template?>/Reg.php">在线注册</a></li>
				<li><a class="page-scroll" href="<?=$custom_template?>/Login.php">在线登录</a></li>
			
			</ul>
		</div>
		<!-- /.navbar-collapse -->
	</div>
	<!-- /.container -->
</nav>
<!-- navbar end -->


<section id="section-intro">
	<div class="bg-overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-5">
				<div class="carousel slide" id="banner-slider" data-ride="carousel">
					<!-- Indicators -->
					<ol class="carousel-indicators">
						<li data-target="#banner-slider" data-slide-to="0" class="active"></li>
						<li data-target="#banner-slider" data-slide-to="1"></li>
						<li data-target="#banner-slider" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<div class="intro-caption">
								<div class="subtitle">手机操作 </div>
								<h1><?php echo $config['title']?></h1>
								<div class="btn-container wow fadeInUp">
									<a href="<?=$custom_template?>/Reg.php" class="btn btn-white ">在线注册</a> 
									<a href="<?=$custom_template?>/Login.php" class="btn btn-black">在线登录</a> 
								</div>
							</div>
						</div>
						<div class="item ">
							<div class="intro-caption">
								<div class="subtitle">安全稳定</div>
								<h1><?php echo $config['title']?></h1>
								<div class="btn-container wow fadeInUp">
									<a href="<?=$custom_template?>/Reg.php" class="btn btn-white ">在线注册</a> 
									<a href="<?=$custom_template?>/Login.php" class="btn btn-black">在线登录</a>
								</div>
							</div>
						</div>
						<div class="item ">
							<div class="intro-caption">
								<div class="subtitle">快速建站</div>
								<h1><?php echo $config['title']?></h1>
								<div class="btn-container wow fadeInUp">
									<a href="<?=$custom_template?>/Reg.php" class="btn btn-white ">在线注册</a> 
									<a href="<?=$custom_template?>/Login.php" class="btn btn-black">在线登录</a> 
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!-- row end  -->
	</div><!-- container end  -->
</section>

<!-- section features start -->
<section id="section-features" class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<div class="feature-wrap">
					<ul class="feature-list">
						<li class="col-md-6 col-sm-6">
							<div class="feature-box">
								<div class="feature-icon"> <i class="icon icon-mobile"></i> </div>
								<div class="feature-inner">
									<h4>安全快速</h4>
									
								</div>
							</div>
						</li>
						<li class="col-md-6 col-sm-6">
							<div class="feature-box">
								<div class="feature-icon"> <i class="icon icon-wallet"></i> </div>
								<div class="feature-inner">
									<h4>高效稳定</h4>
									
								</div>
							</div>
						</li>
						<li class="col-md-6 col-sm-6">
							<div class="feature-box">
								<div class="feature-icon"> <i class="icon icon-flag"></i> </div>
								<div class="feature-inner">
									<h4>奖励丰厚</h4>
									
								</div>
							</div>
						</li>
						<li class="col-md-6 col-sm-6">
							<div class="feature-box">
								<div class="feature-icon"> <i class="icon icon-shield"></i> </div>
								<div class="feature-inner">
									<h4>操作方便</h4>
									
								</div>
							</div>
						</li>
					</ul>
				</div>
				<!--  feature wrap end -->
			</div>
			<!--  col end -->
		</div>
		<!-- row end -->
	</div>
	<!-- container end -->
</section>
<!-- section features end -->

<!--  section services start -->
<section id="section-services" class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-heading">
					
					<h2><?php echo $config['title']?></h2> 
				</div>
			</div>
		</div>
		<!--  row end -->
		<div class="row">
			<div class="col-md-4 col-sm-6">
				<div class="service-box active"> <i class="icon icon-anchor"></i>
					<h4>一站式管理</h4>
					<p>，无需购买主机无需技术，注册登陆后充值搭建即可使用，您可以随时在电脑/手机/平板登陆本网站进行功能设置..</p>
					<div class="line"></div>
				</div>
				<div class="service-box active"> <i class="icon icon-mic"></i>
					<h4>数据安全</h4>
					<p>采用阿里云RDS云数据库，数据加密储存，抵抗各种注入破解，保证每一位用户的账号数据安全！.</p>
					<div class="line"></div>
				</div>
				
			</div>
			<div class="col-md-4 col-sm-6">
				<div class="service-box"> <i class="icon icon-layers"></i>
					<h4>分布式服务器</h4>
					<p>分布式服务器全天24H处理业务，客户站点所在服务器为托管于宿迁优质高防机房实体服务器，保障业务正常运营.</p>
					<div class="line"></div>
				</div>
				<div class="service-box"> <i class="icon icon-chat"></i>
					<h4>智能提醒服务</h4>
					<p>独家登录地点异常、重要操作异常短信通知，保障您的财产不受损失..</p>
					<div class="line"></div>
				</div>
				
			</div>
			<div class="col-md-4 col-sm-6">
				<div class="service-box"> <i class="icon icon-laptop"></i>
					<h4>功能强大</h4>
					<p>全网独家支持用户一键搭建功能，网站配置错误一键恢复.</p>
					<div class="line"></div>
				</div>
				<div class="service-box"> <i class="icon icon-mobile"></i>
					<h4>专员服务</h4>
					<p>客服24小时随叫随到 为您解答任何问题 让您的体验更加愉快.</p>
					<div class="line"></div>
				</div>
			</div>
		</div>
		<!--  row end -->
	</div>
	<!--  container end -->
</section>
<!--  section services end -->

<!-- section portfolio start -->
<section id="section-portfolio" class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-heading">
					<p><?php echo $config['title']?></p>
					
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-3">
				<div class="item-box single-portfolio">
					<figure>
						<a href="#" data-toggle="modal" data-target="#portfolio1">
							<div class="img-box"> <img src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01p3iOIv1sqgpxGMaOm_!!2784095818.jpg" alt="" />
								<div class="img-overlay"></div>
							</div>
						</a>
					</figure>
				</div>
				<div class="item-box single-portfolio">
					<figure>
						<a href="#" data-toggle="modal" data-target="#portfolio1">
							<div class="img-box"> <img src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01L8SaEX1sqgpxGOOeT_!!2784095818.jpg" alt="" />
								<div class="img-overlay"></div>
							</div>
						</a>
					</figure>
				</div>
				<div class="item-box single-portfolio">
					<figure>
						<a href="#" data-toggle="modal" data-target="#portfolio1">
							<div class="img-box"> <img src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01PSGBsj1sqgpyvexGC_!!2784095818.jpg" alt="" />
								<div class="img-overlay"></div>
							</div>
						</a>
					</figure>
				</div>
				
			</div>
			<div class="col-md-5">
				<div class="item-box single-portfolio">
					<figure>
						<a href="#" data-toggle="modal" data-target="#portfolio1">
							<div class="img-box"> <img src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01PSGBsj1sqgpyvexGC_!!2784095818.jpg" alt="" />
								<div class="img-overlay"></div>
							</div>
						</a>
					</figure>
				</div>
				<div class="item-box single-portfolio">
					<figure>
						<a href="#" data-toggle="modal" data-target="#portfolio1">
							<div class="img-box"> <img src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01kFEejv1sqgpxEPfHD_!!2784095818.jpg" alt="" />
								<div class="img-overlay"></div>
							</div>
						</a>
					</figure>
				</div>
			</div>
			<div class="col-md-4">
				<div class="item-box single-portfolio">
					<figure>
						<a href="#" data-toggle="modal" data-target="#portfolio1">
							<div class="img-box"> <img src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01kFEejv1sqgpxEPfHD_!!2784095818.jpg" alt="" />
								<div class="img-overlay"></div>
							</div>
						</a>
					</figure>
				</div>
				<div class="item-box single-portfolio">
					<figure>
						<a href="#" data-toggle="modal" data-target="#portfolio1">
							<div class="img-box"> <img src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01L8SaEX1sqgpxGOOeT_!!2784095818.jpg" alt="" />
								<div class="img-overlay"></div>
							</div>
						</a>
					</figure>
				</div>
			</div>
			
			
		</div>
	</div>
	<!-- Container Full End -->
	
	
	<!-- Portfolio1 fullscreen modal -->
	<div id="portfolio1" class="modal fade modal-fullscreen force-fullscreen" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<div class="modal-title">
						<div class="container">
							<div class="row">
								<div class="col-md-12">
									<h2>Project Details</h2> </div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-body">
					<div class="container">
						<div class="row top-margin">
							<div class="col-md-4"> <img src="./assets/aladdin2/images/portfolio/portfolio6.jpg" alt="" class="img-responsive center-block"> </div>
							<div class="col-md-8">
								<h3>Project Name</h3>
								<p>Title of project</p>
								<h3>Project Description </h3>
								<p>Ipsum partem voluptatibus ex nam, prima virtute electram ius ei, vide error intellegat id cum. Duo ut accumsan molestie. Feugait referrentur vel in, te nostro convenire per, nullam nostrud placerat cum ne. Ne ancillae expetenda nec, dicam oportere te mel, audiam mnesarchum.</p> <a href="#" class="btn btn-black">View demo</a> </div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="btn custom-btn-2 pull-left" data-dismiss="modal">Close</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- END: Portfolio1 fullscreen modal -->
</section>
<!-- section portfolio end -->









<!-- section footer strat -->
<footer id="section-footer" >
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="footer-content">
				<h4 class="wow fadeInUp">	Copyright &copy; 2019<a href="./" ><?php echo $config['footer']?></a> </h4>	
				</div>
			</div>
			 
		</div><!-- row end  -->
	</div><!-- container end  -->
</footer>
<!-- section contact address end -->

<!-- jQuery -->
<script src="./assets/aladdin2/js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="./assets/aladdin2/js/bootstrap.min.js"></script>
<!-- form validation -->
<script type="text/javascript" src="./assets/aladdin2/js/validator.min.js"></script>
<script type="text/javascript" src="./assets/aladdin2/js/form-scripts.js"></script>
<!-- Plugin JavaScript -->
<script src="js/jquery.easing.min.js"></script>
<!-- isotope -->
<script type="text/javascript" src="./assets/aladdin2/js/jquery.isotope.js"></script>
<!-- Waypoints -->
<script type="text/javascript" src="./assets/aladdin2/js/jquery.waypoints.min.js"></script>
<!-- Wow Animation -->
<script type="text/javascript" src="./assets/aladdin2/js/wow.min.js"></script>
<!-- Google Maps API Key - Use your own API key to enable the map feature. More information on the Google Maps API can be found at https://developers.google.com/maps/ -->
<!-- Custom Theme JavaScript -->
<script src="./assets/aladdin2/js/theme.js"></script>

</body>
</html>

<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
