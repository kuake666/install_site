﻿<!--阿拉丁建站系统-夸克QQ79517721 -->
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="format-detection" content="telephone=yes">
<title><?php echo $config[title]?>-<?php echo $config['titles']?></title>
<meta name="description" content="<?php echo $config['description']?>" />
<meta name="keywords" content="<?php echo $config['keywords']?>"" />
<meta name="author" content="阿拉丁建站-夸克QQ79517721" />
<link rel="shortcut icon" href="assets/aladdinlogo/favicon.ico">
<meta name="renderer" content="webkit">
<!--ico-->
<link rel="stylesheet" type="text/css" href="assets/aladdin7/css/base.css" />
<link rel="stylesheet" type="text/css" href="assets/aladdin7/css/animate.min.css" />
<link rel="stylesheet" type="text/css" href="assets/aladdin7/css/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="assets/aladdin7/css/style.css" />
<link rel="stylesheet" type="text/css" href="assets/aladdin7/css/responsive.css" />
<script src="assets/aladdin7/js/jquery-1.11.0.min.js"></script>
<script src="assets/aladdin7/js/wow.min_1.js"></script>
<script src="assets/aladdin7/js/owl.carousel.min.js"></script>
<script src="assets/aladdin7/js/page.js"></script>
<script>
function loadScript(url, callback){
var script = document.createElement_x("script")
script.type = "text/javascript";
if (script.readyState){ //IE
script.onreadystatechange = function(){
if (script.readyState == "loaded" ||
script.readyState == "complete"){
script.onreadystatechange = null;
callback();
}
};
} else { //Others: Firefox, Safari, Chrome, and Opera
script.onload = function(){
callback();
};
}
script.src = url;
document.body.appendChild(script);
}
</script>
</head>
<body>
<div class="header">
  <div class="rowFluid">
    <div class="span3 col-md-12">
        <div class="logo"> <a href="./" title="<?php echo $config['title']?>"> <img src="assets/aladdinlogo/aladdin.png" alt="<?php echo $config['title']?>"/> </a> </div>
    </div>
    <div class="span6">
      <div class="mobileMenuBtn"><span class="span1"></span><span class="span2"></span><span class="span3"></span></div>
      <div class="mobileMenuBtn_shad"></div>
      <div class="header_menu">
        <ul id="menu">
            <li><a href="./"  class="active"  title="">首页</a></li>
			<li><a href="<?=$custom_template?>/Login.php"  class=""  title="">控制台</a></li>
		
        </ul>
      </div>
    </div>
      <div class="span2">
        <div class="login">
                            <a href="<?=$custom_template?>/Login.php" title="<?php echo $config[title]?>">登录</a><span>|</span><a href="<?=$custom_template?>/Reg.php" title="<?php echo $config[title]?>">注册</a>
                    </div>
    </div>
  </div>
</div>
<div class="aside">
  <ul>
    <li> <a href="<?=$custom_template?>/index.php" target="_blank" title="用户控制中心"><img src="assets/aladdin7/picture/057.png" alt="用户控制中心" />会员</a> </li>
    <li class="consulting"><a href="#this" title="建站在线客服"><span></span><span></span><span></span><img src="assets/aladdin7/picture/059.png" class="img1" alt="建站在线客服" /><img src="assets/aladdin7/picture/061.png" class="img2" alt="建站在线客服" />咨询</a></li>

  </ul>
</div>
<div class="consulting_box">
    <div class="title">
        <div class="title_t1">RELATEED CONSULTING</div>
        <div class="title_t2">相关咨询 </div>
    </div>
    <div class="consulting_type">
        <div class="consulting_type_title">马上在线沟通</div>
        <ul>
            <li><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config['kfqq']?>&site=qq&menu=yes" title="售前咨询" /><img src="assets/aladdin7/picture/062.png" class="img1" alt=""><img src="assets/aladdin7/picture/063.png" class="img2" alt="">售前咨询</a></li><li><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config[kfqq]?>&site=qq&menu=yes" title="售后服务" /><img src="assets/aladdin7/picture/062.png" class="img1" alt=""><img src="assets/aladdin7/picture/063.png" class="img2" alt="">售后服务</a></li><li><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config[kfqq]?>&site=qq&menu=yes" title="定制咨询" /><img src="assets/aladdin7/picture/062.png" class="img1" alt=""><img src="assets/aladdin7/picture/063.png" class="img2" alt="">定制咨询</a></li><li><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config[kfqq]?>&site=qq&menu=yes" title="合作咨询" /><img src="assets/aladdin7/picture/062.png" class="img1" alt=""><img src="assets/aladdin7/picture/063.png" class="img2" alt="">合作咨询</a></li>        </ul>
        <div class="time">周一至周天 工作时间：9:30-20:00<br>非工作时间请提交工单,会第一时间处理.</div>
    </div>
    
    <div class="close">
        <img src="assets/aladdin7/picture/close.png" alt="关闭右侧工具栏" />
    </div>
</div>
<div class="page">
        
<div class="main">
<div class="banner clearfix">
            <div class="owl-demo">
            <div class="item"><h3 class="banner_title"><?php echo $config['title']?></h3><div class="banner_text">全网独家开发一键建站系统，高效、安全、便捷。</div><div class="banner_button">
	<a href="<?=$custom_template?>/Reg.php" class="active">注册</a> <a href="<?=$custom_template?>/Login.php" class="active">登录</a>
</div></div><div class="item"><h3 class="banner_title">为用户所想 满足用户需求</h3><div class="banner_text">用户的需求就是我们的追求</div><div class="banner_button">
	<a href="<?=$custom_template?>/Reg.php" class="active">注册</a> <a href="<?=$custom_template?>/Login.php" class="active">登录</a>
</div></div>            </div>
        </div>
    <div id="container" class="mpage">
        <div id="anitOut" class="anitOut"></div>
    </div>

<div class="index_product clearfix">
            <div class="container">
                <div class="all_title1 wow fadeInDown">
                    <h3 class="title">我们的产品</h3>
                    <div class="text">OUR PRODUCT</div>
                </div>
                <div class="rowFluid">
                    <div class="index_product_content">
                        <div class="span4 col-md-6 col-xs-12 wow fadeInDown">
                            <a href="<?=$custom_template?>/index.php" class="index_product_list" title="响应式网站建设">
                                <div class="list_backimg list_backimg1">
                                    <div class="list_img">
                                        <img src="assets/aladdin7/picture/045.png" alt="响应式企业网站建设" />
                                    </div>
                                    <div class="list_txt">
                                        <div class="list_title">企业官网</div>
                                        <div class="list_text">CORPORATE WEBSITES</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="span4 col-md-6 col-xs-12 wow flipInX">
                            <a href="<?=$custom_template?>/index.php" class="index_product_list" title="响应式免费建站">
                                <div class="list_backimg list_backimg2">
                                    <div class="list_img">
                                        <img src="assets/aladdin7/picture/046.png" alt="响应式自助建站" />
                                    </div>
                                    <div class="list_txt">
                                        <div class="list_title">购物商城</div>
                                        <div class="list_text">SHOPPING MALL</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="span4 col-md-6 col-xs-12 wow fadeInRight">
                            <a href="<?=$custom_template?>/index.php" class="index_product_list" title="响应式网站建设">
                                <div class="list_backimg list_backimg3">
                                    <div class="list_img">
                                        <img src="assets/aladdin7/picture/047.png" alt="响应式网站建设" />
                                    </div>
                                    <div class="list_txt">
                                        <div class="list_title">分销平台</div>
                                        <div class="list_text">DISTRIBUTION PLATFROM</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="span4 col-md-6 col-xs-12 wow fadeInDown">
                            <a href="<?=$custom_template?>/index.php" class="index_product_list" title="免费建站">
                                <div class="list_backimg list_backimg4">
                                    <div class="list_img">
                                        <img src="assets/aladdin7/picture/048.png" alt="免费建站" />
                                    </div>
                                    <div class="list_txt">
                                        <div class="list_title">行业门户</div>
                                        <div class="list_text">INDUSTRY PORTAL</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="span4 col-md-6 col-xs-12 wow flipInX">
                            <a href="<?=$custom_template?>/index.php" class="index_product_list" title="免费网站">
                                <div class="list_backimg list_backimg5">
                                    <div class="list_img">
                                        <img src="assets/aladdin7/picture/049.png" alt="免费网站建设" />
                                    </div>
                                    <div class="list_txt">
                                        <div class="list_title">APP生成</div>
                                        <div class="list_text">APP GENERATION</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="span4 col-md-6 col-xs-12 wow fadeInRight">
                            <a href="<?=$custom_template?>/index.php" class="index_product_list" title="网站建设">
                                <div class="list_backimg list_backimg6">
                                    <div class="list_img">
                                        <img src="assets/aladdin7/picture/050.png" alt="免费网站建设" />
                                    </div>
                                    <div class="list_txt">
                                        <div class="list_title">全网营销</div>
                                        <div class="list_text">NETWORK MARKETING</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
</div>

<div class="platform_advantage clearfix">
 
                <div class="container">
                  <div class="all_title2 wow fadeInUp">
                    <h3 class="title">平台优势</h3>
                    <div class="text">PLATFORM ADVANTAGE</div>
                </div>
      
                    <div class="platform_advantage_content clearfix">
                        <div class="span4 col-xm-6 col-xs-12 wow bounceInLeft">
                            <div class="platform_advantage_list">
                                <div class="platform_advantage_img">
                                    <img src="assets/aladdin7/picture/008.png" alt="H5建站平台" />
                                </div>
                                <div class="platform_advantage_brief">
                                    <div class="brief_title">功能模块化</div>
                                    <div class="brief_text">功能可叠加，按需升级</div>
                                </div>
                            </div>
                        </div>
                        <div class="span4 col-xm-6 col-xs-12 wow bounceIn">
                            <div class="platform_advantage_list">
                                <div class="platform_advantage_img">
                                    <img src="assets/aladdin7/picture/009.png" alt="响应式网站建设" />
                                </div>
                                <div class="platform_advantage_brief">
                                    <div class="brief_title">数据前端</div>
                                    <div class="brief_text">
                                        打破传统模板，前端模块化，<br />
                                        任意更换自定义编辑、重组
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="span4 col-xm-6 col-xs-12 wow bounceInRight">
                            <div class="platform_advantage_list">
                                <div class="platform_advantage_img">
                                    <img src="assets/aladdin7/picture/010.png" alt="免费自助建站" />
                                </div>
                                <div class="platform_advantage_brief">
                                    <div class="brief_title">可视化编辑</div>
                                    <div class="brief_text">
                                        前端可视编辑，所见即所得<br />
                                        完美响应终端。
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="span4 col-xm-6 col-xs-12 wow bounceInLeft">
                            <div class="platform_advantage_list">
                                <div class="platform_advantage_img">
                                    <img src="assets/aladdin7/picture/011.png" alt="响应式网站定制" />
                                </div>
                                <div class="platform_advantage_brief">
                                    <div class="brief_title">大数据</div>
                                    <div class="brief_text">
                                        升级更新数据保留，企业数据沉淀<br />
                                        实现数据分析。
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="span4 col-xm-6 col-xs-12 wow bounceIn">
                            <div class="platform_advantage_list">
                                <div class="platform_advantage_img">
                                    <img src="assets/aladdin7/picture/012.png" alt="H5建站平台" />
                                </div>
                                <div class="platform_advantage_brief">
                                    <div class="brief_title">高端设计</div>
                                    <div class="brief_text">
                                        主流设计风格，极致交互体验，<br />
                                        提升品牌价值
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="span4 col-xm-6 col-xs-12 wow bounceInRight">
                            <div class="platform_advantage_list">
                                <div class="platform_advantage_img">
                                    <img src="assets/aladdin7/picture/013.png" alt="H5网站建设" />
                                </div>
                                <div class="platform_advantage_brief">
                                    <div class="brief_title">安全稳定</div>
                                    <div class="brief_text">
                                        平台运行于阿里云计算中心<br />
                                        多备份容灾保障，安全稳定
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
            </div>
            <ul class="platform_advantage_bg">
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
  
</div>
<div class="web_tip">
          <h4>了解更多成品服务或加盟事宜，敬请联系</h4>
          <div class="create_web"> <a href="#this" title="">在线客服</a> </div>
</div>
<div class="marketing_advantage">
            <div class="container">
                <div class="all_title2 wow fadeInUp">
                    <h3 class="title">营销优势</h3>
                    <div class="text">MARKETING ADVANTAGE</div>
                </div>

                    <div class="marketing_advantage_content clearfix">
                        <div class="span3 col-sm-6 wow flipInY">
                            <div class="marketing_advantage_list">
                                <img src="assets/aladdin7/picture/019.jpg" alt="免费建站" />
                            </div>
                        </div>
                        <div class="span3 col-sm-6">
                            <div class="span12 wow flipInY">
                                <div class="marketing_advantage_list">
                                    <img src="assets/aladdin7/picture/054.jpg" />
                                    <div class="marketing_advantage_brief">
                                        <div class="brief_title">功能强大<span><img src="assets/aladdin7/picture/020.png" alt="功能强大" /></span></div>
                                        <div class="brief_text">全网独家支持用户一键重装功能，网站配置错误一键恢复</div>
                                    </div>
                                </div>
                            </div>
                            <div class="span12 wow flipInY">
                                <div class="marketing_advantage_list">
                                    <img src="assets/aladdin7/picture/054.jpg" />
                                    <div class="marketing_advantage_brief">
                                        <div class="brief_title">数据安全<span><img src="assets/aladdin7/picture/023.png" alt="数据安全" /></span></div>
                                        <div class="brief_text">采用阿里云RDS云数据库，数据加密储存，抵抗各种注入破解，保证每一位用户的账号数据安全</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="span3 col-sm-6">
                            <div class="span12 wow flipInY">
                                <div class="marketing_advantage_list">
                                    <img src="assets/aladdin7/picture/054.jpg" />
                                    <div class="marketing_advantage_brief">
                                        <div class="brief_title">智能提醒服务<span><img src="assets/aladdin7/picture/021.png" alt="智能提醒服务" /></span></div>
                                        <div class="brief_text">独家登录地点异常、重要操作异常短信通知，保障您的财产不受损失</div>
                                    </div>
                                </div>
                            </div>
                            <div class="span12 wow flipInY">
                                <div class="marketing_advantage_list">
                                    <img src="assets/aladdin7/picture/054.jpg" />
                                    <div class="marketing_advantage_brief">
                                        <div class="brief_title">分布式服务器<span><img src="assets/aladdin7/picture/024.png" alt="分布式服务器" /></span></div>
                                        <div class="brief_text">分布式服务器全天24H处理业务，客户站点所在服务器为托管于宿迁优质高防机房实体服务器，保障业务正常运营</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="span3 col-sm-6">
                            <div class="span12 wow flipInY">
                                <div class="marketing_advantage_list">
                                    <img src="assets/aladdin7/picture/054.jpg" />
                                    <div class="marketing_advantage_brief">
                                        <div class="brief_title">一站式管理<span><img src="assets/aladdin7/picture/022.png" alt="一站式管理" /></span></div>
                                        <div class="brief_text">使用一键建站，无需购买主机无需技术，注册登陆后充值搭建即可使用，您可以随时在电脑</div>
                                    </div>
                                </div>
                            </div>
                            <div class="span12 wow flipInY">
                                <div class="marketing_advantage_list"> 
                                    <img src="assets/aladdin7/picture/054.jpg" />
                                    <div class="marketing_advantage_brief">
                                        <div class="brief_title">专员服务<span><img src="assets/aladdin7/picture/025.png" alt="专员服务" /></span></div>
                                        <div class="brief_text">客服24小时随叫随到 为您解答任何问题 让您的体验更加愉快</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
</div>
<div class="join_in">

            <div class="container">
                <div class="join_in_title wow fadeInUp">加盟我们，<span>坐享互联网+下一波红利</span></div>
                <div class="join_in_text wow fadeInLeft">无需经验 轻松创业 坐享千亿“互联网+“市场</div>
            </div>
</div>
<div class="web_tip">
          <h4>如果您想要定制服务,戳这里</h4>
          <div class="create_web"> <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config['kfqq']?>&site=qq&menu=yes" title="">联系我们</a> </div>
        </div>

<div class="footer wow fadeInUp">
  <div class="rowFluid">
    <div class="span12">
      <div class="container">
        <div class="footer_content">
          <div class="span4 col-xm-12">
            <div class="footer_list">
              
              <div class="span6 col-xm-12">
                <div class="quick_navigation">
                  <div class="quick_navigation_title">快速导航</div>
                  <ul>
            <li> <a href="./" title="">首页</a> </li>               </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="span4 col-xm-6 col-xs-12">
            <div class="footer_list">
              <div class="footer_link">
                  <div class="footer_link_title">友情链接</div>
                <ul id="frientLinks">
            <li> <a href="http://www.autoaladdin.cn/" title="" target="_blank">官方网站</a> </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="span4 col-xm-6 col-xs-12">
            <div class="footer_list">
              <div class="footer_cotact">
                <div class="footer_cotact_title">联系方式</div>
                <ul>
                
                  <li><span class="footer_cotact_type">QQ：</span><span class="footer_cotact_content"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config[kfqq]?>&site=qq&menu=yes" class="call"><?php echo $config[kfqq]?></a></span></li>
                
                  <li><span class="footer_cotact_type">邮箱：</span><span class="footer_cotact_content"><?php echo $config['kfqq']?>@qq.com</span></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="copyright">
	 
	 </br>Copyright © 2018-2019 <?php echo $config['footer']?>  
	  </div>
    </div>
  </div>
</div>
</div>
</div>
</body>
</html>
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->