<!--阿拉丁建站系统-夸克QQ79517721 -->
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title><?php echo $config['title']?>-<?php echo $config['titles']?></title>
    <meta name="keywords" content="<?php echo $config['keywords']?>">          
     <meta name="description" content="<?php echo $config['description']?>">

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CVarela+Round" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="./assets/aladdin8/css/bootstrap.min.css" />

	<!-- Owl Carousel -->
	<link type="text/css" rel="stylesheet" href="./assets/aladdin8/css/owl.carousel.css" />
	<link type="text/css" rel="stylesheet" href="./assets/aladdin8/css/owl.theme.default.css" />

	<!-- Magnific Popup -->
	<link type="text/css" rel="stylesheet" href="./assets/aladdin8/css/magnific-popup.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="./assets/aladdin8/css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="./assets/aladdin8/css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body>
	<!-- Header -->
	<header id="home">
		<!-- Background Image -->
		<div class="bg-img" style="background-image: url('./assets/aladdin8/img/background1.jpg');">
			<div class="overlay"></div>
		</div>
		<!-- /Background Image -->

		<!-- Nav -->
		<nav id="nav" class="navbar nav-transparent">
			<div class="container">

				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
						<a href="index.html">
							<img class="logo" src="./assets/aladdinlogo/aladdin.png" alt="logo">
							<img class="logo-alt" src="./assets/aladdinlogo/aladdin.png" alt="logo">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Collapse nav button -->
					<div class="nav-collapse">
						<span></span>
					</div>
					<!-- /Collapse nav button -->
				</div>

				<!--  Main navigation  -->
				<ul class="main-nav nav navbar-nav navbar-right">
					<li><a href="#home">Home</a></li>
					<li><a href="#about">About</a></li>
					<li><a href="#portfolio">Portfolio</a></li>
			
				</ul>
				<!-- /Main navigation -->

			</div>
		</nav>
		<!-- /Nav -->

		<!-- home wrapper -->
		<div class="home-wrapper">
			<div class="container">
				<div class="row">

					<!-- home content -->
					<div class="col-md-10 col-md-offset-1">
						<div class="home-content">
							<h1 class="white-text"><?php echo $config['title']?></h1>
							<p class="white-text">智能建站系统-全网独家开发一键建站系统，高效、安全、便捷.
							</p>
							<button class="white-btn">
								<a href="<?=$custom_template?>/Reg.php">在线注册</a>

							</button>
							<button class="white-btn">
								<a href="<?=$custom_template?>/Login.php">在线登陆</a>
							</button>
						</div>
					</div>
					<!-- /home content -->

				</div>
			</div>
		</div>
		<!-- /home wrapper -->

	</header>
	<!-- /Header -->

	<!-- About -->
	<div id="about" class="section md-padding">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section header -->
				<div class="section-header text-center">
					<h2 class="title">Welcome to Website</h2>
				</div>
				<!-- /Section header -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-cogs"></i>
						<h3>我们是您值得信赖的云建站商家</h3>
						<p><?php echo $config['title'] ?>是一个一键搭建网站的系统,用户可一键搭建各种网站,一部手机即可在线管理，专属的网站后台,让您体验做站长的乐趣.</p>
						
					</div>
				</div>
				<!-- /about -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-magic"></i>
						<h3>我们是您值得信赖的云建站商家</h3>
					<p>使用<?php echo $config['title'] ?>，无需购买主机无需技术，注册登陆后充值搭建即可使用，您可以随时在电脑/手机/平板登陆本网站进行功能设置.</p></p>
						
					</div>
				</div>
				<!-- /about -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-mobile"></i>
						<h3>我们是您值得信赖的云建站商家</h3>
						<p>分布式服务器全天24H处理业务，客户站点所在服务器为托管于宿迁优质高防机房实体服务器，保障业务正常运营.</p>
						
					</div>
				</div>
				<!-- /about -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /About -->


	<!-- Portfolio -->
	<div id="portfolio" class="section md-padding bg-grey">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section header -->
				<div class="section-header text-center">
					<h2 class="title">Featured Works</h2>
				</div>
				<!-- /Section header -->

				<!-- Work -->
				<div class="col-md-4 col-xs-6 work">
					<img class="img-responsive" src="https://img.alicdn.com/imgextra/i2/2784095818/O1CN016h573w1sqgpk9tP2c_!!2784095818.jpg" alt="">
					<div class="overlay"></div>
					<div class="work-content">
						<span>Category</span>
						<h3>Lorem ipsum dolor</h3>
						<div class="work-link">
							<a href="#"><i class="fa fa-external-link"></i></a>
							<a class="lightbox" href="https://img.alicdn.com/imgextra/i2/2784095818/O1CN016h573w1sqgpk9tP2c_!!2784095818.jpg"><i class="fa fa-search"></i></a>
						</div>
					</div>
				</div>
				<!-- /Work -->

				<!-- Work -->
				<div class="col-md-4 col-xs-6 work">
					<img class="img-responsive" src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01Aqubsq1sqgpkkAbqd_!!2784095818.jpg" alt="">
					<div class="overlay"></div>
					<div class="work-content">
						<span>Category</span>
						<h3>Lorem ipsum dolor</h3>
						<div class="work-link">
							<a href="#"><i class="fa fa-external-link"></i></a>
							<a class="lightbox" href="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01Aqubsq1sqgpkkAbqd_!!2784095818.jpg"><i class="fa fa-search"></i></a>
						</div>
					</div>
				</div>
				<!-- /Work -->

				<!-- Work -->
				<div class="col-md-4 col-xs-6 work">
					<img class="img-responsive" src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01bTA50p1sqgphcMrS7_!!2784095818.jpg" alt="">
					<div class="overlay"></div>
					<div class="work-content">
						<span>Category</span>
						<h3>Lorem ipsum dolor</h3>
						<div class="work-link">
							<a href="#"><i class="fa fa-external-link"></i></a>
							<a class="lightbox" href="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01bTA50p1sqgphcMrS7_!!2784095818.jpg"><i class="fa fa-search"></i></a>
						</div>
					</div>
				</div>
				<!-- /Work -->

				<!-- Work -->
				<div class="col-md-4 col-xs-6 work">
					<img class="img-responsive" src="https://img.alicdn.com/imgextra/i1/2784095818/O1CN01FFmaLP1sqgpwvsOit_!!2784095818.jpg" alt="">
					<div class="overlay"></div>
					<div class="work-content">
						<span>Category</span>
						<h3>Lorem ipsum dolor</h3>
						<div class="work-link">
							<a href="#"><i class="fa fa-external-link"></i></a>
							<a class="lightbox" href="https://img.alicdn.com/imgextra/i1/2784095818/O1CN01FFmaLP1sqgpwvsOit_!!2784095818.jpg"><i class="fa fa-search"></i></a>
						</div>
					</div>
				</div>
				<!-- /Work -->

				<!-- Work -->
				<div class="col-md-4 col-xs-6 work">
					<img class="img-responsive" src="https://img.alicdn.com/imgextra/i2/2784095818/O1CN01YZW51F1sqgpiUmEhP_!!2784095818.jpg" alt="">
					<div class="overlay"></div>
					<div class="work-content">
						<span>Category</span>
						<h3>Lorem ipsum dolor</h3>
						<div class="work-link">
							<a href="#"><i class="fa fa-external-link"></i></a>
							<a class="lightbox" href="https://img.alicdn.com/imgextra/i2/2784095818/O1CN01YZW51F1sqgpiUmEhP_!!2784095818.jpg"><i class="fa fa-search"></i></a>
						</div>
					</div>
				</div>
				<!-- /Work -->

				<!-- Work -->
				<div class="col-md-4 col-xs-6 work">
					<img class="img-responsive" src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01oFIXQw1sqgpuUj1dG_!!2784095818.jpg" alt="">
					<div class="overlay"></div>
					<div class="work-content">
						<span>Category</span>
						<h3>Lorem ipsum dolor</h3>
						<div class="work-link">
							<a href="#"><i class="fa fa-external-link"></i></a>
							<a class="lightbox" href="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01oFIXQw1sqgpuUj1dG_!!2784095818.jpg"><i class="fa fa-search"></i></a>
						</div>
					</div>
				</div>
				<!-- /Work -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Portfolio -->




	<!-- Why Choose Us -->
	<div id="features" class="section md-padding bg-grey">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- why choose us content -->
				<div class="col-md-6">
					<div class="section-header">
						<h2 class="title">Why Choose Us</h2>
					</div>
					
					<div class="feature">
						<i class="fa fa-check"></i>
						<p>一部手机即可在线管理，专属的网站后台,让您体验做站长的乐趣.</p>
					</div>
					<div class="feature">
						<i class="fa fa-check"></i>
						<p>无需购买主机无需技术，注册登陆后充值搭建即可使用.</p>
					</div>
					<div class="feature">
						<i class="fa fa-check"></i>
						<p>独家登录地点异常、重要操作异常邮件通知，保障您的财产不受损失.</p>
					</div>
					<div class="feature">
						<i class="fa fa-check"></i>
						<p>客服24小时随叫随到 为您解答任何问题 让您的体验更加愉快.</p>
					</div>
				</div>
				<!-- /why choose us content -->

				<!-- About slider -->
				<div class="col-md-6">
					<div id="about-slider" class="owl-carousel owl-theme">
						<img class="img-responsive" src="./assets/aladdin8/img/about1.jpg" alt="">
						<img class="img-responsive" src="./assets/aladdin8/img/about2.jpg" alt="">
						<img class="img-responsive" src="./assets/aladdin8/img/about1.jpg" alt="">
						<img class="img-responsive" src="./assets/aladdin8/img/about2.jpg" alt="">
					</div>
				</div>
				<!-- /About slider -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Why Choose Us -->
	

	<!-- Numbers -->
	<div id="numbers" class="section sm-padding">

		<!-- Background Image -->
		<div class="bg-img" style="background-image: url('./assets/aladdin8/img/background2.jpg');">
			<div class="overlay"></div>
		</div>
		<!-- /Background Image -->

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- number -->
				<div class="col-sm-3 col-xs-6">
					<div class="number">
						<i class="fa fa-users"></i>
						<h3 class="white-text"><span class="counter">999+</span></h3>
						<span class="white-text">建站 天数</span>
					</div>
				</div>
				<!-- /number -->

				<!-- number -->
				<div class="col-sm-3 col-xs-6">
					<div class="number">
						<i class="fa fa-trophy"></i>
						<h3 class="white-text"><span class="counter">999+</span></h3>
						<span class="white-text">客户 人数</span>
					</div>
				</div>
				<!-- /number -->

				<!-- number -->
				<div class="col-sm-3 col-xs-6">
					<div class="number">
						<i class="fa fa-coffee"></i>
						<h3 class="white-text"><span class="counter">999+</span></h3>
						<span class="white-text">建站 总数</span>
					</div>
				</div>
				<!-- /number -->

				<!-- number -->
				<div class="col-sm-3 col-xs-6">
					<div class="number">
						<i class="fa fa-file"></i>
						<h3 class="white-text"><span class="counter">999+</span></h3>
						<span class="white-text">消费 金额</span>
					</div>
				</div>
				<!-- /number -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Numbers -->


	<!-- Footer -->
	<footer id="footer" class="sm-padding bg-dark">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<div class="col-md-12">



					<!-- footer copyright -->
					<div class="footer-copyright">
						<p>Copyright © 2019 All Rights Reserved. Designed by  <?php echo $config['footer']?></p>
					</div>
					<!-- /footer copyright -->

				</div>

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</footer>
	<!-- /Footer -->

	<!-- Back to top -->
	<div id="back-to-top"></div>
	<!-- /Back to top -->

	<!-- Preloader -->
	<div id="preloader">
		<div class="preloader">
			<span></span>
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>
	<!-- /Preloader -->

	<!-- jQuery Plugins -->
	<script type="text/javascript" src="./assets/aladdin8/js/jquery.min.js"></script>
	<script type="text/javascript" src="./assets/aladdin8/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./assets/aladdin8/js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="./assets/aladdin8/js/jquery.magnific-popup.js"></script>
	<script type="text/javascript" src="./assets/aladdin8/js/main.js"></script>

</body>

</html>
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->