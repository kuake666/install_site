<!DOCTYPE html>
<html lang="zxx">

<head>
     <title><?=$config['title']?>-<?=$config['titles']?></title>   
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="<?=$config['keywords']?>">          
    <meta name="description" content="<?=$config['description']?> ">
   
    <!-- Custom Theme files -->
    <link href="./assets/aladdin9/css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="./assets/aladdin9/css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- navigation -->
    <link href="assets/aladdin9/css/nav.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="assets/aladdin9/css/font-awesome.min.css" rel="stylesheet">
    <!-- online-fonts -->
    
</head>

<body>
    <div id="home">
        <!-- header -->
        <header>
            <div class="container">
                <div class="header d-lg-flex justify-content-between align-items-center">
                    <div class="header-wthree">
                        <h1>
                            
                                <span class="fa fa-ioxhost" aria-hidden="true"></span>ALADDIN
                            </a>
                        </h1>
                    </div>
                    <div class="nav_w3ls">
                        <nav>
                            <input class="menu-btn" type="checkbox" id="menu-btn" />
                            <label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
                            <ul class="menu">
                                <li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li>
                                <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                                <li class="nav-item"><a class="nav-link" href="#services">Features</a></li>
                                 <li class="nav-item"><a class="nav-link" href="#plans">Pricing</a></li>
                    

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
        <!-- //header -->
        <!-- banner -->
        <div class="banner">
            <div class="container">
                <div class="banner-text">
                    <div class="slider-info">
                        <h3><?=$config['title']?></h3>
                        <span class="line"></span>
                        <p>新一代建站系统</p></p>
                        <a class="btn bg-theme mt-4 w3_pvt-link-bnr scroll bg-theme" href="<?=$custom_template?>/Login.php" role="button">了解一下</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- //banner -->
    </div>
    <!--  about -->
    <section class="wthree-slide-btm pt-lg-5" id="about">
        <div class="container pt-sm-5 pt-4">
            <div class="title-desc text-center pb-3 pb-lg-5 mb-lg-5">
                <h3 class="main-title-w3pvt">about us</h3>
                <p>Inspired By Passion. Driven By Results.</p>
            </div>
            <div class="row flex-row-reverse no-gutters">
                <div class="col-lg-5">
                    <div class="ab-banner">
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="bg-abt">
                        <div class="container">
                            <div class="title-desc  pb-sm-3">
                                <h4 class="main-title-w3pvt">Creative Thoughts</h4>
                                <p>Inspired By Passion. Driven By Results.</p>
                            </div>
                            <div class="row flex-column mt-lg-4 mt-3">
                                <div class="abt-grid">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <div class="abt-icon">
                                                <span class="fa fa-ravelry"></span>
                                            </div>
                                        </div>
                                        <div class="col-sm-9 pl-sm-0">
                                            <div class="abt-txt ml-sm-0">
                                                <h4>sanctus takimata </h4>
                                                <p>Lo sea takimata sanctus est Lorem ipolor sit amet, no sea takimata
                                                    sanctus est Loremsum dolor sit amet.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="abt-grid mt-4 pt-lg-2">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <div class="abt-icon">
                                                <span class="fa fa-laptop"></span>
                                            </div>
                                        </div>
                                        <div class="col-sm-9 pl-sm-0">
                                            <div class="abt-txt ml-sm-0">
                                                <h4>takimata sanctus</h4>
                                                <p>Lo sea takimata sanctus est Lorem ipsum dolorsita.Lorem ipsum dolor
                                                    sit amet,sed diam nonumy eirmod tempor invidunt ut labore et dolore
                                                    magna aliquyam erat, At vero eos et accusam et justo duo dolores et
                                                    ea
                                                    rebum. Lorem ipsum dolor sit amet, no sea takimata sanctus est
                                                    Lorem
                                                    ipsum dolor sit amet. Stet clita kasd gubergren.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="wthree-slide-btm pb-lg-5">
        <div class="container pb-md-5 pb-4">
            <div class="row no-gutters">
                <div class="col-lg-5">
                    <div class="slide-banner">
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="bg-abt ">
                        <div class="container">
                            <div class="title-desc  pb-sm-3">
                                <h4 class="main-title-w3pvt"> Brand Identity</h4>
                                <p>Inspired By Passion. Driven By Results.</p>
                            </div>
                            <div class="row flex-column mt-lg-4 mt-3">
                                <div class="abt-grid">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <div class="abt-icon">
                                                <span class="fa fa-ravelry"></span>
                                            </div>
                                        </div>
                                        <div class="col-sm-9 pl-sm-0">
                                            <div class="abt-txt ml-sm-0">
                                                <h4>sanctus takimata </h4>
                                                <p>Lo sea takimata sanctus est Lorem ipolor sit amet, no sea takimata
                                                    sanctus est Loremsum dolor sit amet.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="abt-grid mt-4 pt-lg-2">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <div class="abt-icon">
                                                <span class="fa fa-laptop"></span>
                                            </div>
                                        </div>
                                        <div class="col-sm-9 pl-sm-0">
                                            <div class="abt-txt ml-sm-0">
                                                <h4>takimata sanctus</h4>
                                                <p>Lo sea takimata sanctus est Lorem ipsum dolorsita.Lorem ipsum dolor
                                                    sit amet,sed diam nonumy eirmod tempor invidunt ut labore et dolore
                                                    magna aliquyam erat, At vero eos et accusam et justo duo dolores et
                                                    ea
                                                    rebum. Lorem ipsum dolor sit amet, no sea takimata sanctus est
                                                    Lorem
                                                    ipsum dolor sit amet. Stet clita kasd gubergren.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //about -->
    <!-- slide -->
    <div class="abt_bottom py-lg-5 bg-theme">
        <div class="container py-sm-4 py-3">
            <h4 class="abt-text text-capitalize text-sm-center">create your outstanding clean and high quality website.</h4>
            <div class="d-sm-flex justify-content-center">
                <a class="btn  mt-4 w3_pvt-link-bnr scroll" href="#contact" role="button">contact
                    us
                </a>
                <a href="#services" class="btn  mt-4 ml-sm-3 w3_pvt-link-bnr">
                    view more</a>
            </div>
        </div>
    </div>
    <!-- //slide -->
    <!-- services -->
    <div class="w3lspvt-about py-md-5 py-5" id="services">
        <div class="container pt-lg-5">
            <div class="title-desc text-center pb-3 pb-lg-5">
                <h3 class="main-title-w3pvt">premium features</h3>
                <p>Inspired By Passion. Driven By Results.</p>
            </div>
            <div class="w3lspvt-about-row row  text-center pt-md-0 pt-5 mt-lg-5">
                <div class="col-lg-4 col-sm-6 w3lspvt-about-grids">
                    <div class="p-md-5 p-sm-3">
                        <span class="fa fa-map-marker"></span>
                        <h4 class="mt-2 mb-3">heading</h4>
                        <p>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut</p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 w3lspvt-about-grids  border-left border-right my-sm-0 my-5">
                    <div class="p-md-5 p-sm-3">
                        <span class="fa fa-check-circle-o"></span>
                        <h4 class="mt-2 mb-3">heading</h4>
                        <p>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut</p>
                    </div>
                </div>
                <div class="col-lg-4 w3lspvt-about-grids">
                    <div class="p-md-5 p-sm-3">
                        <span class="fa fa-paw"></span>
                        <h4 class="mt-2 mb-3">heading</h4>
                        <p>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut</p>
                    </div>
                </div>
            </div>
            <div class="w3lspvt-about-row border-top row text-center pt-md-0 pt-5 mb-lg-5 mt-md-0 mt-5">
                <div class="col-lg-4 col-sm-6 w3lspvt-about-grids">
                    <div class="p-md-5 p-sm-3 col-label">
                        <span class="fa fa-tint"></span>
                        <h4 class="mt-2 mb-3">heading</h4>
                        <p>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut</p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 w3lspvt-about-grids mt-lg-0 mt-md-3 border-left border-right pt-sm-0 pt-5">
                    <div class="p-md-5 p-sm-3 col-label">
                        <span class="fa fa-handshake-o">
                        </span>
                        <h4 class="mt-2 mb-3">heading</h4>
                        <p>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut</p>
                    </div>
                </div>
                <div class="col-lg-4 w3lspvt-about-grids pt-md-0 pt-5">
                    <div class="p-md-5 p-sm-3 col-label">
                        <span class="fa fa-bar-chart"></span>
                        <h4 class="mt-2 mb-3">heading</h4>
                        <p>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //services -->
    <div class="tlinks">Collect from <a href="http://www.cssmoban.com/"  title="网站模板">网站模板</a></div>
    <!-- stats -->
    <section class="w3_stats py-sm-5 py-4" id="stats">
        <div class="container">
            <div class="py-lg-5 w3-stats">
                <h4 class="w3pvt-title">A World of Solutions for your Growing Needs
                </h4>
                <p class="my-4 color-white stat-txt">
                    Vestibulum volutpat non eros ut vulputate. Nunc id risus accumsan Donec mi nulla, auctor
                    nec sem a, ornare auctor mi. Sed
                    mi tortor, commodo a felis in, fringilla tincidunt nulla.</p>
                <div class="row py-4">
                    <div class="col-md-3 col-6">
                        <div class="counter">
                            <span class="fa fa-smile-o"></span>
                            <div class="timer count-title count-number mt-2 color-white">
                                <h6>133</h6>
                            </div>
                            <p class="count-text">Satisfied Clients</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="counter">
                            <span class="fa fa-users"></span>
                            <div class="timer count-title count-number mt-2 color-white">
                                <h6>533</h6>
                            </div>
                            <p class="count-text">Professional Experts</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mt-md-0 mt-4">
                        <div class="counter">
                            <span class="fa fa-database"></span>
                            <div class="timer count-title count-number mt-2 color-white">
                                <h6>243</h6>
                            </div>
                            <p class="count-text">Successful Projects</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mt-md-0 mt-4">
                        <div class="counter">
                            <span class="fa fa-building"></span>
                            <div class="timer count-title count-number mt-2 color-white">
                                <h6>13</h6>
                            </div>
                            <p class="count-text">Our Branches</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- //stats -->
    <!-- pricing plans -->
    <section class="pt-lg-5 py-4" id="plans">
        <div class="container py-md-5">
            <div class="title-desc text-center pb-sm-3">
                <h3 class="main-title-w3pvt">pricing plans</h3>
                <p>Inspired By Passion. Driven By Results.</p>
            </div>
            <div class="row price-row">
                <div class="col-lg-4 col-sm-6 column mb-lg-0 mb-4">
                    <div class="box">
                        <div class="title">
                            <span class="fa fa-gg"></span>
                            <h5>heading</h5>
                        </div>
                        <div class="option">
                            <ul>
                                <li>50 Gb Space</li>
                                <li>5 Domain Names</li>
                                <li>20 Email Address</li>
                                <li>Live Support</li>
                            </ul>
                        </div>
                        <a href="index.html" class="btn w3ls-btn bg-theme1">
                            view more
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 column mb-lg-0 mb-4">
                    <div class="box">
                        <div class="title">
                            <span class="fa fa-money"></span>
                            <h5>heading</h5>
                        </div>
                        <div class="option">
                            <ul>
                                <li>50 Gb Space</li>
                                <li>5 Domain Names</li>
                                <li>20 Email Address</li>
                                <li>Live Support</li>
                            </ul>
                        </div>
                        <a href="index.html" class="btn w3ls-btn bg-theme1">
                            view more
                        </a>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6  mx-auto mt-lg-0 mt-4 column">
                    <div class="box">
                        <div class="title">
                            <span class="fa fa-gg"></span>
                            <h5>heading</h5>
                        </div>
                        <div class="option">
                            <ul>
                                <li>50 Gb Space</li>
                                <li>5 Domain Names</li>
                                <li>20 Email Address</li>
                                <li>Live Support</li>
                            </ul>
                        </div>
                        <a href="index.html" class="btn w3ls-btn bg-theme1">
                            view more
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //pricing plans -->
   
    <!-- testimonials -->
    <div class="testimonials py-lg-5 py-4" id="testi">
        <div class="container">
            <div class="title-desc text-center pb-3 pb-lg-5">
                <h3 class="main-title-w3pvt">testimonials</h3>
                <p>Inspired By Passion. Driven By Results.</p>
            </div>
            <div class="row mt-lg-5">
                <div class="col-lg-4">
                    <div class="testimonials_grid">
                        <div class="testi-text text-center">
                            <p><span class="fa fa-quote-left"></span>Stet clita kasd gubergren, no sea
                                takimata sanctus est Lorem ipsum dolor sit amet<span class="fa fa-quote-right"></span>
                            </p>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <div class="testi-desc">
                                <span class="fa fa-user"></span>
                                <h5>Aliquyam</h5>
                                <p>some text</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonials_grid my-lg-0 my-4">
                        <div class="testi-text text-center">
                            <p><span class="fa fa-quote-left"></span>Stet clita kasd gubergren, no sea
                                takimata sanctus est Lorem ipsum dolor sit amet<span class="fa fa-quote-right"></span>
                            </p>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <div class="testi-desc">
                                <span class="fa fa-user"></span>
                                <h5>Aliquyam</h5>
                                <p>some text</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonials_grid">
                        <div class="testi-text text-center">
                            <p><span class="fa fa-quote-left"></span>Stet clita kasd gubergren, no sea
                                takimata sanctus est Lorem ipsum dolor sit amet<span class="fa fa-quote-right"></span>
                            </p>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <div class="testi-desc">
                                <span class="fa fa-user"></span>
                                <h5>Aliquyam</h5>
                                <p>some text</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-lg-4">
                    <div class="testimonials_grid">
                        <div class="testi-text text-center">
                            <p><span class="fa fa-quote-left"></span>Stet clita kasd gubergren, no sea
                                takimata sanctus est Lorem ipsum dolor sit amet<span class="fa fa-quote-right"></span>
                            </p>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <div class="testi-desc">
                                <span class="fa fa-user"></span>
                                <h5>Takimata</h5>
                                <p>some text</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonials_grid my-lg-0 my-4">
                        <div class="testi-text text-center">
                            <p><span class="fa fa-quote-left"></span>Stet clita kasd gubergren, no sea
                                takimata sanctus est Lorem ipsum dolor sit amet<span class="fa fa-quote-right"></span>
                            </p>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <div class="testi-desc">
                                <span class="fa fa-user"></span>
                                <h5>Takimata</h5>
                                <p>some text</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonials_grid">
                        <div class="testi-text text-center">
                            <p><span class="fa fa-quote-left"></span>Stet clita kasd gubergren, no sea
                                takimata sanctus est Lorem ipsum dolor sit amet<span class="fa fa-quote-right"></span>
                            </p>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <div class="testi-desc">
                                <span class="fa fa-user"></span>
                                <h5>Sanctus</h5>
                                <p>some text</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 
    <div class="text-center py-3">
        <p class="cpy-wthree">Copyright &copy; 2020.Company name All rights reserved.<?php echo $config['footer']?>  </p>
    </div>
    <!-- //footer -->
  
</body>

</html>