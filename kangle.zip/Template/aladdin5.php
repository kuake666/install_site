<!--阿拉丁建站系统-夸克QQ79517721 -->
<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="./assets/aladdin5/img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="codepixer">
	<!-- Meta Description -->
	<meta name="description" content="<?php echo $config['description']?>">
	<!-- Meta Keyword -->
	<meta name="keywords" content="<?php echo $config['keywords']?>">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title><?php echo $config['title']?>-<?php echo $config['titles']?></title>
	<link rel="shortcut icon" href="assets/aladdinlogo/favicon.ico">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,600|Roboto:400,400i,500" rel="stylesheet">
	<!--
			CSS
			============================================= -->
	<link rel="stylesheet" href="./assets/aladdin5/css/linearicons.css">
	<link rel="stylesheet" href="./assets/aladdin5/css/font-awesome.min.css">
	<link rel="stylesheet" href="./assets/aladdin5/css/bootstrap.css">
	<link rel="stylesheet" href="./assets/aladdin5/css/magnific-popup.css">
	<link rel="stylesheet" href="./assets/aladdin5/css/nice-select.css">
	<link rel="stylesheet" href="./assets/aladdin5/css/hexagons.min.css">
	<link rel="stylesheet" href="./assets/aladdin5/css/owl.carousel.css">
	<link rel="stylesheet" href="./assets/aladdin5/css/main.css">
</head>

<body>
	<!-- start header Area -->
	<header id="header">
		<div class="container main-menu">
			<div class="row align-items-center justify-content-between d-flex">
				<div id="logo">
					<a href="index.php"><img src="./assets/aladdinlogo/aladdin.png" alt="" title="" /></a>
				</div>
				<nav id="nav-menu-container">
					<ul class="nav-menu">
						<li class="menu-active"><a href="index.php">首页</a></li>
						<li><a href="./">关于我们</a></li>
						
						
				
					</ul>
				</nav>
			</div>
		</div>
	</header>
	<!-- end header Area -->

	<!-- start banner Area -->
	<section class="home-banner-area">
		<div class="container">
			<div class="row fullscreen d-flex align-items-center justify-content-between">
				<div class="home-banner-content col-lg-6 col-md-6">
					<h1>
						<?php echo $config['title']?>
					</h1>
					<p><?php echo $config['description']?></p>
					<div class="download-button d-flex flex-row justify-content-start">
						<div class="buttons flex-row d-flex">
							
							<div class="desc">
								<a href="<?=$custom_template?>/Reg.php">
									<p>
										<span>立即注册</span> <br>
										
									</p>
								</a>
							</div>
						</div>
						<div class="buttons  flex-row d-flex">
							
							<div class="desc">
								<a href="<?=$custom_template?>/Login.php">
									<p>
										<span>在线登录</span> <br>
										
									</p>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="banner-img col-lg-4 col-md-6">
					<img class="img-fluid" src="https://img.alicdn.com/imgextra/i1/2784095818/O1CN01YSUEaR1sqgpxMgn3F_!!2784095818.jpg" alt="">
				</div>
			</div>
		</div>
	</section>
	<!-- End banner Area -->


	<!-- Start feature Area -->
	<section class="feature-area section-gap-top">
		<div class="container">
			<div class="row d-flex justify-content-center">
				<div class="col-lg-6">
					<div class="section-title text-center">
						<h2>关于我们</h2>
						<p><?php echo $config['description']?>
						</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6">
					<div class="single-feature">
						<a href="#" class="title">
							<span class="lnr lnr-book"></span>
							<h3>一键搭建</h3>
						</a>
						<p>
							用户注册登录后可进行一键搭建网站
						</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="single-feature">
						<a href="#" class="title">
							<span class="lnr lnr-book"></span>
							<h3>轻松管理</h3>
						</a>
						<p>
							网站搭建成功后，您可以一键管理网站
						</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="single-feature">
						<a href="#" class="title">
							<span class="lnr lnr-book"></span>
							<h3>安全保障</h3>
						</a>
						<p>
							重要事件我们会有邮件提示
						</p>
					</div>
				</div>

			</div>

		</div>
	</section>
	<!-- End feature Area -->

	




	
	
		
				
				
				
				
			
		<center>		
Copyright &copy;<script>document.write(new Date().getFullYear());</script>  All rights reserved  <a href="./" target="_blank" title="<?php echo $config['footer']?>"><?php echo $config['footer']?></a> 
      </center>	
				
		
	
	<!-- End Footer Area -->

	<script src="./assets/aladdin5/js/vendor/jquery-2.2.4.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
	 crossorigin="anonymous"></script>
	<script src="./assets/aladdin5/js/tilt.jquery.min.js"></script>
	<script src="./assets/aladdin5/js/vendor/bootstrap.min.js"></script>

	<script src="./assets/aladdin5/js/easing.min.js"></script>
	<script src="./assets/aladdin5/js/hoverIntent.js"></script>
	<script src="./assets/aladdin5/js/superfish.min.js"></script>
	<script src="./assets/aladdin5/js/jquery.ajaxchimp.min.js"></script>
	<script src="./assets/aladdin5/js/jquery.magnific-popup.min.js"></script>
	<script src="./assets/aladdin5/js/owl.carousel.min.js"></script>
	<script src="./assets/aladdin5/js/owl-carousel-thumb.min.js"></script>
	<script src="./assets/aladdin5/js/hexagons.min.js"></script>
	<script src="./assets/aladdin5/js/jquery.nice-select.min.js"></script>
	<script src="./assets/aladdin5/js/waypoints.min.js"></script>
	<script src="./assets/aladdin5/js/mail-script.js"></script>
	<script src="./assets/aladdin5/js/main.js"></script>
</body>

</html>
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->