<!--阿拉丁建站系统-夸克QQ79517721 -->
<!DOCTYPE html>
<html>
<head>

<!-- /.website title -->
   <link rel="icon" href="assets/aladdinlogo/favicon.ico" />
<title><?php echo $config['title']?>-<?php echo $config['titles']?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
 <meta name="keywords" content="<?php echo $config['keywords']?>">          
        <meta name="description" content="<?php echo $config['description']?>">
 <link rel="shortcut icon" href="./assets/aladdinlogo/favicon.ico">
<!-- CSS Files -->
<link href="./assets/aladdin3/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="./assets/aladdin3/css/font-awesome.min.css" rel="stylesheet">
<link href="./assets/aladdin3/fonts/icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet">
<link href="./assets/aladdin3/css/animate.css" rel="stylesheet" media="screen">
<link href="./assets/aladdin3/css/owl.theme.css" rel="stylesheet">
<link href="./assets/aladdin3/css/owl.carousel.css" rel="stylesheet">
 
<link href="./assets/aladdin3/css/styles.css" rel="stylesheet" media="screen">    

<!-- Google Fonts --> 
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Alegreya+Sans:100,300,400,700' rel='stylesheet' type='text/css'>


<!-- Font Awesome -->
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> 
</head>
  
<body data-spy="scroll" data-target="#navbar-scroll">
 
 <div id="top"></div>

<!-- NAVIGATION -->
<div id="menu">
	<nav class="navbar-wrapper navbar-default" role="navigation">
		<div class="container">
			  <div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-themers">
				  <span class="sr-only">Toggle navigation</span>
				  <span class="icon-bar"></span>
				  <span class="icon-bar"></span>
				  <span class="icon-bar"></span>
				</button>
				<a class="navbar-brand site-name" href="#top"><img src="./assets/aladdinlogo/aladdin.png" alt="logo"></a>
			  </div>
	 
			  <div id="navbar-scroll" class="collapse navbar-collapse navbar-themers navbar-right">
				<ul class="nav navbar-nav">
					<li><a href="./">首页</a></li>
					<li><a href="<?=$custom_template?>/Login.php">在线登录</a></li>
					<li><a href="<?=$custom_template?>/Reg.php">在线注册</a></li>
					
				</ul>
			  </div>
		</div>
	</nav>
</div>

<!-- /.parallax full screen background image -->
<div class="fullscreen landing parallax banner" style="background-image:url('images/bg.jpg');" data-img-width="2000" data-img-height="1325" data-diff="100">
	
	<div class="overlay">
		<div class="container">
			<div class="row">
				
				
				
				<div class="col-md-6">
				
						<!-- /.main title -->
						<h1 class="wow fadeInLeft">
						<?php echo $config['title']?>
						</h1>

					<!-- /.header paragraph -->
					<div class="landing-text wow fadeInLeft">
						<p><?php echo $config['description']?></p>
					</div>				  

					<!-- /.header button -->
					<div class="head-btn wow fadeInLeft">
						<a href="<?=$custom_template?>/Login.php" class="btn-primary app-store">
						 <span> 在线登录</span>
						</a>
						<a href="<?=$custom_template?>/Reg.php" class="btn-primary play-market">
						<span> 在线注册</span>
						</a>
					</div>
	
					 				

				</div> 
				
				<!-- /.phone image -->
				<div class="col-md-6">
				<img src="./assets/aladdin3/images/header-phone.png" alt="phone" class="header-phone img-responsive wow fadeInRight">
				</div>
			</div>
		</div> 
	</div> 
</div>
   
<!-- /.intro section -->
<div id="intro">
		<div class="container">
		<div class="row">
	
	<!-- /.feature image -->
			<div class="col-md-6 feature-2-pic wow fadeInLeft">
				<img src="./assets/aladdin3/images/feature2-image.jpg" alt="image" class="img-responsive">
			</div>	
			
			<!-- /.feature content -->
			<div class="col-md-6 wow fadeInRight">
				<h2><?php echo $config['title']?></h2>
				<p><?php echo $config['description']?>
				</p>

					<div class="btn-section"><a href="<?=$custom_template?>/Reg.php" class="btn-default">在线注册</a></div>
		
			</div>
			 			  
		</div>			  
  
	</div>
</div>

<!-- /.feature section -->
<div id="feature">
	<div class="container">
		<div class="row">
			<div class="col-md-10 col-md-offset-1 col-sm-12 text-center feature-title">

			<!-- /.feature title -->
				<h2>关于<?php echo $config['title']?></h2>
				<p>支持多种网站在线搭建安全快速稳定.</p>
			</div>
		</div>
		<div class="row row-feat">
			
			<div class="col-md-12">

				<!-- /.feature 1 -->
				<div class="col-sm-4 feat-list">
					<i class="fa fa-paint-brush wow fadeInUp"></i>
					<div class="inner">
						<h4>一站式管理</h4>
						<p>无需购买主机无需技术，注册登陆后充值搭建即可使用，您可以随时在电脑/手机/平板登陆本网站进行功能设置.
						</p>
					</div>
				</div>
			
				<!-- /.feature 2 -->
				<div class="col-sm-4 feat-list">
					<i class="fa fa-rss wow fadeInUp" data-wow-delay="0.2s"></i>
					<div class="inner">
						<h4>数据安全</h4>
						<p>采用阿里云RDS云数据库，数据加密储存，抵抗各种注入破解，保证每一位用户的账号数据安全！</p>
					</div>
				</div>
			
				<!-- /.feature 3 -->
				<div class="col-sm-4 feat-list"> 
					<i class="fa fa-recycle wow fadeInUp" data-wow-delay="0.4s"></i>
					<div class="inner">
						<h4>分布式服务器</h4>
						<p>分布式服务器全天24H处理业务，客户站点所在服务器为托管于宿迁优质高防机房实体服务器，保障业务正常运营..</p>
					</div>
				</div>
			
				
			</div>
		</div>
	</div>
</div>







<!-- /.footer -->
<footer id="footer">
	<div class="container">
		<div class="col-sm-4 col-sm-offset-4">
			<!-- /.social links -->

			<div class="text-center wow fadeInUp" style="font-size: 14px;">Copyright &copy; 2019 <a href="/" target="_blank" ><?php echo $config['footer']?></a> -</div>
			<a href="#" class="scrollToTop"><i class="fa fa-arrow-circle-o-up"></i></a>
		</div>	
	</div>	
</footer>
	
	<!-- /.javascript files -->
    <script src="./assets/aladdin3/js/jquery.js"></script>
    <script src="./assets/aladdin3/js/bootstrap.min.js"></script>
    <script src="./assets/aladdin3/js/custom.js"></script>
    <script src="./assets/aladdin3/js/jquery.sticky.js"></script>
	<script src="./assets/aladdin3/js/wow.min.js"></script>
	<script src="./assets/aladdin3/js/owl.carousel.min.js"></script>
	<script src="./assets/aladdin3/js/ekko-lightbox-min.js"></script>
	<script type="text/javascript">
	$(document).delegate('*[data-toggle="lightbox"]', 'click', function(event) { event.preventDefault(); $(this).ekkoLightbox(); }); 
	</script>
	<script>
		new WOW().init();
	</script>
  </body>
</html>
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->