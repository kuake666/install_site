﻿<!--阿拉丁建站系统-夸克QQ79517721 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="webkit"/>
    <title><?php echo $config['title']?>-<?php echo $config['titles']?></title>
    <meta name="keywords" content="<?php echo $config['keywords']?>" />
    <meta name="description" content="<?php echo $config['description']?>" />
    <link rel="shortcut icon" href="./assets/aladdinlogo/favicon.ico">
    <link rel="stylesheet" href="./assets/aladdin6/css/qietu.css">
    <link rel="stylesheet" href="./assets/aladdin6/css/animate.min.css">
    <link rel="stylesheet" href="./assets/aladdin6/css/iconfont.css">
    <link rel="stylesheet" href="./assets/aladdin6/css/style.css">
    <link rel="stylesheet" href="./assets/aladdin6/css/responsive.css"/>
    <link rel="stylesheet" href="./assets/aladdin6/css/owl.carousel.min.css">
    <link rel="stylesheet" href="./assets/aladdin6/css/animate.css">
    <script src="./assets/aladdin6/js/jquery-1.7.2.min.js" type="text/javascript" charset="utf-8"></script>
    
</head>
<body>


<!--头部-->
<div class="hbannerbg">
    <div class="header">
    <div class="wrapper">
        <div class="header-logo">
            <a href="/"><img src="./assets/aladdinlogo/aladdin.png"/></a>
        </div>
        <div class="nav-wp">
            <div class="nav">
                                <div class="nav-item <if condition='$vo.target == 1'>on</if>"><a href="/">网站首页</a></div>
                                
                                <div class="nav-item <if condition='$vo.target == 1'>on</if>"><a href="">关于我们</a></div>
                              
                            </div>
            <div class="header-btn">
                                <a href="<?=$custom_template?>/Login.php">登录</a>
                <a class="b-fff" href="<?=$custom_template?>/Reg.php">注册</a>
                            </div>
        </div>
        <div class="gh">
            <a href="#"></a>
        </div>
    </div>
</div>
    <!-- //头部 -->
    <div class="hbanner">
        <div class="wrapper">
            <div class="hbanner-txt">
                <div class="hbanner-txt-tit">
                    <h2><?php echo $config['title']?></h2>
                    <p class="en">-New Experience-</p>
                </div>
                <div class="hbanner-txt-desc">
                   <?php echo $config['description']?>
                </div>
                <a class="hbanner-txt-btn" href="<?=$custom_template?>/Login.php">立即加入<i class="iconfont icon-jiantou24"></i> </a>
            </div>
            <div class="hbanner-img">
                <img src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01g2bUCQ1sqgq0Ey1Ne_!!2784095818.jpg"/>
            </div>
        </div>
    </div>
</div>

<div class="h-who">
    <div class="wrapper">
        <div class="h-tit">
            <h2>我们是谁？</h2>
            <p class="en">-who are we?-</p>
        </div>
        <div class="h-who-img">
            <img src="https://img.alicdn.com/imgextra/i1/2784095818/O1CN01HXJmvd1sqgpzcU3jJ_!!2784095818.jpg"/>
        </div>
        <div class="h-who-main">
            <div class="h-txt">
                <h3 class="b-red">致力于为用户提供一站式服务的创新型未来互联网企业</h3>
                <div class="h-txt-desc">
                    <p><?php echo $config['title']?>是一家专注于移动互联网领域，致力于为用户提供便捷式应用程序的创新型未来互联网企业。</p>
                    <p><?php echo $config['title']?>为简约风格，应用程序使用简单，界面排版简约明了。用极客精神做产品，用互联网思维为用户提供更好的服务是我们的初衷。</p>
                </div>
                <a class="h-btn" href="<?=$custom_template?>/Reg.php">立即注册</a>
            </div>
        </div>
    </div>
</div>

<div class="h-core">
    <div class="wrapper">
        <div class="h-tit">
            <h2>核心优势技术实力</h2>
            <p class="en">-core advantages-</p>
        </div>
        <div class="h-core-list">
            <ul>
                <li>
                    <div class="icon">
                        <i class="iconfont icon-dingdan"></i>
                    </div>
                    <div class="line line1"></div>
                    <div class="txt">
                        <h3>轻松注册</h3>
                        <p>在线注册一键登录</p>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <i class="iconfont icon-fabu"></i>
                    </div>
                    <div class="line line2"></div>
                    <div class="txt">
                        <h3>轻松搭建</h3>
                        <p>轻松一键搭建网站，简单快捷</p>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <i class="iconfont icon-Automaticdelivery"></i>
                    </div>
                    <div class="line line3"></div>
                    <div class="txt">
                        <h3>网站过户</h3>
                        <p>信誉无忧充分保障</p>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <i class="iconfont icon-bangding"></i>
                    </div>
                    <div class="line line4"></div>
                    <div class="txt">
                        <h3>绑定邮箱</h3>
                        <p>重要信息邮件提示</p>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <i class="iconfont icon-quanqiu"></i>
                    </div>
                    <div class="line line5"></div>
                    <div class="txt">
                        <h3>服务全球</h3>
                        <p>全国用户遥遥领先</p>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <i class="iconfont icon-lightningshandian"></i>
                    </div>
                    <div class="line line6"></div>
                    <div class="txt">
                        <h3>极速响应</h3>
                        <p>全天候10秒响应服务</p>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <i class="iconfont icon-iconset0344"></i>
                    </div>
                    <div class="line line7"></div>
                    <div class="txt">
                        <h3>持续更新</h3>
                        <p>系统持续更新，功能持续完善</p>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <i class="iconfont icon-anquanbaozhang1"></i>
                    </div>
                    <div class="line line8"></div>
                    <div class="txt">
                        <h3>安全保障</h3>
                        <p>宿迁高防服务器为您服务</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>



<div class="h-core-item h-core-item-even">
    <div class="wrapper">
        <div class="img">
            <img src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01UngafU1sqgpwdZgje_!!2784095818.jpg"/>
        </div>
        <div class="h-txt">
            <h3 class="b-green">服务器安全有保障</h3>
            <div class="h-txt-desc">
                <p>采用群集服务器，防御高，故障率低，无论用户身在何处，均能获得流畅安全可靠的体验，全天候10秒响应服务打造强悍性能防御 技术服务支撑极速响应。</p>
            </div>
            <a class="h-btn" href="<?=$custom_template?>/Login.php">了解更多</a>
        </div>

    </div>
</div>

<div class="h-core-item h-core-item-bj">
    <div class="wrapper">
        <div class="img">
            <img src="https://img.alicdn.com/imgextra/i1/2784095818/O1CN012kXX7a1sqgpxMu11Y_!!2784095818.jpg"/>
        </div>
        <div class="h-txt">
            <h3 class="b-blue">终身陪伴稳定发展</h3>
            <div class="h-txt-desc">
                <p>服务器集群部署，多重安全保证，是您创业路上的好帮手！ 系统持续更新，功能持续完善，让商户以及客户的体验不断接近完美是我们一直不变的追求。</p>
            </div>
            <div class="h-txt-list">
                <p><i class="iconfont icon-xuanze"></i>搞标准的代码写法，系统安全</p>
                <p><i class="iconfont icon-xuanze"></i>极速售后响应，无后顾之忧</p>
                <p><i class="iconfont icon-xuanze"></i>不断的迭代更新，功能更全</p>
            </div>
            <a class="h-btn" href="<?=$custom_template?>/Login.php">了解更多</a>
        </div>
    </div>
</div>

<div class="h-pay">
    <div class="h-pay-bj"></div>
    <div class="wrapper">
        <div class="h-tit">
            <h2>多种渠道支付</h2>
            <p class="en">-Channel payment-</p>
        </div>
        <div class="h-pay-list">
            <ul>
                <li>
                    <img src="https://img.alicdn.com/imgextra/i3/2784095818/O1CN01sPJMCD1sqgpwdevSx_!!2784095818.jpg"/>
                    <p>支付宝</p>
                </li>
                <li>
                    <img src="https://img.alicdn.com/imgextra/i4/2784095818/O1CN01jQAeK31sqgpzcdafB_!!2784095818.jpg"/>
                    <p>微信</p>
                </li>
                <li>
                    <img src="https://img.alicdn.com/imgextra/i2/2784095818/O1CN01xUYpxt1sqgpwdeFsb_!!2784095818.jpg"/>
                    <p>QQ</p>
                </li>

                <li>
                    <img src="https://img.alicdn.com/imgextra/i2/2784095818/O1CN019wWLug1sqgpvkAPuk_!!2784095818.jpg"/>
                    <p>京东</p>
                </li>
              
            </ul>
        </div>
    </div>
</div>

<div class="h-contact">
    <div class="wrapper">
        <div class="h-tit">
            <h2>联系我们</h2>
            <p class="en">-CONTACT US-</p>
        </div>
        <div class="h-contact-main">
            <div class="txt">
                <!--<div class="txt-item">-->
                    <!--<span><i class="iconfont icon-qq"></i>企业QQ ：</span>-->
                    <!--79517721-->
                <!--</div>-->
                <div class="txt-item">
                    <span><i class="iconfont icon-qq"></i>客服QQ ：</span>
                    <?php echo $config['kfqq']?>            </div>
                
                <div class="txt-item">
                    <span><i class="iconfont icon-htmal5icon05"></i>联系邮箱：</span>
                     <?php echo $config['kfqq']?> @qq.com                </div>
               
            
        </div>
    </div>
</div>
<div class="h-serve">
    <div class="wrapper">
        <div class="h-serve-tip">
            <h3>为您提供一站式虚拟商品在线购买以及全自动发货服务!</h3>
            <div class="close"></div>
            <p>采用群集式服务器，防御高，故障率低，无论用户身在何处，均能获得100%流畅安全可靠的体验。</p>
            <a class="h-btn" href="<?=$custom_template?>/Login.php">立即联系</a>
        </div>
    </div>
</div>



<!--底部-->
<div class="footer">

    <div class="footer-logo">
        <a href="#"><img src="./assets/aladdinlogo/aladdin.png"/></a>
    </div>
    <div class="copyright">
        <p>Copyright <?php echo $config['footer']?> All rights reserved.</p>
        
    </div>
</div>
<!--//底部-->


<script src="./assets/aladdin6/js/wow.min.js" type="text/javascript" charset="utf-8"></script>
<script src="./assets/aladdin6/js/script.js" type="text/javascript" charset="utf-8"></script>
<script src="./assets/aladdin6/js/layer.js"></script>
<script src="./assets/aladdin6/js/owl.carousel.min.js"></script>
<script src="./assets/aladdin6/js/owl.carousel.min.js"></script>




</body>
</html>

<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
<!-- 阿拉丁建站系统|作者QQ：79517721 -->
