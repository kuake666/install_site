<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------


$title = "控制台";
include("../Includes/Common.php");


include("./Head.php");

if (!$islogin){
    echo "<script type='text/javascript'>layer.alert('您好，您还未登录账号呢,请先进行登录',{icon:5},function(){window.location.href='./Login.php'});</script>";
    exit();
}

if ($userrow['active'] == 0){
    setcookie("kuake_sid", "", time() - 3600*12,'/');
    echo "<script type='text/javascript'>layer.alert('您好，该账号已被封禁,暂时无法使用',{icon:5},function(){window.location.href='./Login.php'});</script>";
    exit();
}

$days = ceil((time() - strtotime($config['buildtime'] ? $config['buildtime'] : date("Y-m-d"))) / 86400);
$allprogram=ceil($db->count("SELECT count(*) FROM kuake_program WHERE onsale=1"));
$usersite=ceil($db->count("SELECT count(*) FROM kuake_site WHERE user='".$userrow['user']."'"));

$getResult = update();

?>
<?php require './Aside.php';?>
<main id="main-container"><div class="content">
        <div class="row gutters-tiny invisible" data-toggle="appear">
            <div class="col-6 col-xl-3">
                <a class="block block-link-shadow text-right" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-puzzle fa-3x text-body-bg-dark"></i>
                        </div>
                        <div class="font-size-h3 font-w600"><span data-toggle="countTo" data-speed="1000" data-to="<?php echo $allprogram;?>">0</span>套</div>
                        <div class="font-size-sm font-w600 text-uppercase text-muted">平台网站程序总数</div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-xl-3">
                <a class="block block-link-shadow text-right" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-grid fa-3x text-body-bg-dark"></i>
                        </div>
                        <div class="font-size-h3 font-w600"><span data-toggle="countTo" data-speed="1000" data-to="<?php echo $usersite;?>">0</span>个</div>
                        <div class="font-size-sm font-w600 text-uppercase text-muted">您所搭建网站数量</div>
                    </div>
                </a>
            </div>



            <div class="col-6 col-xl-3">
                <a class="block block-link-shadow text-right" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-wallet fa-3x text-body-bg-dark"></i>
                        </div>
                        <div class="font-size-h3 font-w600"><?php echo $userrow['money']?>元</div>
                        <div class="font-size-sm font-w600 text-uppercase text-muted">您的可用余额</div>
                    </div>
                </a>
            </div>


            <div class="col-6 col-xl-3">
                <a class="block block-link-shadow text-right" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-envelope-open fa-3x text-body-bg-dark"></i>
                        </div>
                        <div class="font-size-h3 font-w600"><span data-toggle="countTo" data-speed="1000" data-to="<?php echo $days?>">0</span>天</div>
                        <div class="font-size-sm font-w600 text-uppercase text-muted">平台已稳定运行</div>
                    </div>
                </a>
            </div>

        </div>

        <!--平台公告 START-->
        <div class="row gutters-tiny invisible" data-toggle="appear">
            <div class="col-md-12">
                <div class="block">
                    <div class="block-header block-header-default">
                        <h3 class="block-title">平台公告&nbsp;&nbsp;<?php if($config['updatetip']==1 and $userrow['uid']==1 and $getResult['ver'] > VER){ ?>
                                <font color="red">有新版版本!&nbsp;<a href ="./Update.php">点我更新</a><p></font> <?php }?></h3>

                    </div>
                    <div class="block-content">
                        <?php echo $config['sygg']?>



                    </div>
                </div>
            </div>
            <!--平台公告 END-->


        </div>
</main>
<?php require './Aside.php';?>

<footer id="page-footer" class="opacity-0">

    <div class="content py-20 font-size-xs clearfix">
        <div class="float-none ">
            <center>
                <a class="font-w600" href="#" target="_blank"><?=$config['footer']?>V<?php echo VERSION;?></a> &copy; <span class="js-year-copy"></span></center>
        </div>

</footer></div><script src="assets/js/codebase-1.2.min.js"></script><script src="assets/js/plugins/chartjs/Chart.bundle.min.js"></script>

<script>
    var audio=document.createElement('audio');
    var play = function (s) {
        var URL = 'https://fanyi.baidu.com/gettts?lan=zh&text=' + encodeURIComponent(s) + '&spd=5&source=web'

        if(!audio){
            audio.controls = false
            audio.src = URL
            document.body.appendChild(audio)
        }
        audio.src = URL
        audio.play();
    }

    <?php if($config['voiceactive']==1){?>
    play('<?php
    if(version_compare(PHP_VERSION,'5.4', '<')){
        echo '您的PHP版本不符合建站系统要求，请管理员检查环境！';
    }elseif (version_compare(PHP_VERSION,'5.7', '>')) {
        echo '您的PHP版本不符合建站系统要求，请管理员检查环境！';
    }else{
        $voice=$config['voice'];
        $voice=str_replace('{title}',$config['title'],$voice);//网站标题
        $voice=str_replace('{titles}',$config['titles'],$voice);//网站副标题
        $voice=str_replace('{peie}',$userrow['money'],$voice);//登录用户的余额
        if($userrow['active']==10){//用户的权限
            $voice=str_replace('{per}','超级管理员',$voice);
        }else if($userrow['active']==1){
            $voice=str_replace('{per}','普通用户',$voice);
        }else if($userrow['active']==2){
            $voice=str_replace('{per}','初级代理',$voice);
        }else if($userrow['active']==3){
            $voice=str_replace('{per}','中级代理',$voice);
        }else if($userrow['active']==4){
            $voice=str_replace('{per}','高级代理',$voice);
        }else{
            $voice=str_replace('{per}','未知用户',$voice);
        }
        echo $voice;
    }
    ?>
    ');
    <?php }?>
</script>
</body>
</html>