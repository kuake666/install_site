<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------



require_once("../Includes/Common.php");

if(!defined('EPAPI_NULL')){
  $sever=$db->get_row("SELECT * FROM kuake_sever WHERE 1 ");
 
  if(!$sever ){
	 if($config['eplock']==1){
         $db->query("UPDATE kuake_config SET value='0' WHERE vkey='eplock'");
	 }
		exit("<script language='javascript'>alert('请先配置对接服务器!');window.location.href='ApiSet.php';</script>");

	}
}


$usersite=ceil($db->count("SELECT count(*) FROM kuake_site WHERE user='".$userrow['user']."'"));

  
?>
<!doctype html>
<!--[if lte IE 9]>     <html lang="en" class="no-focus lt-ie10 lt-ie10-msg"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="en" class="no-focus"> <!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title><?php echo $config['title'];?></title>
<meta name="description" content="建站系统控制台">
<link rel="shortcut icon" href="./assets/img/favicons/favicon.png">
<link rel="icon" type="image/png" sizes="192x192" href="./assets/img/favicons/favicon-192x192.png">
<link rel="apple-touch-icon" sizes="180x180" href="./assets/img/favicons/apple-touch-icon-180x180.png">
<link rel="stylesheet" id="css-main" href="./assets/css/codebase-1.2.min.css">
<link rel="stylesheet" id="css-main" href="./assets/css/card.css">
<style>
	.geektestshow {
		display: block;
	}
	.geektesthide {
		display: none;
	}
	#geektestnotice {
		color: red;
	}
</style>
</head>
<body><div id="page-container" class="sidebar-o side-scroll page-header-modern main-content-boxed">
<nav id="sidebar">
<div id="sidebar-scroll">
<div class="sidebar-content">
<div class="content-header content-header-fullrow px-15">
<div class="content-header-section sidebar-mini-visible-b">
<span class="content-header-item font-w700 font-size-xl float-left animated fadeIn">
<span class="text-dual-primary-dark">c</span><span class="text-primary">b</span>
</span>
</div>
<div class="content-header-section text-center align-parent sidebar-mini-hidden">
<button type="button" class="btn btn-circle btn-dual-secondary d-lg-none align-v-r" data-toggle="layout" data-action="sidebar_close">
<i class="fa fa-times text-danger"></i>
</button>
<div class="content-header-item">
<a class="link-effect font-w700" href="index.php">
<i class="si si-fire text-primary"></i>
<span class="font-size-xl text-dual-primary-dark">建站系统</span><span class="font-size-xl text-primary">控制台</span>
</a>
</div>
</div>
</div>
<div class="content-side content-side-full content-side-user px-10 align-parent">
<div class="sidebar-mini-visible-b align-v animated fadeIn">
<img class="img-avatar img-avatar32" src="./assets/img/avatars/avatar15.jpg" alt="">
</div>
<div class="sidebar-mini-hidden-b text-center">
<a class="img-link">
<?php if($userrow['qq'] == null){ ?>
<img  class="img-avatar" src="//q4.qlogo.cn/headimg_dl?dst_uin=79517721&spec=100" alt="<?php echo $userrow['qq'];?>">
<?php	}else { ?>
<img class="img-avatar" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $userrow['qq'] ?>&spec=100" alt="<?php echo $userrow['qq'];?>">
<?php } ?>
  
</a>
<ul class="list-inline mt-10">
<li class="list-inline-item">
<a class="link-effect text-dual-primary-dark font-size-xs font-w600 text-uppercase"><?php echo $userrow['name'];?></a>
</li>
<li class="list-inline-item">
<a class="link-effect text-dual-primary-dark" data-toggle="layout" data-action="sidebar_style_inverse_toggle" href="javascript:void(0)">
<i class="si si-drop"></i>
</a>
</li>
<li class="list-inline-item">
<a class="link-effect text-dual-primary-dark" href="./Login.php?logout">
<i class="si si-logout"></i>
</a>
</li>
</ul>
</div>
</div>
<div class="content-side content-side-full">
<ul class="nav-main">
<li>
<a href="index.php"><i class="si si-home"></i>首页</a></a>
</li>

<li><?php if ($userrow['uid'] == 1){?>
<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-wrench"></i><span class="sidebar-mini-hide">系统设置</span></a>
<ul>
<li>
<a href="Set.php">网站设置</a>
<a href="ApiSet.php">对接设置</a>
<a href="Payset.php">支付设置</a>
<a href="AgentSet.php">代理设置</a>
<a href="Notice.php">公告设置</a>
<a href="Update.php">系统更新</a>
<a href="About.php">常见问题</a>
</li>
</ul>
</li>
</li>
<?php } ?>	



<li><?php if ($userrow['uid'] == 1){?>
<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-puzzle"></i><span class="sidebar-mini-hide">系统管理</span></a>
<ul>
<li>
<a href="AdminWebSet.php">分站管理</a>
<a href="CashOrder.php">分站提现</a>
<a href="Webph.php">分站排行</a>
<a href="AdminSiteList.php">站点管理</a>
<a href="Program.php">程序管理</a>
<a href="UserList.php">用户管理</a>
<a href="KmSet.php">卡密管理</a>
<a href="AdminWorkOrder.php">工单管理</a>
<a href="AdminOrder.php">充值记录</a>
</li>
</ul>
</li>
</li>
<?php } ?>	


<li><?php if ($userrow['openweb'] == 1){?>
<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-users"></i><span class="sidebar-mini-hide">分站后台</span></a>
<ul>
<?php if ($config['webagentactive'] == 1){?><a href="WebAddAgent.php">添加代理</a><?php } ?> 
<?php if ($config['webcash'] == 1){?><a href="WebCash.php">分站提现</a><?php } ?> 
<a href="WebSet.php">站点信息</a>
</li>
</ul>
</li>
<?php } ?>	

<li>
<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-grid"></i><span class="sidebar-mini-hide">站点管理</span></a>
<ul>
<li>
<a href="AddSite.php">搭建网站</a>
<a href="SiteList.php">网站列表</a>
<?php if ($config['transferactive'] == 1){?><a href="Transfer.php">网站过户</a><?php } ?> 

</li>
</ul>
</li>




<li><?php if ($config['hostactive']==1){?>

<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-credit-card"></i><span class="sidebar-mini-hide">虚拟主机</span></a>
<ul>
<li>
<?php if ($userrow['uid'] == 1){?><a href="HostSever.php">主机对接</a><?php } ?> 

<?php if ($userrow['uid'] == 1){?><a href="HostLb.php">主机管理</a><?php } ?> 

<?php if ($userrow['uid'] == 1){?><a href="AdminHostList.php">管理主机</a><?php } ?> 
<a href="AddHost.php">购买主机</a>
<a href="HostList.php">主机记录</a>
</li>
</ul>
</li>
	<?php } ?>	


<li>
<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-users"></i><span class="sidebar-mini-hide">账号管理</span></a>
<ul>
<a href="Information.php">个人信息</a>
<?php if ($config['agentactive'] == 1){?><a href="UpdateAgent.php">升级代理</a><?php } ?> 
<a href="SetPwd.php">修改密码</a>



</li>
</ul>
</li>
<li>
<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-wallet"></i><span class="sidebar-mini-hide">我的钱包</span></a>
<ul>
<li>
<a href="Balance.php">账户余额</a>
<a href="Recharge.php">在线充值</a>
<?php if ($config['kmactive'] == 1){?><a href="Kmcharge.php">卡密充值</a><?php } ?> 
<a href="Order.php">充值记录</a>
</li>
</ul>
</li>


 <li><?php if ($userrow['openweb'] != 1 and $config['webactive']==1){?>

<a href="OpenWeb.php" class="waves-effect"><i class="si si-key"></i><span><b>搭建分站</b></span>
 <span class="right badge badge-danger">New</span></a>
 </li><?php } ?>
 
	
<li><?php if ($config['invite'] == 1){?>
<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-share"></i><span class="sidebar-mini-hide">我的推广</span></a>
<ul>
<li>
<a href="Invite.php">推广链接</a>
</li>
<li>
<a href="InviteList.php">推广记录</a>
</li>
</ul>
</li>
<?php } ?> 


<li>
<a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-briefcase"></i><span class="sidebar-mini-hide">更多功能</span></a>
<ul>
<li>
<?php if ($config['woactive'] == 1){?><a href="WorkOrder.php">在线工单</a><?php } ?>
<?php if ($config['qiandao'] == 1){?><a href="QianDao.php">签到达人</a><?php } ?>
<a href="<?php echo $config['qqun']?>" target="_blank">交流Q群</a>
</li>
</ul>
</li>
<a href="./Login.php?logout" class="waves-effect" ><i class="si si-logout"></i><span class="sidebar-mini-hide">退出登录</span></a>

</ul>
</li>
</ul>
<hr />

</div>
</div>
</div>
</nav>
<header id="page-header">
<div class="content-header">
<div class="content-header-section">
<button type="button" class="btn btn-circle btn-dual-secondary" data-toggle="layout" data-action="sidebar_toggle">
<i class="fa fa-navicon"></i>
</button>
<div class="btn-group" role="group">
<button type="button" class="btn btn-circle btn-dual-secondary" id="page-header-options-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fa fa-wrench"></i>
</button>
<div class="dropdown-menu" aria-labelledby="page-header-options-dropdown">
<h6 class="dropdown-header">Header</h6>

<div class="dropdown-divider"></div>
<a class="dropdown-item" href="#">
<i class="si si-chemistry"></i> 正常运行中
</a>
</div>
</div>
<div class="btn-group" role="group">
<button type="button" class="btn btn-circle btn-dual-secondary" id="page-header-themes-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fa fa-paint-brush"></i>
</button>
<div class="dropdown-menu min-width-150" aria-labelledby="page-header-themes-dropdown">
<h6 class="dropdown-header text-center">颜色主题</h6>
<div class="row no-gutters text-center mb-5">
<div class="col-4 mb-5">
<a class="text-default" data-toggle="theme" data-theme="default" href="javascript:void(0)">
<i class="fa fa-2x fa-circle"></i>
</a>
</div>
<div class="col-4 mb-5">
<a class="text-elegance" data-toggle="theme" data-theme="./assets/css/themes/elegance.min.css" href="javascript:void(0)">
<i class="fa fa-2x fa-circle"></i>
</a>
</div>
<div class="col-4 mb-5">
<a class="text-pulse" data-toggle="theme" data-theme="./assets/css/themes/pulse.min.css" href="javascript:void(0)">
<i class="fa fa-2x fa-circle"></i>
</a>
</div>
<div class="col-4 mb-5">
<a class="text-flat" data-toggle="theme" data-theme="./assets/css/themes/flat.min.css" href="javascript:void(0)">
<i class="fa fa-2x fa-circle"></i>
</a>
</div>
<div class="col-4 mb-5">
<a class="text-corporate" data-toggle="theme" data-theme="./assets/css/themes/corporate.min.css" href="javascript:void(0)">
<i class="fa fa-2x fa-circle"></i>
</a>
</div>
<div class="col-4 mb-5">
<a class="text-earth" data-toggle="theme" data-theme="./assets/css/themes/earth.min.css" href="javascript:void(0)">
<i class="fa fa-2x fa-circle"></i>
</a>
</div>
</div>
  <div class="dropdown-divider"></div>

</div>
</div>
</div>
<div class="content-header-section">
<div class="btn-group" role="group">
<button type="button" class="btn btn-rounded btn-dual-secondary" id="page-header-user-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<?php echo $udata['name'];?><i class="fa fa-angle-down ml-5"></i>
</button>
<div class="dropdown-menu dropdown-menu-right min-width-150" aria-labelledby="page-header-user-dropdown">

<a class="dropdown-item">
<?php
$h=date('G');
if ($h<5) {
	$h='凌晨好，天还没亮呢';
}else if ($h>=5 && $h<8){
	$h='早上好，记得吃早餐哦';
}else if ($h>=8 && $h<11){
	$h='上午好，再忙也要喝水哦';
}else if ($h>=11 && $h<13){
	$h='中午好，该吃午饭了';
}else if ($h>=13 && $h<17){
	$h='下午好，适当放松一下';
}else if ($h>=17 && $h<22){
	$h='晚上好，累了就睡觉哦';
}else{
	$h='夜深了，熬夜可是不好的哦';
}
?>
<i class="si si-tag mr-5"></i> <?php echo $h;?>！
</a>

<a class="dropdown-item d-flex align-items-center justify-content-between" href="balance.php">
<span><i class="si si-wallet mr-5"></i> 当前余额</span>
<span class="badge badge-primary">￥<?php echo $userrow['money'];?></span>
</a>

<div class="dropdown-divider"></div>
<a class="dropdown-item" href="./Login.php?logout"><i class="si si-logout mr-5"></i> 退出登录
</a>
</div>
</div>
<button type="button" class="btn btn-circle btn-dual-secondary" data-toggle="layout" data-action="side_overlay_toggle">
<i class="fa fa-tasks"></i>
</button>
</div>
</div>
<div id="page-header-loader" class="overlay-header bg-primary">
<div class="content-header content-header-fullrow text-center">
<div class="content-header-item">
<i class="fa fa-sun-o fa-spin text-white"></i>
</div>
</div>
</div>
</header>
<script src="../Admin/assets/js/jquery.min.js"></script>
<script src="../assets/layer/layer.js" type="text/javascript" charset="utf-8"></script>