<?php

include("../Includes/Common.php");
$trade_no = trim($_GET['trade_no']);
$sql = $db->query("SELECT * FROM kuake_order WHERE order_no='{$trade_no}' limit 1");
$row = $db->fetch($sql);
if($row['state'] == 1){
	echo json_encode(array('code'=>1,'backurl'=>'/Admin/Order.php'));
}else{
	echo json_encode(array('code'=>0));
}