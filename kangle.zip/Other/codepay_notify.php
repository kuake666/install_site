<?php
require_once("./Codepay/codepay_config.php");
ksort($_POST); //排序post参数
reset($_POST); //内部指针指向数组中的第一个元素
$sign = '';
foreach ($_POST AS $key => $val) {
    if ($val == '') continue;
    if ($key != 'sign') {
        if ($sign != '') {
            $sign .= "&";
            $urls .= "&";
        }
        $sign .= "$key=$val"; //拼接为url参数形式
        $urls .= "$key=" . urlencode($val); //拼接为url参数形式
    }
}

if (!$_POST['pay_no'] || md5($sign . $codepay_config['key']) != $_POST['sign']) { //不合法的数据 KEY密钥为你的密钥
    exit('fail');
} else { //合法的数据

    $out_trade_no = $_POST['param'];

    //支付宝交易号
    $trade_no = $_POST['pay_no'];

    $recharge = $db->get_row("SELECT * FROM kuake_order  WHERE order_no='".$out_trade_no."' and state=0 limit 1;");
    if($recharge){
        $row = $db->get_row("SELECT * FROM kuake_user WHERE uid='".$recharge['user']."' limit 1;");
        if($row){
            $peie=$row['money']+$recharge['peie'];
            $db->query("update kuake_user set `money`='".$peie."' where uid='".$row['uid']."';");
            $db->query("update kuake_order set state='1' where id='".$recharge['id']."';");

        }
    }
    exit('success');
}

?>