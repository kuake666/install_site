<?php
require_once('../Includes/Common.php');
//if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
/* * 
 * 功能：彩虹易支付页面跳转同步通知页面
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。

 *************************页面功能说明*************************
 * 该页面可在本机电脑测试
 * 可放入HTML等美化页面的代码、商户业务逻辑程序代码
 * 该页面可以使用PHP开发工具调试，也可以使用写文本函数logResult，该函数已被默认关闭，见epay_notify_class.php中的函数verifyReturn
 */

require_once("./Epay/epay.config.php");
require_once("./Epay/epay_notify.class.php");
?>
<!DOCTYPE HTML>
<html>
    <head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyReturn();
if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代码
	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
    //获取支付宝的通知返回参数，可参考技术文档中页面跳转同步通知参数列表

	//商户订单号

	$out_trade_no = $_GET['out_trade_no'];

	//支付宝交易号

	$trade_no = $_GET['trade_no'];

	//交易状态
	$trade_status = $_GET['trade_status'];

	//支付方式
	$type = $_GET['type'];


    if($_GET['trade_status'] == 'TRADE_SUCCESS') {
		$recharge = $db->get_row("SELECT * FROM kuake_order WHERE order_no='".$out_trade_no."' limit 1");
      
      
		if($recharge['state']==1){
          
		  $userrow = $db->get_row("SELECT * FROM kuake_user WHERE uid='".$recharge['user']."' ");
	  
          //以下为充值赠送代码
          if($config['charge']==1 and $recharge['peie']>=0.1){//开启充值优惠
          $charge = $db->get_row("SELECT * FROM kuake_order WHERE order_no='".$out_trade_no."' limit 1");//查找充值用户
            //判断重复刷新支付
             $repay = $db->get_row("SELECT * FROM kuake_order WHERE order_no='".$out_trade_no."' and  type='charge' ");
            //判断重复刷新支付
            if(!$repay){
           			 $user = $db->get_row("SELECT * FROM kuake_user WHERE uid='".$charge['user']."' ");//查找充值用户
          			  $money=$recharge['peie']*$config['chargemoney']+$user['money'];//用户金额为 现有金额+充值赠送的金额
						$db->query("update kuake_user set `money`='".$money."' where uid='".$user['uid']."';");   //更新余额  
         			  $order_num=$out_trade_no;
         			   $name="充值赠送";
        			    $type="charge";
              			$ordermoney=$recharge['peie']*$config['chargemoney'];
					$db->query("INSERT INTO `kuake_order` (`order_no`, `name`,`user`, `peie`, `date`, `type`, `state`) VALUES ('".$order_num."','".$name."', '".$user['uid']."' , '".$ordermoney."' ,'".date("Y-m-d H:i:s")."' ,'".$type."',1)");//写入订单记录
				}
          }
          //以上为充值赠送代码
          
           //以下为推广充值代码
          if($config['invite']==1 and $recharge['peie']>=0.1){ 
            	$charge = $db->get_row("SELECT * FROM kuake_order WHERE order_no='".$out_trade_no."' limit 1");
             $repay2 = $db->get_row("SELECT * FROM kuake_order WHERE order_no='".$out_trade_no."' and  type='invite' ");//防止刷新
            if(!$repay2){
            	$user = $db->get_row("SELECT * FROM kuake_user WHERE uid='".$charge['user']."' ");//查找充值用户
            	if($user['adduser']){
                  		$inviteuser = $db->get_row("SELECT * FROM kuake_user WHERE user='".$user['adduser']."' limit 1");//查找邀请人
                 	    $money=$recharge['peie']*$config['invitemoney']+$inviteuser['money'];//用户金额为 现有金额+充值赠送的金额
						$db->query("update kuake_user set `money`='".$money."' where uid='".$inviteuser['uid']."';");   //更新余额  
       					$order_num=$out_trade_no;
         			    $name="推广赠送";
         			    $type="invite";
                  		$ordermoney=$recharge['peie']*$config['invitemoney'];//推广奖励金额=充值金额*推广奖励比例
					    $db->query("INSERT INTO `kuake_order` (`order_no`, `name`,`user`, `peie`, `date`, `type`, `state`) VALUES ('".$order_num."','".$name."', '".$inviteuser['uid']."' , '".$ordermoney."' ,'".date("Y-m-d H:i:s")."' ,'".$type."',1)");//写入订单记录
                }
           	 }
          }
           //以上为推广充值代码
		   
		   
		   
		   
		  //以下为分站提成
		   if($config['webtc'] and $recharge['peie']>=0.1){
              	       $webdomain = $_SERVER['HTTP_HOST'];
	             		if ($IS_FZ = $db->get_row("SELECT * FROM `kuake_web` WHERE `domain`='{$webdomain}' LIMIT 1")){//判断当前域名如果是分站
          
								if ($web = $db->get_row("SELECT * FROM `kuake_user` WHERE `uid`='{$IS_FZ['uid']}' LIMIT 1"))
				
             					   {
									   if($web['uid']!=$recharge['user']){
									    $repay3 = $db->get_row("SELECT * FROM kuake_order WHERE order_no='".$out_trade_no."' and  type='webtc' ");//防止刷新
										if(!$repay3){
       								     $tc = $recharge['peie'] *  $config['webtc'];
         								 $money=$web['money']+$tc;    
        								  $db->query("UPDATE kuake_user SET `money` = '{$money}' WHERE uid = '{$web['uid']}'"); 
										 $order_num=$out_trade_no;
										$name="分站提成";
										$type="webtc";
										$db->query("INSERT INTO `kuake_order` (`order_no`, `name`,`user`, `peie`, `date`, `type`, `state`) VALUES ('".$order_num."','".$name."', '".$IS_FZ['uid']."' , '".$tc."' ,'".date("Y-m-d H:i:s")."' ,'".$type."',1)");//写入订单记录 
										}
                                       }
									} 
									
 						 } 
		   }
		   //以上为分站提成
			echo "充值".$recharge['peie']."元成功。<a href=\"../$custom_template/index.php\">返回首页</a> | <a href=\"\" onclick=\"window.close();\">关闭当前页面</a>";
		}else{
			echo "充值失败！有问题可联系网站管理员";
		}
    }

	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    echo "验证失败";
}
?>
        <title>在线支付</title>
	</head>
    <body>
    </body>
</html>