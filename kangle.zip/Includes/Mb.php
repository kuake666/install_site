<?php
/*后台模板配置*/
$template_type = array(
	0 => 'Admin',
	1 => 'Admin2',
);
?>