<?php
//if(preg_match('/Baiduspider/', $_SERVER['HTTP_USER_AGENT']))exit;
include("./Includes/Common.php");
$cronapi=$_GET['cronapi'];

$rowsites=$db->rs("SELECT * FROM kuake_site WHERE active='1' ");

if($cronapi==$config['cronkey']&& $config['aladdincron']==1){//得到监控参数 且开通监控
	$flag = false;
	$date = time();
	if ($rowsites){
		foreach($rowsites as $rowsite) {
          $rest=strtotime($rowsite['endtime'])-$date;//网站的到期时间-现在的时间=剩余时间
          $days = intval($rest/86400);//将剩余时间戳转换为天数
          if($days<=$config['cronday']){//如果剩余天数小于等于设置的到期提醒天数则执行下面程序
         
            if($config['email']==1){//发送邮件开启
              
 				$date = date("Y-m-d H:i:s");
              	$severdomain= $db->get_row("SELECT * FROM `kuake_sever` WHERE `id`='{$rowsite['severid']}' LIMIT 1");
              	$userrow= $db->get_row("SELECT * FROM `kuake_user` WHERE `uid`='{$rowsite['uid']}' LIMIT 1");
				  
           		$domain=  "$rowsite[domain].$severdomain[domain]";
            
              	$belongs=$rowsite['belongs'];//判断站点属于主站or分站
                	if($rowsite['belongs']==0){
                			$adress=$config['authdomain'];//站点属于主站
               		 }else{
                    		 $fz= $db->get_row("SELECT * FROM `kuake_web` WHERE `id`='{$rowsite['belongs']}' LIMIT 1");//站点属于分站
                  
                 			 if($fz['active']==1){//判断分站是否禁用
                				  $adress=$fz['domain'];
                               $config['kfqq']=$fz['kfqq'];
                 			 }else{
                    			  $adress=$config['authdomain'];//站点属于主站
                                  $config['kfqq']=$config['kfqq'];
                 			 }
                	}
             
                  $flag = true;
         
                 $mail_name = $userrow['qq']."@qq.com" ? $userrow['qq']."@qq.com" : $config["mail_name"];
				send_mail($mail_name, '自助建站系统信息', '尊敬客户您好：<br/>你所在'.$config['title'].'搭建的网站剩余时间不足'.$config['cronday'].'天,请尽快续费<br/>需要续费的网站域名为'.$domain.'<br/>建站系统地址：http://'.$adress.'/<br/>站长ＱＱ：'.$config['kfqq'].'<br/>');
              
 			   }else{
            		$flag = false;
               }
            
            
           
          }
           
		}
	}

	if($flag){
		echo "邮件发送完成";
	}else{
		echo "暂无即将到期的网站或者邮件功能未开启";
	}
}else{
		echo "没有得到监控密钥,监控失败!";
	}
?>