﻿
INSERT INTO `kuake_config` VALUES ('kuake', '79517721');
INSERT INTO `kuake_config` VALUES ('is_find', '0');
INSERT INTO `kuake_config` VALUES ('terms', '注册即同意我们的条款');
INSERT INTO `kuake_config` VALUES ('admintemplate', '0');
INSERT INTO `kuake_config` VALUES ('aladdincron', '0');
INSERT INTO `kuake_config` VALUES ('cronday', '7');
INSERT INTO `kuake_config` VALUES ('cronkey', '879121');

ALTER TABLE `kuake_user`
ADD COLUMN `findpwd`  varchar(50) DEFAULT NULL,
ADD COLUMN `email`  varchar(50) DEFAULT NULL;