<?php
$install = true;
require_once('../Includes/Common.php');
//require_once('../Includes/Config.php');

@header('Content-Type: text/html; charset=UTF-8');

if($config['version']<2001){
	$sqls = file_get_contents('install.sql');
	$version = 2001;
}elseif($config['version']<2010){
    $sqls = file_get_contents('update1.sql');
    $version = 2010; 
   $k="authdomain";
   $value=$_SERVER['HTTP_HOST'];
   $db->query("UPDATE kuake_config SET value='{$value}' WHERE vkey='{$k}'");
}elseif($config['version']<2020){
    $sqls = file_get_contents('update2.sql');
    $version = 2020; 
}elseif($config['version']<3000){
    $sqls = file_get_contents('update3.sql');
    $version = 3000; 
}elseif($config['version']<3050){
    $sqls = file_get_contents('update4.sql');
    $version = 3050; 
}elseif($config['version']<4000){
    $sqls = file_get_contents('update5.sql');
    $version = 4000; 
}else{
	exit('你的网站已经升级到最新版本了');
}


$explode = explode(';', $sqls);
$cn = new db($Mysql['host'],$Mysql['user'],$Mysql['pwd'],$Mysql['name'],$Mysql['port']);
	$cn->query("set names utf8");
	$t=0; $e=0; $error='';
	for($i=0;$i<count($explode);$i++) {
    
		if ($explode[$i]=='')continue;
		if($cn->query($explode[$i])) {
			++$t;
		} else {
			++$e;
			$error.=$cn->error().'<br/>';
		}
     
	}	

$num = count($explode);
foreach ($explode as $sql) {
      if ($sql == trim($sql)) {
        $db->query($sql);
     }

}
  
  $db->query("UPDATE kuake_config SET value='{$version}' WHERE vkey='version'");			
	

exit("<script language='javascript'>alert('网站数据库升级完成！');window.location.href='../';</script>");
?>
