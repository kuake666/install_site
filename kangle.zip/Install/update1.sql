
INSERT INTO `kuake_config` VALUES ('authdomain', '');
INSERT INTO `kuake_config` VALUES ('updatetip', '1');