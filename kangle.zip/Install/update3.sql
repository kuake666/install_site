﻿
INSERT INTO `kuake_config` VALUES ('kuake', '79517721');
INSERT INTO `kuake_config` VALUES ('hostactive', '0');
INSERT INTO `kuake_config` VALUES ('jump', '0');
INSERT INTO `kuake_config` VALUES ('qqun', 'https://jq.qq.com/?_wv=1027&k=5sDB7AX');
INSERT INTO `kuake_config` VALUES ('tiaozhuan', '1');

DROP TABLE IF EXISTS `kuake_hostsever`;
CREATE TABLE `kuake_hostsever` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `severname` varchar(255) NOT NULL,
  `epurl` varchar(255) NOT NULL,
  `authcode` varchar(255) NOT NULL,
  `epid` varchar(255) NOT NULL,
  `active` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `kuake_hostlb`;
CREATE TABLE `kuake_hostlb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `name` varchar(255) NOT NULL,
  `install` varchar(255) NOT NULL,
  `siteintroduce` varchar(255) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '1',
  `onsale` int(1) NOT NULL DEFAULT '1',
  `discount` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `kuake_hostlist`;
CREATE TABLE `kuake_hostlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(16) NOT NULL,
  `severid` int(11) NOT NULL,
  `name` varchar(1024) DEFAULT NULL,
  `username` varchar(1024) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `install` varchar(255) NOT NULL,
  `endtime` datetime NOT NULL,
  `belongs` varchar(16) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;