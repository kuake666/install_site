﻿
INSERT INTO `kuake_config` VALUES ('kuake', '79517721');
INSERT INTO `kuake_config` VALUES ('kmactive', '1');
INSERT INTO `kuake_config` VALUES ('agentactive', '1');
INSERT INTO `kuake_config` VALUES ('codeactive', '1');
INSERT INTO `kuake_config` VALUES ('paymethod', '1');
INSERT INTO `kuake_config` VALUES ('transferactive', '1');
INSERT INTO `kuake_config` VALUES ('siteactive', '0');
INSERT INTO `kuake_config` VALUES ('woactive', '1');
INSERT INTO `kuake_config` VALUES ('maapi', 'http://api2.yy2169.com:52888/creat_order/');
INSERT INTO `kuake_config` VALUES ('maid', '');
INSERT INTO `kuake_config` VALUES ('makey', '');

ALTER TABLE `kuake_web`
ADD COLUMN `qqun`  varchar(255) DEFAULT NULL;

DROP TABLE IF EXISTS `kuake_workorder`;
CREATE TABLE `kuake_workorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `num` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `userreply` datetime NOT NULL,
  `adminreply` datetime DEFAULT '0000-00-00 00:00:00',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;