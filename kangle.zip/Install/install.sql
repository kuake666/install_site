
DROP TABLE IF EXISTS `kuake_user`;
CREATE TABLE `kuake_user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `adduser` varchar(16) DEFAULT NULL,
  `invitemoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `user` varchar(255) NOT NULL,
  `pwd` varchar(40) NOT NULL,
  `qq` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `cookie` varchar(50) DEFAULT NULL,
  `findpwd` varchar(50) DEFAULT NULL,
  `zcip` varchar(255) NOT NULL,
  `zctime` datetime NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  `money`  decimal(10,2) NOT NULL DEFAULT '0.00',
  `openweb` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `kuake_user` VALUES (1,'','0.00','admin','e10adc3949ba59abbe56e057f20f883e','79517721','79517721@qq.com','','','','',10,9999.00,'0');
/*!40000 ALTER TABLE `kuake_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_user` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_config`;
CREATE TABLE `kuake_config` (
  `vkey` varchar(255) NOT NULL,
  `value` text,
  PRIMARY KEY (`vkey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_config` ENABLE KEYS */;
INSERT INTO `kuake_config` VALUES ('sygg','<div><li class="list-group-item"><a href="./AddSite.php" class="btn btn-primary btn-sm">搭建网站</a> <a href="./SiteList.php" class="btn btn-success btn-sm">网站列表</a> <a href="./Recharge.php" class="btn btn-warning btn-sm">在线充值</a></li><li class="list-group-item"><span class="badge badge-success btn-xs">代理折扣</span>  初级代理8折搭建，中级代理5折搭建，高级代理1折搭建。 心动不如行动。  <a href="./UpdateAgent.php">购买代理</a></li><li class="list-group-item"><span class="badge badge-info btn-xs">建站交流</span>  建站系统官方群：<a target="_blank" href="https://jq.qq.com/?_wv=1027&k=5H0SxPz">835887903</a></li><li class="list-group-item"><span class="badge badge-warning btn-xs">使用教程</span>  阿拉丁建站-支持无限次重装支持站点过户的建站，如有问题请先参考<a href="http://www.w-cms.cn/" target="_blank">FQA</a> 看不懂再问</li><p></p></div></div></div></div></div>'),('updateagentgg','<div><li class="list-group-item"><span class="badge badge-success btn-xs">初级代理折扣</span>  初级代理5元享8折优惠 </li>
<li class="list-group-item"><span class="badge badge-danger btn-xs">中级代理折扣</span>  中级代理10元享5折优惠 </li>
<li class="list-group-item"><span class="badge badge-info btn-xs">高级代理折扣</span>高级代理50元享1折优惠 </li>
<li class="list-group-item"><span class="badge badge-warning btn-xs">其它折扣</span> 正版授权网站无折扣优惠</li></div>'),('domaingg','<div class="panel-body"><font color="#000000"> <div class="list-group-item reed"><span class="label label-default">绑定域名：</span><span class="label label-primary">绑定域名</span>  <span class="label label-danger">绑定域名</span> <span class="label label-warning">绑定域名</span></font></div>'),('invitegg','<div><li class="list-group-item"><span class="badge badge-success btn-xs">推广邀请</span>  复制推广链接发给朋友</li>
<li class="list-group-item"><span class="badge badge-danger btn-xs">在线推广</span>  你可获得相应提成奖励</li>
<li class="list-group-item"><span class="badge badge-info btn-xs">获得奖励</span>推广的人越多奖励越多</li></div>'),('openwebgg','<div>
<li class="list-group-item"><span class="badge badge-success btn-xs">在线开通</span> 用户可在线开通分站</li>
<li class="list-group-item"><span class="badge badge-danger btn-xs">实时奖励</span>  用户在您网站充值您直接获得奖励</li>
<li class="list-group-item"><span class="badge badge-info btn-xs">丰厚提成</span>充值的人越多奖励越多</li>
</div>'),('wbpe','0.00'),('alipay','1'),('wxpay','1'),('qqpay','1'),('defaultpay','alipay'),('epayapi',''),('epayid',''),('epaykey',''),('eplock','0'),('footer','自助建站系统'),('fxpe','0.00'),('authdomain',''),('updatetip','1'),('template','4'),('title','智能自助建站系统'),('titles','全民自助建站平台'),('keywords','自助建站系统智能建站系统,自助建站系统,安云建站系统,全自动建站'),('description','在线自助建站系统智能建站是一个全自动搭建网站的平台'),('kfqq','79517721'),('buildtime','2018-11-11'),('cjprice','10'),('zjprice','30'),('gjprice','50'),('cjdiscount','0.8'),('zjdiscount','0.5'),('gjdiscount','0.1'),('webactive','0'),('webprice','80'),('webdomain','w-cms.cn'),('webagentactive','0'),('webcash','0'),('webtc','0.2'),('webcashmoney','5'),('version','4000'),('qiandao','0'),('qiandaomoney','0.5'),('voiceactive','0'),('voice','尊敬的{per}，您好，欢迎使用"{title}"，您目前还有"{peie}"元余额，可以在站点管理中搭建网站。'),('webtime','12'),('invite','1'),('invitemoney','0.1'),('give','0'),('givemoney','0.5'),('charge','0'),('chargemoney','0.1'),('email','0'),('mail_cloud','0'),('mail_smtp','smtp.qq.com'),('mail_port','465'),('mail_name','79517721@qq.com'),('mail_pwd',''),('hostactive','0'),('jump','0'),('qqun','https://jq.qq.com/?_wv=1027&k=5HP98pZ'),('tiaozhuan','1'),('kmactive','1'),('agentactive','1'),('codeactive','1'),('paymethod','1'),('transferactive','1'),('siteactive','0'),('woactive','1'),('maapi','http://api2.yy2169.com:52888/creat_order/'),('maid',''),('makey',''),('is_find','0'),('terms','注册即同意我们的条款'),('admintemplate','0'),('aladdincron','0'),('cronday','7'),('cronkey','879121');
/*!40000 ALTER TABLE `kuake_config` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_program`;
CREATE TABLE `kuake_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `name` varchar(255) NOT NULL,
  `install` varchar(255) NOT NULL,
  `houtai` varchar(255) DEFAULT NULL,
  `siteshow` varchar(255) DEFAULT NULL,
  `siteintroduce` varchar(255) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '12',
  `onsale` int(1) NOT NULL DEFAULT '1',
  `discount` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_program` DISABLE KEYS */;
INSERT INTO `kuake_program` VALUES (1,100.00,'表白墙','bb','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的表白网站',12,1,1),(2,10.00,'彩虹等级代挂网','djdg','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的等级代挂网站',12,1,1),(3,10.00,'阿洋发卡网[免授权]','ayfk','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的发卡网站',12,1,1),(4,10.00,'彩虹代刷最新版[免授权]','dsmsq','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的代刷业务网站',12,1,1),(5,10.00,'易支付','epay','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的易支付网站',12,1,1),(6,10.00,'音乐网','music','vip','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的音乐网站',12,1,1),(7,10.00,'zblog博客','zblog','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的zblog博客',12,1,1),(8,50.00,'总裁迪代刷网[正版授权]','zcdds','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,0),(9,10.00,'要饭网','yf','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的要饭网站',12,1,1),(10,10.00,'导航网','daohang','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的导航网站',12,1,1),(11,10.00,'dz论坛','dzluntan','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的论坛',12,1,1),(12,10.00,'emlog博客','emlog','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的博客网站',12,1,1),(13,10.00,'个人官网','gerenguanwang','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的个人官网',12,1,1),(14,10.00,'God秒赞网[免授权]','godmz','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的秒赞网站',12,1,1),(15,10.00,'idc互联','idc','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的idc互联',12,1,1),(16,10.00,'教程网','jiaocheng','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的教程网站',12,1,1),(17,10.00,'搜索网','sousuo','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(18,10.00,'似水年华同学录','ssnhtxl','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(19,10.00,'表情网','biaoqing','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(20,10.00,'黑名单查询网','blacklist','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(21,10.00,'流量卡官网','liuliangka','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(22,10.00,'企业官网','qiyedou','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的企业网站',12,1,1),(23,50.00,'淘宝客[需授权]','taoke','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的淘宝客网站',12,1,1),(24,10.00,'图床网','tuchuang','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的图床网站',12,1,1),(25,10.00,'选号网','xuanhao','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的选号网站',12,1,1),(26,10.00,'织梦网','zmcms','dede','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的织梦网站',12,1,1),(27,10.00,'影视网','movie','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的影视网站',12,1,1),(28,10.00,'代理查询网','dailichaxun','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的代理查询网站',12,1,1),(29,10.00,'Typecho博客','typecho','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的博客网站',12,1,1),(30,10.00,'个人导航网','gerendhw','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的个人导航网站',12,1,1),(31,10.00,'收款码网','shoukuan','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的收款码网站',12,1,1),(32,10.00,'个人业务网','gerenyewu','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的个人业务网站',12,1,1),(33,10.00,'抽奖网','choujiang','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的抽奖网站',12,1,1),(34,10.00,'laysns','laysns','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(35,100.00,'修罗论坛','xiunobbs','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的论坛网站',12,1,1),(36,100.00,'彩虹秒赞网','chmz','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(37,100.00,'源码站[需授权]','yuanmazhan','','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(38,100.00,'授权系统','shouquan','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(39,100.00,'匿言网','niyan','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(40,100.00,'PHP加密系统','jiami','admin','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1),(41,100.00,'留言网','liuyan','sysytem','https://img.alicdn.com/imgextra/i3/2784095818/O1CN01IIspEw1sqgpvhwedl_!!2784095818.jpg','一个好玩的网站',12,1,1);

/*!40000 ALTER TABLE `kuake_program` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_hostsever`;
CREATE TABLE `kuake_hostsever` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `severname` varchar(255) NOT NULL,
  `epurl` varchar(255) NOT NULL,
  `authcode` varchar(255) NOT NULL,
  `epid` varchar(255) NOT NULL,
  `active` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_hostsever` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_hostsever` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_hostlb`;
CREATE TABLE `kuake_hostlb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `name` varchar(255) NOT NULL,
  `install` varchar(255) NOT NULL,
  `siteintroduce` varchar(255) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '1',
  `onsale` int(1) NOT NULL DEFAULT '1',
  `discount` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_hostlb` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_hostlb` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_hostlist`;
CREATE TABLE `kuake_hostlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(16) NOT NULL,
  `severid` int(11) NOT NULL,
  `name` varchar(1024) DEFAULT NULL,
  `username` varchar(1024) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `install` varchar(255) NOT NULL,
  `endtime` datetime NOT NULL,
  `belongs` varchar(16) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_hostlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_hostlist` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_order`;
CREATE TABLE `kuake_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` text,
  `name` varchar(255) NOT NULL,
  `user` int(11) DEFAULT NULL,
  `peie` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_order` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_workorder`;
CREATE TABLE `kuake_workorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `num` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `userreply` datetime NOT NULL,
 `adminreply` datetime DEFAULT '0000-00-00 00:00:00',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_workorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_workorder` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_kami`;
CREATE TABLE `kuake_kami` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `km` varchar(255) NOT NULL,
  `money`  decimal(10,2) NOT NULL DEFAULT '0.00',
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `active` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_kami` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_kami` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_qiandao`;
CREATE TABLE `kuake_qiandao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `money`  decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_qiandao` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_qiandao` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_sever`;
CREATE TABLE `kuake_sever` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `severname` varchar(255) NOT NULL,
  `fwqip` varchar(255) NOT NULL,
  `epurl` varchar(255) NOT NULL,
  `authcode` varchar(255) NOT NULL,
  `epid` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `optdomain` varchar(255) DEFAULT NULL,
  `active` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_sever` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_sever` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_webcash`;
CREATE TABLE `kuake_webcash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid`  int(11) DEFAULT NULL,
  `user` varchar(255) NOT NULL,
  `cashmoney` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `active` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_webcash` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_webcash` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_site`;
CREATE TABLE `kuake_site` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `optdomain` varchar(1024) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `install` varchar(255) NOT NULL,
  `endtime` datetime NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  `user` varchar(16) NOT NULL,
  `belongs` varchar(16) DEFAULT 'admin',
  `severid` int(11) DEFAULT '1',
  `passwd` varchar(16) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_site` ENABLE KEYS */;

DROP TABLE IF EXISTS `kuake_web`;
CREATE TABLE `kuake_web` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `optdomain` varchar(1024) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `starttime` datetime NOT NULL,
  `endtime` datetime NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `titles` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `sygg` text DEFAULT NULL,
  `kfqq` varchar(255) DEFAULT NULL,
  `qqun` varchar(255) DEFAULT NULL,
  `footer` varchar(255) DEFAULT NULL,
  `template` int(11) DEFAULT '4',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `kuake_web` DISABLE KEYS */;
/*!40000 ALTER TABLE `kuake_web` ENABLE KEYS */;