﻿
INSERT INTO `kuake_config` VALUES ('kuake', '79517721');
INSERT INTO `kuake_config` VALUES ('qiandao', '0');
INSERT INTO `kuake_config` VALUES ('qiandaomoney', '0.1');
INSERT INTO `kuake_config` VALUES ('voiceactive', '0');
INSERT INTO `kuake_config` VALUES ('voice', '尊敬的{per}，您好，欢迎使用"{title}"，您目前还有"{peie}"元余额，可以在站点管理中搭建网站。');
INSERT INTO `kuake_config` VALUES ('webtime', '12');
INSERT INTO `kuake_config` VALUES ('give', '0');
INSERT INTO `kuake_config` VALUES ('givemoney', '0.2');
INSERT INTO `kuake_config` VALUES ('charge', '0');
INSERT INTO `kuake_config` VALUES ('chargemoney', '0.1');
INSERT INTO `kuake_config` VALUES ('email', '0');
INSERT INTO `kuake_config` VALUES ('mail_cloud', '0');
INSERT INTO `kuake_config` VALUES ('mail_smtp', 'smtp.qq.com');
INSERT INTO `kuake_config` VALUES ('mail_port', '465');
INSERT INTO `kuake_config` VALUES ('mail_name', '79517721@qq.com');
INSERT INTO `kuake_config` VALUES ('mail_pwd', '');

ALTER TABLE `kuake_program`
ADD COLUMN `houtai` varchar(255) DEFAULT NULL,
ADD COLUMN `siteshow` varchar(255) DEFAULT NULL,
ADD COLUMN `siteintroduce` varchar(255) DEFAULT NULL,
ADD COLUMN `time` int(11) NOT NULL DEFAULT '12';

ALTER TABLE `kuake_site`
ADD COLUMN `belongs` varchar(16) DEFAULT 'admin',
ADD COLUMN `severid` int(11) NOT NULL DEFAULT '1';

DROP TABLE IF EXISTS `kuake_kami`;
CREATE TABLE `kuake_kami` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `km` varchar(255) NOT NULL,
  `money`  decimal(10,2) NOT NULL DEFAULT '0.00',
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `active` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `kuake_qiandao`;
CREATE TABLE `kuake_qiandao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `money`  decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `kuake_sever`;
CREATE TABLE `kuake_sever` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `severname` varchar(255) NOT NULL,
  `fwqip` varchar(255) NOT NULL,
  `epurl` varchar(255) NOT NULL,
  `authcode` varchar(255) NOT NULL,
  `epid` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `optdomain` varchar(255) DEFAULT NULL,
  `active` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;