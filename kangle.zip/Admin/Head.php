<?php

// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------
require_once("../Includes/Common.php");

if(!defined('EPAPI_NULL')){
  $sever=$db->get_row("SELECT * FROM kuake_sever WHERE 1 ");
 
  if(!$sever ){
	 if($config['eplock']==1){
         $db->query("UPDATE kuake_config SET value='0' WHERE vkey='eplock'");
	 }
		exit("<script language='javascript'>alert('请先配置对接服务器!');window.location.href='ApiSet.php';</script>");

	}
}


$usersite=ceil($db->count("SELECT count(*) FROM kuake_site WHERE user='".$userrow['user']."'"));

  
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="assets/images/favicon_1.ico">

         <title><?php echo $title?>丨<?=$config['title']; ?></title>


        <link href="./assets/plugins/sweetalert/dist/sweetalert.css" rel="stylesheet" type="text/css">

        <link href="./assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="./assets/css/core.css" rel="stylesheet" type="text/css">
        <link href="./assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="./assets/css/components.css" rel="stylesheet" type="text/css">
        <link href="./assets/css/pages.css" rel="stylesheet" type="text/css">
        <link href="./assets/css/menu.css" rel="stylesheet" type="text/css">
        <link href="./assets/css/responsive.css" rel="stylesheet" type="text/css">

        <script src="./assets/js/modernizr.min.js"></script>

    </head>


    <body class="fixed-left">
        
        <!-- Begin page -->
        <div id="wrapper">
        
            <!-- Top Bar Start -->
            <div class="topbar">
                <!-- LOGO -->
                <div class="topbar-left">
                    <div class="text-center">
                        <a href="index.php" class="logo"><i class="md md-terrain"></i> <span><?=$config['title']; ?></span></a>
                    </div>
                </div>
                <!-- Button mobile view to collapse sidebar menu -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="">
                            <div class="pull-left">
                                <button class="button-menu-mobile open-left">
                                    <i class="fa fa-bars"></i>
                                </button>
                                <span class="clearfix"></span>
                            </div>
                            <form class="navbar-form pull-left" role="search">
                                <div class="form-group">
                                    <input type="text" class="form-control search-bar" placeholder="欢迎使用自助建站系统">
                                </div>
                                <button type="submit" class="btn btn-search"><i class="fa fa-search"></i></button>
                            </form>

                            <ul class="nav navbar-nav navbar-right pull-right">
                                <li class="dropdown hidden-xs">
                                    <a href="#" data-target="#" class="dropdown-toggle waves-effect" data-toggle="dropdown" aria-expanded="true">
                                        <i class="md md-notifications"></i> <span class="badge badge-xs badge-danger">3</span>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-lg">
                                        <li class="text-center notifi-title">最新消息</li>
                                        <li class="list-group">
                                           <!-- list item-->
                                           <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="pull-left">
                                                    <em class="fa fa-user-plus fa-2x text-info"></em>
                                                 </div>
                                                 <div class="media-body clearfix">
                                                    <div class="media-heading">自助建站系统v<?php echo VER;?>已上线</div>
                                                    <p class="m-0">
                                                       <small>You have 10 unread messages</small>
                                                    </p>
                                                 </div>
                                              </div>
                                           </a>
                                           <!-- list item-->
                                            <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="pull-left">
                                                    <em class="fa fa-diamond fa-2x text-primary"></em>
                                                 </div>
                                                 <div class="media-body clearfix">
                                                    <div class="media-heading">新模板新款式新感觉</div>
                                                    <p class="m-0">
                                                       <small>There are new settings available</small>
                                                    </p>
                                                 </div>
                                              </div>
                                            </a>
                                            <!-- list item-->
                                            <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="pull-left">
                                                    <em class="fa fa-bell-o fa-2x text-danger"></em>
                                                 </div>
                                                 <div class="media-body clearfix">
                                                    <div class="media-heading">购买正版可联系总站长</div>
                                                    <p class="m-0">
                                                       <small>There are
                                                          <span class="text-primary">2</span> new updates available</small>
                                                    </p>
                                                 </div>
                                              </div>
                                            </a>
                                           <!-- last list item -->
                                            <a href="javascript:void(0);" class="list-group-item">
                                              <small>See all notifications</small>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                          
                                <li class="dropdown">
                                    <a href="" class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true"><img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $userrow['qq'] ?>&spec=100" class="img-circle elevation-2" alt="User Image">
 </a>
                                    <ul class="dropdown-menu">
                                       <li><a href="javascript:void(0)"><i class="md md-face-unlock"></i> 当前余额:<?php echo $userrow['money'] ?>元<div class="ripple-wrapper"></div></a></li>
                                    <li><a href="javascript:void(0)"><i class=" md-insert-emoticon"></i> 搭建网站:<?php echo $usersite?>个</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                </div>
            </div>
            <!-- Top Bar End -->


            <!-- ========== Left Sidebar Start ========== -->
	
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">
                    <div class="user-details">
                        <div class="pull-left">
                        	<?php if($userrow['qq'] == null){ ?>
                            <img src="//q4.qlogo.cn/headimg_dl?dst_uin=79517721&spec=100" alt="" class="thumb-md img-circle">
                         	<?php	}else { ?>
                         		<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $userrow['qq'] ?>&spec=100" alt="" class="thumb-md img-circle">
                         		<?php } ?>
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo $userrow['user'] ?> <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="javascript:void(0)"><i class="md md-face-unlock"></i> 当前余额:<?php echo $userrow['money'] ?>元<div class="ripple-wrapper"></div></a></li>
                                    <li><a href="javascript:void(0)"><i class=" md-insert-emoticon"></i> 搭建网站:<?php echo "0"?>个</a></li>
                                    
                                </ul>
                            </div>
                            
                            <p class="text-muted m-0"><?php if ($userrow['active'] == 10){echo '超级管理员';}
                               elseif ($userrow['active'] ==0 ) {echo '封禁用户';}
                               elseif ($userrow['active'] ==1 ) {echo '普通用户';}
                               elseif ($userrow['active'] ==2 ) {echo '初级代理';}
                               elseif ($userrow['active'] ==3 ) {echo '中级代理';}
                               elseif ($userrow['active'] ==4 ) {echo '高级代理';}
                               else{echo "未知用户";}?></p>
                        </div>
                    </div>
                    <!--- Divider -->
                    <div id="sidebar-menu">
                        <ul>
                            <li>
                                <a href="index.php" class="waves-effect waves-light "><i class="md md-home"></i><span> <b>系统控制台</b> </span></a>
                            </li>

                            <li class="has_sub"><?php if ($userrow['uid'] == 1){?>

                                <a href="#" class="waves-effect waves-light"><i class=" md-settings"></i><span> <b>系统设置 </b>  
                                  </span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="Set.php">网站设置</a></li>
                                    <li><a href="ApiSet.php">对接设置</a></li>
                                    <li><a href="Payset.php">支付设置</a></li>
                                   <li><?php if ($config['agentactive'] == 1){?><a href="AgentSet.php">代理设置</a></li><?php } ?> 
 								  <li><a href="Notice.php">公告设置</a></li>
                                   <li><a href="Update.php">系统更新</a></li>
								   <li><a href="About.php">关于系统</a></li>
                                </ul>
                            </li><?php } ?>

                             <li class="has_sub"><?php if ($userrow['uid'] == 1){?>
                                <a href="#" class="waves-effect waves-light"><i class="md-markunread-mailbox"></i><span> <b>系统管理 </b>
                                  </span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                   <li> <a href="AdminWebSet.php">分站管理</a></li>
                                     <li><?php if($config['webactive']==1){ ?><a href="CashOrder.php">分站提现</a></li> <?php } ?> 
                                 	 <li><?php if($config['webactive']==1){ ?><a href="Webph.php">分站排行</a></li> <?php } ?> 
                                     <li><a href="AdminSiteList.php">站点管理</a></li>
                                 <li><a href="Program.php">程序管理</a></li>
                                    <li><a href="UserList.php">用户管理</a></li>
                                  <li><?php if ($config['kmactive'] == 1){?><a href="KmSet.php">卡密管理</a></li> <?php } ?>
                                  <li><?php if ($config['woactive'] == 1){?><a href="AdminWorkOrder.php">工单管理</a></li>	<?php } ?>							  
                                    <li><a href="AdminOrder.php">充值记录</a></li>
                                </ul>
                            </li><?php } ?>
                            <li class="has_sub"><?php if ($userrow['openweb'] == 1){?>

                                <a href="#" class="waves-effect waves-light"><i class="md md-palette"></i> <span> <b>分站后台</b></span> <span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">

                                    <li><a href="WebSet.php">站点信息</a></li>
                                    <li> <?php if ($config['webagentactive'] == 1){?><a href="WebAddAgent.php">添加代理</a></li><?php } ?> 

                                    <li><?php if ($config['webcash'] == 1){?><a href="WebCash.php">分站提现</a></li>  <?php } ?> 


                                </ul>
                            </li> <?php } ?> 


                            <li class="has_sub">
                                <a href="#" class="waves-effect waves-light"><i class="md md-invert-colors-on"></i><span> <b>站点管理</b> </span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="AddSite.php">网站搭建</a></li>
                                    <li><a href="SiteList.php">网站列表</a></li>
                                    <li><?php if ($config['transferactive'] == 1){?><a href="Transfer.php">网站过户</a></li> <?php } ?> 
                                </ul>
                            </li>
							
						
								
								<li class="has_sub"><?php if ($config['hostactive']==1){?>
                                <a href="#" class="waves-effect waves-light"><i class="fa fa-database"></i><span><b>虚拟主机</b> </span><span class="pull-right"><i class="md md-add"></i></span></a>							
                                <ul class="list-unstyled">   
									<li><?php if ($userrow['uid'] == 1){?><a href="HostSever.php">主机对接</a></li>	<?php } ?> 
									<li><?php if ($userrow['uid'] == 1){?><a href="HostLb.php">主机管理</a></li><?php } ?> 
									<li><?php if ($userrow['uid'] == 1){?><a href="AdminHostList.php">管理主机</a></li><?php } ?> 

									<li><a href="AddHost.php">购买主机</a></li>	
									<li><a href="HostList.php">主机记录</a></li>
                                </ul>
                            </li>	<?php } ?>	
							
							<li>
							
                            <li class="has_sub">
                                <a href="#" class="waves-effect waves-light"><i class="fa fa-credit-card"></i> <span> <b>个人资料</b> </span> <span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="Information.php">个人信息</a></li>
                                    <li><?php if ($config['agentactive'] == 1){?><a href="UpdateAgent.php">升级代理</a></li><?php } ?> 
                                    <li><a href="Recharge.php">在线充值</a></li>
                                   <li><?php if ($config['kmactive'] == 1){?><a href="Kmcharge.php">卡密充值</a></li><?php } ?> 
                                   <li><a href="Order.php">充值记录</a></li>
                                   <li><a href="SetPwd.php">修改密码</a></li>
                                </ul>
                            </li>
                            
                            <li class="has_sub"><?php if ($config['invite'] == 1){?>
                                <a href="#" class="waves-effect waves-light"><i class="md md-share"></i><span><b>我的推广</b> </span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="Invite.php">推广链接</a></li>
                                    <li><a href="InviteList.php">推广记录</a></li>
                                </ul>
                            </li><?php } ?> 
                 				 <li><?php if ($userrow['openweb'] != 1 and $config['webactive']==1){?>

                                <a href="OpenWeb.php" class="waves-effect"><i class=" md-shopping-cart"></i><span><b>搭建分站</b></span>
                                   <span class="right badge badge-danger">New</span></a>
                            </li><?php } ?>
                          
                          
								
							 	<li class="has_sub">
                                <a href="#" class="waves-effect waves-light"><i class="fa fa-search"></i><span><b>更多功能</b> </span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    
									<li><?php if ($config['woactive'] == 1){?><a href="WorkOrder.php">在线工单</a></li><?php } ?> 
                                    <li><?php if ($config['qiandao'] == 1){?><a href="QianDao.php">签到达人</a></li> <?php } ?> 
									<li><a href="<?php echo $config['qqun']?>">交流Q群</a></li> 
                                </ul>
                            </li>	
                             <li>
                                <a href="Login.php?logout" class="waves-effect"><i class="md md-event"></i><span><b>退出登录</b></span></a>
                            </li>
                          
                          
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- Left Sidebar End --> 
          
          
          
		  <script>
            var resizefunc = [];
        </script>

        <!-- Main  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="../assets/layer/layer.js" type="text/javascript" charset="utf-8"></script>
        <script src="assets/js/jquery.app.js"></script>s