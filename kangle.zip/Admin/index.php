<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------
$title = "控制台";
include("../Includes/Common.php");

include("./Head.php");

if (!$islogin){
    echo "<script type='text/javascript'>layer.alert('您好，您还未登录账号呢,请先进行登录',{icon:5},function(){window.location.href='./Login.php'});</script>";
    exit();
}

if ($userrow['active'] == 0){
    setcookie("kuake_sid", "", time() - 3600*12,'/');
    echo "<script type='text/javascript'>layer.alert('您好，该账号已被封禁,暂时无法使用',{icon:5},function(){window.location.href='./Login.php'});</script>";
    exit();
}


$days = ceil((time() - strtotime($config['buildtime'] ? $config['buildtime'] : date("Y-m-d"))) / 86400);
$allprogram=ceil($db->count("SELECT count(*) FROM kuake_program WHERE onsale=1"));
$usersite=ceil($db->count("SELECT count(*) FROM kuake_site WHERE user='".$userrow['user']."'"));


$getResult = update();
?>


    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">欢迎回来,本站<?php if ($userrow['active'] == 10){echo '超级管理员';}
                        elseif ($userrow['active'] ==0 ) {echo '封禁用户';}
                        elseif ($userrow['active'] ==1 ) {echo '普通用户';}
                        elseif ($userrow['active'] ==2 ) {echo '初级代理';}
                        elseif ($userrow['active'] ==3 ) {echo '中级代理';}
                        elseif ($userrow['active'] ==4 ) {echo '高级代理';}
                        else{echo "未知用户";}?><?php if($config['updatetip']==1 and $userrow['uid']==1 and $getResult['ver'] > VER){ ?>
                            <font color="red">有新版版本!&nbsp;<a href ="./Update.php">点我更新</a><p></font> <?php }?> </h4>

                </div>
            </div>


            <!--Widget-4 -->
            <div class="row">
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <div class="mini-stat clearfix bx-shadow bg-white">
                        <span class="mini-stat-icon bg-info"><i class="fa fa-usd"></i></span>
                        <div class="mini-stat-info text-right text-dark">
                            <span class="counter text-dark"><?php echo $userrow['money']?>元</span>
                            我的当前余额
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <div class="mini-stat clearfix bx-shadow bg-white">
                        <span class="mini-stat-icon bg-warning"><i class="fa fa-shopping-cart"></i></span>
                        <div class="mini-stat-info text-right text-dark">
                            <span class="counter text-dark"><?php echo $usersite?>个</span>
                            我的建站总数
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <div class="mini-stat clearfix bx-shadow bg-white">
                        <span class="mini-stat-icon bg-pink"><i class="fa  fa-archive"></i></span>
                        <div class="mini-stat-info text-right text-dark">
                            <span class="counter text-dark"><?php echo $allprogram?>套</span>
                            系统程序总数
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <div class="mini-stat clearfix bx-shadow bg-white">
                        <span class="mini-stat-icon bg-success"><i class="fa   fa-cloud"></i></span>
                        <div class="mini-stat-info text-right text-dark">
                            <span class="counter text-dark"><?php echo $days?>天</span>
                            系统运行时间
                        </div>
                    </div>
                </div>
            </div> <!-- End row-->



            <!-- Inline Form -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title">平台公告</h3></div>
                        <?=$config['sygg']?>

                    </div> <!-- col -->
                </div> <!-- End row -->













            </div> <!-- container -->

        </div> <!-- content -->



    </div>
    <!-- ============================================================== -->
    <!-- End Right content here -->
    <!-- ============================================================== -->






    <!-- END wrapper -->







    <!-- moment js  -->
    <script src="assets/plugins/moment/moment.js"></script>

    <!-- counters  -->
    <script src="assets/plugins/waypoints/lib/jquery.waypoints.js"></script>
    <script src="assets/plugins/counterup/jquery.counterup.min.js"></script>

    <!-- sweet alert  -->
    <script src="assets/plugins/sweetalert/dist/sweetalert.min.js"></script>


    <!-- flot Chart -->
    <script src="assets/plugins/flot-chart/jquery.flot.js"></script>
    <script src="assets/plugins/flot-chart/jquery.flot.time.js"></script>
    <script src="assets/plugins/flot-chart/jquery.flot.tooltip.min.js"></script>
    <script src="assets/plugins/flot-chart/jquery.flot.resize.js"></script>
    <script src="assets/plugins/flot-chart/jquery.flot.pie.js"></script>
    <script src="assets/plugins/flot-chart/jquery.flot.selection.js"></script>
    <script src="assets/plugins/flot-chart/jquery.flot.stack.js"></script>
    <script src="assets/plugins/flot-chart/jquery.flot.crosshair.js"></script>

    <!-- todos app  -->
    <script src="assets/pages/jquery.todo.js"></script>

    <!-- chat app  -->
    <script src="assets/pages/jquery.chat.js"></script>

    <!-- dashboard  -->
    <script src="assets/pages/jquery.dashboard.js"></script>


    <script>
        var audio=document.createElement('audio');
        var play = function (s) {
            var URL = 'https://fanyi.baidu.com/gettts?lan=zh&text=' + encodeURIComponent(s) + '&spd=5&source=web'

            if(!audio){
                audio.controls = false
                audio.src = URL
                document.body.appendChild(audio)
            }
            audio.src = URL
            audio.play();
        }

        <?php if($config['voiceactive']==1){?>
        play('<?php
        if(version_compare(PHP_VERSION,'5.4', '<')){
            echo '您的PHP版本不符合建站系统要求，请管理员检查环境！';
        }elseif (version_compare(PHP_VERSION,'5.7', '>')) {
            echo '您的PHP版本不符合建站系统要求，请管理员检查环境！';
        }else{
            $voice=$config['voice'];
            $voice=str_replace('{title}',$config['title'],$voice);//网站标题
            $voice=str_replace('{titles}',$config['titles'],$voice);//网站副标题
            $voice=str_replace('{peie}',$userrow['money'],$voice);//登录用户的余额
            if($userrow['active']==10){//用户的权限
                $voice=str_replace('{per}','超级管理员',$voice);
            }else if($userrow['active']==1){
                $voice=str_replace('{per}','普通用户',$voice);
            }else if($userrow['active']==2){
                $voice=str_replace('{per}','初级代理',$voice);
            }else if($userrow['active']==3){
                $voice=str_replace('{per}','中级代理',$voice);
            }else if($userrow['active']==4){
                $voice=str_replace('{per}','高级代理',$voice);
            }else{
                $voice=str_replace('{per}','未知用户',$voice);
            }
            echo $voice;
        }
        ?>
        ');
        <?php }?>
    </script>

<?php

include("./Footer.php");

?>