
<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------
include("../Includes/Common.php");
include("./Loginjs.php");
if ($_POST['do'] == 'login') {
 session_start(); 
    if ($_POST['username']=='' or $_POST['password']==''){
        echo "<script type='text/javascript'>layer.alert('账号或密码不能为空',{icon:5},function(){history.back(-1)});</script>";
                exit();
    }else{
        $user = daddslashes($_POST['username']);
        $pwd = daddslashes($_POST['password']);
        $code=daddslashes($_POST['code']);
        if($config['codeactive']==1){
            if(!$code || strtolower($_SESSION['mulin_code'])!=strtolower($code)){
                echo "<script type='text/javascript'>layer.msg('验证码错误,请重新输入',{icon:5},function(){history.back(-1)});</script>";
                exit();
            }
        }
        $pwd = md5($pwd);
        if($row=$db->get_row("SELECT * FROM kuake_user WHERE user='$user' and pwd='$pwd' LIMIT 1")) {
            $sid=md5(uniqid().rand(1,1000));
            $db->query("UPDATE kuake_user SET cookie='$sid' WHERE uid='".$row['uid']."'");
            setcookie("kuake_sid",$sid,time()+3600*12,'/');
            $userrow=$db->get_row("SELECT * FROM kuake_user WHERE uid='".$row['uid']."' LIMIT 1");
        
       //   exit("<script language='javascript'>alert('登录成功!');window.location.href='index.php';</script>");
         echo "<script type='text/javascript'>layer.msg('恭喜您：登录成功!',{icon:6},function(){window.location.href='./index.php'});</script>";
              exit();
        }else{
            echo "<script type='text/javascript'>layer.msg('账号或密码错误',{icon:5},function(){history.back(-1)});</script>";
                exit();
        }
    }
}else if(isset($_GET['logout'])){
    $newsid=md5(uniqid().rand(1,1000));
    $db->query("update kuake_user set cookie='$newsid' where uid='{$userrow['uid']}'");
    setcookie("kuake_sid", "", time() - 3600*12,'/');
    $sql = $db->query("SELECT `value` FROM kuake_config WHERE vkey='admintemplate'" );
    $row1 = $db->fetch($sql);
    $custom_template = $template_type[$row1['value']];
   echo "<script type='text/javascript'>layer.msg('恭喜您：成功注销登陆!',{icon:6},function(){window.location.href='./Login.php'});</script>";
              exit();
}else if($islogin==1){
  echo "<script type='text/javascript'>layer.msg('您已成功登陆',{icon:6},function(){window.location.href='./index.php'});</script>";
                exit();
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="assets/images/favicon_1.ico">

        <title><?php echo $config['title']?><?php echo $config['titles']?></title>


        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/core.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/components.css" rel="stylesheet" type="text/css">
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css">
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css">
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css">

        <script src="assets/js/modernizr.min.js"></script>


        
    </head>
   <body onLoad="createCode()">



        <div class="wrapper-page">
            <div class="panel panel-color panel-primary panel-pages">
                <div class="panel-heading bg-img"> 
                    <div class="bg-overlay"></div>
                    <h3 class="text-center m-t-10 text-white"> <strong>在线登录</strong> </h3>
                </div> 


                <div class="panel-body">
                <form class="form-horizontal m-t-20" action="Login.php" method="post" > 

                    
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control input-lg" type="text" required="" placeholder="用户名"  name="username">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control input-lg" type="password" required="" placeholder="用户密码" name="password" >
                        </div>
                    </div>
                            
                  
             <div class="form-group  "> 
             <?php if($config['codeactive']==1){ ?>
                <div class="col-xs-7">
                 
             <input type="text" class="form-control input-lg"   name="code" onkeyup="this.value=this.value.replace(/\D/g,'')" maxlength="4" placeholder="输入验证码" autocomplete="off" required/>   </div>  
        <span style="padding: 0">
        <img src="./Code.php"height="43"onclick="this.src='./Code.php?r='+Math.random();" title="点击更换验证码" > 
                </span> <?php }?> 
              </div>
                
                  
                    <div class="form-group">
                        <div class="col-xs-12">
                            <div class="checkbox checkbox-primary">
                                <input id="checkbox-signup" type="checkbox">
                                <label for="checkbox-signup">
                                    记住我
                                </label>
                            </div>
                            
                        </div>
                    </div>
                    <input type="hidden"  name="do" value="login"/> 

                    <div class="form-group text-center m-t-40">
                        <div class="col-xs-12">
                            <button class="btn btn-primary btn-lg w-lg waves-effect waves-light" onclick="validate();" type="submit">立即登录</button>
                        </div>
                    </div>
        <div class="block-content bg-body-light">
                     <div class="form-group m-t-30">
                        <div class="col-sm-12 text-center">
                            <a href="Reg.php"> <i class="fa fa-plus mr-5"></i> 立即注册</a>&nbsp;&nbsp;
                            <a class="link-effect text-muted mr-10 mb-5 d-inline-block"  href="FindPwd.php"> <i class="fa fa-warning mr-5"></i> 找回密码
                                </a>
                        </div>
                    </div>
                       </div>
                    
                    
                    
                    
                </form> 
                </div>                                 
                
            </div>
        </div>

        
        <script>
            var resizefunc = [];
        </script>

        <!-- Main  -->
        
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/js/jquery.app.js"></script>
    
    </body>
</html>

   
<?php

/*
  *
 *Aladdin建站系统|作者QQ：79517721
  *
*/
?>
  