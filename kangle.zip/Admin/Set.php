<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------
$title = "系统设置";
include("../Includes/Common.php");


include("./Head.php");

if (!$islogin){
    echo "<script type='text/javascript'>layer.alert('您好，您还未登录账号呢,请先进行登录',{icon:5},function(){window.location.href='./Login.php'});</script>";
    exit();
}

if ($userrow['active'] == 0){
  setcookie("kuake_sid", "", time() - 3600*12,'/');
    echo "<script type='text/javascript'>layer.alert('您好，该账号已被封禁,暂时无法使用',{icon:5},function(){window.location.href='./Login.php'});</script>";
    exit();
}

if ($userrow['uid']!=1){
  echo "<script type='text/javascript'>layer.alert('非法访问!无权限',{icon:5},function(){window.location.href='./index.php'});</script>";
    exit();
}

if ($domain!=$config['authdomain']){
   echo "<script type='text/javascript'>layer.alert('您好，当前域名不是授权域名呢',{icon:5},function(){window.location.href='./index.php'});</script>";
    exit();
}


if ($_POST['do'] == 'edit'){
    foreach($_POST as $k => $value){
    
        $db->query("UPDATE kuake_config SET value='{$value}' WHERE vkey='{$k}'");
    }
  echo "<script type='text/javascript'>layer.alert('恭喜您：数据修改成功！',{icon:6},function(){window.location.href='./Set.php'});</script>";
  exit();
 
}




?>


          <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->                      
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                      
         
                      
                      <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading"><h3 class="panel-title">网站设置</h3></div>
                                    <div class="panel-body">
                                        <form class="form-horizontal tasi-form" method="post">
                              <input type="hidden" name="do" value="edit">
                      <div class="form-group">
                                                <label class="col-md-2 control-label">主站域名</label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" name="authdomain" value="<?=$config['authdomain']?>" >
                           <span class="help-block"><small>填写已授权的域名,请勿胡乱更改.</small></span>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">网站标题</label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" name="title" value="<?=$config['title']?>" >

                                                </div>
                                            </div>
                                       
                                          <div class="form-group">
                                                <label class="col-md-2 control-label">网站副标题</label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" name="titles" value="<?=$config['titles']?>" >

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">网站关键字</label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" name="keywords" value="<?=$config['keywords']?>">

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">网站描述</label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" name="description" value="<?=$config['description']?>">

                                                </div>
                                            </div>                                    
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">底部信息</label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control"  name="footer" value="<?=$config['footer']?>">

                                                </div>
                                            </div>  
                      <div class="form-group">
                                                <label class="col-md-2 control-label">注册条款及条件</label>
                                                <div class="col-md-10">
                                                   <textarea type="text" class="form-control" rows="5" name="terms" value=""   > <?=$config['terms']?></textarea>

                                                </div>
                                            </div>  
                      
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">站长客服QQ</label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" name="kfqq" value="<?=$config['kfqq']?>">

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">QQ交流群链接</label>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" name="qqun" value="<?=$config['qqun']?>">

                                                </div>
                                            </div>                      
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">网站开通时间</label>
                                               <div class="col-sm-10">
                                                    <input type="date" class="form-control" name="buildtime" value="<?=$config['buildtime']?>">

                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启ep锁</label>
                                                <div class="col-sm-10">
                                                   <select name="eplock" class="form-control" >
                                                   <?php if($config['eplock']==0){ ?>
                                                   <option value="0">关闭</option>
                                                   <option value="1">开启</option>
                                                   <?php }else{?>
                                                   <option value="1">开启</option>
                                                   <option value="0">关闭</option>
                                                   <?php }?>
                                                   </select>
                                                   </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启工单功能</label>
                                                <div class="col-sm-10">
                                                   <select name="woactive" class="form-control" >
                                                   <?php if($config['woactive']==0){ ?>
                                                   <option value="0">关闭</option>
                                                   <option value="1">开启</option>
                                                   <?php }else{?>
                                                   <option value="1">开启</option>
                                                   <option value="0">关闭</option>
                                                   <?php }?>
                                                   </select>
                                                   </div>
                                            </div>                      
                     <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启用户登陆3312后台管理网站</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="siteactive" class="form-control" >
                                                 <?php if($config['siteactive']==0){ ?>
                                                 <option value="0">关闭</option>
                                                 <option value="1">开启</option>
                                                 <?php }else{?>
                                                 <option value="1">开启</option>
                                                 <option value="0">关闭</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                
                                 <span class="help-block"><small>不建议开启。</small></span>
                                            </div>    </div>  
                                         <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启主机销售</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="hostactive" class="form-control" >
                                                 <?php if($config['hostactive']==0){ ?>
                                                 <option value="0">关闭主机销售</option>
                                                 <option value="1">开启主机销售</option>
                                                 <?php }else{?>
                                                 <option value="1">开启主机销售</option>
                                                 <option value="0">关闭主机销售</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                  </div>
                                            </div>
                      <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启网站过户</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="transferactive" class="form-control" >
                                                 <?php if($config['transferactive']==0){ ?>
                                                 <option value="0">关闭网站过户</option>
                                                 <option value="1">开启网站过户</option>
                                                 <?php }else{?>
                                                 <option value="1">开启网站过户</option>
                                                 <option value="0">关闭网站过户</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                  </div>
                                            </div>
                      <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启卡密充值</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="kmactive" class="form-control" >
                                                 <?php if($config['kmactive']==0){ ?>
                                                 <option value="0">关闭卡密充值</option>
                                                 <option value="1">开启卡密充值</option>
                                                 <?php }else{?>
                                                 <option value="1">开启卡密充值</option>
                                                 <option value="0">关闭卡密充值</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                  </div>
                                            </div>
                      <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启升级代理</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="agentactive" class="form-control" >
                                                 <?php if($config['agentactive']==0){ ?>
                                                 <option value="0">关闭升级代理</option>
                                                 <option value="1">开启升级代理</option>
                                                 <?php }else{?>
                                                 <option value="1">开启升级代理</option>
                                                 <option value="0">关闭升级代理</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                  </div>
                                            </div>
                      <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启登录注册验证</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="codeactive" class="form-control" >
                                                 <?php if($config['codeactive']==0){ ?>
                                                 <option value="0">关闭验证</option>
                                                 <option value="1">开启验证</option>
                                                 <?php }else{?>
                                                 <option value="1">开启验证 </option>
                                                 <option value="0">关闭验证</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                  </div>
                                            </div>
                                          <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启浏览器跳转</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="jump" class="form-control" >
                                                 <?php if($config['jump']==0){ ?>
                                                 <option value="0">关闭浏览器跳转</option>
                                                 <option value="1">开启浏览器跳转</option>
                                                 <?php }else{?>
                                                 <option value="1">开启浏览器跳转</option>
                                                 <option value="0">关闭浏览器跳转</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                  </div>
                                            </div>    
                      <div class="form-group">
                                                <label class="col-sm-2 control-label">非授权域名跳转主站</label>
                                                <div class="col-sm-10">
                                                  <select name="tiaozhuan" class="form-control" >
                                                 <?php if($config['tiaozhuan']==0){ ?>
                                                 <option value="0">关闭</option>
                                                 <option value="1">开启</option>
                                                 <?php }else{?>
                                                 <option value="1">开启</option>
                                                 <option value="0">关闭</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                  </div>
                                            </div>                          
                      <div class="form-group">
                                                <label class="col-sm-2 control-label">建站系统后台模板</label>
                                                <div class="col-sm-10">
                                                  <select name="admintemplate" class="form-control" >
                                                 <?php if($config['admintemplate']==0){ ?>
                                                 <option value="0">后台默认模板</option>
                                                 <option value="1">后台一号模板</option>
                                                 <?php }else{?>
                                                 <option value="1">后台一号模板</option>
                                                 <option value="0">后台默认模板</option>
                                                 <?php }?>
                                                 </select>                                                 
                                                  </div>
                                            </div>      
                                          <div class="form-group">
                                                <label class="col-sm-2 control-label">建站系统首页模板</label>
                                                <div class="col-sm-10">
                                                  <select name="template" class="form-control"  >
                                                   <?php if($config['template']==1){ ?>
                                                   <option value="1">阿拉丁一号模板</option>
                                                   <option value="2">阿拉丁二号模板</option>
                                                   <option value="3">阿拉丁三号模板</option>
                                                   <option value="5">阿拉丁五号模板</option>
                                                   <option value="4">阿拉丁默认模板</option>
                                                   <option value="6">阿拉丁六号模板</option>
                                                   <option value="7">阿拉丁七号模板</option>
                                                   <option value="8">阿拉丁八号模板</option>
													<option value="8">阿拉丁九号模板</option>
                                                   <option value="0">关闭</option>
                                                   <?php }if($config['template']==2){ ?>
                                                   <option value="2">阿拉丁二号模板</option>
                                                   <option value="1">阿拉丁一号模板</option>
                                                   <option value="3">阿拉丁三号模板</option>
                                                   <option value="5">阿拉丁五号模板</option>
                                                   <option value="6">阿拉丁六号模板</option>
                                                     <option value="7">阿拉丁七号模板</option>
                                                     <option value="8">阿拉丁八号模板</option>
													<option value="8">阿拉丁九号模板</option>
                                                   <option value="4">阿拉丁默认模板</option>
                                                   <option value="0">关闭</option>
                                                   <?php }if($config['template']==3){ ?>
                                                   <option value="3">阿拉丁三号模板</option>
                                                     <option value="7">阿拉丁七号模板</option>
                                                     <option value="8">阿拉丁八号模板</option>
													<option value="8">阿拉丁九号模板</option>
                                                   <option value="6">阿拉丁六号模板</option>
                                                   <option value="5">阿拉丁五号模板</option>
                                                   <option value="4">阿拉丁默认模板</option>                                                             
                                                   <option value="2">阿拉丁二号模板</option>
                                                   <option value="1">阿拉丁一号模板</option>
                                                   <option value="0">关闭</option>
                                                 <?php }if($config['template']==0){ ?>
                                                  <option value="0">关闭</option>
													<option value="8">阿拉丁九号模板</option>
                                                  <option value="8">阿拉丁八号模板</option>
                                                   <option value="7">阿拉丁七号模板</option>
                                                  <option value="6">阿拉丁六号模板</option>
                                                  <option value="5">阿拉丁五号模板</option>
                                                   <option value="4">阿拉丁默认模板</option>  
                                                   <option value="3">阿拉丁三号模板</option>
                                                  <option value="2">阿拉丁二号模板</option>
                                                  <option value="1">阿拉丁一号模板</option>
                                                 <?php }if($config['template']==4){ ?>
                                                   <option value="4">阿拉丁默认模板</option> 
													<option value="8">阿拉丁九号模板</option>
                                                   <option value="8">阿拉丁八号模板</option>
                                                     <option value="7">阿拉丁七号模板</option>                      
                                                   <option value="6">阿拉丁六号模板</option>
                                                  <option value="5">阿拉丁五号模板</option>
                                                   <option value="3">阿拉丁三号模板</option>
                                                  <option value="2">阿拉丁二号模板</option>
                                                  <option value="1">阿拉丁一号模板</option>
                                                    <option value="0">关闭</option>
                                                 <?php }if($config['template']==5){ ?>                    
                                                  <option value="5">阿拉丁五号模板</option>
													<option value="8">阿拉丁九号模板</option>
                                                  <option value="8">阿拉丁八号模板</option>
                                                     <option value="7">阿拉丁七号模板</option>                         
                                                  <option value="6">阿拉丁六号模板</option>          
                                                  <option value="4">阿拉丁默认模板</option>          
                                                   <option value="3">阿拉丁三号模板</option>
                                                  <option value="2">阿拉丁二号模板</option>
                                                  <option value="1">阿拉丁一号模板</option>
                                                    <option value="0">关闭</option>
                                                 <?php }if($config['template']==6){ ?> 
                                                  <option value="6">阿拉丁六号模板</option>  
                                                  <option value="5">阿拉丁五号模板</option>  
                                                  <option value="4">阿拉丁默认模板</option>          
                                                   <option value="3">阿拉丁三号模板</option>
                                                  <option value="2">阿拉丁二号模板</option>
                                                  <option value="1">阿拉丁一号模板</option>
													<option value="8">阿拉丁九号模板</option>
                                                  <option value="8">阿拉丁八号模板</option>
                                                    <option value="7">阿拉丁七号模板</option>                           
                                                    <option value="0">关闭</option>
                                                  <?php }if($config['template']==7){ ?>
                                                  <option value="7">阿拉丁七号模板</option>                   
                                                  <option value="6">阿拉丁六号模板</option>  
                                                  <option value="5">阿拉丁五号模板</option>  
                                                  <option value="4">阿拉丁默认模板</option>          
                                                   <option value="3">阿拉丁三号模板</option>
                                                  <option value="2">阿拉丁二号模板</option>
                                                  <option value="1">阿拉丁一号模板</option>   
                                                  <option value="8">阿拉丁八号模板</option>  
													<option value="8">阿拉丁九号模板</option>             
                                                    <option value="0">关闭</option>               
                                                 <?php }
                                                      if($config['template']==8){ ?>
                                                  <option value="8">阿拉丁八号模板</option>      
                                                  <option value="7">阿拉丁七号模板</option>                   
                                                  <option value="6">阿拉丁六号模板</option>  
                                                  <option value="5">阿拉丁五号模板</option>  
                                                  <option value="4">阿拉丁默认模板</option>          
                                                   <option value="3">阿拉丁三号模板</option>
                                                  <option value="2">阿拉丁二号模板</option>
                                                  <option value="1">阿拉丁一号模板</option>   
													<option value="8">阿拉丁九号模板</option>
                                                    <option value="0">关闭</option>               
                                                 <?php }
												 
												 if($config['template']==9){ ?>
												 <option value="8">阿拉丁九号模板</option>
                                                  <option value="8">阿拉丁八号模板</option>      
                                                  <option value="7">阿拉丁七号模板</option>                   
                                                  <option value="6">阿拉丁六号模板</option>  
                                                  <option value="5">阿拉丁五号模板</option>  
                                                  <option value="4">阿拉丁默认模板</option>          
                                                   <option value="3">阿拉丁三号模板</option>
                                                  <option value="2">阿拉丁二号模板</option>
                                                  <option value="1">阿拉丁一号模板</option>   
                                                    <option value="0">关闭</option>               
                                                 <?php }

                                                 ?>
                                                   </select>

                                                </div>
                                            </div>  
                      
                       <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启语音提示</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="voiceactive" class="form-control" id="change_666" >
                                                   <?php if($config['voiceactive']==0){ ?>
                                                   <option value="0">关闭语音提示</option>
                                                   <option value="1">开启语音提示</option>
                                                   <?php }else{?>
                                                   <option value="1">开启语音提示</option>
                                                   <option value="0">关闭语音提示</option>
                                                   <?php }?>
                                                   </select>                                                 
                                                  </div>
                                            </div>        
                      <div class="form-group" id="open_666" <?php if($config['voiceactive']==0){ echo "style='display:none;'";} ?>>
                                                <label class="col-sm-2 control-label">语音提示内容</label>
                                                <div class="col-sm-10">
                                                 <input  type="text" name="voice" value="<?=htmlspecialchars($config['voice']); ?>"  class="form-control">
            <span class="help-block"><small>可使用定义变量：{title}网站标题，{titles}网站副标题，{peie}登录用户的余额，{per}用户的权限。</small></span>
                                                </div>
                                            </div> 
                                          <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启推广充值返利</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="invite" class="form-control"  id="change_1">
                                                   <?php if($config['invite']==0){ ?>
                                                   <option value="0">关闭推广充值返利</option>
                                                   <option value="1">开启推广充值返利</option>
                                                   <?php }else{?>
                                                    <option value="1">开启推广充值返利</option>
                                                    <option value="0">关闭推广充值返利</option>
                                                   <?php }?>
                                                   </select>

                                                
                                           <span class="help-block"><small>开启功能,被邀请的用户充值余额后,邀请人可以获得奖励.</small></span>
                                                   <span class="help-block"><small>奖励方式:充值金额*奖励比例，如充值10元，比例为0.1,邀请人可获得1元.充值小于0.1元不赠送</small></span>
                                                  </div>
                                            </div>
                                          
    
                                          <div class="form-group" id="open_1"  <?php if($config['invite']==0){ echo "style='display:none;'";} ?>>
                                                <label class="col-sm-2 control-label">推广充值返利比例</label>
                                                <div class="col-sm-10">
                                                  <input type="text" class="form-control" name="invitemoney" value="<?=$config['invitemoney']?>">
                                                </div>
                                            </div>  
                                           <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启充值优惠</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="charge" class="form-control" id="change_2">
                                                   <?php if($config['charge']==0){ ?>
                                                   <option value="0">关闭充值优惠</option>
                                                   <option value="1">开启充值优惠</option>
                                                   <?php }else{?>
                                                    <option value="1">开启充值优惠</option>
                                                   <option value="0">关闭充值优惠</option>
                                                   <?php }?>
                                                    </select>
                                                   <span class="help-block"><small>开启功能,用户充值可获得奖励.实际金额=充值金额+充值金额*充值奖励比例</small></span>
                                                   <span class="help-block"><small>如充值10元，充值奖励余额为0.1，则实际到账金额为11元.充值小于0.1元不赠送</small></span>
                                                  
                                                  </div>
                                            </div>  
                                          <div class="form-group"  id="open_2"  <?php if($config['charge']==0){ echo "style='display:none;'";} ?>>
                                                <label class="col-sm-2 control-label">充值奖励比例</label>
                                                <div class="col-sm-10">
                                                  <input type="text" class="form-control" name="chargemoney" value="<?=$config['chargemoney']?>">
                                                </div>
                                            </div> 
                                          <div class="form-group">
                                                <label class="col-sm-2 control-label">是否注册赠送余额</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="give" class="form-control"  id="change_3">
                                                   <?php if($config['give']==0){ ?>
                                                  <option value="0">关闭赠送</option>
                                                  <option value="1">开启赠送</option>
                                                  <?php }else{?>
                                                  <option value="1">开启赠送</option>
                                                  <option value="0">关闭赠送</option>
                                                   <?php }?>
                                                  </select>
                                                  <span class="help-block"><small>开启功能,新用户注册可获得奖励.</small></span>
                                                  
                                                  </div>
                                            </div>   
                                          <div class="form-group"  id="open_3" <?php if($config['give']==0){ echo "style='display:none;'";} ?>>
                                                <label class="col-sm-2 control-label">注册赠送余额</label>
                                                <div class="col-sm-10">
                                                  <input type="text" class="form-control" name="givemoney" value="<?=$config['givemoney']?>">
                                                </div>
                                            </div> 
                                         <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启签到功能</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="qiandao" class="form-control"  id="change_4">
                                                  <?php if($config['qiandao']==0){ ?>
                                                  <option value="0">关闭签到</option>
                                                  <option value="1">开启签到</option>
                                                  <?php }else{?>
                                                  <option value="1">开启签到</option>
                                                  <option value="0">关闭签到</option>
                                                  <?php }?>
                                                  </select>
                                                  <span class="help-block"><small>开启功能,用户每天签到可获得奖励.</small></span>
                                                  
                                                  </div>
                                            </div> 
                                          <div class="form-group"  id="open_4"  <?php if($config['qiandao']==0){ echo "style='display:none;'";} ?>>
                                                <label class="col-sm-2 control-label">签到奖励金额</label>
                                                <div class="col-sm-10">
                                                  <input type="text" class="form-control" name="qiandaomoney" value="<?=$config['qiandaomoney']?>">
                                                </div>
                                            </div> 
                                        
                                          
                                          
                                          
                                          
                                           <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启邮件提醒</label>
                                           
                                                <div class="col-sm-10">
                                                    <select name="email" class="form-control"  id="change_5">
                                                     <?php if($config['email']==0){ ?>
                                                      <option value="0">关闭邮件提醒</option>
                                                      <option value="1">开启邮件提醒</option>
                                                     <?php }else{?>
                                                     <option value="1">开启邮件提醒</option>
                                                     <option value="0">关闭邮件提醒</option>
                                                     <?php }?>
                                                       </select>
                                          <span class="help-block"><small>使用普通模式发信时，建议使用QQ邮箱，SMTP服务器smtp.qq.com，端口465，密码不是QQ密码也不是邮箱独立密码，是QQ邮箱设置界面生成的<a href="http://service.mail.qq.com/cgi-bin/help?subtype=1&&no=1001256&&id=28"  target="_blank" rel="noreferrer">授权码</a>。</small></span>


                                                  
                                                  </div>
                                            </div>    
                                          <div id="open_5" <?php if($config['email']==0){ echo "style='display:none;'";} ?>>
                                          <div class="form-group"  id="open_5">
                                                <label class="col-sm-2 control-label">发信模式</label>
                                                <div class="col-sm-10">
                                                 <select name="mail_cloud" class="form-control" >
                                                   <?php if($config['mail_cloud']==0){ ?>
                                                    <option value="0">普通模式</option>
                                                    <option value="1">搜狐Sendcloud</option>
                                                   <?php }else{?>
                                                   <option value="1">搜狐Sendcloud</option>
                                                   <option value="0">普通模式</option>
                                                   <?php }?>
                                                     </select>
                                                </div>
                                            </div>  
                                          <div class="form-group" >
                                                <label class="col-sm-2 control-label">STMP服务器</label>
                                                <div class="col-sm-10">
                                                 <input type="text" name="mail_smtp" value="<?=$config['mail_smtp']; ?>"  class="form-control">           
                                                </div>
                                            </div> 
                                          <div class="form-group" >
                                                <label class="col-sm-2 control-label">STMP端口</label>
                                                <div class="col-sm-10">
                                                 <input type="text" name="mail_port" value="<?=$config['mail_port']; ?>"  class="form-control">           
                                                </div>
                                            </div> 
                                          <div class="form-group" >
                                                <label class="col-sm-2 control-label">邮箱账号</label>
                                                <div class="col-sm-10">
                                                 <input type="text" name="mail_name" value="<?=$config['mail_name']; ?>"  class="form-control">           
                                                </div>
                                            </div>
                                          <div class="form-group" >
                                                <label class="col-sm-2 control-label">邮箱授权码</label>
                                                <div class="col-sm-10">
                                                 <input type="text" name="mail_pwd" value="<?=$config['mail_pwd']; ?>"  class="form-control">
                                                                                      </div>
                                            </div>
                                          </div>
                      

                      
                      
                      
                      
                      
                      
                      
                      
                                                  
                                           <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启网站到期提醒</label>
                                           
                                                <div class="col-sm-10">
                                                 <select name="aladdincron" class="form-control"  id="change_11">
                                                  <?php if($config['aladdincron']==0){ ?>
                                                  <option value="0">关闭</option>
                                                  <option value="1">开启</option>
                                                  <?php }else{?>
                                                  <option value="1">开启</option>
                                                  <option value="0">关闭</option>
                                                  <?php }?>
                                                  </select>
                    <span class="help-block"><small>开启此功能,需先开启邮箱提醒.</small></span>

                                                  
                                                  </div>
                                            </div>    
                                          <div id="open_11" <?php if($config['aladdincron']==0){ echo "style='display:none;'";} ?>>
                                         
                                          <div class="form-group" >
                                                <label class="col-sm-2 control-label">到期天数提醒</label>
                                                <div class="col-sm-10">
                                                 <input type="text" class="form-control" name="cronday" value="<?=$config['cronday']?>">
                        
                        <span class="help-block"><small>网站剩余天数少于该设置天数将自动发送邮件</small></span>       
                                                </div>
                                            </div> 
                                          <div class="form-group" >
                                                <label class="col-sm-2 control-label">监控密钥</label>
                                                <div class="col-sm-10">
                                             <input type="text" class="form-control" name="cronkey" value="<?=$config['cronkey']?>" class="form-control"> 
                      <span class="help-block"><small>监控地址:<?php  echo 'http://'.$_SERVER['HTTP_HOST']; ?><?php  echo "/aladdincron.php?cronapi=监控密钥"; ?></small></span>                               
                                                </div>
                                            </div> 
                                          </div>        
                      
                      
                      
                      
                      
                      
                      
                      
                    

                      <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启自助找回密码</label>
                                           
                                                <div class="col-sm-10">
                                                  <select name="is_find" class="form-control" >
                                                 <?php if($config['is_find']==0){ ?>
                                                 <option value="0">关闭</option>
                                                 <option value="1">开启</option>
                                                 <?php }else{?>
                                                 <option value="1">开启</option>
                                                 <option value="0">关闭</option>
                                                 <?php }?>
                                                 </select>     
                        <span class="help-block"><small>开通此功能前需先开启邮件提醒功能</small></span>                        
                                                  </div>
                                            </div>
                      
    
                      

                    
                                          <div class="form-group">
                                                <label class="col-sm-2 control-label">是否开启系统更新提示</label>
                                                <div class="col-sm-10">
                                                   <select name="updatetip" class="form-control" >
                                                     <?php if($config['updatetip']==0){ ?>
                                                      <option value="0">关闭</option>
                                                      <option value="1">开启</option>
                                                     <?php }else{?>
                                                     <option value="1">开启</option>
                                                     <option value="0">关闭</option>
                                                     <?php }?>
                                                       </select>

                                                </div>
                                            </div>  
                                          
                      
                      
                      
                      
                      
                             <div class="form-group m-b-0">
                                                <div class="col-sm-offset-3 col-sm-9">
                                                  <button type="submit" class="btn btn-info waves-effect waves-light">确认修改</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div> <!-- panel-body -->
                                </div> <!-- panel -->
                            </div> <!-- col -->
                        </div> <!-- End row -->

                   </div> <!-- container -->
                               
                </div> <!-- content -->             
            
      </div>
<script type="text/javascript">
$("select[id^='change_']").change(function(){
    var id = $(this).attr('id').split('_')[1];
    var c  = $(this).val();
    if( parseInt(c) == 1 ){
      $('#open_'+id).show();
    }else{
      $('#open_'+id).hide();
    }
});
</script>

<?php

include("./Footer.php");

?>