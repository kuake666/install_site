CREATE TABLE IF NOT EXISTS `m_conf` (
  `k` varchar(255) NOT NULL DEFAULT '',
  `v` varchar(2550) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `m_conf` (`k`, `v`) VALUES
('title', '自助建站商城|API分站版'),
('keywords', '简单的商城,简单的操作,成就非凡的系统'),
('desc', '简单的商城,简单的操作,成就非凡的系统'),
('create', '2020-01-01'),
('epay_api', ''),
('epay_id', ''),
('epay_key', ''),
('qqun', 'http://www.baidu.com'),
('version', '1000'),
('template', 'default'),
('api_url', ''),
('api_key', ''),
('notice', '<li class="list-group-item">\n   <span class="badge badge-info btn-xs">建站交流</span> 建站系统官方群：<a target="_blank" href="https://jq.qq.com/?_wv=1027&k=5NfsF9k">123456</a>\n</li>\n<li class="list-group-item">\n   <span class="badge badge-warning btn-xs">使用教程</span> 如有问题请先参考<a href="http://www.baidu.com/" target="_blank">FQA</a> 看不懂再问\n</li>'),
('kfqq', '123456'),
('rate', '2');

CREATE TABLE IF NOT EXISTS `m_order` (
  `id` int(11) NOT NULL,
  `order_no` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `uid` int(11) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `date` datetime NOT NULL,
  `type` varchar(20) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `m_site` (
  `id` int(5) unsigned NOT NULL,
  `uid` int(5) NOT NULL COMMENT '用户编号',
  `domain` varchar(255) DEFAULT NULL COMMENT '默认域名',
  `date` datetime DEFAULT NULL COMMENT '创建时间',
  `name` varchar(255) DEFAULT NULL COMMENT '程序名',
  `isinstall` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `m_user` (
  `id` int(5) NOT NULL,
  `email` varchar(255) DEFAULT NULL COMMENT '用户邮箱',
  `password` varchar(255) DEFAULT NULL COMMENT '用户密码',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '用户余额',
  `date` datetime DEFAULT NULL COMMENT '注册时间',
  `type` int(1) unsigned zerofill DEFAULT '1' COMMENT '用户类型',
  `status` int(1) DEFAULT '1' COMMENT '用户状态'
) ENGINE=InnoDB AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8;



INSERT INTO `m_user` (`id`, `email`, `password`, `money`, `date`, `type`, `status`) VALUES
(10000, '123456@qq.com', 'e10adc3949ba59abbe56e057f20f883e', '1000.00', '2020-01-01 00:00:00', 1, 1);


ALTER TABLE `m_conf`
  ADD PRIMARY KEY (`k`),
  ADD UNIQUE KEY `k` (`k`);


ALTER TABLE `m_order`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `m_site`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `m_user`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `m_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10000;

ALTER TABLE `m_site`
  MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10000;

ALTER TABLE `m_user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10001;
