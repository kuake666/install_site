<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------

include('./head.php');
$id = intval($_GET['id']);
$list = $DB->query("SELECT * FROM m_site WHERE uid='{$id}' ")->fetchAll();
?>

<div class="content-page">
    <div class="content">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">商城系统</a></li>
                            <li class="breadcrumb-item active">建站数据</li>
                        </ol>
                    </div>
                    <h4 class="page-title">用户-<?php echo $id ?> 建站数据</h4>
                </div> <!-- end page-title-box -->
            </div> <!-- end col-->
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <!--
                            <div class="col-sm-4">
                                <a href="javascript:void(0);" class="btn btn-danger mb-2"><i class="mdi mdi-plus-circle mr-2"></i> 添加用户</a>
                            </div>
                            -->
                            <div class="col-sm-8">
                                <div class="text-sm-right">


                                </div>
                            </div><!-- end col-->
                        </div>

                        <div class="table-responsive">
                            <table class="table table-centered w-100 dt-responsive nowrap" id="products-datatable">
                                <thead class="thead-light">
                                <tr>
                                    <th class="all" style="width: 20px;">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1">
                                            <label class="custom-control-label" for="customCheck1">&nbsp;</label>
                                        </div>
                                    </th>
                                    <th class="all">默认域名</th>
                                    <th>程序名</th>
                                    <th>网站编号</th>
                                    <th>到期时间</th>
                                    <th>是否正版</th>
                                    <th>是否启用</th>
                                    <th style="width: 85px;">操作</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php
                                foreach ($list as $res) {

                                    echo '
                                                    <tr id="' . $res['id'] . '">
                                                        <td>
                                                            <div class="custom-control custom-checkbox">
                                                                <input type="checkbox" class="custom-control-input" id="customCheck2">
                                                                <label class="custom-control-label" for="customCheck2">&nbsp;</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                    	 <a href="http://' . $res['domain'] . '" target="_blank">' . $res['domain'] . '</a>
                                                        </td>
                                                        <td>
                                                             ' . $res['name'] . '
                                                        </td>
                                                        <td>
                                                            ' . $res['id'] . '
                                                        </td>
                                                        <td>
                                                            ' . $res['date'] . '
                                                        </td>
                                                        <td>
                                                             <span class="badge badge-success">正版</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge badge-success">启用</span>
                                                        </td>
                    
                                                        <td class="table-action">
                                                          <!--   <a href="javascript: void(0);" class="action-icon" onclick="rePay(' . $res['id'] . ');"> <i class="mdi mdi-checkbox-marked-circle"></i></a>-->
                                                            <a href="#" class="action-icon" onclick="delSite(' . $res['id'] . ');"> <i class="mdi mdi-delete"></i></a>
                                                        </td>
                                                     
                                                    </tr>';
                                } ?>

                                </tbody>
                            </table>
                        </div>
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->
        </div>
        <!-- end row -->

    </div> <!-- content -->

    <?php
    include('./footer.php');
    ?>
    <script>
        function installSite(id) {
            var index = layer.msg('数据加载中', {time: 9999999});
            $.ajax({
                type: "post",
                url: "ajax.php?act=installSite",
                dataType: "json",
                data: {
                    id: id
                },
                success: function (data) {
                    layer.close(index);
                    if (data.code == 1) {
                        layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                            location.reload();
                        });
                    } else {
                        layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                    }
                },
                error: function () {
                    layer.alert('服务器异常！');
                    layer.close(index);
                }
            });

        }

        function delSite(id) {
            layer.confirm('删除后不可恢复,确定删除吗?', {
                btn: ['是', '否'], btn1: function () {
                    var index = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 9999999});
                    $.ajax({
                        type: "post",
                        url: "ajax.php?act=delSite",
                        dataType: "json",
                        data: {
                            id: id
                        },
                        success: function (data) {
                            layer.close(index);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    var del = "#" + id;
                                    $(del).remove();
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert('网络连接异常！');
                        }
                    });
                }
            });
        }


        function rePay(id) {
            layer.confirm('确定续费吗?', {
                btn: ['是', '否'], btn1: function () {
                    var index = layer.msg('数据处理中···', {icon: 16, shade: 0.01, time: 9999999});
                    $.ajax({
                        type: "post",
                        url: "ajax.php?act=rePay",
                        dataType: "json",
                        data: {
                            id: id
                        },
                        success: function (data) {
                            layer.close(index);
                            if (data.code == 1) {
                                layer.msg(data.msg, {icon: 1, time: 2000, shade: 0.4}, function () {
                                    location.reload();
                                });
                            } else {
                                layer.msg(data.msg, {icon: 2, time: 2000, shade: 0.4});
                            }
                        },
                        error: function () {
                            layer.alert('网络连接异常！');
                        }
                    });
                }
            });
        }

    </script>