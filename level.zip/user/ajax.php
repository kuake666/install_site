<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 微站网 www.w-cms.cn 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2020年2月5日
// +----------------------------------------------------------------------


include("../app/common.php");
$act = isset($_GET['act']) ? daddslashes($_GET['act']) : null;

@header('Content-Type: application/json; charset=UTF-8');

if (!$userrow['id']) {
    exit('{"code":-1,"msg":"非法访问"}');
}

switch ($act) {

    /**
     * author: 79517721@qq.com
     * time:2020/2/12 22:35
     * description:TODO 用户邮箱设置
     */
    case 'emailSet':
        $email = trim(strip_tags(daddslashes($_POST['email'])));

        if (!preg_match('/^[A-z0-9._-]+@[A-z0-9._-]+\.[A-z0-9._-]+$/', $email)) {
            exit('{"code":-1,"msg":"邮箱格式不正确"}');
        }
        $email = strtolower($email);
        $exitemail = $DB->query("SELECT * FROM m_user WHERE email='{$email}'  and id!='{$userrow['id']}' limit 1")->fetch();

        if ($exitemail) {
            exit('{"code":-1,"msg":"邮箱已存在,请重新设置"}');
        }
        if ($email == $userrow['email']) {
            exit('{"code":1,"msg":"修改成功"}');
        }
        //正常修改
        $sql = $DB->exec("UPDATE `m_user` SET `email` ='{$email}' WHERE `id`='{$userrow['id']}'");
        if ($sql) {
            exit('{"code":1,"msg":"修改成功"}');
        } else {
            exit('{"code":-1,"msg":"修改失败啦"}');
        }

        break;

    /**
     * author: 79517721@qq.com
     * time:2020/2/12 22:35
     * description:TODO 用户密码设置
     */
    case 'passSet':
        $oldpass = trim(strip_tags(daddslashes($_POST['oldpass'])));
        $password = trim(strip_tags(daddslashes($_POST['password'])));
        $password1 = trim(strip_tags(daddslashes($_POST['password1'])));

        if ($userrow['password'] != md5($oldpass)) {
            exit('{"code":-1,"msg":"原密码错误"}');
        }

        if (strlen($password) < 6) {
            exit('{"code":-1,"msg":"密码不能低于6位"}');
        }
        if ($password != $password1) {
            exit('{"code":-1,"msg":"两次输入密码不一致"}');
        }

        $password = md5($password);
        $oldpass = md5($oldpass); //原密码

        //没有修改的情况下
        if ($oldpass == $password) {
            exit('{"code":-1,"msg":"新密码不能和旧密码一样"}');
        }

        //正常修改
        $sql = $DB->exec("UPDATE `m_user` SET `password` ='{$password}' WHERE `id`='{$userrow['id']}'");
        if ($sql) {
            exit('{"code":1,"msg":"修改成功,请重新登录"}');
        } else {
            exit('{"code":-1,"msg":"修改失败啦"}');
        }

        break;

    /**
     * author: 79517721@qq.com
     * time:2020/2/12 22:35
     * description:TODO 用户支付
     */
    case 'pay':

        $account = trim(strip_tags(daddslashes($_POST['account'])));
        $type = trim(strip_tags(daddslashes($_POST['method'])));

        $order_no = date("YmdHis") . rand(111, 999);
        if (!is_numeric($account)) {
            exit('{"code":-1,"msg":"提交参数错误！"}');
        }
        if ($account > 1000 || $account < 1) {
            exit('{"code":-1,"msg":"充值金额不能小于1且不能超过1000！"}');
        }
        $name = '用户' . $userrow['id'] . '-在线充值' . $account . '元余额';
        $sitename = $conf['title'];//站点名字

        $sql = $DB->exec("INSERT INTO `m_order` (`order_no`,  `name`,`uid`, `money`, `date`, `type`, `status`)VALUES ('{$order_no}', '{$name}', '{$userrow['id']}',  '{$account}', '{$date}','{$type}', '0')");

        if ($sql) {
            exit('{"code":1,"msg":"提交订单成功！","order_no":"' . $order_no . '","money":"' . $account . '","type":"' . $type . '"}');
        } else {
            exit('{"code":-1,"msg":"提交订单失败！"}');
        }


        break;

    /**
     * author: 79517721@qq.com
     * time:2020/2/12 22:35
     * description:TODO 用户创建网站
     */
    case 'build':
        $pid = trim(strip_tags(daddslashes($_POST['pid'])));
        $serverid = trim(strip_tags(daddslashes($_POST['serverid'])));
        $proname = trim(strip_tags(daddslashes($_POST['proname'])));
        $proList = Site::getProgramList($conf['api_url'], $conf['api_key']);
        $price = 200;
        foreach ($proList['data'] as $pro) {
            if ($pro['pid'] == $pid) {
                $price = $pro['price'] * $conf['rate'];
                $usetime = $pro['usetime']; //项目使用时间
                $endtime = (date('Y-m-d H:i:s', strtotime("+$usetime month")));  //过期时间 = 现在的时间 + 使用时间
            }
        }
        if ($price > $userrow['money']) {
            exit('{"code":-1,"msg":"余额不足,请先充值"}');
        }
        $result = Site::build($pid, $serverid, $conf['api_url'], $conf['api_key']);
        if ($result['code'] == 1) {

            $sql = $DB->exec("INSERT INTO `m_site` (`uid`,  `domain`, `date`, `name`,`isinstall`)VALUES ( '{$userrow['id']}',  '{$result['domain']}', '{$endtime}', '{$proname}','0')");
            //计算用户余额
            $money = $userrow['money'] - $price;
            $DB->exec("UPDATE `m_user` SET `money` ='{$money}' WHERE `id`='{$userrow['id']}'");
            exit('{"code":1,"msg":"搭建成功"}');
        } else {
            exit('{"code":-1,"msg":"' . $result['msg'] . '"}');
        }

    /**
     * author: 79517721@qq.com
     * time:2020/2/12 22:35
     * description:TODO 用户初始化网站
     */
    case 'installSite':
        $id = trim(strip_tags(daddslashes($_POST['id'])));

        $site = $DB->query("SELECT * FROM m_site WHERE id='{$id}' limit 1")->fetch();

        $result = Site::installSite($site['domain'], $conf['api_url'], $conf['api_key']);
        if ($result['code'] == 1) {
            $sql = $DB->exec("UPDATE `m_site` SET `isinstall` ='1' WHERE `id`='{$id}'");
            exit('{"code":1,"msg":"网站初始化成功"}');
        } else {
            exit('{"code":-1,"msg":"' . $result['msg'] . '"}');
        }
        break;

    /**
     * author: 79517721@qq.com
     * time:2020/2/12 22:35
     * description:TODO 用户删除网站
     */
    case 'delSite':
        $id = trim(strip_tags(daddslashes($_POST['id'])));
        $site = $DB->query("SELECT * FROM m_site WHERE id='{$id}' and uid='{$userrow['id']}' limit 1")->fetch();
        if (!$site) {
            exit('{"code":-1,"msg":"网站不存在,或操作不是您的网站"}');
        }

        $result = Site::delSite($site['domain'], $conf['api_url'], $conf['api_key']);
        if ($result['code'] == 1) {
            $sql = $DB->exec("DELETE FROM m_site WHERE id='$id'");
            exit('{"code":1,"msg":"网站删除成功"}');
        } else {
            exit('{"code":-1,"msg":"' . $result['msg'] . '"}');
        }
        break;


    default:

        break;


}

?>