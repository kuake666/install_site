
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<meta name=author content="夸克QQ 79517721"/>
	<meta name="description" content="<?php echo $conf['desc']?>" />
    <meta name="keywords" content="<?php echo $conf['keywords']?>" />
    <link rel="icon" href="favicon.ico">
    <link rel=icon href="img/favicon.ico">
    <!--[if IE]><link rel="shortcut icon" href="img/favicon.ico"><![endif]-->    
    <script src="assets/js/1.js" async></script>    
    
    <title><?php echo $conf['title']?></title>

    <!-- Awwwwards CSS -->
    <link type="text/css" media="screen" rel="stylesheet" href="awwwards.css" />

		<link rel="stylesheet" href="assets/css/first.css" media="all"> 
		<!-- <script src="assets/js/baidu/html5shiv.js"></script> -->
		
		
		
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">   

    <!-- Animate.css -->
    <link href="assets/css/animate.css" rel="stylesheet">   
    
    <!-- Pace -->   
    <link href="assets/css/pace.css" rel="stylesheet">        
        
    <!-- ScrollFlow -->   
    <link href="assets/css/eskju.jquery.scrollflow.css" rel="stylesheet">      
    
    <!-- Custom CSS and js -->     
    <link href="assets/css/fullscreen-modals.css" rel="stylesheet">  
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/custom.css" rel="stylesheet">

      <script src="assets/js/layer/jquery.min.js"></script>

  <script src="assets/js/baidu/jquery-1.8.1.min.js"></script>
  <script src="assets/js/baidu/skrollr.min.js"></script>
        <script src="assets/js/baidu/jquery.iosslider.min.js"></script>
          <script src="assets/js/baidu/ui.js"></script>
		<script>
			$(document).ready(function(){

				//boot();	
				initMainSlider();						
				//if (IEVersion()==false || IEVersion()>8) initMainAnimation();

			});
            /* 点击按钮，下拉菜单在 显示/隐藏 之间切换 */
            function myFunction() {
                document.getElementById("myDropdown").classList.toggle("show");
            }
		</script>
		
		<!--[if IE 8]>
		<link rel="stylesheet" type="text/css" href="assets/css/ie8.css" />
		<![endif]-->

        <!--[if lt IE 9]>
        <script type="text/javascript" src="assets/js/baidu/skrollr.ie.min.js"></script>
        <![endif]-->

		<!--[if lt IE 9]>
			<script type="text/javascript" src="assets/js/baidu/respond.min.js"></script>
		<![endif]-->
  </head>

  <body data-spy="scroll" data-target=".navbar" data-offset="50">   
							    
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top blue-bg">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" onclick="myFunction()" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand logo" href="./"><img src="assets/images/ds-logo-2.png"></a>
        </div>
        <div id="myDropdown" name="navbar" class="navbar-collapse collapse pull-left">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#top">主页</a></li>
            <li><a href="#section3">关于服务</a></li>
            <li><a href="#section6">私人定制</a></li>
            <li><a href="./user/reg.php">免费注册</a></li>            
            <li><a href="./user/login.php">立即登录</a></li>          
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <section id="section1" class="region region-1 align-center blue-bg">
    	<!--
        	作者：1069339155@qq.com
        	时间：2016-03-04
        	描述：
        	<section id="section1" class="region region-1 align-center blue-bg">
        -->
    	<div class="container">
		    <h1 class="wow zoomIn"><?php echo $conf['title']?></h1>
		    <div class="desc wow zoomIn">
		    	<p>我们能做的,就是把最好的给你.</p>
		    </div>                      
        <img src="assets/images/learn-how.png" class="wow fadeInUp img-responsive center" data-wow-delay=".5s"/>
      </div>
    </section>
    
    <section id="section2" class="region region-2 align-center">
    	<div class="container">
		    <h1 class="scrollflow -pop -opacity">关于系统</h1>
		    <div class="scrollflow -slide-top -opacity desc">
		      <p>程序支持自定义支付接口对接 <br/> 邮箱在线登录,方便快捷</p>
        	  <p class="tagline">系统开发团队成员均来自于互联网行业。系统更新频率快，紧跟潮流. <br>轻松设置即可完成建站！更为人性化.</p>
        </div>	   
      </div>
    </section>    

    <section id="section3" class="region region-3 dark-grey-bg centerVert">
    	<div class="container">
    		<div class="col col-md-5 col-left detail">
			    <h1 class="scrollflow -slide-bottom -opacity">关于服务</h1>
		      <div class="scrollflow -slide-top -opacity desc">			    
			    	<p>官方正版&永久更新.所有正版用户均可享受程序永久更新服务,后台一键更新！</p>
			    </div>    				
		    </div>
		    <div class="col col-md-7 col-right">
		    	<img src="assets/images/responsive-web-design.png" class="scrollflow -pop -opacity img-responsive center" />
		    </div>         		    
      </div>
    </section>  
    
    
    
    <section id="section6" class="region region-6 align-center">
    	<div class="container">
		    <h1 class="scrollflow -pop -opacity">私人定制.</h1>
		    <div class="scrollflow -pop -opacity desc">		    
		    	<p>We create & craft websites that ooze practicality in every aspect. Our goal is to drive sales and attract new customers to your business.</p>
		    </div>                      
        <img src="assets/images/web-design-studio.png" class="scrollflow -slide-top -opacity img-responsive center" data-wow-delay=".5s" />                
      </div>
    </section>  

    
            
    
    <footer class="region blue-bg align-center">
    	<div class="container wow zoomIn">
		    <h1>现在加入我们吧?</h1>
		    <a class="btn" href="./user/login.php" >GO</a>                      
      </div>    	
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/layer/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="assets/js/jquery.min.js"><\/script>')</script>          
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>    
    <script src="assets/js/masonry.pkgd.min.js"></script>
    <script src="assets/js/eskju.jquery.scrollflow.min.js"></script>    
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.parallax.min.js"></script>
    <script src="assets/js/pace.min.js"></script>    
    <script src="assets/js/validator.js"></script>   
    <script src="assets/js/wow.min.js"></script>    
    <script src="assets/js/masonry.pkgd.min.js"></script>             
    <script src="assets/js/script.js"></script>
    

    
  </body>
</html>