<?php
include("../Includes/Common.php");
include("./Loginjs.php");
$newsid=md5(uniqid().rand(1,1000));
$db->query("update kuake_user set cookie='$newsid' where uid='{$userrow['uid']}'");
setcookie("kuake_sid", "", -1, '/');
header("Location:Login.php");
echo "<script type='text/javascript'>layer.alert('恭喜您：成功注销登陆!',{icon:6},function(){window.location.href='./Login.php'});</script>";
              exit();
/*
  *
 *Aladdin建站系统|作者QQ：79517721
  *
*/?>