<?php
?>
<footer class="footer text-right">
          <center>          2019 © <?=$config['footer']?></center>   
                </footer>
