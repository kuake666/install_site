<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------
include("../Includes/Common.php");
include("./Loginjs.php");
if ($_POST['do'] == 'reg'){
   session_start(); 
     
     $user = daddslashes($_POST['user']);
     $pwd = daddslashes($_POST['pwd']);
     $pwd1 = daddslashes($_POST['pwd1']);
     $qq = daddslashes($_POST['qq']);
    $code=daddslashes($_POST['code']);
     $uid = $_POST['inviteuid'];
    $email = daddslashes($_POST['email']);
	if (!$user or !$pwd or !$qq){
         echo "<script type='text/javascript'>layer.alert('客官，您的所有项不能为空！',{icon:5},function(){history.back(-1)});</script>";
              exit();
    
    }
	if (!preg_match('/^[a-zA-Z0-9]+$/',$user)) {		
		echo "<script type='text/javascript'>layer.alert('用户名只能为英文或数字！',{icon:5},function(){history.back(-1)});</script>";
        exit();
	}

    if ($pwd!=$pwd1){
        echo "<script type='text/javascript'>layer.alert('客官，您两次输入密码不一样！',{icon:5},function(){history.back(-1)});</script>";
              exit();
    }
  
    
    if ($db->get_row("SELECT * FROM kuake_user WHERE user='{$user}' ")){
         echo "<script type='text/javascript'>layer.alert('客官，您的用户名已存在！',{icon:5},function(){history.back(-1)});</script>";
          exit();
    }
    if ($db->get_row("SELECT * FROM kuake_user WHERE email='{$email}' ")){
         echo "<script type='text/javascript'>layer.alert('您好，邮箱已存在！',{icon:5},function(){history.back(-1)});</script>";
              exit();
    }
		if (strlen($qq) < 5 || !preg_match('/^[0-9]+$/',$qq)) {
		
		   echo "<script type='text/javascript'>layer.alert('QQ格式不正确！',{icon:5},function(){history.back(-1)});</script>";
           exit();
	}
    if(strlen($user) < '3'  ){
     echo "<script type='text/javascript'>layer.alert('客官，您的用户名长度过短！',{icon:5},function(){history.back(-1)});</script>";
              exit();
      
    }
  
   if(strlen($pwd) < '3'  ){
    echo "<script type='text/javascript'>layer.alert('客官，您的密码长度过短！',{icon:5},function(){history.back(-1)});</script>";
              exit();
      
    }
    if($config['codeactive']==1){
        if(!$code || strtolower($_SESSION['mulin_code'])!=strtolower($code)){
        echo "<script type='text/javascript'>layer.alert('客官，您的验证码错误！',{icon:5},function(){history.back(-1)});</script>";
              exit();
        }
    }
         $userrow = $db->get_row("SELECT * FROM kuake_user WHERE uid =  '{$uid}' LIMIT 1");

        $pwd = md5($pwd);
    
        $date= date("YmdHis");
    
  if ($uid=='' or $userrow=='' ){  
          $adduser="无邀请人"; 
     }
     
  else{  
    
      $adduser=$userrow['user'];
     
    
    }
if($config['give']==1){//开启注册奖励
  $money=$config['givemoney'];
}else{
$money="0.00";
}
  if ($db->query("INSERT INTO `kuake_user` (`user`, `adduser`, `pwd`, `cookie`, `qq`,`email`, `active`, `zcip`, `zctime`, `money`) VALUES ('{$user}','{$adduser}','{$pwd}',NULL,'{$qq}','{$email}',1,'{$clientip}','{$date}','{$money}')")){
         
    
    if($config['give']==1){//开启注册奖励，将奖励金额写入充值记录
                  $money=$config['givemoney'];
                  $order = date("YmdHis") . rand(111, 999);
                  $name="注册奖励";
                  $type="reg";
      $reg = $db->get_row("SELECT * FROM kuake_user WHERE user =  '{$user}' LIMIT 1");
      
     $db->query("INSERT INTO `kuake_order` (`order_no`, `name`, `user`, `peie`, `date`, `type`, `state`) VALUES ('".$order."','".$name."','".$reg['uid']."','".$money."','".$date."','".$type."','1')");

    
    }
    
     echo "<script type='text/javascript'>layer.alert('恭喜您：注册成功！',{icon:6},function(){window.location.href='./Login.php'});</script>";
              exit();
      
}else{
     echo "<script type='text/javascript'>layer.alert('很遗憾:注册失败,请稍后再试！',{icon:5},function(){history.back(-1)});</script>";
              exit();
    }
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="assets/images/favicon_1.ico">

        <title><?php echo $config['title']?><?php echo $config['titles']?></title>

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/core.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/components.css" rel="stylesheet" type="text/css">
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css">
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css">
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css">

        <script src="assets/js/modernizr.min.js"></script>


        
    </head>
    <body   onLoad="createCode()">


        <div class="wrapper-page">
            <div class="panel panel-color panel-primary panel-pages">
                <div class="panel-heading bg-img"> 
                    <div class="bg-overlay"></div>
                   <h3 class="text-center m-t-10 text-white">注册用户 </h3>
                </div> 


                <div class="panel-body">
                <form class="form-horizontal m-t-20" action="Reg.php" method="post"> 
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control input-lg"    name="qq" onkeyup="this.value=this.value.replace(/\D/g,'')"   type="text" required="" placeholder="用户QQ">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control input-lg" name="email"  type="email"   placeholder="用户邮箱" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control input-lg" name="user"  type="text" required="" placeholder="用户名字,至少包含3个字符">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control input-lg" name="pwd"  type="password" required="" placeholder="用户密码,尽量复杂些">
                        </div>
                    </div>
                    <input class="form-control"   type="hidden"  onkeyup="this.value=this.value.replace(/\D/g,'')"   name="inviteuid" value="<?php echo $_GET['uid']?>"/> 

                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control input-lg" name="pwd1"  type="password" required="" placeholder="再次输入密码">
                        </div>
                    </div>
                  
                   <div class="form-group  ">
                   <?php if($config['codeactive']==1){ ?>
                <div class="col-xs-7">
                  
        <input type="text" class="form-control input-lg"   name="code" onkeyup="this.value=this.value.replace(/\D/g,'')" maxlength="4" placeholder="输入验证码" autocomplete="off" required/>   </div> 
        <span style="padding: 0">
        <img src="./Code.php"height="43"onclick="this.src='./Code.php?r='+Math.random();" title="点击更换验证码" > 
                  </span><?php }?> 
              </div>
                  
                     <div class="form-group row mb-0">
                                <div class="col-sm-6 push">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="signup-terms" name="signup-terms">
                                        <label class="custom-control-label" for="signup-terms"><a href="#" data-toggle="modal" data-target="#modal-terms">我已阅读条款和条件</a></label>
                                    </div>
                                </div>
                       <input type="hidden" name="do" value="reg" /> 
                    <div class="form-group text-center m-t-40">
                        <div class="col-xs-12">
                            <button class="btn btn-primary waves-effect waves-light btn-lg w-lg"   id="embed-submit" type="submit">立即注册</button>
                        </div>
                    </div>

                    <div class="form-group m-t-30">
                        <div class="col-sm-12 text-center">
                            <a href="Login.php">已经有账户?点我登陆</a>
                        </div>
                    </div>
                </form> 
                </div>                                 
                
            </div>
        </div>

  

  
  
  
  <div class="modal fade" id="modal-terms" tabindex="-1" role="dialog" aria-labelledby="modal-terms" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-slidedown" role="document">
        <div class="modal-content">
            <div class="block block-themed block-transparent mb-0">
                <div class="block-header bg-primary-dark">
                    <h3 class="block-title">条款和条件</h3>
                    <div class="block-options">
                        
                     
                    </div>
                </div>
                <div class="block-content">
<?php echo $config['terms'];?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-alt-secondary" onclick="PausePlay()" data-dismiss="modal">关闭</button>
                <a onclick="TermsChecked();PausePlay()"><button type="button" class="btn btn-alt-success" data-dismiss="modal">
                    <i class="fa fa-check"></i> 阅读完毕
                </button></a>
            </div>
        </div>
    </div>
</div>
<script src="assets/js/codebase.min-2.1.js"></script><script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="assets/js/gt.js"></script>
<script>
var audio=document.createElement('audio');  
var play = function (s) {
    var URL = 'https://fanyi.baidu.com/gettts?lan=zh&text=' + encodeURIComponent(s) + '&spd=5&source=web'

    if(!audio){
        audio.controls = false  
        audio.src = URL 
        document.body.appendChild(audio)  
    }
    audio.src = URL  
    audio.play();
}
function TermsPlay(){
    play('条款和条件内容如下：<?php echo $config['terms'];?>');
    document.getElementById("Terms-Play").className="si si-volume-off";
}
function PausePlay(){
    audio.pause();
}
</script>
<script>
    var handlerEmbed = function (captchaObj) {
        $("#embed-submit").click(function (e) {
            var validate = captchaObj.getValidate();
            if (!validate) {
                $("#notice")[0].className = "show";
              play('请先完成验证');
                setTimeout(function () {
                    $("#notice")[0].className = "hide";
                }, 2000);
                e.preventDefault();
            }
        });
        // 将验证码加到id为captcha的元素里，同时会有三个input的值：geetest_challenge, geetest_validate, geetest_seccode
        captchaObj.appendTo("#embed-captcha");
        captchaObj.onReady(function () {
            $("#wait")[0].className = "hide";
        });
        // 更多接口参考：http://www.geetest.com/install/sections/idx-client-sdk.html
    };
    $.ajax({
        // 获取id，challenge，success（是否启用failback）
        url: "../GeektestCaptcha.php?act=reg&t=" + (new Date()).getTime(), // 加随机数防止缓存
        type: "get",
        dataType: "json",
        success: function (data) {
            console.log(data);
            // 使用initGeetest接口
            // 参数1：配置参数
            // 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
            initGeetest({
                gt: data.gt,
                https: true,
                width: '100%',
                challenge: data.challenge,
                new_captcha: data.new_captcha,
                product: "popup", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
                offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
                // 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
            }, handlerEmbed);
        }
    });
</script>
<script type="text/javascript">
function TermsChecked(){
    document.getElementById("signup-terms").checked=true;
}
</script>
<script src="assets/js/pages/op_auth_signup.js"></script><br />
  


<script src="assets/js/codebase.min-2.1.js"></script><script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="assets/js/gt.js"></script>

  
        <script>
            var resizefunc = [];
        </script>

        <!-- Main  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>

        <script src="assets/js/jquery.app.js"></script>
    
    </body>
</html>


<?php

/*
  *
 *Aladdin建站系统|作者QQ：79517721
  *
*/
?>
  