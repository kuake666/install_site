<?php
require_once("../Includes/Common.php");
?>
<aside id="side-overlay">
<div id="side-overlay-scroll">
<div class="content-header content-header-fullrow">
<div class="content-header-section align-parent">
<button type="button" class="btn btn-circle btn-dual-secondary align-v-r" data-toggle="layout" data-action="side_overlay_close">
<i class="fa fa-times text-danger"></i>
</button>
<div class="content-header-item">
<a class="img-link mr-5">
<img class="img-avatar img-avatar32" src="//q1.qlogo.cn/g?b=qq&s=100&nk=<?php echo $userrow['qq'];?>" alt="<?php echo $userrow['qq'];?>">
</a>
<a class="align-middle link-effect text-primary-dark font-w600"><?php echo $userrow['username'];?></a>
</div>
</div>
</div>
<div class="content-side">
<div class="block pull-r-l">
<div class="block-content block-content-full block-content-sm bg-body-light">
<div class="row">
<div class="col-6">
<div class="font-size-sm font-w600 text-uppercase text-muted">版本号</div>
<div class="font-size-h4">v<?php echo VER;?></a> </div>
</div>
<div class="col-6">
<div class="font-size-sm font-w600 text-uppercase text-muted">服务器</div>
<div class="font-size-h4">正常</div>
</div>
</div>
</div>
</div>
<div class="block pull-r-l">
<div class="block-header bg-body-light">
<h3 class="block-title"><i class="fa fa-fw fa-users font-size-default mr-5"></i>站点客服</h3>
<div class="block-options">
<button type="button" class="btn-block-option" data-toggle="block-option" data-action="state_toggle" data-action-mode="demo">
<i class="si si-refresh"></i>
</button>
<button type="button" class="btn-block-option" data-toggle="block-option" data-action="content_toggle"></button>
</div>
</div>
<div class="block-content">
<ul class="nav-users push">
<li>
<a href="#">
<img class="img-avatar" src="//q1.qlogo.cn/g?b=qq&s=100&nk=<?php echo $config['kfqq']?>" alt="<?php echo $config['kfqq']?>">
<i class="fa fa-circle text-success"></i> 站长
<div class="font-w400 font-size-xs text-muted">系统负责人</div>
</a>
</li>

<li>
<a href="#">
<img class="img-avatar" src="//q1.qlogo.cn/g?b=qq&s=100&nk=10000" alt="10000">
<i class="fa fa-circle text-danger"></i> 虚以待位
<div class="font-w400 font-size-xs text-muted">虚以待位</div>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</aside>
