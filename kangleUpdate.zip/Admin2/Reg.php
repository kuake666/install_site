<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------


include("../Includes/Common.php");
include("./Loginjs.php");
if ($_POST['do'] == 'reg'){
   session_start(); 
     
     $user = daddslashes($_POST['user']);
     $pwd = daddslashes($_POST['pwd']);
     $pwd1 = daddslashes($_POST['pwd1']);
     $qq = daddslashes($_POST['qq']);
    $code=daddslashes($_POST['code']);
     $uid = $_POST['inviteuid'];
    $email = daddslashes($_POST['email']);
	if (!$user or !$pwd or !$qq){
         echo "<script type='text/javascript'>layer.alert('客官，您的所有项不能为空！',{icon:5},function(){history.back(-1)});</script>";
              exit();
    
    }
	if (!preg_match('/^[a-zA-Z0-9]+$/',$user)) {		
		 echo "<script type='text/javascript'>layer.alert('用户名只能为英文或数字！',{icon:5},function(){history.back(-1)});</script>";
              exit();
	}

    if ($pwd!=$pwd1){
        echo "<script type='text/javascript'>layer.alert('客官，您两次输入密码不一样！',{icon:5},function(){history.back(-1)});</script>";
              exit();
    }
  

    if ($db->get_row("SELECT * FROM kuake_user WHERE user='{$user}' ")){
         echo "<script type='text/javascript'>layer.alert('客官，您的用户名已存在！',{icon:5},function(){history.back(-1)});</script>";
          exit();
    }
    if ($db->get_row("SELECT * FROM kuake_user WHERE email='{$email}' ")){
         echo "<script type='text/javascript'>layer.alert('您好，邮箱已存在！',{icon:5},function(){history.back(-1)});</script>";
              exit();
    }
	
	if (strlen($qq) < 5 || !preg_match('/^[0-9]+$/',$qq)) {
		
		   echo "<script type='text/javascript'>layer.alert('QQ格式不正确！',{icon:5},function(){history.back(-1)});</script>";
           exit();
	}
	
    if(strlen($user) < '3'  ){
     echo "<script type='text/javascript'>layer.alert('客官，您的用户名长度过短！',{icon:5},function(){history.back(-1)});</script>";
              exit();
      
    }
  
   if(strlen($pwd) < '3'  ){
    echo "<script type='text/javascript'>layer.alert('客官，您的密码长度过短！',{icon:5},function(){history.back(-1)});</script>";
              exit();
      
    }
    if($config['codeactive']==1){
        if(!$code || strtolower($_SESSION['mulin_code'])!=strtolower($code)){
        echo "<script type='text/javascript'>layer.alert('客官，您的验证码错误！',{icon:5},function(){history.back(-1)});</script>";
              exit();
        }
    }
         $userrow = $db->get_row("SELECT * FROM kuake_user WHERE uid =  '{$uid}' LIMIT 1");

        $pwd = md5($pwd);
    
        $date= date("YmdHis");
    
  if ($uid=='' or $userrow=='' ){  
          $adduser="无邀请人"; 
     }
     
  else{  
    
      $adduser=$userrow['user'];
     
    
    }
if($config['give']==1){//开启注册奖励
  $money=$config['givemoney'];
}else{
$money="0.00";
}
  if ($db->query("INSERT INTO `kuake_user` (`user`, `adduser`, `pwd`, `cookie`, `qq`,`email`, `active`, `zcip`, `zctime`, `money`) VALUES ('{$user}','{$adduser}','{$pwd}',NULL,'{$qq}','{$email}',1,'{$clientip}','{$date}','{$money}')")){
         
    
    if($config['give']==1){//开启注册奖励，将奖励金额写入充值记录
                  $money=$config['givemoney'];
                  $order = date("YmdHis") . rand(111, 999);
                  $name="注册奖励";
                  $type="reg";
      $reg = $db->get_row("SELECT * FROM kuake_user WHERE user =  '{$user}' LIMIT 1");
      
     $db->query("INSERT INTO `kuake_order` (`order_no`, `name`, `user`, `peie`, `date`, `type`, `state`) VALUES ('".$order."','".$name."','".$reg['uid']."','".$money."','".$date."','".$type."','1')");

    
    }
    
     echo "<script type='text/javascript'>layer.alert('恭喜您：注册成功！',{icon:6},function(){window.location.href='./Login.php'});</script>";
              exit();
      
}else{
     echo "<script type='text/javascript'>layer.alert('很遗憾:注册失败,请稍后再试！',{icon:5},function(){history.back(-1)});</script>";
              exit();
    }
}

?>
<!doctype html>
<!--[if lte IE 9]>     <html lang="zh-cn" class="no-focus lt-ie10 lt-ie10-msg"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="zh-cn" class="no-focus"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>建站系统-注册账号</title>
        <link rel="shortcut icon" href="../assets/aladdinlogo/favicon.ico">
        <link rel="icon" type="image/png" sizes="192x192"  href="../assets/aladdinlogo/favicon.ico">
        <link rel="apple-touch-icon" sizes="180x180" href="assets/media/favicons/apple-touch-icon-180x180.png">
        <link rel="stylesheet" id="css-main" href="assets/css/codebase.min-2.1.css">
        <style>
        	.show {
        		display: block;
        		}
        	.hide {
        		display: none;
        		}
        	#notice {
        		color: red;
        		}
        </style>
    </head>
<body><div id="page-container" class="main-content-boxed">
                <main id="main-container">
<div class="bg-body-dark bg-pattern" style="background-image: url('assets/media/various/bg-pattern-inverse.png');">
    <div class="row mx-0 justify-content-center">
        <div class="hero-static col-lg-6 col-xl-4">
            <div class="content content-full overflow-hidden">
                <div class="py-30 text-center">
                    <a class="link-effect font-w700" href="index.php">
                        <i class="si si-fire"></i>
                        <span class="font-size-xl text-primary-dark">建站系统</span><span class="font-size-xl">控制台</span>
                    </a>
                </div>
                <form class="js-validation-signup" action="" method="post">
                    <div class="block block-themed block-rounded block-shadow">
                        <div class="block-header bg-gd-emerald">
                            <h3 class="block-title">请填写注册信息</h3>
                            <div class="block-options">
                                <button type="button" class="btn-block-option">
                                    <i class="si si-wrench"></i>
                                </button>
                            </div>
                        </div>
                        <div class="block-content">
                            <div class="form-group row">
                                <div class="col-12">
                                    <label for="signup-username">用户名</label>
                                    <input type="text" class="form-control" id="signup-username" name="user"  required="" placeholder="用户名字,至少包含3个字符">
                                </div>
                            </div>
                           
                            <div class="form-group row">
                                <div class="col-12">
                                    <label for="signup-qq">QQ</label>
                                    <input type="text" class="form-control" name="qq" onkeyup="this.value=this.value.replace(/\D/g,'')"    required="" placeholder="用户QQ">
                                </div>
                            </div>
                           <div class="form-group row">
                                <div class="col-12">
                                    <label for="signup-qq">邮箱</label>
                                    <input  class="form-control" name="email"  type="email" required="" placeholder="用户邮箱">
                                </div>
                            </div>
                           
                            <div class="form-group row">
                                <div class="col-12">
                                    <label for="signup-password">密码</label>
                                    <input type="password" class="form-control" id="signup-password" name="pwd" required="" placeholder="用户密码,尽量复杂些">
                                </div>
                            </div>
                         

                            <div class="form-group row">
                                <div class="col-12">
                                    <label for="signup-password-confirm">再次输入密码</label>
                                    <input type="password" class="form-control" id="signup-password-confirm" name="pwd1" required=""placeholder="重复输入密码">
                                </div>
                            </div>
							<input class="form-control"   type="hidden"  onkeyup="this.value=this.value.replace(/\D/g,'')"   name="inviteuid" value="<?php echo $_GET['uid'];?>"/> 
                            
                              <div class="form-group  row">
				   <?php if($config['codeactive']==1){ ?>
                <div class="col-7">
             
        <input type="text" class="form-control "   name="code" onkeyup="this.value=this.value.replace(/\D/g,'')" maxlength="4" placeholder="输入验证码" autocomplete="off" required/>   </div> 
 		<span style="padding: 0">
		<img src="./Code.php"height="42"onclick="this.src='./Code.php?r='+Math.random();" title="点击更换验证码" > 
                  </span><?php }?> 
              </div>
                            <div class="form-group row mb-0">
                                <div class="col-sm-6 push">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="signup-terms" name="signup-terms">
                                        <label class="custom-control-label" for="signup-terms"><a href="#" data-toggle="modal" data-target="#modal-terms">我已阅读条款和条件</a></label>
                                    </div>
                                </div>
								 <input type="hidden" name="do" value="reg" /> 
                                <div class="col-sm-6 text-sm-right push">
                                    <button type="submit" id="embed-submit" name="submit" class="btn btn-alt-success">
                                        <i class="fa fa-user-plus mr-10"></i> 立即注册
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="block-content bg-body-light">
                            <div class="form-group text-center">
                            	<!-- 弹框
                                <a class="link-effect text-muted mr-10 mb-5 d-inline-block" href="#" data-toggle="modal" data-target="#modal-terms">
                                    <i class="fa fa-book text-muted mr-5"></i> 阅读条款和条件
                                </a>-->
                                <a class="link-effect text-muted mr-10 mb-5 d-inline-block" href="Login.php">
                                    <i class="fa fa-user text-muted mr-5"></i> 登录
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    </main>
    </div>
<div class="modal fade" id="modal-terms" tabindex="-1" role="dialog" aria-labelledby="modal-terms" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-slidedown" role="document">
        <div class="modal-content">
            <div class="block block-themed block-transparent mb-0">
                <div class="block-header bg-primary-dark">
                    <h3 class="block-title">条款和条件 </h3>
                    <div class="block-options">
                        <button type="button" class="btn-block-option" id="TermsPausePlay" onclick="TermsPlay()" title="语音朗读">
                            <i id="Terms-Play" class="si si-volume-2"></i>
                        </button>
                      <button type="button" class="btn-block-option" data-dismiss="modal" aria-label="Close">
                            <i class="si si-close"></i>
                        </button>
                    </div>
                </div>
                <div class="block-content">
<?php echo $config['terms'];?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-alt-secondary" onclick="PausePlay()" data-dismiss="modal">关闭</button>
                <a onclick="TermsChecked();PausePlay()"><button type="button" class="btn btn-alt-success" data-dismiss="modal">
                    <i class="fa fa-check"></i> 阅读完毕
                </button></a>
            </div>
        </div>
    </div>
</div>
<script src="assets/js/codebase.min-2.1.js"></script><script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="assets/js/gt.js"></script>
<script>
var audio=document.createElement('audio');  
var play = function (s) {
    var URL = 'https://fanyi.baidu.com/gettts?lan=zh&text=' + encodeURIComponent(s) + '&spd=5&source=web'

    if(!audio){
        audio.controls = false  
        audio.src = URL 
        document.body.appendChild(audio)  
    }
    audio.src = URL  
    audio.play();
}
function TermsPlay(){
	play('条款和条件内容如下：<?php echo $config['terms'];?>');
	document.getElementById("Terms-Play").className="si si-volume-off";
}
function PausePlay(){
	audio.pause();
}
</script>

<script type="text/javascript">
function TermsChecked(){
	document.getElementById("signup-terms").checked=true;
}
</script>
<script src="assets/js/pages/op_auth_signup.js"></script><br />
</body>
</html>