
<?php
// +----------------------------------------------------------------------
// | Quotes [未来可期]
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | Author: 阿拉丁建站系统 作者QQ：79517721
// +----------------------------------------------------------------------
// | Date: 2019年1月11日
// +----------------------------------------------------------------------


include("../Includes/Common.php");
include("./Loginjs.php");
if ($_POST['do'] == 'login') {
 session_start(); 
    if ($_POST['username']=='' or $_POST['password']==''){
        echo "<script type='text/javascript'>layer.alert('账号或密码不能为空',{icon:5},function(){history.back(-1)});</script>";
                exit();
    }else{
        $user = daddslashes($_POST['username']);
        $pwd = daddslashes($_POST['password']);
       
        
        $pwd = md5($pwd);
        if($row=$db->get_row("SELECT * FROM kuake_user WHERE user='$user' and pwd='$pwd' LIMIT 1")) {
            $sid=md5(uniqid().rand(1,1000));
            $db->query("UPDATE kuake_user SET cookie='$sid' WHERE uid='".$row['uid']."'");
            setcookie("kuake_sid",$sid,time()+3600*12,'/');
            $userrow=$db->get_row("SELECT * FROM kuake_user WHERE uid='".$row['uid']."' LIMIT 1");
        
       //   exit("<script language='javascript'>alert('登录成功!');window.location.href='index.php';</script>");
         echo "<script type='text/javascript'>layer.msg('恭喜您：登录成功!',{icon:6},function(){window.location.href='./index.php'});</script>";
              exit();
        }else{
            echo "<script type='text/javascript'>layer.msg('账号或密码错误',{icon:5},function(){history.back(-1)});</script>";
                exit();
        }
    }
}else if(isset($_GET['logout'])){
    $newsid=md5(uniqid().rand(1,1000));
    $db->query("update kuake_user set cookie='$newsid' where uid='{$userrow['uid']}'");
    setcookie("kuake_sid", "", time() - 3600*12,'/');
    $sql = $db->query("SELECT `value` FROM kuake_config WHERE vkey='admintemplate'" );
    $row1 = $db->fetch($sql);
    $custom_template = $template_type[$row1['value']];
   echo "<script type='text/javascript'>layer.msg('恭喜您：成功注销登陆!',{icon:6},function(){window.location.href='./Login.php'});</script>";
              exit();
}else if($islogin==1){
  echo "<script type='text/javascript'>layer.msg('您已成功登陆',{icon:6},function(){window.location.href='./index.php'});</script>";
                exit();
}
?>
<!doctype html>
<!--[if lte IE 9]>     <html lang="zh-cn" class="no-focus lt-ie10 lt-ie10-msg"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="zh-cn" class="no-focus"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title><?php echo $config['title']?>-登录用户中心</title>
        <meta name="description" content="一键建站系统">
        <meta name="keyword" content="一键建站系统">
         <link rel="shortcut icon" href="assets/aladdinlogo/favicon.ico">
        <link rel="icon" type="image/png" sizes="192x192"  href="../assets/aladdinlogo/favicon.ico">
        <link rel="apple-touch-icon" sizes="180x180" href="assets/media/favicons/apple-touch-icon-180x180.png">
    <link rel="stylesheet" id="css-main" href="assets/css/codebase.min-2.1.css">
    </head>
<body><div id="page-container" class="main-content-boxed">
                <main id="main-container">
<div class="bg-body-dark bg-pattern" style="background-image: url('assets/media/various/bg-pattern-inverse.png');">
    <div class="row mx-0 justify-content-center">
        <div class="hero-static col-lg-6 col-xl-4">
            <div class="content content-full overflow-hidden">
                <div class="py-30 text-center">
                    <a class="link-effect font-w700" href="index.php">
                        <i class="si si-fire"></i>
                        <span class="font-size-xl text-primary-dark"><?php echo $config['title']?></span><span class="font-size-xl">控制台</span>
                    </a>
                </div>
                <form class="js-validation-signin" action="Login.php" method="post">
				
					 <input type="hidden"  name="do" value="login"/> 
                    <div class="block block-themed block-rounded block-shadow">
                        <div class="block-header bg-gd-dusk">
                            <h3 class="block-title">使用你的账户登录用户中心</h3>
                            <div class="block-options">
                                <button type="button" class="btn-block-option">
                                    <a title="刷新" onclick="document.cookie='cf_use_ob=0;path=/';window.location.reload();return false;"><i class="si si-refresh"></i></a>
                                </button>
                            </div>
                        </div>
                        <div class="block-content">
                            <div class="form-group row">
                                <div class="col-12">
                                    <label for="login-username">用户名</label>
                                    <input type="text" class="form-control" id="login-username"  name="username">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-12">
                                    <label for="login-password">用户密码</label>
                                    <input type="password" class="form-control" id="login-password" name="password" >
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-sm-6 d-sm-flex align-items-center push">
                                    <div class="custom-control custom-checkbox mr-auto ml-0 mb-0">
                                        <input type="checkbox" class="custom-control-input" id="login-remember-me" name="ispersis">
                                        <label class="custom-control-label" for="login-remember-me">记住我(7天免登录)</label>
                                    </div>
                                </div>
                                <div class="col-sm-6 text-sm-right push">
                                    <button type="submit" name="login" class="btn btn-alt-primary">
                                        <i class="si si-login mr-10"></i> 立即登录
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="block-content bg-body-light">
                            <div class="form-group text-center">
                                <a class="link-effect text-muted mr-10 mb-5 d-inline-block" href="Reg.php">
                                    <i class="fa fa-plus mr-5"></i> 立即注册
                                </a>
                                <a class="link-effect text-muted mr-10 mb-5 d-inline-block"  href="FindPwd.php">
                                    <i class="fa fa-warning mr-5"></i> 找回密码
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    </main>
    </div>
<script src="assets/js/codebase.min-2.1.js"></script><script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="assets/js/pages/op_auth_signin.js"></script>
</body>
</html>